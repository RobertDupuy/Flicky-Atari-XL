"""Compare original gameplay against both native compatibility paths.

Seed at the same HALT boundary to isolate CPU semantics from the still evolving
video/interrupt scheduler. Pixel collision hardware is deliberately disabled in
both sides here; its separate tests must not be conflated with this CPU test.
"""
import ctypes as C,sys
import numpy as np
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from run_reference import Reference
from run_native import Native

@pytest.mark.parametrize('compact',[False,True])
def test_seeded_gameplay(compact):
    r=Reference();n=Native(compact)
    r.lib.fm_collisions(0)
    r.lib.fm_registers.restype=C.POINTER(C.c_uint16)
    for f in range(400):r.frame(255,254 if 180<=f<190 else 239 if 210<=f<220 else 255)
    r.lib.fm_until_halt(255,255);n.run()
    n.memory[0xc000:0xd000]=r.ram[0xc000:0xd000]
    n.memory[0x7000:0x7800]=r.ram[0xd000:0xd800]
    n.memory[0xd800:0xf000]=r.ram[0xd800:0xf000]
    registers=list(r.lib.fm_registers()[:12])
    for i,key in enumerate(['f','c','e','l','ix','iy','sp','pc']):
        a=n.labels['z_'+key];n.memory[a]=registers[i]&255;n.memory[a+1]=registers[i]>>8
    for i,offset in [(8,6),(9,0),(10,2),(11,4)]:
        a=n.labels['z_alt']+offset;n.memory[a]=registers[i]&255;n.memory[a+1]=registers[i]>>8
    n.memory[n.labels['z_iff']]=1
    for f in range(300):
        p1=255 if f<100 else 191 if f<200 else 123
        n.resume(p1,255);r.lib.fm_until_halt(p1,255)
        # The unused stack below SP contains interrupt-timing-dependent debris.
        np.testing.assert_array_equal(n.memory[0xc000:0xcf80],r.ram[0xc000:0xcf80],err_msg=f'update {f}')
        np.testing.assert_array_equal(n.memory[0x7000:0x7800],r.ram[0xd000:0xd800],err_msg=f'sprite upload {f}')
        np.testing.assert_array_equal(n.memory[0xd800:0xf000],r.ram[0xd800:0xf000],err_msg=f'palette/tile RAM {f}')
