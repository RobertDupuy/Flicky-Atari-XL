"""Rebuild both delivered cartridges from the source ZIP without private ROMs."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from build import ROOT,executable

def main():
    clean=Path(tempfile.mkdtemp(prefix='flicky-release-rebuild-',dir=ROOT.parent))
    with zipfile.ZipFile(ROOT/'release/Flicky-Prepared-Game-Source.zip') as z:
        assert not any('/private-roms/' in x or '/mame-roms/' in x for x in z.namelist())
        z.extractall(clean)
    project=clean/'Flicky-Prepared-Game'
    env=os.environ.copy();env.pop('FLICKY_BENCHMARK',None)
    env['CA65']=executable('ca65');env['LD65']=executable('ld65')
    with (clean/'rebuild.log').open('w') as log:
        subprocess.run([sys.executable,'tools/build_variants.py'],cwd=project,env=env,stdout=log,stderr=log,check=True)
    report=[]
    for mode in ('NTSC','PAL'):
        name=f'Flicky-Atari-XL-{mode}-512K.car'
        actual=(project/'release'/name).read_bytes();expected=(ROOT/'release'/name).read_bytes()
        assert actual==expected,name
        report.append(dict(file=name,byte_identical=True,sha256=hashlib.sha256(actual).hexdigest(),
                           bytes=len(actual),original_rom_inputs_required=False))
    env['FLICKY_VARIANT']='pal'
    with (clean/'tests.log').open('w') as log:
        subprocess.run([sys.executable,'-m','pytest','tests/test_arcade_bonus.py','tests/test_presentation_audio.py','tests/test_bonus_jump_visibility.py','-q'],cwd=project,env=env,stdout=log,stderr=log,check=True)
    (ROOT/'evidence/clean-variants-rebuild.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(directory=str(clean),variants=report,tests=(clean/'tests.log').read_text()),indent=2))

if __name__=='__main__':main()
