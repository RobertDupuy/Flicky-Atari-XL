#!/usr/bin/env python3
"""Headless visual smoke test in Atari800, using its bundled Altirra OS.

Run on Linux with Atari800, Xvfb, python-xlib, and Pillow installed.
Runs both processes together (works in an isolated network namespace).
Saves actual emulator screenshots; does not fabricate the Atari display.
"""
import os, re, subprocess, time
from pathlib import Path
from Xlib import X, XK, display
from Xlib.ext import xtest
from PIL import Image
from build import ROOT, BUILD, executable

def main():
    env=os.environ.copy()
    local=ROOT.parent/'toolchain/root/usr/lib/x86_64-linux-gnu'
    env['LD_LIBRARY_PATH']=str(local)+':'+env.get('LD_LIBRARY_PATH','')
    env['DISPLAY']='127.0.0.1:101'
    env['SDL_VIDEODRIVER']='x11'
    BUILD.mkdir(exist_ok=True)
    with (BUILD/'xvfb.log').open('w') as log:
        xvfb=subprocess.Popen([executable('Xvfb'),':101','-screen','0','900x700x24','-ac','-nolisten','unix','-nolisten','local','-listen','tcp'],env=env,stdout=log,stderr=log)
        try:
            time.sleep(1)
            x=display.Display(env['DISPLAY'])
            for standard in ['ntsc','pal']:
                with (BUILD/f'emulator-{standard}.log').open('w') as log:
                    emu=subprocess.Popen([executable('atari800'),'-config',str(BUILD/'atari800.cfg'),'-xl','-xl-rev','altirra','-nobasic','-'+standard,'-nosound','-windowed','-no-video-accel','-stretch','2','-cart',str(BUILD/'flicky-xl-stage1.car')],env=env,stdin=subprocess.PIPE,stdout=log,stderr=log)
                    try:
                        time.sleep(3)
                        assert emu.poll() is None, 'Emulator failed; see emulator log'
                        windows=[w for w in x.screen().root.query_tree().children if 'Atari' in (w.get_wm_name() or '')]
                        assert windows,'No Atari window'
                        window=windows[0]
                        window.set_input_focus(X.RevertToParent,X.CurrentTime)
                        x.sync()
                        def capture(suffix):
                            geo=window.get_geometry()
                            data=window.get_image(0,0,geo.width,geo.height,X.ZPixmap,0xffffffff)
                            im=Image.frombytes('RGB',(geo.width,geo.height),data.data,'raw','BGRX')
                            im.save(BUILD/f'emulator-{standard}-{suffix}.png')
                            assert len(im.getcolors())==5, 'Unexpected display colors'
                            if suffix in ('left','right'):
                                expected_x=80 if suffix=='left' else 576
                                marker_y=336 if standard=='ntsc' else 352
                                color=im.getpixel((expected_x+8,marker_y+8))
                                assert color==im.getpixel((500,280 if standard=='ntsc' else 296)), 'Marker did not reach held-input endpoint'
                                assert im.getpixel((expected_x-1,marker_y+8))!=color
                        capture('boot')
                        # Keyboard joystick defaults use numeric keypad 4 and 6.
                        for key,suffix in [('KP_4','left'),('KP_6','right')]:
                            code=x.keysym_to_keycode(XK.string_to_keysym(key))
                            xtest.fake_input(x,X.KeyPress,code)
                            x.sync()
                            time.sleep(1)
                            xtest.fake_input(x,X.KeyRelease,code)
                            x.sync()
                            time.sleep(.2)
                            capture(suffix)
                        # Enter built-in monitor and capture guest counters and host state.
                        code=x.keysym_to_keycode(XK.string_to_keysym('F8'))
                        xtest.fake_input(x,X.KeyPress,code)
                        x.sync()
                        time.sleep(.15)
                        xtest.fake_input(x,X.KeyRelease,code)
                        x.sync()
                        time.sleep(.3)
                        emu.stdin.write(b'm 0080\nm 3000\nm 2540\nquit\n')
                        emu.stdin.flush()
                        emu.wait(timeout=5)
                        log.flush()
                        dump=(BUILD/f'emulator-{standard}.log').read_text()
                        memory={}
                        for line in dump.splitlines():
                            match=re.match(r'^([0-9A-F]{4}): ((?:[0-9A-F]{2} ){15}[0-9A-F]{2})',line)
                            if match:
                                address=int(match[1],16)
                                memory.update({address+i:v for i,v in enumerate(bytes.fromhex(match[2]))})
                        assert memory.get(0x3001)==31 and memory.get(0x3003)==1
                        assert bytes(memory[0x255b+i] for i in range(4))==bytes(ord(c)-32 for c in 'PASS')
                        print(f'{standard}: cartridge booted; screenshots and monitor dump saved')
                    finally:
                        if emu.poll() is None:
                            emu.terminate()
                            emu.wait(timeout=5)
            x.close()
        finally:
            xvfb.terminate()
            xvfb.wait(timeout=5)

if __name__=='__main__': main()
