#!/usr/bin/env python3
"""Package the prepared native build without original executable ROM inputs."""
import hashlib,json,re,shutil,zipfile
from pathlib import Path
from build import ROOT,BUILD

def main():
    out=ROOT/'release';out.mkdir(exist_ok=True)
    files=set()
    for folder in ('src','tools','tests','vendor'):
        files.update(p for p in (ROOT/folder).rglob('*')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.c','.h','.s','.inc','.cfg','.lua'))
    for name in ('README.md','PREPARED_ENGINE.md','SG1000_STUDY.md','ARCADE_BONUS.md','THIRD_PARTY.md','requirements-dev.txt','LICENSE','.gitignore'):
        files.add(ROOT/name)
    files.add(BUILD/'sg1000-disassembly.txt')
    files.update(p for p in (BUILD/'sg-study').iterdir()if p.suffix in ('.txt','.json','.md'))
    native=BUILD/'native';seen=set()
    def source(path):
        if path in seen:return
        seen.add(path);files.add(path)
        for kind,name in re.findall(r'\.(include|incbin)\s+"([^"]+)"',path.read_text()):
            candidates=[path.parent/name,ROOT/'src/native'/name,native/name]
            target=next((p.resolve() for p in candidates if p.is_file()),None)
            if target is None:raise FileNotFoundError((path,name))
            if kind=='include':source(target)
            else:files.add(target)
    source(ROOT/'src/native/game.s')
    for kind in ('player','chick','cat'):
        files.add(native/f'{kind}-data.s')
        files.update(native.glob(f'{kind}-image-*.bin'))
    for kind in ('player','chick','cat','object'):files.add(native/f'{kind}-assets.json')
    files.add(native/'maps-reference.bin')
    for name in ('arcade-bonus-assets.json','arcade-bonus-font.bin','arcade-bonus-overlays.bin',
                 'arcade-bonus-golden.npz','arcade-bonus-collision-golden.npz'):
        files.add(native/name)
    files.add(native/'object-data.s')
    files.update(native.glob('object-pixels-*.bin'))
    for name in ('tile-index.bin','tile-glyphs.bin'):files.add(BUILD/name)
    files.update(p for p in (BUILD/'audio').iterdir()if p.suffix in ('.bin','.json','.npy'))
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True)
    evidence_names={'release.json','rounds.json','static-messages.json',
                    'maximum-load.json','raster-before.json','raster-after.json',
                    'clean-variants-rebuild.json','bonus-pal-movie.json'}
    for name in ('arcade-bonus-differential.json','arcade-bonus-collision.json','arcade-bonus-render.json'):
        shutil.copy2(native/name,evidence/name);evidence_names.add(name)
    for mode in ('ntsc','pal'):
        for name in ('verification.json','input-log.json'):
            dst=f'bonus-{mode}-{name}'
            shutil.copy2(BUILD/f'arcade-bonus/{mode}-realtime'/name,evidence/dst)
            evidence_names.add(dst)
    for src,dst in [(native/'round-acceptance.json','rounds.json'),
                    (native/'static-messages.json','static-messages.json')]:
        shutil.copy2(src,evidence/dst)
    shutil.copy2(native/'raster-before/result.json',evidence/'raster-before.json')
    cartridge=out/'Flicky-Prepared-Game.car'
    shutil.copy2(out/'Flicky-Atari-XL-NTSC-512K.car',cartridge)
    manifest={'cartridge':cartridge.name,'sha256':hashlib.sha256(cartridge.read_bytes()).hexdigest(),
        'bytes':cartridge.stat().st_size,'rom_bytes':524288,'mapper':'SIC! 512 KB','target_ram_bytes':65536,
        'original_executable_roms_included':False,'stress_fixture_in_playable_cartridge':False}
    manifest['variants']=json.loads((out/'variants.json').read_text())
    (evidence/'release.json').write_text(json.dumps(manifest,indent=2)+'\n')
    # These reports belong to the current 512 KB variants. Keep the earlier
    # baseline evidence separate from the acceptance data for this release.
    for mode in ('ntsc','pal'):
        for src,dst in [(native/f'tests-{mode}.xml',f'tests-{mode}.xml'),
                        (BUILD/f'variants/{mode}/render.json',f'render-{mode}.json'),
                        (native/f'{mode}-normal/timing.json',f'normal-{mode}.json')]:
            shutil.copy2(src,evidence/dst)
            evidence_names.add(dst)
    for src,dst in [('ntsc-one-stress','stress-ntsc-one'),('pal-three-stress','stress-pal-three'),('pal-six-stress','stress-pal-six')]:
        shutil.copy2(native/src/'timing.json',evidence/(dst+'.json'))
        evidence_names.add(dst+'.json')
    current={}
    for mode,source in [('ntsc','ntsc-one-stress'),('pal','pal-three-stress')]:
        current[mode]=json.loads((native/source/'timing.json').read_text())[mode]
    (evidence/'maximum-load.json').write_text(json.dumps(current,indent=2)+'\n')
    shutil.copy2(native/'raster-variants/result.json',evidence/'raster-after.json')
    files.update(evidence/name for name in evidence_names if (evidence/name).is_file())
    archive=out/'Flicky-Prepared-Game-Source.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(files):z.write(p,Path('Flicky-Prepared-Game')/p.relative_to(ROOT))
    print(json.dumps({'source_files':len(files),'source_zip_bytes':archive.stat().st_size,**manifest},indent=2))

if __name__=='__main__':main()
