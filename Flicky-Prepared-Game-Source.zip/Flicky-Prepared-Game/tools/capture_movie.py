#!/usr/bin/env python3
"""Record actual NTSC cartridge gameplay and POKEY sound, then encode an MP4."""
import argparse, time, subprocess, json
from pathlib import Path
from build import BUILD, ROOT
from raster_probe import Session

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seconds',type=float,default=45)
    ap.add_argument('--cartridge',type=Path,default=BUILD/'native/flicky-native-dev.car')
    ap.add_argument('--output',type=Path,default=ROOT/'release/Flicky-Atari-XL-45s.mp4')
    args=ap.parse_args();args.output=args.output.resolve();args.output.parent.mkdir(parents=True,exist_ok=True)
    out=BUILD/'native/movie';out.mkdir(exist_ok=True)
    (out/'capture.avi').unlink(missing_ok=True)
    s=Session(args.cartridge.resolve(),out.resolve(),'ntsc',sound=True)
    try:
        s.record();start=time.monotonic();last=-1;direction=None
        # Actual keyboard input, no game-state patches. Start on the title,
        # then vary direction and tap fire to jump and throw on the live engine.
        while time.monotonic()-start<args.seconds+4:
            t=time.monotonic()-start;phase=int(t*4)
            if phase!=last:
                s.key('Control_R',phase>=4 and phase%4==2)
                wanted=None if t<2 else ('Left' if 8<=t%18<11 else 'Right')
                if wanted!=direction:
                    if direction:s.key(direction,False)
                    if wanted:s.key(wanted,True)
                    direction=wanted
                if phase in (24,48,80,120,160):s.capture().save(out/f'frame-{phase//4:02d}.png')
                last=phase
            time.sleep(.008)
        s.key('Control_R',False)
        if direction:s.key(direction,False)
        s.record();time.sleep(1)
    finally:s.close()
    raw=out/'capture.avi'
    assert raw.is_file(),'Atari800 did not produce its recording'
    subprocess.run(['ffmpeg','-y','-v','warning','-i',str(raw),'-t',str(args.seconds),
        '-vf','scale=iw*3:ih*3:flags=neighbor,fps=60','-c:v','libx264','-preset','slow','-crf','17',
        '-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart',str(args.output)],check=True)
    data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(args.output)]))
    assert abs(float(data['format']['duration'])-args.seconds)<.05,data['format']
    assert any(s['codec_type']=='audio'for s in data['streams']),'Missing audio track'
    (out/'movie.json').write_text(json.dumps(data,indent=2)+'\n')
    print(args.output,flush=True)
if __name__=='__main__':main()
