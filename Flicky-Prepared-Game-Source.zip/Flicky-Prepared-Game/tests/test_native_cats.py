"""Native enemy behavior checked against independently executed source routines."""
import json
import random
import subprocess
import sys
from pathlib import Path
import pytest
import ctypes as C
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine
from native_oracle import Original
from run_reference import Reference

DESCRIPTORS=[0x67b2,0x67bb,0x67c4,0x67cd,0x67d6,0x67df,0x67e8,0x67f1,0x67fa,
             0x6803,0x680c,0x6815,0x681e,0x6827,0x6830,0x6839,0x6842,0x684b]
FIELDS=[('n_flags',0),('n_pause',6),('n_ylo',9),('n_yhi',10),('n_target',11),
        ('n_acceleration',12),('n_frame',13),('n_bob',16),('n_pose',17),
        ('n_vx',18),('n_fx',19),('n_vy',20),('n_fy',21),('n_timer',22),('n_cycle',23),
        ('n_chain',24),('n_draw_yoffset',25),('n_chick_state',26),('n_enemy_contact',27)]

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    engine=Engine()
    yield engine
    (BUILD/'native/cat-cycles.json').write_text(json.dumps(engine.maximum,indent=2)+'\n')

def word(n,name,value):
    n.set(name,value);n.set(name,value>>8,1)

def position(n,o,actor,world,screen,height,pose):
    a=0xc300+actor*32
    word(n,'n_world',world);o.ram[0xc01a:0xc01c]=[world&255,world>>8]
    p=(screen-world)&65535
    n.set('n_xlo',p,actor);n.set('n_xhi',p>>8,actor);n.set('n_ylo',height,actor)
    n.set('n_animation',pose,actor)
    o.ram[a+7:a+10]=[screen&255,screen>>8,height]
    o.ram[a+1:a+3]=[DESCRIPTORS[pose]&255,DESCRIPTORS[pose]>>8]
    o.ram[a+5]=actor
    return a

def test_native_cat_spawn_and_floor(native):
    o=Original();r=random.Random(0x6435)
    for trial in range(1024):
        native.call('native_reset');o.ram[:]=0
        tiles=bytearray(1792)
        for row in (8,14,22,27):
            for col in range(32):tiles[row*64+col*2+1]=16
        native.ram[0xc000:0xc700]=list(tiles);o.ram[0xe000:0xe700]=list(tiles)
        actor=9+trial%2;world=r.randrange(65536);screen=r.randrange(65536);height=r.randrange(16,160)
        a=position(native,o,actor,world,screen,height,12)
        for field,offset in FIELDS:
            value=r.randrange(256);native.set(field,value,actor);o.ram[a+offset]=value
        for field,address in [('n_round',0xc018),('n_difficulty',0xc004),('n_spawn_delay',0xc027)]:
            value=r.randrange(256);native.set(field,value);o.ram[address]=value
        word(native,'n_spawn_x',screen);native.set('n_spawn_y',height)
        o.call(0x6435,af=height<<8,hl=screen,ix=a)
        native.call('cat_spawn',x=actor)
        for field,offset in FIELDS:
            assert native.get(field,actor)==o.ram[a+offset],(trial,field,native.get(field,actor),o.ram[a+offset])
        assert native.get('n_animation',actor)==12
        actual=(native.get('n_xlo',actor)+(native.get('n_xhi',actor)<<8)+world)&65535
        assert actual==screen&511

def test_native_cat_door_locations_and_initial_state(native):
    o=Original();r=random.Random(0x2736)
    for stage in range(48):
        for actor in (9,10):
            native.call('native_reset');native.set('n_round',stage)
            native.call('level_load');o.ram[:]=0
            o.ram[0xe000:0xe700]=native.ram[0xc000:0xc700]
            world=r.randrange(65536);word(native,'n_world',world)
            o.ram[0xc01a:0xc01c]=[world&255,world>>8]
            o.ram[0xc014]=native.get('n_layout');o.ram[0xc018]=stage
            a=0xc300+actor*32;o.ram[a+5]=actor
            regs=o.call(0x2736,ix=a)
            o.call(0x6435,ix=a,af=regs[0],hl=regs[3])
            native.call('cat_spawn_door',x=actor)
            for field,offset in FIELDS:
                assert native.get(field,actor)==o.ram[a+offset],(stage,actor,field)
            actual=(native.get('n_xlo',actor)+(native.get('n_xhi',actor)<<8)+world)&65535
            assert actual==int(o.ram[a+7])+(int(o.ram[a+8])<<8)

def test_native_cat_directional_terrain(native):
    o=Original();r=random.Random(0x7172)
    for trial in range(4096):
        tiles=bytes(r.randrange(256) for _ in range(1792))
        native.ram[0xc000:0xc700]=list(tiles);o.ram[0xe000:0xe700]=list(tiles)
        actor=9+trial%2;world=r.randrange(65536);screen=r.randrange(65536)
        height=r.randrange(32,196);pose=r.randrange(18);mode=trial%4
        a=position(native,o,actor,world,screen,height,pose)
        result=o.call([0x7172,0x71a5,0x71d0,0x71fd][mode],af=1,ix=a)
        native.set('e_mode',mode);native.call('cat_sample_terrain',x=actor)
        assert native.get('e_mask')==(result[1]&255),(trial,mode,pose,screen,height,native.get('e_mask'),result)
        assert native.get('e_row')==((result[3]-0xe000)//64),(trial,mode,'row',result)

def test_native_cat_animation_timing_and_direction(native):
    o=Original();r=random.Random(0x7430)
    lists=[(0x6774,7),(0x6782,4),(0x678c,4),(0x6796,8),(0x67a6,3),(0x67ac,3)]
    for trial in range(4096):
        actor=9;kind=trial%6;table,count=lists[kind];index=r.randrange(count)
        a=position(native,o,actor,0,256,128,0)
        timer=r.randrange(0,5);delay=r.randrange(1,24);reverse=r.randrange(2)
        o.ram[a+16]=index;o.ram[a+22]=timer
        native.set('n_bob',index,actor);native.set('n_timer',timer,actor)
        for k,v in [('e_list',kind),('e_delay',delay),('e_length',count),('e_reverse',reverse)]:native.set(k,v)
        result=o.call(0x7430,af=reverse<<8,bc=delay<<8|count,hl=table,ix=a)
        native.call('cat_animation',x=actor)
        assert native.get('n_bob',actor)==o.ram[a+16],(trial,'index')
        assert native.get('n_timer',actor)==o.ram[a+22],(trial,'timer')
        descriptor=int(o.ram[a+1])|int(o.ram[a+2])<<8
        assert DESCRIPTORS[native.get('n_animation',actor)]==descriptor,(trial,'pose')

def test_native_cat_terrain_response(native):
    o=Original();r=random.Random(0x4cd7)
    for trial in range(4096):
        tiles=bytes(r.randrange(256) for _ in range(1792))
        native.ram[0xc000:0xc700]=list(tiles);o.ram[0xe000:0xe700]=list(tiles)
        actor=9+trial%2;world=r.randrange(65536);screen=r.randrange(512)
        height=r.randrange(32,196);pose=r.randrange(18)
        a=position(native,o,actor,world,screen,height,pose)
        for field,offset in [('n_flags',0),('n_vx',18),('n_vy',20),('n_target',11),
                             ('n_acceleration',12),('n_chick_state',26)]:
            value=r.randrange(256);native.set(field,value,actor);o.ram[a+offset]=value
        o.call(0x4cd7,ix=a);native.call('cat_terrain',x=actor)
        for field,offset in [('n_flags',0),('n_ylo',9),('n_vx',18),('n_vy',20),('n_target',11),
                             ('n_acceleration',12),('n_chick_state',26)]:
            assert native.get(field,actor)==o.ram[a+offset],(trial,field,native.get(field,actor),o.ram[a+offset])

def test_native_cat_chase_jump_turn_spawn_and_death(native):
    o=Original();r=random.Random(0x48b5)
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    states=[0,1,4,0x40,0x41,0x48,0x42,0x44,0x50,0x80,0x10]
    for trial in range(8192):
        native.call('native_reset');o.ram[:]=0
        stage=trial%48;tiles=maps[stage*1792:(stage+1)*1792]
        native.ram[0xc000:0xc700]=list(tiles);o.ram[0xe000:0xe700]=list(tiles)
        native.set('n_round',stage);native.call('round_select')
        o.ram[0xc008]=stage;o.ram[0xc018]=stage;o.ram[0xc014]=native.get('n_layout')
        actor=9+trial%2;world=r.randrange(65536);screen=r.randrange(512);height=r.randrange(32,196)
        a=position(native,o,actor,world,screen,height,r.randrange(9))
        state=r.choice(states);spawning=r.randrange(8)==0
        phase=r.randrange(3 if state==0x10 or spawning else 4 if state&10 else 7)
        values=[0xb0|r.randrange(2),int(spawning),height,0,r.randrange(-64,65)&255,
                r.choice([-8,-1,1,8])&255,0,phase,r.randrange(5),r.randrange(-64,65)&255,
                r.randrange(16),r.randrange(-48,49)&255,r.randrange(16),r.randrange(1,22),0,
                r.randrange(-64,65)&255,r.randrange(-48,0)&255,state,r.randrange(256)]
        for (field,offset),value in zip(FIELDS,values):
            native.set(field,value,actor);o.ram[a+offset]=value
        for field,address,value in [('n_frozen',0xc029,int(r.randrange(32)==0)),
                    ('n_difficulty',0xc004,r.randrange(256))]:
            native.set(field,value);o.ram[address]=value
        player_y=r.randrange(32,196);native.set('n_ylo',player_y,8);o.ram[0xc409]=player_y
        o.ram[0xc407:0xc409]=[0,1]
        before=bytes(o.ram[a:a+32])
        fast=int(trial%3==0);native.set('n_action_latch',fast,actor)
        o.call(0x4865 if fast else 0x48b5,ix=a);native.call('cat_update',x=actor)
        for field,offset in FIELDS:
            assert native.get(field,actor)==o.ram[a+offset],(trial,field,native.get(field,actor),o.ram[a+offset],before.hex())
        actual=(native.get('n_xlo',actor)+(native.get('n_xhi',actor)<<8)+world)&65535
        expected=int(o.ram[a+7])|int(o.ram[a+8])<<8
        assert actual==expected,(trial,'position',actual,expected,before.hex())
        descriptor=int(o.ram[a+1])|int(o.ram[a+2])<<8
        assert DESCRIPTORS[native.get('n_animation',actor)]==descriptor,(trial,'pose',native.get('n_animation',actor),hex(descriptor),before.hex())

def test_native_cat_pixel_masks_and_upside_down_hit_poses(native):
    video=Reference();video.lib.fm_mix.restype=C.POINTER(C.c_uint8)
    metadata=json.loads((BUILD/'native/cat-assets.json').read_text())['records']
    maps=(BUILD/'native/maps-reference.bin').read_bytes();r=random.Random(0x6866)
    blank=int(np.flatnonzero(~video.tiles.any(axis=(1,2)))[0])
    for stage in (0,7,19,23):
        native.call('native_reset');native.set('n_round',stage)
        native.call('level_load');native.call('display_init')
        video.ram[0xc000:]=0
        video.ram[0xe000:0xe700]=list(maps[stage*1792:(stage+1)*1792])
        video.ram[0xe800:0xf000:2]=blank&255;video.ram[0xe801:0xf000:2]=blank>>8
        for trial in range(384):
            world=r.randrange(65536);screen=r.randrange(512)
            if trial%2==0:screen=r.choice([0,1,7,8,12,16,19,20,21,500,510,511])
            pose=r.randrange(21);facing=r.randrange(2);center=r.randrange(24,204)
            word(native,'n_world',world);p=(screen-world)&65535
            native.set('n_xlo',p,9);native.set('n_xhi',p>>8,9);native.set('n_ylo',center,9)
            native.set('n_flags',0xb0|facing|(2 if pose>=18 else 0),9)
            native.set('n_animation',[5,7,8][pose-18] if pose>=18 else pose,9)
            actual=native.call('cat_terrain_contact',x=9)
            record=metadata[pose*8+facing*4];h=record['height'];stride=record['stride']
            source=record['source'];top=(center-h//2)&255
            if pose>=18:source+=stride*(h-1)
            if facing:source=(source+stride-2)|0x8000
            delta=-stride if pose>=18 else stride
            source=(source-delta)&65535;left=(screen-2*(stride-1))&511
            video.ram[0xd090:0xd098]=[top,(top+h)&255,left&255,left>>8,delta&255,(delta>>8)&255,source&255,source>>8]
            scroll=(world-28)&65535;video.ram[0xeffc:0xeffe]=[scroll&255,scroll>>8]
            video.lib.fm_render_snapshot(0)
            assert actual==video.lib.fm_mix()[41],(stage,trial,pose,facing,screen)

def test_native_cat_spawn_timing_and_replacement(native):
    o=Original();r=random.Random(0x1c5f)
    for trial in range(2048):
        native.call('native_reset');native.set('n_round',trial%9);native.call('level_load')
        o.ram[:]=0;o.ram[0xe000:0xe700]=native.ram[0xc000:0xc700]
        o.ram[0xc014]=native.get('n_layout');o.ram[0xc018]=trial%9;o.ram[0xc008]=trial%9
        o.ram[0xc425]=9;o.ram[0xc445]=10
        world=r.randrange(512);word(native,'n_world',world);o.ram[0xc01a:0xc01c]=[world&255,world>>8]
        fields=[('n_game_ticks',0xc0c4,r.randrange(256)),('n_spawn_clock',0xc0c0,r.choice([0,0,1,59])),
                ('n_spawn_wait',0xc6fb,r.randrange(12)),('n_spawn_delay',0xc027,r.randrange(256))]
        for name,address,value in fields:native.set(name,value);o.ram[address]=value
        for actor in (8,9,10):
            value=r.choice([0x80,0x84]) if actor==8 else r.choice([0,0x80])
            native.set('n_flags',value,actor);o.ram[0xc300+actor*32]=value
        for door in range(2):
            value=r.choice([0,1,4,5,10,15,16,17])
            # In these early rounds a pending cat door belongs to an empty slot.
            # The later-round third enemy uses a separate spawn path.
            if native.get('n_flags',9+door)&128:value=0
            native.set('n_door_timers',value,door);o.ram[0xc031+door]=value
        o.call(0x1c5f,stop=0x1dc2)
        native.call('enemies_spawn')
        for name,address,_ in fields:
            assert native.get(name)==o.ram[address],(trial,name,native.get(name),o.ram[address])
        for door in range(2):assert native.get('n_door_timers',door)==o.ram[0xc031+door],(trial,'door',door)
        for actor in (9,10):assert native.get('n_flags',actor)==o.ram[0xc300+actor*32],(trial,'flags',actor)
