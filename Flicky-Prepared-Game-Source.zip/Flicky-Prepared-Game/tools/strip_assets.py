"""Deduplicate padded ink/mask columns; Y phases are pointer offsets."""
import json
REGIONS=((4,8192),(5,8192),(10,8192),(11,8192),(12,8192),(15,8192),(14,5292),(13,3152))
class Strips:
    def __init__(self):
        self.lines=[];self.records={};self.columns={};self.poses={};self.descriptors=set();self.region=self.used=self.desc_used=0
    def column(self,ink):
        if ink not in self.columns:
            if self.used+44>REGIONS[self.region][1]:self.region+=1;self.used=0
            bank=REGIONS[self.region][0];label=f'pose_column_{len(self.columns)}'
            self.columns[ink]=label,bank;self.used+=44
            mask=bytes(sum((3 if v>>s&3==0 else 0)<<s for s in (6,4,2,0))for v in ink)
            self.lines += [f'.segment "UPPER{bank}"',label+':','.byte '+','.join(map(str,ink+mask))]
        return self.columns[ink]
    def put(self,pixels,descriptor=True):
        pixels=bytes(pixels)
        if pixels not in self.records:
            label=f'pose_strip_{len(self.records)}';self.records[pixels]=label,None
            columns=[bytes(6)+pixels[c::2]+bytes(6)for c in range(2)]
            refs=[self.column(ink)for ink in columns];flags=[]
            for phase in (0,2,4,6):
                cells=[columns[c][6-phase+cy*8:14-phase+cy*8]for cy in range(2)for c in range(2)]
                flags.append(sum((bool(any(cell))<<i) | (all((v&85)==((v>>1)&85)for v in cell)<<(i+4))for i,cell in enumerate(cells)))
            self.poses[label]=refs,flags
        label,db=self.records[pixels]
        if descriptor and label not in self.descriptors:
            db=5 if self.desc_used+10<=5020 else 2;self.desc_used+=10;self.descriptors.add(label);self.records[pixels]=label,db
            refs,flags=self.poses[label];self.lines += [f'.segment "BANK{db}"',label+':']
            for name,bank in refs:self.lines += [f'.word {name}',f'.byte {bank}']
            self.lines += ['.byte '+','.join(map(str,flags))]
        return label,db
    def save(self,out):
        (out/'pose-strips.s').write_text('\n'.join(self.lines)+'\n')
        (out/'pose-strips.json').write_text(json.dumps({'unique_poses':len(self.records),'unique_columns':len(self.columns),
            'pixel_and_mask_bytes':len(self.columns)*44,'prop_pose_directory_bytes':len(self.descriptors)*10,
            'upper_banks':[b for b,size in REGIONS[:self.region+1]],'vertical_phases_share_pixels':True},indent=2)+'\n')
