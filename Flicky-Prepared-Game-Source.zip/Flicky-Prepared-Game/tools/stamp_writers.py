"""Generate screen-write programs with row addresses and wrap writes resolved."""
def build(out):
    lines=[]
    for back,bank in ((0,9),(1,31)):
        lines += [f'.segment "BANK{bank}"']
        for row in range(28):
            base=0x6000+back*4096+row*96
            lines += [f'stamp_row_{back}_{row}:']
            for cell in range(2):
                lines += [f'    lda ${base:04x},x','    sta p_bg','    and #127','    cmp #64',f'    bcc @dirty{cell}','    cmp #96',f'    bcs @write{cell}', '    tay','    lda stamp_idle_bit,y','    and i_active',f'    beq @write{cell}',f'@dirty{cell}:',
                    '    ldy p_count_index','    lda p_bg','    sta $3e00,y','    txa','    clc',f'    adc #${base&255:02x}','    sta $3c00,y',f'    lda #${base>>8:02x}','    sta $3d00,y','    inc p_count_index',f'@write{cell}:',
                    '    lda s_code',f'    sta ${base:04x},x',f'    sta ${base+32:04x},x',f'    sta ${base+64:04x},x','    inc s_code']
                if not cell:lines+=['    inx','    txa','    and #31','    tax']
            lines += ['    rts']
    lines+=['.segment "FIXED"','stamp_row_lo:', '.lobytes '+','.join(f'stamp_row_0_{r}'for r in range(28)),
            'stamp_row_hi:', '.hibytes '+','.join(f'stamp_row_0_{r}'for r in range(28)), 'stamp_idle_bit:','.res 64,0','.byte '+','.join(str(1<<(i//4))for i in range(32))]
    for row in range(28):lines+=[f'.assert stamp_row_0_{row}=stamp_row_1_{row},error,"Writer bank offsets differ"']
    (out/'stamp-writers.s').write_text('\n'.join(lines)+'\n')
