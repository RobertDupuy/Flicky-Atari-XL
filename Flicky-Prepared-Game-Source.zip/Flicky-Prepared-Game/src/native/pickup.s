; Original-resolution sprite-to-sprite contact. Later-drawn chicks hide
; earlier chicks, matching the source hardware's collision owner at each pixel.
; A cached 64-source-clock player mask makes the test independent of ANTIC.
q_cached_ptr=$0720
q_cached_bank=$0722
q_cached_valid=$0723
q_candidates=$0724
q_last=$0732
q_row=$a4
q_player_y=$ac
q_player_height=$ad
q_window=$ae
q_offset=$af
q_column=$b0
q_rows=$b1
q_temp=$b2
q_hit=$b3
q_actor=$b4
q_player_mask=$1c00
q_remaining=$1d00
.segment "FIXED"
.export pickup_contacts
pickup_contacts:
    lda #0
    sta q_candidates
    ldx #7
@candidate:
    lda n_flags,x
    bpl @next
    clc
    lda n_xlo,x
    adc n_world
    sta q_temp
    lda n_xhi,x
    adc n_world+1
    sta n_step
    sec
    lda q_temp
    sbc n_xlo+PLAYER
    sta q_temp
    lda n_step
    sbc n_xhi+PLAYER
    beq @right
    cmp #$ff
    bne @next
    lda q_temp
    cmp #$e0
    bcc @next
    bcs @vertical
@right:
    lda q_temp
    cmp #33
    bcs @next
@vertical:
    lda n_ylo,x
    clc
    adc n_draw_yoffset,x
    sec
    sbc n_ylo+PLAYER
    clc
    adc #24
    cmp #49
    bcs @next
    lda q_candidates
    ora pickup_bits,x
    sta q_candidates
@next:
    dex
    bpl @candidate
    lda q_candidates
    bne :+
    rts
:   jsr player_prepare
    lda p_y
    sta q_player_y
    lda p_height
    sta q_player_height
    jsr sprite_screen_mask
    lda p_screen+1
    lsr a
    lda p_screen
    ror a
    lsr a
    lsr a
    and #$3e
    sta q_window
    lda q_cached_valid
    beq @new_mask
    lda p_mask
    cmp q_cached_ptr
    bne @new_mask
    lda p_mask+1
    cmp q_cached_ptr+1
    bne @new_mask
    lda p_maskbank
    cmp q_cached_bank
    beq @copy
@new_mask:
    lda #1
    sta q_cached_valid
    lda p_mask
    sta q_cached_ptr
    lda p_mask+1
    sta q_cached_ptr+1
    lda p_maskbank
    sta q_cached_bank
    NATIVE_BANK
    lda #0
    sta q_offset
@player_row:
    jsr sprite_expand_mask
    ldy q_offset
    ldx #0
@store:
    lda q_row,x
    sta q_player_mask,y
    iny
    inx
    cpx #8
    bcc @store
    sty q_offset
    dec p_height
    bne @player_row
@copy:
    lda q_player_height
    asl a
    asl a
    asl a
    tax
    dex
@copy_byte:
    lda q_player_mask,x
    sta q_remaining,x
    dex
    cpx #$ff
    bne @copy_byte
    lda #7
    sta q_actor
@actor:
    ldx q_actor
    lda q_candidates
    and pickup_bits,x
    bne :+
    jmp @next_actor
:   lda pickup_bits,x
    sec
    sbc #1
    and q_candidates
    sta q_last
    jsr chick_prepare
    lda p_visible
    bne :+
    jmp @next_actor
:   jsr sprite_screen_mask
    lda p_maskbank
    NATIVE_BANK
    sec
    lda p_y
    sbc q_player_y
    bcs @start_row
    eor #$ff
    clc
    adc #1
    cmp p_height
    bcc :+
    jmp @next_actor
:   sta q_temp
    lda p_height
    sec
    sbc q_temp
    sta p_height
    lda q_temp
    asl a
    asl a
    clc
    adc p_mask
    sta p_mask
    bcc :+
    inc p_mask+1
:   lda #0
@start_row:
    cmp q_player_height
    bcc :+
    jmp @next_actor
:   sta q_temp
    asl a
    asl a
    asl a
    sta q_offset
    lda q_player_height
    sec
    sbc q_temp
    cmp p_height
    bcc :+
    lda p_height
:   sta q_rows
    lda p_screen+1
    lsr a
    lda p_screen
    ror a
    lsr a
    lsr a
    and #$3e
    sec
    sbc q_window
    sta q_column
    lda #0
    sta q_hit
@row:
    jsr sprite_expand_mask
    lda q_column
    sta q_temp
    ldx #0
@byte:
    lda q_temp
    cmp #8
    bcs @skip
    clc
    adc q_offset
    tay
    lda q_row,x
    and q_remaining,y
    beq @skip
    lda q_last
    bne :+
    ldx q_actor
    lda pickup_bits,x
    ora n_pickup
    sta n_pickup
    rts
:   lda #1
    sta q_hit
    lda q_row,x
    eor #$ff
    and q_remaining,y
    sta q_remaining,y
@skip:
    inc q_temp
    inx
    cpx #8
    bcc @byte
    clc
    lda q_offset
    adc #8
    sta q_offset
    dec q_rows
    bne @row
    lda q_hit
    beq @next_actor
    ldx q_actor
    lda pickup_bits,x
    ora n_pickup
    sta n_pickup
@next_actor:
    dec q_actor
    bmi @done
    jmp @actor
@done:
    rts

; Select the same original mask aligned to screen pixels for actor collisions.
; The terrain mask is aligned to world pixels and therefore has a different phase.
sprite_screen_mask:
    ldx p_actor
    cpx #9
    bcc @ordinary
    lda p_cat_pose
    asl a
    asl a
    asl a
    sta p_index
    jmp @orientation
@ordinary:
    lda n_animation,x
    asl a
    asl a
    asl a
    asl a
    cpx #PLAYER
    bne :+
    asl a
:   sta p_index
    lda n_frame,x
    asl a
    asl a
    asl a
    ora p_index
    sta p_index
@orientation:
    lda n_flags,x
    and #1
    asl a
    asl a
    ora p_index
    sta p_index
    lda p_screen
    lsr a
    lsr a
    and #3
    ora p_index
    tay
    lda #5
    NATIVE_BANK
    cpx #PLAYER
    beq @player
    bcs @cat
    lda p_screen
    and #2
    bne @chick_odd
    lda native_chick_mask_lo0,y
    sta p_mask
    lda native_chick_mask_hi0,y
    sta p_mask+1
    lda native_chick_mask_bank0,y
    sta p_maskbank
    rts
@chick_odd:
    lda native_chick_mask_lo1,y
    sta p_mask
    lda native_chick_mask_hi1,y
    sta p_mask+1
    lda native_chick_mask_bank1,y
    sta p_maskbank
    rts
@player:
    lda p_screen
    and #2
    bne @player_odd
    lda native_player_mask_lo0,y
    sta p_mask
    lda native_player_mask_hi0,y
    sta p_mask+1
    lda native_player_mask_bank0,y
    sta p_maskbank
    rts
@player_odd:
    lda native_player_mask_lo1,y
    sta p_mask
    lda native_player_mask_hi1,y
    sta p_mask+1
    lda native_player_mask_bank1,y
    sta p_maskbank
    rts

@cat:
    lda p_screen
    and #2
    bne @cat_odd
    lda native_cat_mask_lo0,y
    sta p_mask
    lda native_cat_mask_hi0,y
    sta p_mask+1
    lda native_cat_mask_bank0,y
    sta p_maskbank
    rts
@cat_odd:
    lda native_cat_mask_lo1,y
    sta p_mask
    lda native_cat_mask_hi1,y
    sta p_mask+1
    lda native_cat_mask_bank1,y
    sta p_maskbank
    rts

; Four one-bit-per-source-pixel bytes become eight source-clock bytes.
sprite_expand_mask:
    ldy #0
    .repeat 4,I
        lda (p_mask),y
        tax
        lda $f400,x
        sta q_row+I*2
        lda $f500,x
        sta q_row+I*2+1
        .if I<3
            iny
        .endif
    .endrepeat
    lda p_screen
    and #1
    beq @advance
    clc
    .repeat 8,I
        ror q_row+I
    .endrepeat
@advance:
    clc
    lda p_mask
    adc #4
    sta p_mask
    bcc :+
    inc p_mask+1
:   rts
pickup_bits: .byte 1,2,4,8,16,32,64,128
pickup_expand: .byte $00,$03,$0c,$0f,$30,$33,$3c,$3f,$c0,$c3,$cc,$cf,$f0,$f3,$fc,$ff
