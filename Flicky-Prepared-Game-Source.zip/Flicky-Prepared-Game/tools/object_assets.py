"""Prepare the fifteen object types and their original three rotation frames."""
import json
from pathlib import Path
from build import ROOT,BUILD
from character_atlas import CharacterAtlas
import native_assets


def object_art(allocator,compact_writer=None):
    source=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    rom=bytearray(source);descriptors=[];palettes=[];flipped=[]
    for kind in range(15):
        descriptor=int.from_bytes(source[0x6746+kind*2:0x6748+kind*2],'little')
        palette=int.from_bytes(source[descriptor+4:descriptor+6],'little')
        for flip in range(2):
            for frame in range(3):
                descriptors.append(len(rom));palettes.append(source[palette:palette+15]+b'\0')
                if flip:flipped.append(len(descriptors)-1)
                rom.extend(source[descriptor:descriptor+7])
                rom.extend(source[descriptor+7+frame*2:descriptor+9+frame*2])
    native_assets.small_actor_assets(rom,allocator,'object',descriptors,palettes,1,tuple(range(40)),flipped=flipped,compact_writer=compact_writer)


def pack_native_records(output,records,masks,images,mask_index,metadata):
    lines=[];bank=27;used=0;pointers=[];mask_pointers=[]
    def put(data,label,filename):
        nonlocal bank,used
        if used+len(data)>8192:bank+=1;used=0
        assert bank<=31,'Object artwork exceeds SIC upper-ROM regions'
        used+=len(data)
        (output/filename).write_bytes(data)
        lines.extend([f'.segment "UPPER{bank}"',label+':',f'.incbin "{filename}"'])
        return bank
    assert max(map(len,records))<=128
    for i,record in enumerate(records):
        height,width=record[:2]
        cells=width*((height+14)//8)
        assert cells<=16, 'Object cell IDs overlap the next pose'
        assert 23+2*cells+2*width*(height+14)<=256, 'Object frame exceeds its RAM page'
        label=f'native_object_pixels_{i}'
        pointers.append((label,put(record,label,f'object-pixels-{i:03}.bin'),len(record)))
    for i,mask in enumerate(masks):
        data=b''.join(mask[y:y+3]+b'\0' for y in range(0,len(mask),3))
        label=f'native_object_mask_{i}'
        mask_pointers.append((label,put(data,label,f'object-mask-{i:03}.bin')))
    lines+=['.segment "UPPER13"','native_object_records:']
    for image,mask in zip(images,mask_index):
        label,b,size=pointers[image];mlabel,mb=mask_pointers[mask]
        lines += [f'.byte {size}',f'.word {label}',f'.byte {b}',f'.word {mlabel}',f'.byte {mb}']
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    desc=[int.from_bytes(rom[0x6746+i*2:0x6748+i*2],'little') for i in range(15)]
    for segment,suffix in [('BANK3','')]:
        lines += [f'.segment "{segment}"',f'native_object_height{suffix}:','.byte '+','.join(str(rom[p]) for p in desc),
                  f'native_object_radius{suffix}:','.byte '+','.join(str(2*(rom[p+1]-1)) for p in desc)]
    positions=[]
    for layout in range(36):
        p=int.from_bytes(rom[0x654e+layout*2:0x6550+layout*2],'little')
        positions.append(rom[p:p+12])
    lines += ['.segment "BANK3"','native_object_positions:']
    for row in positions:lines.append('.byte '+','.join(map(str,row)))
    (output/'object-data.s').write_text('\n'.join(lines)+'\n')
    report={'image_bytes':sum(map(len,records)),'mask_bytes':sum(len(m)*4//3 for m in masks),
            'pointer_bytes':len(images)*7,'last_upper_bank':bank,'images':images,'masks':mask_index,'records':metadata}
    (output/'object-assets.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    class Measure(CharacterAtlas):
        def allocate(self,size):
            self.frame_bytes+=size
            return 0
    output=BUILD/'object-study';output.mkdir(exist_ok=True)
    native_assets.OUT=output
    a=Measure(output);object_art(a)
    d=json.loads((output/'object-assets.json').read_text())
    print({k:v for k,v in d.items() if k not in ('images','masks','records')})
    print('unique images',len(set(d['images'])),'unique masks',len(set(d['masks'])),'patterns',len(a.patterns))
