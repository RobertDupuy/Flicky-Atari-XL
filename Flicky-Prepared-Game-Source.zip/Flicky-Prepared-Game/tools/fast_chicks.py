"""Bake every chick pose at four X and four Y phases into fixed 2x2 stamps.

Ten-scanline silhouettes allow two-scanline positioning with four glyphs.
The Atari only copies prepared bytes; no shifting, scaling, masks or allocation.
"""
import json
from pathlib import Path

def build(out:Path):
    d=json.loads((out/'chick-assets.json').read_text());frames=[];indices=[]
    for py in (0,2,4,6):
        row=[]
        for image in d['images']:
            raw=(out/f'chick-image-{image:03d}.bin').read_bytes();h,w=raw[:2]
            rows=[round(y*(h-1)/9) for y in range(10)]
            data=bytearray()
            for cy in range(2):
                for cx in range(2):
                    glyph=bytes(raw[4+2*(rows[cy*8+y-py]*w+cx)] if 0<=cy*8+y-py<10 and cx<w else 0 for y in range(8))
                    data+=glyph
            frame=bytes(data)
            if frame not in frames:frames.append(frame)
            row.append(frames.index(frame))
        indices.append(row)
    lines=[];banks=[];bank=16;used=0
    for i,data in enumerate(frames):
        if used+len(data)>8192:bank+=1;used=0
        used+=len(data);banks.append(bank)
        name=f'fast-chick-{i:03d}.bin';(out/name).write_bytes(data)
        lines += [f'.segment "BANK{bank}"',f'fast_chick_{i}: .incbin "{name}"']
    lines+=['.segment "BANK5"']
    for py,row in enumerate(indices):
        lines += [f'fast_chick_lo{py}:','.lobytes '+','.join(f'fast_chick_{i}' for i in row),
                  f'fast_chick_hi{py}:','.hibytes '+','.join(f'fast_chick_{i}' for i in row),
                  f'fast_chick_bank{py}:','.byte '+','.join(str(banks[i]) for i in row)]
    lines += ['.segment "FIXED"','stamp_font_hi:']
    for back in range(2):lines+=['.byte '+','.join(str(0x22+back*0x20+(r//4)*4) for r in range(28))]
    lines += ['stamp_actor_offset:','.byte '+','.join(str((a if a<8 else max(0,a-12))*32) for a in range(18)),
              'stamp_actor_code:','.byte '+','.join(str(0xc0+a*4 if a<8 else 0xe0+max(0,a-12)*4) for a in range(18))]
    lines += ['stamp_actor_page:', '.byte '+','.join(str(int(a>=12)) for a in range(18))]
    (out/'fast-chick-data.s').write_text('\n'.join(lines)+'\n')
