"""Native, outlined score digits for the original eight delivery awards."""
from fast_ui_assets import FONT
from character_atlas import CharacterAtlas
import json

VALUES=(100,200,300,400,500,1000,2000,5000)

def build(out):
    atlas=CharacterAtlas(out);lines=[];names=[];banks=[];radii=[];bank=14;used=0
    for value in VALUES:
        text=str(value);width=len(text)*4-1;radii.append((width+2)*2)
        for phase in range(4):
            w=(width+2+phase+3)//4;h=7
            ink=[[0]*(w*4) for _ in range(h)]
            mask=[[3]*(w*4) for _ in range(h)]
            for i,ch in enumerate(text):
                for y,row in enumerate(FONT[ch].split()):
                    for x,v in enumerate(row):
                        if v=='1':
                            xx=phase+1+i*4+x;yy=y+1;ink[yy][xx]=1
                            for dy in (-1,0,1):
                                for dx in (-1,0,1):mask[yy+dy][xx+dx]=0
            raw=bytearray([h,w,0])
            for y in range(h):
                for x in range(w):
                    raw+=bytes([sum(mask[y][x*4+i]<<(6-2*i) for i in range(4)),
                                sum(ink[y][x*4+i]<<(6-2*i) for i in range(4))])
            data=atlas.convert(raw)
            if used+len(data)>4600:bank=16;used=0
            assert bank in (14,16)
            name=f'delivery-{value}-{phase}.bin';(out/name).write_bytes(data)
            label=f'delivery_{value}_{phase}';names.append(label);banks.append(bank)
            lines += [f'.segment "BANK{bank}"',f'{label}: .incbin "{name}"'];used+=len(data)
    lines += ['.segment "BANK27"','delivery_lo: .lobytes '+','.join(names),
              'delivery_hi: .hibytes '+','.join(names),'delivery_banks: .byte '+','.join(map(str,banks)),
              'delivery_radius: .byte '+','.join(map(str,radii)),
              'delivery_value_index: .byte 0,0,0,0,0,0,1,2,3,4,4,5,6,6,7']
    (out/'delivery-data.s').write_text('\n'.join(lines)+'\n')
    (out/'delivery-art.json').write_text(json.dumps(dict(awards=VALUES,native_digits=True,
        black_outline=True,score_source='original ROM table 1A7D and train offsets 5,6,7,8,9,11,12,14'),indent=2)+'\n')
