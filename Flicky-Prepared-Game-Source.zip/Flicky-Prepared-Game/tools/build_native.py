#!/usr/bin/env python3
"""Build only the new native 6502 implementation, never the reference runtime."""
import os
import argparse
import json
import struct
import subprocess
from build import ROOT, BUILD, executable

OUT=BUILD/'native'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared',action='store_true',help='Build from the included converted assets (default).')
    parser.add_argument('--variant',choices=('ntsc','pal'),default=os.environ.get('FLICKY_VARIANT','ntsc'),help='NTSC limits active props to one; PAL keeps all six independent.')
    parser.add_argument('--convert-original',action='store_true',help='Regenerate converted assets from separately supplied original ROMs.')
    args=parser.parse_args()
    stress_props=int(os.environ.get('FLICKY_STRESS_PROPS',6 if args.variant=='pal' else 1))
    if not 1<=stress_props<=6:parser.error('FLICKY_STRESS_PROPS must be between one and six')
    if args.convert_original:
        from native_assets import main as assets
        assets()
    OUT.mkdir(parents=True,exist_ok=True)
    from benchmark_fixture import build as build_benchmark
    build_benchmark(OUT)
    from fast_ui_assets import build as build_ui
    build_ui(OUT)
    from strip_assets import Strips
    strips=Strips()
    from fast_chicks import build as build_chicks
    build_chicks(OUT,strips)
    from stamp_writers import build as build_writers
    build_writers(OUT)
    from stamp_blits import build as build_blits
    build_blits(OUT)
    from prepared_assets import build as build_prepared
    build_prepared(OUT)
    from prepared_terrain import build as build_terrain
    build_terrain(OUT)
    from prepared_objects import build as build_objects
    build_objects(OUT,strips)
    strips.save(OUT)
    from compact_objects import build as build_floor
    build_floor(OUT)
    from prepared_audio import build as build_audio
    build_audio(OUT)
    from static_messages import build as build_messages
    build_messages(OUT)
    memory=['ZP:start=$30,size=$50,type=rw;', 'MRAM:start=$0300,size=$0300,type=rw,file=\"\";', 'MHIGH:start=$F800,size=$07FA,type=rw,file=\"\";']
    segments=['ZEROPAGE:load=ZP,type=zp,optional=yes;']
    for bank in range(32):
        memory.append(f'M{bank}:start=$8000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;')
        segments.append(f'BANK{bank}:load=M{bank},type=ro,optional=yes;')
    memory += ['MF:start=$A000,size=$1FFA,type=ro,file=%O,fill=yes,fillval=$FF;',
               'MV:start=$BFFA,size=6,type=ro,file=%O,fill=yes;']
    segments += ['FIXED:load=MF,type=ro;', 'RESIDENT:load=MF,run=MRAM,type=ro,define=yes;', 'HIGHRAM:load=M15,run=MHIGH,type=ro,define=yes;', 'VECTORS:load=MV,type=ro;']
    for bank in range(1,32):
        memory.append(f'MU{bank}:start=$A000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;')
        segments.append(f'UPPER{bank}:load=MU{bank},type=ro,optional=yes;')
    cfg=OUT/'native.cfg'
    cfg.write_text('MEMORY {\n'+'\n'.join(memory)+'\n}\nSEGMENTS {\n'+'\n'.join(segments)+'\n}\n')
    subprocess.run([executable('ca65')]+(['-D','BENCHMARK=1','-D',f'STRESS_PROPS={stress_props}'] if os.environ.get('FLICKY_BENCHMARK') else [])+['-D',f'PAL_MULTI_PROP={int(args.variant=="pal")}','-D','NATIVE_SIC=1','-g','-l',str(OUT/'native.lst'),'-I',str(ROOT/'src/native'),'-I',str(OUT),
                    '--bin-include-dir',str(OUT),str(ROOT/'src/native/game.s'),'-o',str(OUT/'native.o')],check=True)
    subprocess.run([executable('ld65'),'-C',str(cfg),str(OUT/'native.o'),'-o',str(OUT/'native.rom'),
                    '-Ln',str(OUT/'native.lbl'),'-m',str(OUT/'native.map')],check=True)
    rom=bytearray((OUT/'native.rom').read_bytes())
    assert len(rom)==524288
    index=bytearray((BUILD/'tile-index.bin').read_bytes())
    for i in range(4096,6144):index[i]+=1  # native glyph banks 10 and 11
    rom[12*8192:13*8192]=index
    glyphs=(BUILD/'tile-glyphs.bin').read_bytes()
    assert len(glyphs)<=16384
    rom[10*8192:10*8192+len(glyphs)]=glyphs
    # Link lower windows first and upper windows second, then interleave the
    # physical 16 KB banks required by the SIC! mapper.
    rom=bytearray(b''.join(rom[b*8192:(b+1)*8192]+rom[(32+b)*8192:(33+b)*8192] for b in range(32)))
    (OUT/'native.rom').write_bytes(rom)
    cartridge=OUT/'flicky-native-dev.car' 
    cartridge.write_bytes(b'CART'+struct.pack('>III',56,sum(rom)&0xffffffff,0)+rom)
    (OUT/'manifest.json').write_text(json.dumps({'status':'playable prepared-engine build',
        'runtime':'handwritten NMOS 6502','original_executable_rom_bytes':0,'variant':args.variant,'moving_prop_limit':6 if args.variant=='pal' else 1,
        'rom_bytes':len(rom),'target':'64 KB Atari 800XL, SIC! 512 KB','display_rate':'NTSC host/2; PAL host/2','player_clock':'original rational arcade clock','stress_fixture':bool(os.environ.get('FLICKY_BENCHMARK')),'display':'ANTIC 4, 32 visible columns, seven character bands, hardware scrolling'},indent=2)+'\n')
    print(cartridge)

if __name__=='__main__':main()
