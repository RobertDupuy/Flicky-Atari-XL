"""Publish verified native intro/portrait captures and continuous PAL movies."""
import hashlib,json,shutil
from concurrent.futures import ThreadPoolExecutor
from build import ROOT,BUILD
from package_visibility import encode

def main():
    release=ROOT/'release';source=BUILD/'intro-final'
    for mode in ('pal','ntsc'):
        folder=source/f'final-intro-{mode}'
        capture=json.loads((folder/'capture.json').read_text())
        pixels=json.loads((folder/'pixel-verification.json').read_text())
        assert pixels['video']==capture['video']
        assert pixels['prepared_frames_seen']==pixels['prepared_frames_total']==315
        assert pixels['mismatched_host_frames']==0 and not pixels['missing_frames']
        shutil.copyfile(folder/'intro-08.png',release/f'Flicky-Arcade-Intro-{mode.upper()}.png')
        shutil.copyfile(source/f'roundclear-{mode}/portrait.png',release/f'Flicky-Round-Clear-{mode.upper()}.png')
    jobs=[]
    for folder,report,name in [
        (source/'final-intro-pal','capture.json','Flicky-Atari-XL-PAL-Arcade-Intro.mp4'),
        (BUILD/'native/pal-level-realtime','verification.json','Flicky-Atari-XL-PAL-Level-Complete.mp4')]:
        verification=json.loads((folder/report).read_text())
        jobs.append((folder/verification['video'],release/name,verification))
    with ThreadPoolExecutor(max_workers=2)as pool:
        futures=[pool.submit(encode,src,dest)for src,dest,_ in jobs]
        movies=[dict(**f.result(),verification=job[2])for f,job in zip(futures,jobs)]
    (ROOT/'evidence/intro-movies.json').write_text(json.dumps(movies,indent=2)+'\n')
    print(json.dumps([dict(file=m['file'],duration=m['video']['format']['duration'],
                          bytes=m['video']['format']['size'])for m in movies],indent=2))

if __name__=='__main__':main()
