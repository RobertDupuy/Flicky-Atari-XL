"""Pack exact POKEY events, with fixed loop pointers and bounded decoding."""
import json
from build import BUILD

def build(out):
    tracks=sorted(json.loads((BUILD/'audio/manifest.json').read_text()),key=lambda t:t['command'])
    lines=[];bank=2;used=0;banks=[]
    for t in tracks:
        data=(BUILD/f'audio/{t["command"]:02x}.bin').read_bytes()
        if used+len(data)>8192:bank+=1;used=0
        assert bank<=3
        banks.append(bank);used+=len(data)
        lines += [f'.segment "UPPER{bank}"',f'pa_{t["command"]:02x}:','.byte '+','.join(map(str,data))]
    lines += ['.segment "FIXED"']
    refs=[f'pa_{t["command"]:02x}'for t in tracks]
    loops=[f'{r}+{t["loop_offset"]}'if t['loop_offset'] is not None else '0'for t,r in zip(tracks,refs)]
    for name,values in [('audio_banks',list(map(str,banks))),('audio_lo',['<'+r for r in refs]),('audio_hi',['>'+r for r in refs]),
                        ('audio_loop_lo',['<('+r+')'for r in loops]),('audio_loop_hi',['>('+r+')'for r in loops]),
                        # 1 music, 0 overlay, 2 exclusive jingle, 3 game over,
                        # 4 source-only reset commands (not audible effects).
                        ('audio_flags',[str(1 if t['loop_frame']is not None else 4 if t['command'] in (0x8c,0x8d) else 3 if t['command']==0x87 else 2 if t['command'] in (0x86,0x8e) else 0)for t in tracks])]:
        lines += [name+':','.byte '+','.join(values)]
    (out/'audio-data.s').write_text('\n'.join(lines)+'\n')
    (out/'prepared-audio.json').write_text(json.dumps({'commands':len(tracks),'rom_bytes':sum(t['bytes']for t in tracks),
        'upper_banks':bank-1,'maximum_changed_registers_per_event':8},indent=2)+'\n')
