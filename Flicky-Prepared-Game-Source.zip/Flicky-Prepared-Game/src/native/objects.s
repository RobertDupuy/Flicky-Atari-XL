; Six objects, as in the SG loop at $1539. Original Atari artwork and level
; positions are retained. States: floor=0, carried=$40, projectile=$80.
n_carry=$07e9
o_actor=$07e7
o_target=$07e8
.segment "FIXED"
.export objects_reset,objects_update,n_carry
objects_reset:
    lda #3
    NATIVE_BANK
    jmp objects_reset_bank
objects_update:
    lda #3
    NATIVE_BANK
    jmp objects_update_bank
.segment "BANK3"
objects_reset_bank:
    lda #255
    sta n_carry
    lda n_layout
    asl a
    sta n_ptr
    asl a
    clc
    adc n_ptr
    sta n_ptr
    lda #0
    rol a
    sta n_ptr+1
    asl n_ptr
    rol n_ptr+1
    lda n_ptr
    clc
    adc #<native_object_positions
    sta n_ptr
    lda n_ptr+1
    adc #>native_object_positions
    sta n_ptr+1
    ldx #12
    ldy #0
@object:
    lda (n_ptr),y
    asl a
    sta n_xlo,x
    lda #0
    rol a
    sta n_xhi,x
    iny
    lda (n_ptr),y
    sta n_ylo,x
    iny
    lda #$80
    sta n_flags,x
    lda n_bonus
    beq :+
    lda #0
    sta n_flags,x
:   lda #0
    sta n_chick_state,x
    sta n_frame,x
    sta n_vx,x
    sta n_vy,x
    sta n_yhi,x
    sta n_fx,x
    sta n_fy,x
    sta n_pose,x
    sta n_timer,x
    lda n_round
@kind:
    cmp #15
    bcc :+
    sbc #15
    bcs @kind
:   sta n_animation,x
    inx
    cpx #18
    bcc @object
    ldx #12
@floor:
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
    sta c_screen+1
    lda n_ylo,x
    sta e_y
    jsr cat_tile
@scan:
    ldy #0
    lda (n_ptr),y
    and #$10
    bne @place
    jsr cat_down
    lda e_row
    cmp #28
    bcc @scan
    lda #27
    sta e_row
@place:
    ldy n_animation,x
    lda native_object_height,y
    lsr a
    sta n_step
    lda e_row
    asl a
    asl a
    asl a
    sec
    sbc n_step
    sec
    sbc #1
    sta n_ylo,x
    inx
    cpx #18
    bcc @floor
    ldx #5
    lda #0
@cache:
    sta n_object_cache_valid,x
    dex
    bpl @cache
    rts

objects_update_bank:
    lda n_bonus
    beq :+
    rts
:   lda #12
    sta o_actor
@object:
    ldx o_actor
    lda n_flags,x
    bmi :+
    jmp @next
:   lda n_chick_state,x
    bpl :+
    jmp @thrown
:   
    bne @carried
    lda n_game_ticks
    and #1
    beq :+
    jmp @next
:
    lda n_carry
    cmp #255
    beq :+
    jmp @next
:   
    lda n_flags+PLAYER
    and #4
    ora n_exiting
    beq :+
    jmp @next
:
    jsr object_player_position
    jsr object_near
    bcc @next_jump
    stx n_carry
    lda #$40
    sta n_chick_state,x
    ora n_action_latch+PLAYER
    sta n_action_latch+PLAYER
    lda #$89
    sta n_sound_event
@carried:
    jsr object_player_position
    lda n_flags+PLAYER
    and #1
    beq @right
    sec
    lda f_x
    sbc #16
    sta n_xlo,x
    lda f_x+1
    sbc #0
    sta n_xhi,x
    lda #$a0
    bne @velocity
@right:
    clc
    lda f_x
    adc #16
    sta n_xlo,x
    lda f_x+1
    adc #0
    sta n_xhi,x
    lda #$60
@velocity:
    sta n_vx,x
    lda n_ylo+PLAYER
    sta n_ylo,x
    lda n_action_latch+PLAYER
    and #$40
    beq :+
    jmp @next
:
    lda #255
    sta n_carry
    lda #$80
    sta n_chick_state,x
    lda #$e0
    sta n_vy,x
    lda #90
    sta n_timer,x
    lda #$8a
    sta n_sound_event
    jmp @next
@next_jump:
    jmp @next
@thrown:
    dec n_timer,x
    bne :+
    jmp @remove
:   
    jsr object_prepared_motion
    lda n_game_ticks
    and #1
    bne :+
    jsr object_bounce
:
    lda n_ylo,x
    cmp #216
    bcc :+
    jmp @remove
:   
    lda n_game_ticks
    and #7
    bne @hits
    inc n_frame,x
    lda n_frame,x
    cmp #3
    bcc @hits
    lda #0
    sta n_frame,x
@hits:
    lda n_game_ticks
    and #1
    beq :+
    jmp @next
:   lda n_xlo,x
    sta f_x
    lda n_xhi,x
    and #1
    sta f_x+1
    lda n_ylo,x
    sta f_y
    lda #9
    sta o_target
@enemy:
    ldx o_target
    lda n_flags,x
    and #$a0
    cmp #$a0
    bne @next_enemy
    lda n_chick_state,x
    and #$10
    bne @next_enemy
    jsr object_near
    bcc @next_enemy
    lda n_chick_state,x
    ora #$80
    sta n_chick_state,x
    lda #$d8
    sta n_vy,x
    ldy o_actor
    lda n_vx,y
    sta n_vx,x
    lda #0
    sta n_target,x
    lda n_vx,x
    bmi :+
    lda #$fe
    bne @brake
:   lda #2
@brake:
    sta n_acceleration,x
    ldx o_actor
    inc n_pose,x
    lda n_pose,x
    sed
    clc
    adc n_score+1
    sta n_score+1
    lda n_score+2
    adc #0
    sta n_score+2
    cld
    lda #$8d
    sta n_sound_event
@next_enemy:
    inc o_target
    lda o_target
    cmp #11
    bcc @enemy
    jmp @next
@remove:
    lda #0
    sta n_flags,x
@next:
    inc o_actor
    lda o_actor
    cmp #18
    beq :+
    jmp @object
:   rts

object_player_position:
    sec
    lda n_xlo+PLAYER
    sbc n_world
    sta f_x
    lda n_xhi+PLAYER
    sbc n_world+1
    and #1
    sta f_x+1
    lda n_ylo+PLAYER
    sta f_y
    rts
object_bounce:
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
    sta c_screen+1
    lda n_ylo,x
    clc
    adc #5
    sta e_y
    cmp #216
    bcs @done
    jsr cat_tile
    ldy #0
    lda (n_ptr),y
    and #$10
    beq @wall
    lda n_vy,x
    bmi @wall
    lda #$e0
    sta n_vy,x
@wall:
    lda n_vx,x
    bmi @left
    clc
    lda c_screen
    adc #12
    sta c_screen
    bcc @sample
    inc c_screen+1
    bne @sample
@left:
    sec
    lda c_screen
    sbc #12
    sta c_screen
    bcs @sample
    dec c_screen+1
@sample:
    lda n_ylo,x
    sta e_y
    jsr cat_tile
    ldy #0
    lda (n_ptr),y
    and #$10
    beq @done
    lda n_vx,x
    eor #255
    clc
    adc #1
    sta n_vx,x
@done:
    rts
object_near:
    sec
    lda n_ylo,x
    sbc f_y
    clc
    adc #12
    cmp #25
    bcs @no
    sec
    lda n_xlo,x
    sbc f_x
    sta f_dx
    lda n_xhi,x
    sbc f_x+1
    sta f_dx+1
    clc
    lda f_dx
    adc #24
    sta f_dx
    lda f_dx+1
    adc #0
    and #1
    bne @no
    lda f_dx
    cmp #49
    bcs @no
    sec
    rts
@no:
    clc
    rts

; Props have exactly two horizontal velocities. Vertical integer deltas and
; fractional remainders are table lookups; no general actor integrator runs.
object_prepared_motion:
    lda n_vx,x
    bmi @left
    clc
    lda n_xlo,x
    adc #6
    sta n_xlo,x
    lda n_xhi,x
    adc #0
    jmp @x
@left:
    sec
    lda n_xlo,x
    sbc #6
    sta n_xlo,x
    lda n_xhi,x
    sbc #0
@x:
    and #1
    sta n_xhi,x
    ldy n_vy,x
    lda object_gravity_next,y
    sta n_vy,x
    clc
    adc n_fy,x
    tay
    lda object_fraction,y
    sta n_fy,x
    lda object_delta,y
    clc
    adc n_ylo,x
    sta n_ylo,x
    rts
object_gravity_next:
.repeat 256,I
    .byte (I+1) .mod 256 - ((I+1>=49) .and (I+1<128))
.endrepeat
object_fraction:
.repeat 256,I
    .byte I .mod 16
.endrepeat
object_delta:
.repeat 256,I
    .byte ((I / 16) + (240 * (I>=128))) .mod 256
.endrepeat
