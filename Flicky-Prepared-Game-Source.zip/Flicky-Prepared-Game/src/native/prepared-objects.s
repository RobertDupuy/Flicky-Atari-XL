.segment "HIGHRAM"
.export prepared_object
prepared_object:
    stx p_actor
    ldy n_animation,x
    lda native_object_height_draw,y
    lsr a
    sta n_step
    lda n_ylo,x
    sec
    sbc n_step
    clc
    adc #1
    and #$fe
    sta p_y
    cmp #216
    bcc :+
    rts
:   sec
    lda n_xlo,x
    sbc native_object_radius_draw,y
    sta p_left
    lda n_xhi,x
    sbc #0
    and #1
    sta p_left+1
    lda p_left
    lsr a
    lsr a
    and #3
    sta p_index
    lda obj_kind_index,y
    sta n_ptr
    lda n_frame,x
    asl a
    clc
    adc n_ptr
    sta n_ptr
    lda n_flags,x
    and #2
    beq :+
    lda n_ptr
    clc
    adc #6
    sta n_ptr
:   lda n_flags,x
    and #1
    ora n_ptr
    sta n_ptr
    lda #0
    sta n_ptr+1
    asl n_ptr
    rol n_ptr+1
    asl n_ptr
    rol n_ptr+1
    lda n_ptr
    ora p_index
    sta n_ptr
    sta n_src
    lda n_ptr+1
    sta n_src+1
    asl n_ptr
    rol n_ptr+1
    clc
    lda n_ptr
    adc n_src
    sta n_ptr
    lda n_ptr+1
    adc n_src+1
    sta n_ptr+1
    lda p_y
    and #6
    lsr a
    tax
    clc
    lda obj_dir_lo,x
    adc n_ptr
    sta n_ptr
    lda obj_dir_hi,x
    adc n_ptr+1
    sta n_ptr+1
    lda obj_dir_bank,x
    NATIVE_BANK
    ldy #0
    lda (n_ptr),y
    sta s_data
    iny
    lda (n_ptr),y
    sta s_data+1
    iny
    lda (n_ptr),y
    sta s_bank
    NATIVE_BANK
    jmp stamp_draw
