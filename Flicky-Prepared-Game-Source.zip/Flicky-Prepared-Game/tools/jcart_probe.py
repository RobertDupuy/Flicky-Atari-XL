#!/usr/bin/env python3
"""Verify released Type 110 carts in Atari800, including real ANTIC/POKEY timing."""
import argparse, hashlib, json, os, time
from pathlib import Path
from build import ROOT, BUILD
from native_engine import Engine
from raster_probe import Session
from attract_probe import observe_ram
from hardware_model import HOST_FPS

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=('ntsc','pal'),required=True)
    a=p.parse_args();mode=a.mode
    cart=ROOT/'release'/f'Flicky-Atari-XL-{mode.upper()}-JatariCart-512K.car'
    n=Engine(cart,BUILD/'variants-jcart'/mode/'native.lbl')
    out=BUILD/'jcart-hardware'/mode;s=Session(cart,out,mode,True);fd=None
    def get(m,k,i=0):return m[n.labels[k]+i]
    def word(m,k):return int.from_bytes(m[n.labels[k]:n.labels[k]+2],'little')
    try:
        deadline=time.monotonic()+15
        while True:
            try:fd,base=observe_ram(s,cart,n);break
            except RuntimeError:
                if time.monotonic()>deadline:raise
                time.sleep(.25)
        read=lambda:os.pread(fd,65536,base)
        deadline=time.monotonic()+15
        while get(read(),'u_mode')!=1 or not 2<=word(read(),'it_frame')<=315:
            assert time.monotonic()<deadline,'intro startup timeout'
            time.sleep(.1)
        intro=[];deadline=time.monotonic()+65
        while True:
            m=read();row=dict(frame=word(m,'it_frame'),finished=get(m,'it_finished'),overflow=get(m,'c_overflow'))
            intro.append(row)
            if len(intro)%5==0:print(mode,'intro',row,flush=True)
            assert not row['overflow']
            if row['finished']:break
            assert time.monotonic()<deadline,('intro timeout',row)
            time.sleep(1)
        s.capture().save(out/'intro-complete.png')
        s.tap('Control_R');deadline=time.monotonic()+10
        while get(read(),'u_mode')!=0 or get(read(),'result_active'):
            assert time.monotonic()<deadline,'game entry timeout'
            time.sleep(.1)
        time.sleep(1.2)
        normal=[]
        # Ordinary joystick-equivalent keyboard inputs at normal emulation speed.
        normal_begin=read();start=time.monotonic()
        while time.monotonic()-start<8:
            t=time.monotonic()-start
            s.key('Right',t<3);s.key('Left',4<t<6)
            s.key('Control_R',1<t<1.25 or 4.5<t<4.7)
            m=read();normal.append(dict(x=word(m,'n_world'),y=get(m,'n_ylo',8),fault=get(m,'r_fault'),overflow=get(m,'c_overflow')))
            time.sleep(.03)
        for key in ('Right','Left','Control_R'):s.key(key,False)
        normal_end=read()
        host_frames=(word(normal_end,'r_host_frames')-word(normal_begin,'r_host_frames'))&65535
        shown=(word(normal_end,'r_presented')-word(normal_begin,'r_presented'))&65535
        displayed_fps=shown*float(HOST_FPS[mode])/host_frames
        assert abs(displayed_fps-float(HOST_FPS[mode])/2)<.5,displayed_fps
        s.capture().save(out/'level-1.png')
        assert len({v['x'] for v in normal})>10
        assert not max(v['fault']|v['overflow'] for v in normal)
        # Select bonus before observation. Only ordinary fire presses follow.
        load=n.labels['game_round_load'];idle=n.labels['native_idle'];round_addr=n.labels['n_round']
        code=bytes([0xa9,0,0x8d,0x0e,0xd4,0x8d,0,0xd4,0xa9,2,0x8d,round_addr&255,round_addr>>8,
                    0x20,load&255,load>>8,0xa9,1,0x8d,0xff,5,0x4c,idle&255,idle>>8])
        s.monitor(['c 05ff 00','c 05d0 '+code[:16].hex(' '),'c 05e0 '+code[16:].hex(' '),'cont 05d0'],resume=False)
        deadline=time.monotonic()+12
        while not read()[0x05ff]:
            assert time.monotonic()<deadline,'bonus loader timeout'
            time.sleep(.03)
        time.sleep(1.2);bonus=[];start=time.monotonic();captured=False
        while time.monotonic()-start<8:
            t=time.monotonic()-start;s.key('Control_R',1<=t<3.4 or 4.5<=t<4.7)
            m=read();row=dict(y=get(m,'n_ylo',8),grounded=get(m,'n_grounded'),fault=get(m,'r_fault'),overflow=get(m,'c_overflow'))
            bonus.append(row)
            if row['y']<=109 and not captured:s.capture().save(out/'bonus-jump.png');captured=True
            time.sleep(.015)
        s.key('Control_R',False)
        jumps=sum(b['grounded'] and not c['grounded'] for b,c in zip(bonus,bonus[1:]))
        assert jumps==2 and min(v['y']for v in bonus)<=109 and bonus[-1]['grounded']
        assert not max(v['fault']|v['overflow']for v in bonus)
        s.capture().save(out/'bonus-landed.png')
        result=dict(mode=mode,cartridge=cart.name,sha256=hashlib.sha256(cart.read_bytes()).hexdigest(),
                    emulator='Atari800 7.2.1',machine='64 KB 800XL, BASIC disabled, normal speed',
                    cart_type=n.cart_type,intro_frames=intro[-1]['frame'],intro_completed=True,
                    level_1_input_seconds=8,bonus_input_seconds=8,bonus_jumps=jumps,minimum_bonus_y=min(v['y']for v in bonus),
                    normal_displayed_fps=round(displayed_fps,3),normal_host_frames=host_frames,
                    renderer_faults=0,input_overflow=0,physical_hardware_tested=False)
        (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    finally:
        if fd is not None:os.close(fd)
        s.close()
if __name__=='__main__':main()
