#!/usr/bin/env python3
from run_reference import Reference,BUILD,ROOT
import ctypes as C,json

def main():
    r=Reference();r.lib.fm_disassemble.argtypes=[C.c_uint16,C.c_char_p,C.c_int]
    prof=json.loads((BUILD/'reference/profile.json').read_text())
    lines=[];out=C.create_string_buffer(128)
    records=[]
    for key,count in prof.items():
        pc=int(key,16)
        end=r.lib.fm_disassemble(pc,out,0)
        text=out.value.decode()
        lines.append(f'{pc:04X} {count:9d} {text}')
        records.append({'pc':pc,'end':end,'text':text,'count':count})
    (BUILD/'reference/executed.asm').write_text('\n'.join(lines)+'\n')
    (BUILD/'reference/instructions.json').write_text(json.dumps(records,indent=2))
    print('\n'.join(f'{a["pc"]:04X} {a["count"]:10d} {a["text"]}' for a in sorted(records,key=lambda a:-a['count'])[:55]))

if __name__=='__main__':main()
