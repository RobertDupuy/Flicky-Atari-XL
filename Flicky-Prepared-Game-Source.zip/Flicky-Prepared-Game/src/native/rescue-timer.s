; Source rescue delay: 213061 CPU T-states plus 32775 opcode fetch stretches,
; or 1130855 clocks at 20 MHz (56.54275 ms, excluding source interrupt work).
; Wait in raster time, not CPU busy-loop iterations. Rendering and audio keep
; running; gameplay input samples during the intended freeze are discarded.
w_period=$0725
w_frame=$0726
w_phase=$0727
w_left=$0728
w_current_frame=$072a
w_current_phase=$072b
w_overrun=$072c
.segment "FIXED"
.export rescue_wait,w_overrun
rescue_wait:
    txa
    pha
    lda $061f
    pha
    lda #1
    sta c_paused
    sta w_left+1
    lda $d014
    and #$0e
    beq @pal
    lda #131
    sta w_period
    lda #<444
    bne @start
@pal:
    lda #156
    sta w_period
    lda #<440
@start:
    sta w_left
    jsr rescue_sample
    sta w_phase
    sty w_frame
    jsr native_present
    jsr rescue_elapsed
    bcc @finish
@wait:
    jsr rescue_elapsed
    bcs @wait
@finish:
    lda #0
    sta c_paused
    lda r_input
    sta n_input
    pla
    NATIVE_BANK
    pla
    tax
    rts
rescue_sample:
    ldy r_vbis
    lda $d40b
    cpy r_vbis
    bne rescue_sample
    sec
    sbc #124
    bcs :+
    clc
    adc w_period
:   rts
rescue_elapsed:
    jsr rescue_sample
    sta w_current_phase
    sty w_current_frame
    tya
    sec
    sbc w_frame
    tax
    beq @partial
@frame:
    sec
    lda w_left
    sbc w_period
    sta w_left
    lda w_left+1
    sbc #0
    sta w_left+1
    dex
    bne @frame
@partial:
    ; remaining -= current_phase - previous_phase, retaining signed carry.
    clc
    lda w_left
    adc w_phase
    sta w_left
    lda w_left+1
    adc #0
    sta w_left+1
    sec
    lda w_left
    sbc w_current_phase
    sta w_left
    lda w_left+1
    sbc #0
    sta w_left+1
    lda w_current_phase
    sta w_phase
    lda w_current_frame
    sta w_frame
    lda w_left+1
    bmi @done
    ora w_left
    beq @done
    sec
    rts
@done:
    clc
    rts
