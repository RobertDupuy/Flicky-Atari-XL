-- Research fixture: enter the requested bonus through the original setup code.
-- This is an explicitly staged ROM reference, never a gameplay demonstration.
local m=manager.machine
local cpu=m.devices[":maincpu"]
local s=cpu.spaces["program"]
local screen=m.screens[":screen"]
local dir=assert(os.getenv("FLICKY_ORACLE_DIR"))
local round=tonumber(os.getenv("FLICKY_BONUS_ROUND") or "2")
local f=0
local trace=assert(io.open(dir.."/mame-state.bin","wb"))
emu.register_frame_done(function()
  f=f+1
  local system=m.ioport.ports[":SYSTEM"]
  system:field(1):set_value(f>=180 and f<190 and 1 or 0)
  system:field(16):set_value(f>=210 and f<220 and 1 or 0)
  if f==300 then
    s:write_u8(0xc018,round)
    cpu.state["PC"].value=0x1ae
  end
  if f>=300 then
    for a=0xc000,0xc6ff do trace:write(string.char(s:read_u8(a))) end
  end
  if f==400 or f==600 or f==700 or f==800 or f==1000 or f==1300 then
    screen:snapshot(dir..string.format("/mame-%04d.png",f))
    local file=assert(io.open(dir..string.format("/mame-%04d.bin",f),"wb"))
    for a=0,65535 do file:write(string.char(s:read_u8(a))) end
    file:close()
  end
  if f>=1800 then trace:close();m:exit() end
end)
