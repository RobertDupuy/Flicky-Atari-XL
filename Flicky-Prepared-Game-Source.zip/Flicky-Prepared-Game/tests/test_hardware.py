from pathlib import Path
import hashlib,json,sys,zlib
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from hardware_model import *
from import_roms import decode_byte,decrypt,validate,import_set

@pytest.mark.parametrize('standard',['ntsc','pal'])
def test_scheduler_long_run_and_two_tick_frames(standard):
    s=FrameScheduler(standard)
    frames=100000
    ticks=[s.next_frame() for _ in range(frames)]
    assert min(ticks)==1 and max(ticks)==2
    assert sum(ticks)==int(frames*ARCADE_FPS/HOST_FPS[standard])
    assert 0<=s.phase<s.denominator

def test_guest_master_clock():
    assert ARCADE_FPS==Fraction(3125,52)
    assert 20_000_000/ARCADE_FPS==MASTER_TICKS_PER_FRAME
    assert master_ticks(607,74)==3183
    assert master_ticks(607,74,7)==3218

@pytest.mark.parametrize('size',[64,1024])
def test_collision_summary_and_entry_are_independent(size):
    c=CollisionLatch(size)
    assert c.read(3)==0x7e
    c.hit(3)
    assert c.read(3)==0xff and c.read(4)==0xfe
    c.clear_entry(3)
    assert c.read(3)==0xfe
    c.hit(3)
    c.clear_summary()
    assert c.read(3)==0x7f and c.read(4)==0x7e
    assert c.read(size+3)==0x7f

def test_antic4_fifth_color_is_cell_choice():
    assert [character_pixel(0x1b,i,0) for i in range(4)]==[0,1,2,3]
    assert [character_pixel(0x1b,i,128) for i in range(4)]==[0,1,2,4]

def test_sega_decode_known_table_entries():
    assert decode_byte(0,0,True)==0x08
    assert decode_byte(0,0,False)==0xa0
    assert decode_byte(0,0x80,True)==0x28
    assert decode_byte(0,0x80,False)==0x20
    assert decode_byte(1,0,True)==0x80
    for a in [0,1,16,256,4096,0x7111,0x7fff]:
        for v in range(256):
            for m1 in [True,False]:
                assert (decode_byte(a,v,m1)&0x57)==(v&0x57)
    with pytest.raises(ValueError): decrypt(bytes(5))

def test_importer_refuses_missing_and_wrong_revision(tmp_path):
    manifest=json.loads((ROOT/'config/flicky-roms.json').read_text())
    with pytest.raises(ValueError,match='Missing epr-5978a.116'):
        import_set(tmp_path,tmp_path/'out')
    assert not (tmp_path/'out').exists()
    files={e['name']:bytes(e['size']) for e in manifest['files']}
    with pytest.raises(ValueError,match='Wrong revision'):
        validate(files,manifest)

def test_hash_checks_accept_and_reject_known_sample():
    b=b'non-ROM test payload'
    entry={'name':'sample','size':len(b),'crc32':f'{zlib.crc32(b):08x}','sha1':hashlib.sha1(b).hexdigest()}
    validate({'sample':b},{'files':[entry]})
    with pytest.raises(ValueError): validate({'sample':b[:-1]+b'!'},{'files':[entry]})
