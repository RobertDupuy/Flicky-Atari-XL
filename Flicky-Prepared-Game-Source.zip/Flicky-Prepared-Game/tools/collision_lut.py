"""Exact silhouette-overlap intervals for native enemy broad-phase survivors.

The first overlapping actor can be resolved by a ROM lookup. Multiple overlaps
retain the pixel ownership path. A rare non-contiguous interval explicitly asks
for that path too; the table never invents a pixel hit.
"""
import json
import hashlib
from pathlib import Path
import numpy as np


def build_collision_tables(output: Path):
    shapes=[];shape_ids={};indices={}
    for kind in ('player','chick','cat'):
        data=json.loads((output/f'{kind}-assets.json').read_text())
        ids=[]
        for index in range(0,len(data['records']),4):
            row=data['records'][index];mask=data['masks'][index]
            packed=(output/f'{kind}-maskshift-{mask:03}-0.bin').read_bytes()
            key=(row['height'],2*(row['stride']-1),packed)
            if key not in shape_ids:
                shape_ids[key]=len(shapes);shapes.append(key)
            ids.append(shape_ids[key])
        indices[kind]=ids
    fingerprint=hashlib.sha256(b'collision-interval-v2'+repr((shapes,indices)).encode()).hexdigest()
    report=output/'collision-lut.json'
    if report.exists() and (output/'collision-data.s').exists():
        old=json.loads(report.read_text())
        if old.get('fingerprint')==fingerprint and all((output/f'collision-profile-{i:04}.bin').exists() for i in range(old['unique_profiles'])):
            return old
    # Every facing pair reflects around the same x=-0.5 axis. Normalize the
    # enemy to facing zero; reflect the other actor and negate relative X.
    cats=sorted(set(indices['cat'][::2]));cat_ids={s:i for i,s in enumerate(cats)}
    pixels=[]
    for height,radius,packed in shapes:
        mask=np.unpackbits(np.frombuffer(packed,dtype=np.uint8)).reshape(height,32)
        pixels.append([np.flatnonzero(np.repeat(row,2))-radius for row in mask])
    profiles=[];profile_ids={};directory=[];holes=0
    for enemy in cats:
        h_b=shapes[enemy][0];rows_b=pixels[enemy]
        entries=[]
        for actor,(h_a,_,_) in enumerate(shapes):
            rows=[]
            first=-(h_a-h_a//2-1)-h_b//2
            last=(h_b-h_b//2-1)+h_a//2
            for dy in range(first,last+1):
                hit=np.zeros(128,dtype=bool)
                for ya,xa in enumerate(pixels[actor]):
                    yb=ya+dy+h_b//2-h_a//2
                    if not 0<=yb<h_b or not len(xa) or not len(rows_b[yb]):continue
                    delta=(rows_b[yb][:,None]-xa[None,:]).ravel()+64
                    assert delta.min()>=0 and delta.max()<128
                    hit[delta]=True
                places=np.flatnonzero(hit)
                if not len(places):rows.append(bytes((1,0)));continue
                low,high=int(places[0]),int(places[-1])
                hole=int(not hit[low:high+1].all());holes+=hole
                rows.append(bytes((low|(hole<<7),high)))
            while rows and rows[0]==bytes((1,0)):rows.pop(0);first+=1
            while rows and rows[-1]==bytes((1,0)):rows.pop()
            profile=bytes((first&255,len(rows)))+b''.join(rows)
            if profile not in profile_ids:
                profile_ids[profile]=len(profiles);profiles.append(profile)
            entries.append(profile_ids[profile])
        directory.append(entries)
    # Pointer directories occupy UPPER12/13; deduplicated profiles start at 14.
    lines=[];banks=[];bank=14;used=0
    for i,profile in enumerate(profiles):
        if used+len(profile)>8192:bank+=1;used=0
        assert bank<=31,'Collision lookup exceeded SIC capacity'
        banks.append(bank);used+=len(profile)
        name=f'collision-profile-{i:04}.bin';(output/name).write_bytes(profile)
        lines += [f'.segment "UPPER{bank}"',f'native_collision_profile_{i}:',f'.incbin "{name}"']
    dir_banks=[];dir_bank=12;dir_used=0
    for enemy,entries in enumerate(directory):
        size=len(entries)*3
        if dir_used+size>8192:dir_bank+=1;dir_used=0
        assert dir_bank<14
        dir_used+=size;dir_banks.append(dir_bank)
        lines += [f'.segment "UPPER{dir_bank}"',f'native_collision_enemy_{enemy}:']
        for profile in entries:
            lines += [f'.word native_collision_profile_{profile}',f'.byte {banks[profile]}']
    lines += ['.segment "BANK5"']
    for kind in ('player','chick','cat'):
        lines += [f'native_collision_{kind}_shape:', '.byte '+','.join(map(str,indices[kind]))]
    lines += ['native_collision_cat_directory:', '.byte '+','.join(str(cat_ids[indices['cat'][i&~1]]) for i in range(len(indices['cat']))),
              'native_collision_directory_lo:', '.lobytes '+','.join(f'native_collision_enemy_{i}' for i in range(len(cats))),
              'native_collision_directory_hi:', '.hibytes '+','.join(f'native_collision_enemy_{i}' for i in range(len(cats))),
              'native_collision_directory_bank:', '.byte '+','.join(map(str,dir_banks))]
    (output/'collision-data.s').write_text('\n'.join(lines)+'\n')
    result={'fingerprint':fingerprint,'shapes':len(shapes),'cat_shapes':len(cats),'pairs':len(shapes)*len(cats),
            'unique_profiles':len(profiles),'profile_bytes':sum(map(len,profiles)),
            'directory_bytes':len(shapes)*len(cats)*3,'noncontiguous_rows':holes,
            'last_upper_bank':bank,'shape_indices':indices}
    (output/'collision-lut.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    from build import BUILD
    print({k:v for k,v in build_collision_tables(BUILD/'native').items() if k!='shape_indices'})
