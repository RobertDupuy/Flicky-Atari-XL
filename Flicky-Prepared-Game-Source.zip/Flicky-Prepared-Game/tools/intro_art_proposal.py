"""Hand-drawn native intro art and a standalone Atari hardware proof cartridge.

This is a review frame, not an animation conversion or a replacement release.
The drawing uses TV-dot coordinates and is sampled to 160 color pixels. All
colors must survive losslessly in ANTIC 4 plus four single-width players.
"""
from pathlib import Path
import json, struct, subprocess, time
import numpy as np
from PIL import Image, ImageDraw
from build import ROOT, BUILD, executable
from round_clear_art import LETTERS

OUT = BUILD/'intro-art-proposal'
# Semantic inks; 0-4 are ANTIC inks. Extra inks have explicit player colors.
SKY, WHITE, BLACK, MAIN, SECOND, GOLD, ORANGE, BLUE, LIGHTBLUE = range(9)

def picture():
    im=Image.new('L',(320,224),SKY);d=ImageDraw.Draw(im)
    def poly(points,c,outline=None):
        d.polygon(points,fill=c)
        if outline is not None:d.line(points+[points[0]],fill=outline,width=2)
    def line(points,c,w=1):d.line(points,fill=c,width=w)
    def ellipse(box,c,outline=None,width=1):d.ellipse(box,fill=c,outline=outline,width=width)
    def path(c,*commands):
        points=[];last=(0,0)
        for cmd in commands:
            if len(cmd)==2:points.append(cmd);last=cmd
            else:
                x0,y0=last;x1,y1,x2,y2,x3,y3=cmd
                for j in range(1,25):
                    t=j/24;s=1-t
                    points.append((s*s*s*x0+3*s*s*t*x1+3*s*t*t*x2+t*t*t*x3,
                                   s*s*s*y0+3*s*s*t*y1+3*s*t*t*y2+t*t*t*y3))
                last=(x3,y3)
        d.polygon(points,fill=c)

    # Quiet background: coherent silhouettes, no source-pixel noise.
    for x,y in ((4,10),(109,4),(285,107)):
        path(WHITE,(x,y+10),(x+2,y+5,x+8,y+6,x+11,y+6),
             (x+14,y-2,x+24,y-2,x+29,y+6),
             (x+37,y+3,x+43,y+7,x+43,y+11),(x,y+11))

    # Two rose balloons and their small, clearly yellow passengers.
    for x,y in ((24,37),(86,25)):
        ellipse((x,y,x+33,y+36),BLACK)
        ellipse((x+2,y+1,x+31,y+33),SECOND)
        path(WHITE,(x+7,y+15),(x+5,y+8,x+10,y+4,x+17,y+4),
             (x+13,y+6,x+10,y+9,x+10,y+14))
        poly([(x+13,y+34),(x+20,y+34),(x+18,y+38),(x+15,y+38)],SECOND)
        line([(x+17,y+39),(x+15,y+47),(x+18,y+54)],BLACK,2)
        cy=y+55
        # The chicks hang by their wings. The balloon strings stay separate.
        poly([(x+13,cy+9),(x+8,cy+3),(x+7,cy-1),(x+11,cy+1),
              (x+16,cy+5),(x+24,cy+6),(x+29,cy+2),(x+28,cy+7),
              (x+24,cy+11)],BLACK)
        ellipse((x+12,cy,x+25,cy+13),BLACK)
        ellipse((x+14,cy+1,x+24,cy+11),GOLD)
        poly([(x+22,cy+4),(x+29,cy+6),(x+23,cy+8)],GOLD)
        d.rectangle((x+21,cy+2,x+22,cy+4),fill=BLACK)
        line([(x+16,cy+12),(x+15,cy+15),(x+20,cy+15)],GOLD,2)
        line([(x+22,cy+12),(x+22,cy+14),(x+26,cy+14)],GOLD,2)

    # Cat's purple propeller airplane, flying left. Full silhouette first.
    poly([(279,51),(288,25),(301,24),(299,57)],BLACK)
    poly([(282,50),(291,28),(298,27),(296,55)],MAIN)
    line([(291,29),(296,28),(294,40)],WHITE,2)
    poly([(271,60),(307,57),(313,61),(283,68)],BLACK)
    poly([(279,61),(305,60),(308,61),(284,65)],MAIN)
    path(BLACK,(157,54),(173,43,206,42,234,47),(256,50,276,56,299,54),
         (292,65,276,71,244,75),(206,81,174,72,157,63))
    path(MAIN,(160,55),(174,47,204,46,233,50),(257,53,274,59,294,57),
         (286,64,271,68,242,72),(207,78,176,69,160,61))
    path(WHITE,(171,52),(184,47,205,47,219,49),(204,50,188,51,174,55))
    # Rounded nose with an engine ring and a distinct two-blade propeller.
    ellipse((158,50,176,66),BLACK)
    ellipse((160,51,172,64),MAIN)
    line([(166,52),(166,63)],WHITE,2)
    ellipse((149,39,155,54),BLACK)
    ellipse((149,63,155,79),BLACK)
    ellipse((151,40,153,53),WHITE)
    ellipse((151,64,153,77),WHITE)
    line([(152,52),(152,66)],BLACK,2)
    ellipse((149,55,162,62),BLACK)
    ellipse((151,56,160,60),WHITE)
    # Far wing and near swept wing remain separated from the fuselage.
    poly([(205,50),(224,34),(234,35),(227,52)],BLACK)
    poly([(210,49),(225,37),(230,37),(224,51)],MAIN)
    poly([(209,66),(230,63),(263,86),(254,91),(228,84)],BLACK)
    poly([(214,67),(229,66),(258,86),(254,88),(230,81)],MAIN)
    line([(218,67),(229,67),(254,85)],WHITE,2)
    # Cockpit rim, orange cat shoulders, and a strong eared head.
    ellipse((231,43,274,56),BLACK)
    ellipse((234,44,271,52),WHITE)
    path(BLACK,(238,47),(237,40,242,34,249,34),(260,33,268,37,267,48))
    path(GOLD,(241,46),(241,40,244,37,250,37),(258,35,264,40,264,47))
    path(BLACK,(232,32),(229,23,231,12,234,9),(241,12,244,16,246,17),
         (252,15,256,16,260,18),(265,12,270,11,272,11),
         (274,19,271,25,271,31),(273,43,265,48,251,48),
         (238,48,232,41,232,32))
    path(GOLD,(235,31),(232,24,233,16,235,13),(241,17,242,20,247,21),
         (251,19,257,19,261,22),(265,17,268,16,269,15),
         (270,21,268,26,268,31),(270,40,263,45,251,45),
         (240,45,235,40,235,31))
    poly([(235,16),(240,21),(235,23)],ORANGE)
    poly([(266,19),(268,17),(267,25),(263,24)],GOLD)
    path(ORANGE,(235,31),(235,40,239,43,248,44),(240,40,239,37,240,31))
    # White brows/muzzle and asymmetric pupils give the pilot an expression.
    ellipse((239,25,250,36),WHITE);ellipse((253,24,264,35),WHITE)
    d.rectangle((240,27,243,33),fill=BLACK);d.rectangle((254,26,257,32),fill=BLACK)
    line([(239,24),(248,26)],BLACK,2);line([(255,24),(265,22)],BLACK,2)
    ellipse((242,35,261,43),WHITE)
    poly([(247,33),(255,33),(251,37)],BLACK)
    line([(251,37),(251,40),(247,41)],BLACK)
    line([(251,40),(256,40),(258,38)],BLACK)
    line([(241,36),(230,34)],BLACK);line([(240,39),(229,40)],BLACK)
    line([(262,35),(274,32)],BLACK);line([(263,39),(275,39)],BLACK)
    # Paw visibly rests on the cockpit edge.
    ellipse((236,44,249,50),BLACK);ellipse((238,44,247,48),GOLD)
    line([(242,45),(242,48)],ORANGE)

    # A rolling green horizon only below the hero's silhouette.
    # These shapes use the bottom band's background / main inks.
    path(SECOND,(0,196),(32,188,51,190,70,196),(95,201,127,199,151,196),
         (184,189,210,190,238,196),(268,204,297,195,319,193),(319,207),(0,207))
    line([(2,205),(55,205)],WHITE)
    line([(240,203),(274,203)],WHITE)
    line([(278,205),(313,205)],WHITE)

    # Red motorcycle: wheels, frame, fork, tank, seat and engine are separate.
    for x in (91,185):
        ellipse((x-15,181,x+15,205),BLACK)
        ellipse((x-10,185,x+10,201),WHITE)
        ellipse((x-7,187,x+7,199),BLACK)
        line([(x-6,193),(x+6,193)],WHITE)
        line([(x,188),(x,198)],WHITE)
        ellipse((x-2,191,x+2,195),WHITE)
    # Red rear fender arcs independently above the tire.
    path(BLACK,(74,184),(79,173,102,172,110,182),(107,186),(104,182),
         (95,177,82,179,78,187))
    path(MAIN,(77,182),(84,175,100,175,106,182),(101,180),
         (88,178,83,181,79,185))
    line([(90,192),(120,175),(143,191),(90,192)],BLACK,4)
    line([(92,191),(120,178),(140,190),(92,191)],WHITE,1)
    line([(167,160),(186,192)],BLACK,5)
    line([(166,162),(184,190)],WHITE,2)
    # Handlebars and headlamp, leaving blue sky between the fork and tank.
    line([(167,162),(164,153),(151,151),(145,154)],BLACK,3)
    line([(164,156),(170,153),(175,153)],BLACK,2)
    ellipse((165,158,180,170),BLACK)
    ellipse((168,160,178,168),SECOND)
    d.rectangle((171,161,177,164),fill=WHITE)
    # Tank has a deliberate red silhouette, white highlight and dark outline.
    path(BLACK,(126,172),(130,164,147,163,160,168),(169,173,168,180,159,182),
         (143,184,131,181,126,176))
    path(MAIN,(130,172),(134,167,148,166,158,170),(165,174,165,177,158,179),
         (144,181,133,179,130,175))
    path(WHITE,(135,170),(141,167,150,167,156,171),(147,170,140,170,135,172))
    d.rectangle((143,163,150,165),fill=BLACK)
    # Saddle and a compact finned engine block.
    path(BLACK,(101,166),(111,165,119,170,132,169),(136,171,132,175,126,175),(102,172))
    line([(105,167),(119,171),(130,171)],WHITE)
    poly([(124,182),(141,182),(148,189),(145,195),(124,194),(117,189)],BLACK)
    line([(125,184),(138,184)],WHITE,2)
    line([(123,188),(143,188)],WHITE)
    line([(126,191),(141,191)],WHITE)
    # Chrome exhaust and red front fender, never blended into the wheels.
    line([(136,195),(158,196),(163,193)],BLACK,5)
    line([(136,194),(158,195),(162,193)],WHITE,2)
    path(BLACK,(169,181),(177,174,195,176,202,184),(199,186),
         (188,180,179,181,173,185))
    path(MAIN,(172,180),(179,177,194,178,198,182),(190,180,180,179,174,183))

    # Flicky: new side-view artwork at native resolution, not an actor resize.
    # Tail feathers and white bib establish the bird's seated body.
    path(BLACK,(105,151),(94,149,84,143,80,139),(81,148,88,155,96,158),
         (85,154,84,157,88,160),(94,166,104,167,111,164))
    path(MAIN,(103,153),(94,152,89,149,85,146),(90,154,97,156,103,158),
         (94,157,92,159,95,161),(103,165,108,161,110,159))
    path(BLACK,(109,139),(94,147,95,163,108,170),(119,176,139,171,145,162),
         (149,153,139,144,129,141))
    path(MAIN,(111,142),(99,148,99,161,110,167),(121,172,136,168,141,161),
         (144,153,136,147,128,145))
    path(WHITE,(126,144),(115,148,111,158,116,165),(126,171,139,163,140,157),
         (139,151,134,147,126,144))
    # Back wing bends forward to the grip; fingers stay distinct.
    path(BLACK,(109,150),(105,156,110,162,119,162),(133,160,142,155,150,156),
         (157,156,158,151,152,149),(144,148,135,151,124,154),(118,151,114,148,109,150))
    path(MAIN,(110,153),(109,158,115,160,120,159),(132,157,143,152,150,153),
         (153,153,153,151,149,151),(140,151,133,154,124,157),(117,155,113,152,110,153))
    line([(150,153),(154,153)],WHITE)
    # Golden foot sits on a peg, below the body and above the engine.
    path(BLACK,(124,164),(122,170,126,177,132,180),(139,182,149,179,148,175),
         (146,172,139,175,137,174),(132,171,134,167,133,165))
    path(SECOND,(126,166),(125,172,129,177,133,178),(140,180,147,177,145,176),
         (141,177,136,178,134,174),(130,171,132,168,131,167))
    # Head with three crown feathers, two large eyes and a projecting beak.
    path(BLACK,(103,137),(94,126,98,115,108,111),(102,104,107,101,115,109),
         (113,100,120,99,124,108),(127,99,133,103,132,110),
         (145,110,152,119,150,131),(148,144,121,151,109,143))
    path(MAIN,(105,135),(98,127,102,117,112,114),(108,108,108,107,115,112),
         (118,114,118,105,121,108),(123,114,128,111,129,107),(129,113),
         (141,112,149,119,147,130),(145,141,122,147,111,140))
    path(WHITE,(107,120),(107,116,111,115,116,116),(113,117,111,119,110,121))
    ellipse((116,116,130,136),BLACK);ellipse((118,117,129,134),WHITE)
    ellipse((131,115,146,135),BLACK);ellipse((133,116,145,133),WHITE)
    ellipse((124,122,129,133),BLACK);ellipse((140,121,145,132),BLACK)
    d.rectangle((124,122,125,125),fill=WHITE);d.rectangle((140,121,141,124),fill=WHITE)
    path(BLACK,(132,135),(139,130,151,131,160,136),(166,139,164,143,157,145),
         (147,149,138,145,133,141))
    path(SECOND,(135,135),(141,133,151,133,159,137),(163,139,160,141,155,142),
         (146,145,139,142,135,139))
    line([(140,136),(152,135)],WHITE)
    line([(141,142),(150,143),(157,141)],BLACK)

    # Speed lines are intentional, isolated strokes, not dithering.
    line([(31,171),(66,171)],WHITE)
    line([(43,181),(64,181)],WHITE)
    line([(21,190),(59,190)],WHITE)

    # Native 5x7 text, physically balanced to the color-pixel aspect ratio.
    d.rectangle((0,208,319,223),fill=SKY)
    text='PRESS FIRE';x=(320-(len(text)*6-1)*2)//2
    for c in text:
        for y,row in enumerate(LETTERS[c]):
            for xx,b in enumerate(row):
                if b=='1':d.rectangle((x+xx*2,213+y,x+xx*2+1,213+y),fill=WHITE)
        x+=12
    return np.asarray(im.resize((160,224),Image.Resampling.NEAREST)).copy()

def row_palette(row):
    y=row*8
    # Background, PF0, PF1, PF2, PF3. Only the two variable inks change above
    # the horizon. Stable white and dark outlines keep faces readable.
    bg=0x9c if y<192 else 0xba if y<208 else 0x00
    primary=0x5c if y<48 else 0x5a if y<64 else 0x58 if y<96 else 0x8c if y<128 else 0x8a if y<152 else 0x88 if y<168 else 0x3a if y<184 else 0x38
    secondary=0x4c if y<96 else 0xee if y<192 else 0xb6
    return (bg,0x0e,0,primary,secondary)

EXTRA={GOLD:0xee,ORANGE:0x1c,BLUE:0x8a,LIGHTBLUE:0x8e}

def compile_art(pix,fixed_cat=True):
    fonts=bytearray();screen=bytearray();pmg=np.zeros((4,256),dtype=np.uint8)
    mux=np.zeros((28,4,2),dtype=np.uint8);pf=pix.copy();counts=[]
    # Conflict pixels become real player pixels, never an approximated ink.
    extra=np.zeros_like(pix)
    for row in range(28):
        y=row*8;pal=row_palette(row)
        # A semantic gold pixel can directly use an available playfield ink.
        for semantic,value in EXTRA.items():
            hit=pf[y:y+8]==semantic
            if value in pal:
                pf[y:y+8][hit]=pal.index(value)
            else:
                extra[y:y+8][hit]=value;pf[y:y+8][hit]=0
        for col in range(40):
            cell=pf[y:y+8,col*4:col*4+4]
            if np.any(cell==3) and np.any(cell==4):
                # Choose which per-cell alternate ink requires fewer players.
                ink=4 if np.sum(cell==4)<=np.sum(cell==3) else 3
                ex=extra[y:y+8,col*4:col*4+4]
                ex[cell==ink]=pal[ink];cell[cell==ink]=0
        # Cover all extra pixels with the fewest native-width, single-color
        # player strips. Players may move/recolor only at 8-scanline DLIs.
        choices=[]
        for color in sorted(set(extra[y:y+8].flatten())-{0}):
            mask=extra[y:y+8]==color
            while np.any(mask):
                x=int(np.flatnonzero(mask.any(axis=0))[0]);x=min(x,152)
                bits=mask[:,x:x+8].copy();mask[:,x:x+8]=False
                choices.append((x,int(color),bits))
        if fixed_cat and row<7:
            # Fixed cat spans eliminate repositioning in the middle of its
            # face. The fourth player is reserved for the warm cheek shade.
            choices=[(x,c,extra[y:y+8,x:x+8]==c) for x,c in
                     ((116,0xee),(117,0x1c),(124,0xee),(132,0xee))]
        assert len(choices)<=4,('player allocation',row,len(choices),[(x,c)for x,c,_ in choices])
        for player,(x,color,bits) in enumerate(sorted(choices,key=lambda a:a[0])):
            pmg[player,24+y:24+y+8]=np.packbits(bits,axis=1)[:,0]
            mux[row,player]=(48+x,color)
    # Configure each player during preceding empty bands, giving GTIA ample
    # time before the first visible pixel. This is actual DMA scheduling.
    for row in range(26,-1,-1):
        for player in range(4):
            if not np.any(pmg[player,24+row*8:32+row*8]):
                mux[row,player]=mux[row+1,player]
    for row in range(1,28):
        for player in range(4):
            if not mux[row,player,0]:mux[row,player]=mux[row-1,player]
    # Five-color ANTIC 4 encoding, checked without discarding a single pixel.
    for band in range(7):
        patterns={bytes(8):0};cells=[]
        for row in range(band*4,band*4+4):
            for col in range(40):
                a=pf[row*8:row*8+8,col*4:col*4+4]
                assert not(np.any(a==3) and np.any(a==4))
                inverse=128 if np.any(a==4) else 0
                a=np.where(a==4,3,a)
                g=np.sum(a*np.array([64,16,4,1]),axis=1).astype(np.uint8).tobytes()
                if g not in patterns:patterns[g]=len(patterns)
                cells.append(patterns[g]|inverse)
        assert len(patterns)<=128,(band,len(patterns))
        fonts+=b''.join(patterns)+bytes((128-len(patterns))*8)
        screen+=bytes(cells);counts.append(len(patterns))
    expected=np.zeros_like(pix)
    for row in range(28):
        pal=row_palette(row)
        expected[row*8:row*8+8]=np.array(pal,dtype=np.uint8)[pf[row*8:row*8+8]]
        for player in range(4):
            x,c=map(int,mux[row,player])
            if x:
                x-=48;bits=np.unpackbits(pmg[player,24+row*8:32+row*8,None],axis=1).astype(bool)
                expected[row*8:row*8+8,x:x+8][bits]=c
        desired=pix[row*8:row*8+8]
        exact=np.zeros_like(desired)
        for v in np.unique(desired):exact[desired==v]=pal[v] if v<=4 else EXTRA[v]
        assert np.array_equal(exact,expected[row*8:row*8+8]),('lossless failure',row)
    return fonts,screen,pmg,mux,expected,counts

def write_cartridge(fonts,screen,pmg,mux):
    (OUT/'fonts.bin').write_bytes(fonts)
    (OUT/'screen.bin').write_bytes(screen+bytes(1280-len(screen)))
    (OUT/'pmg.bin').write_bytes(bytes(1024)+pmg.tobytes())
    lines=['.setcpu "6502"','.segment "CODE"','start:','sei','cld','ldx #$ff','txs',
      'lda #0','sta $d40e','sta $d400','sta $d20e','sta $d01d',
      'lda #$fe','sta $d301','lda #<nmi','sta $fffa','lda #>nmi','sta $fffb','ldx #0','copy:']
    for label,dst,pages in [('fonts',0x2000,28),('screen',0x6000,5),('players',0x0800,8)]:
        for page in range(pages):lines += [f'lda {label}+${page*256:04x},x',f'sta ${dst+page*256:04x},x']
    lines += ['inx','beq copied','jmp copy','copied:','lda #0']
    for addr in range(0xd000,0xd010):lines += [f'sta ${addr:04x}']
    lines += ['sta $d404','sta $d405','sta $d01c','lda #1','sta $d01b',
      'lda #3','sta $d01d','lda #8','sta $d407','jsr frame',
      'lda #0','sta $d40f','lda #$40','sta $d40e','blank:','bit $d40f','bvc blank',
      'lda #$3e','sta $d400','lda #$c0','sta $d40e','idle:','jmp idle',
      'nmi:','sta $1b','bit $d40f','bpl vbi','dli:','jmp row1','vbi:','jsr frame','lda $1b','rti',
      'frame:','lda #<displaylist','sta $d402','lda #>displaylist','sta $d403',
      'lda #$20','sta $d409','lda #<row1','sta dli+1','lda #>row1','sta dli+2']
    # The DLI jump has to live in RAM; frame and the DLI handlers are copied
    # to RAM as one small executable block before display is enabled.
    # Use an indirect jump through zero page instead, so ROM remains read-only.
    lines=[s.replace('sta dli+1','sta $80').replace('sta dli+2','sta $81') for s in lines]
    lines[lines.index('jmp row1')]='jmp ($0080)'
    def store(a,v):return [f'lda #${v:02x}',f'sta ${a:04x}']
    addrs=(0xd01a,0xd016,0xd017,0xd018,0xd019)
    for a,v in zip(addrs,row_palette(0)):lines+=store(a,v)
    for p,(x,c) in enumerate(mux[0]):lines+=store(0xd000+p,int(x))+store(0xd012+p,int(c))
    lines += ['rts']
    for row in range(1,28):
        lines += [f'row{row}:','sta $d40a']
        prev=row_palette(row-1);pal=row_palette(row)
        for a,v,old in zip(addrs,pal,prev):
            if v!=old:lines+=store(a,v)
        if row%4==0:lines+=store(0xd409,0x20+row//4*4)
        for p in range(4):
            x,c=map(int,mux[row,p]);ox,oc=map(int,mux[row-1,p])
            if c!=oc:lines+=store(0xd012+p,c)
            if x!=ox:lines+=store(0xd000+p,x)
        nextrow=row+1 if row<27 else 1
        lines += [f'lda #<row{nextrow}','sta $80',f'lda #>row{nextrow}','sta $81','lda $1b','rti']
    lines += ['cart_init:','rts','.align 256','displaylist:','.byte $70,$70']
    for row in range(28):lines += [f'.byte ${0xc4 if row<27 else 0x44:02x}',f'.word ${0x6000+row*40:04x}']
    lines += ['.byte $41','.word displaylist','.align 256','fonts: .incbin "fonts.bin"',
              'screen: .incbin "screen.bin"','players: .incbin "pmg.bin"',
              '.segment "VECTORS"','.word start','.byte 0,$04','.word cart_init']
    (OUT/'proposal.s').write_text('\n'.join(lines)+'\n')
    (OUT/'proposal.cfg').write_text('MEMORY { ROM:start=$8000,size=$3FFA,type=ro,file=%O,fill=yes,fillval=$FF; V:start=$BFFA,size=6,type=ro,file=%O; }\nSEGMENTS { CODE:load=ROM,type=ro,align=$100; VECTORS:load=V,type=ro; }\n')
    subprocess.run([executable('ca65'),'--bin-include-dir',str(OUT),str(OUT/'proposal.s'),'-o',str(OUT/'proposal.o')],check=True)
    subprocess.run([executable('ld65'),'-C',str(OUT/'proposal.cfg'),str(OUT/'proposal.o'),'-o',str(OUT/'proposal.rom'),'-Ln',str(OUT/'proposal.lbl')],check=True)
    rom=(OUT/'proposal.rom').read_bytes();assert len(rom)==16384
    (OUT/'proposal.car').write_bytes(b'CART'+struct.pack('>III',2,sum(rom)&0xffffffff,0)+rom)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    pix=picture();fonts,screen,pmg,mux,expected,counts=compile_art(pix)
    np.savez_compressed(OUT/'native-art.npz',pixels=pix,pmg=pmg,mux=mux,expected=expected)
    write_cartridge(fonts,screen,pmg,mux)
    report=dict(display='160 x 224, ANTIC 4',players=4,player_width='single',
       multiplex_scanlines=8,font_patterns=counts,lossless_encoding=True,rom_bytes=16384,
       status='Static art proposal; not the intro animation or a game release')
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
    from raster_probe import Session
    s=Session(OUT/'proposal.car',OUT/'pal','pal')
    try:
        time.sleep(.7)
        s.capture().save(OUT/'proposal-pal.png')
        time.sleep(.1)
        s.capture().save(OUT/'proposal-pal-second.png')
    finally:s.close()

if __name__=='__main__':main()
