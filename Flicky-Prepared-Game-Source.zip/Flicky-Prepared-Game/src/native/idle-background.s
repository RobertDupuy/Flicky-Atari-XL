; Idle birds are prepared ANTIC character animations in the background layer.
; Their six character slots stay reserved while they remain at their spawn.
; Foreground sprites restore these current codes instead of repainting birds.
i_ptr=$e6
i_actor=$e8
i_cell=$e9
i_frame=$ea
i_cache_index=$eb
i_glyph=$ec
i_mode=$ee
i_table=$ef
i_saved_back=$f1
i_cell_row=$f2
i_base_code=$f3
i_bank=$f4
i_last_bank=$f5
i_ordinary=$079a
i_rows=$0750
i_columns=$0758
i_style_lo=$0760
i_style_hi=$0768
i_style_bank=$0770
i_pose_cache=$0780
i_active=$0790
i_variant=$0791
i_ready=$0799
i_frame_data=$1e00
.segment "FIXED"
.export idle_reset,idle_update,i_active,i_ready
idle_reset:
    lda #6
    NATIVE_BANK
    jmp idle_reset_bank
idle_update:
    lda n_train
    cmp #8
    bne @ordinary
    lda r_back
    beq :+
    lda #8
:   tax
    ldy #8
@detached:
    lda i_pose_cache,x
    cmp #255
    bne @ordinary
    inx
    dey
    bne @detached
    lda #0
    sta i_active
    rts
@ordinary:
    lda i_ready
    bne :+
    rts
:   lda #6
    NATIVE_BANK
    jmp idle_update_bank
idle_load_frame:
    jmp sic_read_frame
idle_copy_glyph:
    jmp sic_read_glyph

.segment "BANK6"
idle_reset_bank:
    lda #0
    sta i_ready
    sta i_active
    lda #255
    ldx #15
@clear:
    sta i_pose_cache,x
    dex
    bpl @clear
    lda n_round
    cmp #8
    bcs @modulo
    clc
    adc #48
    bne @profile
@modulo:
    cmp #48
    bcc @profile
    sec
    sbc #48
    bcs @modulo
@profile:
    sta i_ptr
    lda #0
    sta i_ptr+1
    .repeat 5
        asl i_ptr
        rol i_ptr+1
    .endrepeat
    clc
    lda i_ptr
    adc #<native_idle_profiles
    sta i_ptr
    lda i_ptr+1
    adc #>native_idle_profiles
    sta i_ptr+1
    ldx #0
@actor:
    txa
    tay
    lda (i_ptr),y
    cmp #255
    beq @unsupported
    tay
    lda native_idle_style_lo,y
    sta i_style_lo,x
    lda native_idle_style_hi,y
    sta i_style_hi,x
    lda native_idle_style_bank,y
    bne @style
@unsupported:
    lda #0
@style:
    sta i_style_bank,x
    txa
    clc
    adc #8
    tay
    lda (i_ptr),y
    sta i_rows,x
    tya
    clc
    adc #8
    tay
    lda (i_ptr),y
    sta i_columns,x
    tya
    clc
    adc #8
    tay
    lda (i_ptr),y
    sta i_variant,x
    inx
    cpx #8
    bne @actor
    lda r_back
    sta i_saved_back
    lda #0
    sta r_back
@buffer:
    lda #0
    sta i_actor
@geometry:
    jsr idle_table_address
    lda #0
    sta i_cell
@cell:
    ldx i_actor
    lda i_cell
    lsr a
    clc
    adc i_rows,x
    sta r_row
    lsr a
    lsr a
    sta r_band_index
    lda i_cell
    and #1
    clc
    adc i_columns,x
    and #31
    sta r_column
    jsr sprite_screen_address
    ldy #2
    lda r_screen
    sta (i_table),y
    iny
    lda r_screen+1
    sta (i_table),y
    ldy #0
    lda (r_screen),y
    ldy #6
    sta (i_table),y
    lda i_actor
    asl a
    asl a
    clc
    adc i_cell
    sta i_base_code
    ora #64
    ldy #7
    sta (i_table),y
    tax
    jsr display_glyph_address
    ldy #0
    lda r_font
    sta (i_table),y
    iny
    lda r_font+1
    ldx r_back
    beq :+
    clc
    adc #$20
:   sta (i_table),y
    lda i_base_code
    asl a
    asl a
    ldx r_band_index
    clc
    adc cache_band_lo,x
    ldy #4
    sta (i_table),y
    lda cache_band_hi,x
    adc #0
    sta i_cell_row
    lda r_back
    asl a
    asl a
    asl a
    asl a
    clc
    adc i_cell_row
    iny
    sta (i_table),y
    jsr idle_next_cell
    beq :+
    jmp @cell
:
    inc i_actor
    lda i_actor
    cmp #8
    beq :+
    jmp @geometry
:   inc r_back
    lda r_back
    cmp #2
    beq :+
    jmp @buffer
:
    lda i_saved_back
    sta r_back
    lda #1
    sta i_ready
    rts

.segment "BANK6"
idle_table_address:
    ldx i_actor
    lda idle_table_lo,x
    sta i_table
    lda r_back
    asl a
    clc
    adc r_back
    clc
    adc idle_table_hi,x
    sta i_table+1
    rts
idle_next_cell:
    clc
    lda i_table
    adc #16
    sta i_table
    bcc :+
    inc i_table+1
:   inc i_cell
    lda i_cell
    cmp #4
    rts
idle_table_lo:
.repeat 8,I
    .byte <($c800+I*96)
.endrepeat
idle_table_hi:
.repeat 8,I
    .byte >($c800+I*96)
.endrepeat
.segment "BANK6"
idle_update_bank:
    lda #0
    sta i_active
    sta i_actor
    sta i_ordinary
    ldx #7
@moving:
    lda n_flags,x
    bpl @moving_next
    lda n_chick_state,x
    and #3
    bne @ordinary
    lda n_xlo,x
    cmp n_idle_xlo,x
    bne @ordinary
    lda n_xhi,x
    and #1
    cmp n_idle_xhi,x
    bne @ordinary
    lda n_ylo,x
    cmp n_idle_y,x
    beq @moving_next
@ordinary:
    lda i_ordinary
    ora pickup_bits,x
    sta i_ordinary
@moving_next:
    dex
    bpl @moving
@actor:
    lda r_back
    asl a
    asl a
    asl a
    clc
    adc i_actor
    sta i_cache_index
    jsr idle_eligible
    bcc @disable
    sta i_frame
    ldx i_actor
    lda pickup_bits,x
    ora i_active
    sta i_active
    ldx i_cache_index
    lda i_frame
    cmp i_pose_cache,x
    beq @next
    lda #1
    sta i_mode
    lda i_pose_cache,x
    cmp #255
    bne :+
    inc i_mode
:   lda i_frame
    sta i_pose_cache,x
    sta i_ptr
    lda #0
    sta i_ptr+1
    .repeat 3
        asl i_ptr
        rol i_ptr+1
    .endrepeat
    lda i_frame
    asl a
    asl a
    clc
    adc i_ptr
    sta i_ptr
    bcc :+
    inc i_ptr+1
:
    ldx i_actor
    clc
    lda i_ptr
    adc i_style_lo,x
    sta i_ptr
    lda i_ptr+1
    adc i_style_hi,x
    sta i_ptr+1
    jsr idle_load_frame
    jsr idle_change_cells
    jmp @next
@disable:
    ldx i_cache_index
    lda i_pose_cache,x
    cmp #255
    beq @next
    lda #255
    sta i_pose_cache,x
    lda #0
    sta i_mode
    jsr idle_change_cells
@next:
    inc i_actor
    lda i_actor
    cmp #8
    beq :+
    jmp @actor
:   rts

idle_eligible:
    ldx i_actor
    lda i_style_bank,x
    beq @no
    lda n_flags,x
    bpl @no
    lda n_chick_state,x
    and #3
    bne @no
    lda n_xlo,x
    cmp n_idle_xlo,x
    bne @no
    lda n_xhi,x
    and #1
    cmp n_idle_xhi,x
    bne @no
    lda n_ylo,x
    cmp n_idle_y,x
    bne @no
    lda n_frame,x
    cmp i_variant,x
    bne @no
    lda n_animation,x
    cmp #5
    beq @pose
    cmp #6
    beq @pose
@no:
    clc
    rts
@pose:
    jsr idle_priority_clear
    bcc @no
    ldx i_actor
    ldy n_animation,x
    clc
    lda n_xlo,x
    adc n_world
    sta i_glyph
    lda n_xhi,x
    adc n_world+1
    sta i_glyph+1
    sec
    lda i_glyph
    sbc native_chick_radius,y
    sta i_glyph
    lda i_glyph+1
    sbc #0
    and #1
    beq @full
    lda i_glyph
    cmp #208
    bcc @full
    eor #255
    clc
    adc #2
    lsr a
    ; The display merges pairs of source pixels. A clipped source pixel does
    ; not change the prepared character when its whole projected pair remains.
    clc
    adc #1
    cmp native_chick_radius,y
    bcc @no
@full:
    clc
    lda n_draw_yoffset,x
    adc #3
    cmp #7
    bcs @no
    sta i_frame
    lda n_flags,x
    and #1
    beq :+
    lda i_frame
    clc
    adc #7
    sta i_frame
:   lda n_animation,x
    cmp #6
    lda i_frame
    bcc :+
    clc
    adc #14
:   sec
    rts

idle_priority_clear:
    lda pickup_bits,x
    sec
    sbc #1
    and i_ordinary
    beq @clear
    sta n_count
    ldy #0
@actor:
    lda n_count
    and pickup_bits,y
    beq @next
    sec
    lda n_xlo,y
    sbc n_idle_xlo,x
    sta n_step
    lda n_xhi,y
    sbc n_idle_xhi,x
    and #1
    beq @positive
    lda n_step
    cmp #224
    bcc @next
    bcs @vertical
@positive:
    lda n_step
    cmp #33
    bcs @next
@vertical:
    sec
    lda n_ylo,y
    sbc n_idle_y,x
    cmp #33
    bcc @blocked
    cmp #224
    bcs @blocked
@next:
    iny
    cpy i_actor
    bcc @actor
@clear:
    sec
    rts
@blocked:
    clc
    rts

.segment "BANK6"
idle_change_cells:
    jsr idle_table_address
    lda #6
    sta i_last_bank
    lda #0
    sta i_cell
@cell:
    lda i_mode
    bne :+
    jmp @remove
:
    lda i_cell
    asl a
    clc
    adc i_cell
    tax
    lda i_frame_data,x
    sta i_glyph
    lda i_frame_data+1,x
    sta i_glyph+1
    lda i_frame_data+2,x
    sta i_bank
    lda i_mode
    cmp #2
    beq @upload
    ldy #8
    lda (i_table),y
    cmp i_glyph
    bne @upload
    iny
    lda (i_table),y
    cmp i_glyph+1
    bne @upload
    iny
    lda (i_table),y
    cmp i_bank
    beq @next
@upload:
    ldy #8
    lda i_glyph
    sta (i_table),y
    iny
    lda i_glyph+1
    sta (i_table),y
    iny
    lda i_bank
    sta (i_table),y
    ldy #0
    lda (i_table),y
    sta r_font
    iny
    lda (i_table),y
    sta r_font+1
    jsr idle_copy_glyph
    ldy #7
    lda (i_table),y
    and #127
    sta i_base_code
    lda i_bank
    and #128
    ora i_base_code
    sta (i_table),y
    pha
    jsr idle_screen_and_meta
    pla
    jsr sprite_write_cell
    lda i_mode
    cmp #2
    bne @next
    ldy #0
    lda #255
    sta (p_meta),y
    iny
    sta (p_meta),y
    iny
    sta (p_meta),y
    iny
    lda #1
    sta (p_meta),y
    jmp @next
@remove:
    jsr idle_screen_and_meta
    ldy #6
    lda (i_table),y
    jsr sprite_write_cell
    ldy #2
    lda #0
    sta (p_meta),y
    iny
    sta (p_meta),y
@next:
    jsr idle_next_cell
    beq :+
    jmp @cell
:   lda #6
    NATIVE_BANK
    rts
idle_screen_and_meta:
    ldy #2
    lda (i_table),y
    sta r_screen
    iny
    lda (i_table),y
    sta r_screen+1
    iny
    lda (i_table),y
    sta p_meta
    iny
    lda (i_table),y
    sta p_meta+1
    rts
