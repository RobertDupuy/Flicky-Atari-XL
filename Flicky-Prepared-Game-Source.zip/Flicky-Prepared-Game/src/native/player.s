; Native player terrain response and controls. Positions retain arcade units.
.segment "FIXED"
.export player_contacts,player_controls,player_sample_terrain
.export n_contacts,n_blocked,n_action,n_exiting,n_sound_event,n_action_latch
.export n_frame,n_timer
.export n_animation
.export n_collision_wait

player_contacts:
    lda #4
    NATIVE_BANK
    jmp player_contacts_bank
player_controls:
    lda #4
    NATIVE_BANK
    jmp player_controls_bank
player_sample_terrain:
    lda #4
    NATIVE_BANK
    jmp player_sample_terrain_bank

.segment "BANK4"
; Eight surrounding solid-tile bits, clockwise from the upper left:
; 7 3 2
; 6 . 1
; 5 4 0
; The original collision hardware determines whether terrain response is due.
player_contacts_bank:
    lda #0
    sta n_blocked
    lda n_contacts
    and #$f0
    cmp #$c0
    bcs @left_wall
    cmp #$70
    beq @left_wall
    cmp #$60
    bne @right_check
@left_wall:
    lda n_grounded
    beq @bounce_left
    lda n_world
    and #14
    cmp #12
    bcs @right_check
    cmp #8
    bcc @right_check
@bounce_left:
    lda n_vx+CAMERA
    bmi @blocked
    clc
    adc #8
    eor #$ff
    clc
    adc #1
    sta n_vx+CAMERA
    lda #$d0
    bne @wall_target
@right_check:
    lda n_contacts
    and #$18
    cmp #$18
    beq @right_wall
    lda n_contacts
    and #15
    cmp #3
    beq @right_wall
    cmp #6
    beq @right_wall
    cmp #7
    bne @floor_check
@right_wall:
    lda n_grounded
    beq @bounce_right
    lda n_world
    and #14
    cmp #8
    bcs @floor_check
    cmp #4
    bcc @floor_check
@bounce_right:
    lda n_vx+CAMERA
    bpl @blocked
    eor #$ff
    clc
    adc #9
    sta n_vx+CAMERA
    lda #$30
@wall_target:
    sta n_target+CAMERA
    lda n_flags+CAMERA
    and #$f7
    sta n_flags+CAMERA
@blocked:
    lda #1
    sta n_blocked
@floor_check:
    lda n_contacts
    and #$31
    cmp #$31
    beq @floor_jump
    cmp #$30
    beq @floor_jump
    cmp #$11
    beq @floor_jump
    cmp #$20
    beq @edge_floor
    cmp #1
    bne @ceiling_check
@edge_floor:
    lda n_pose+PLAYER
    bne @ceiling_check
@floor_jump:
    jmp @floor
@ceiling_check:
    lda #0
    sta n_grounded
    lda n_contacts
    and #$8c
    cmp #$8c
    beq @ceiling_jump
    cmp #$88
    beq @ceiling_jump
    cmp #$0c
    beq @ceiling_jump
    lda n_ceiling
    bne @done
    lda n_contacts
    and #$42
    beq @free
    cmp #$42
    beq @vertical_direction
    lda n_blocked
    bne @free
    lda n_contacts
    cmp #$40
    beq @ledge_left
    cmp #2
    bne @vertical_direction
    lda #$18
    bne @ledge
@ledge_left:
    lda #$e8
@ledge:
    pha
    lda n_pose+PLAYER
    cmp #2
    bcs @ledge_cancel
    pla
    sta n_vx+CAMERA
    lda n_flags+CAMERA
    and #$f7
    sta n_flags+CAMERA
    lda #$80
    sta n_blocked
@free:
    lda #0
    sta n_ceiling
    sta n_grounded
    rts
@ledge_cancel:
    pla
@vertical_direction:
    lda n_vy+PLAYER
    bpl @floor
@ceiling_jump:
    jmp @ceiling
@done:
    rts
@ceiling:
    lda n_ceiling
    bne @done
    lda #1
    sta n_ceiling
    ldy #3
    lda n_contacts
    and #$42
    beq :+
    ldy #11
:   lda n_pose+PLAYER
    cmp #2
    bcs :+
    iny
    iny
    iny
:   sty n_step
    lda n_ylo+PLAYER
    and #$f8
    clc
    adc n_step
    sta n_ylo+PLAYER
    jmp motion_vertical_stop
@floor:
    lda n_grounded
    bne @done
    lda #1
    sta n_grounded
    ldy #1
    lda n_pose+PLAYER
    cmp #2
    bne :+
    lda n_contacts
    and #$42
    beq :+
    ldy #9
:   sty n_step
    lda n_ylo+PLAYER
    and #$f8
    beq @done
    sec
    sbc n_step
    sta n_ylo+PLAYER
    jmp motion_vertical_stop

player_controls_bank:
    lda n_exiting
    beq @input
    lda n_grounded
    beq :+
    jmp @stand
:   
    jmp @jump_pose
@input:
    lda #0
    sta n_action
    lda n_input
    eor #$ff
    and #6
    bne :+
    lda n_action_latch+PLAYER
    and #$7e
    sta n_action_latch+PLAYER
:   lda n_grounded
    beq @airborne
    jsr motion_vertical_stop
    lda n_flags+PLAYER
    and #4
    beq :+
    jmp @death_pose
:   lda n_input
    eor #$ff
    and #6
    beq @ground_pose
    lda n_action_latch+PLAYER
    and #1
    bne @action_edge
    lda n_action_latch+PLAYER
    ora #1
    sta n_action_latch+PLAYER
    lda #$d7
    sta n_vy+PLAYER
    lda #0
    sta n_grounded
    lda #$84
    sta n_sound_event
@action_edge:
    lda n_action_latch+PLAYER
    bmi @ground_pose
    ora #$80
    sta n_action_latch+PLAYER
    lda #1
    sta n_action
    bne @airborne
@ground_pose:
    lda n_blocked
    and #1
    bne @ground_speed
    lda n_vx+CAMERA
    beq @stand
    sta n_step
    lda n_acceleration+CAMERA
    bmi @positive_braking
    lda n_step
    bpl @ground_speed
    bmi @braking
@positive_braking:
    lda n_step
    bmi @ground_speed
@braking:
    lda #3
    sta n_animation+PLAYER
    bne @pose
@ground_speed:
    lda n_vx+CAMERA
    bne @walk
@stand:
    lda #0
    sta n_animation+PLAYER
    beq @pose
@walk:
    lda #1
    sta n_animation+PLAYER
    lda #0
    beq @pose
@airborne:
    ldx #PLAYER
    jsr motion_gravity
    jsr motion_integrate
    lda n_ylo+PLAYER
    cmp #$cb
    bcc :+
    lda #$cb
:   cmp #13
    bcs :+
    lda #13
:   sta n_ylo+PLAYER
    lda n_flags+PLAYER
    and #4
    bne @falling_death
    lda n_blocked
    bmi @jump_pose
    lda n_input
    eor #$ff
    and #6
    beq @air_pose
    lda n_action_latch+PLAYER
    bmi @air_pose
    ora #$80
    sta n_action_latch+PLAYER
    lda #1
    sta n_action
@air_pose:
    lda n_vx+CAMERA
    and #$f8
    bne @fast_jump
@jump_pose:
    lda #4
    sta n_animation+PLAYER
    lda #1
    bne @pose
@fast_jump:
    lda #2
    sta n_animation+PLAYER
@pose:
    ldy #1
    bne @animate
@falling_death:
    lda #5
    sta n_animation+PLAYER
    lda #1
    ldy #3
@animate:
    sta n_pose+PLAYER
    sty n_pose_mask
    lda n_timer+PLAYER
    beq @next_frame
    dec n_timer+PLAYER
    jmp @facing
@next_frame:
    lda #2
    sta n_timer+PLAYER
    lda n_frame+PLAYER
    clc
    adc #1
    and n_pose_mask
    sta n_frame+PLAYER
@facing:
    lda n_vx+CAMERA
    beq @throw
    bmi @face_right
    lda n_flags+PLAYER
    ora #1
    bne @face_store
@face_right:
    lda n_flags+PLAYER
    and #$fe
@face_store:
    sta n_flags+PLAYER
@throw:
    lda n_action
    bne @release
    lda n_vy+PLAYER
    bpl @done
    cmp #$e8
    bcs @done
    lda #1
    sta n_action
@release:
    lda n_action_latch+PLAYER
    and #$40
    beq @done
    lda n_action_latch+PLAYER
    and #$bf
    sta n_action_latch+PLAYER
    lda #$8a
    sta n_sound_event
    ; Carried-object launch is consumed by the native object system.
@done:
    rts
@death_pose:
    lda #5
    sta n_animation+PLAYER
    lda #0
    sta n_timer+PLAYER
    sta n_frame+PLAYER
    lda #1
    sta n_pose+PLAYER
    rts

player_sample_terrain_bank:
    lda #0
    sta n_contacts
    lda n_ylo+PLAYER
    ldx n_pose+PLAYER
    beq @height
    cpx #3
    beq @height
    sec
    sbc #8
@height:
    sta n_tile_y
    and #$18
    asl a
    asl a
    asl a
    sta n_ptr
    lda n_tile_y
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #>n_map
    sta n_ptr+1
    sec
    lda #0
    sbc n_world
    sta n_step
    lda #2
    sbc n_world+1
    lsr a
    lda n_step
    ror a
    lsr a
    lsr a
    lsr a
    clc
    adc #15
    and #31
    asl a
    ora #1
    sta n_column
    jsr @sample
    jsr @down
    jsr @sample
    jsr @down
    jsr @sample
    jsr @right
    jsr @sample
    jsr train_check_door
    sec
    lda n_ptr
    sbc #128
    sta n_ptr
    bcs :+
    dec n_ptr+1
:   jsr @sample
    jsr @right
    jsr @sample
    jsr @down
    jsr @sample
    jsr @down
    jmp @sample
@sample:
    ldy n_column
    lda (n_ptr),y
    and #$10
    cmp #$10
    rol n_contacts
    rts
@down:
    clc
    lda n_ptr
    adc #64
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   rts
@right:
    lda n_column
    clc
    adc #2
    and #63
    sta n_column
    rts
