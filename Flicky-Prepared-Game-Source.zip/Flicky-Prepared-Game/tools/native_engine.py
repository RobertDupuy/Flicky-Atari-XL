"""Cycle-counted NMOS 6502 test runner for the new native engine."""
import ctypes as C
import subprocess
import numpy as np
from build import ROOT, BUILD

class Engine:
    def __init__(self, cartridge=None, labels=None):
        library=BUILD/'native-engine.so'
        source=ROOT/'tests/atari_cpu.c'
        if not library.exists() or source.stat().st_mtime>library.stat().st_mtime:
            subprocess.run(['gcc','-std=c11','-O2','-fPIC','-shared',str(source),'-o',str(library)],check=True)
        self.labels={}
        for line in (labels or BUILD/'native/native.lbl').read_text().splitlines():
            fields=line.split()
            if len(fields)==3:self.labels[fields[2].lstrip('.')]=int(fields[1],16)
        self.lib=C.CDLL(str(library))
        self.lib.at_init.argtypes=[C.c_char_p,C.c_uint16]
        self.lib.at_memory.restype=C.POINTER(C.c_uint8)
        self.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
        self.lib.at_call.restype=C.c_int64
        self.lib.at_run.argtypes=[C.c_uint16,C.c_uint32]
        self.lib.at_run.restype=C.c_int64
        cartridge=cartridge or BUILD/'native/flicky-native-dev.car'
        data=cartridge.read_bytes()
        self.cart_type=int.from_bytes(data[4:8],'big')
        boot_address=self.labels['sic_boot']+(0x2000 if self.cart_type==110 else 0)
        assert self.lib.at_init(str(cartridge).encode(),boot_address)
        self.ram=np.ctypeslib.as_array(self.lib.at_memory(),shape=(65536,))
        self.memory=self.ram
        self.maximum={}
        boot=self.lib.at_run(self.labels['native_idle'],10_000_000)
        if boot<0:raise RuntimeError(f'Cartridge bootstrap did not finish at {self.lib.at_pc():04x}')
        self.boot_cycles=boot

    def call(self,name,a=0,x=0,y=0):
        cycles=self.lib.at_call(self.labels[name],a,x,y)
        if cycles<0:raise RuntimeError(f'{name} did not return; CPU {self.lib.at_pc():04x}')
        self.maximum[name]=max(cycles,self.maximum.get(name,0))
        return self.lib.at_a()

    def get(self,name,index=0):return int(self.ram[self.labels[name]+index])
    def set(self,name,value,index=0):self.ram[self.labels[name]+index]=value&255

