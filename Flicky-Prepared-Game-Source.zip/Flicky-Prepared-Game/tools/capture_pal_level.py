"""Play a rehearsed first-level route through ordinary keys, in real time.

The recorded emulator is never paused, patched, rewound, or level-selected.
Read-only observation verifies completion and stops after the results screen.
"""
import os
os.environ['FLICKY_MOVIE_VARIANT'] = 'pal'
import json
import time
from pathlib import Path
from raster_probe import Session
from capture_skillful import locate, state, keyset
from build import BUILD
import movie_plan as plan


def main():
    out = BUILD / 'native/pal-level-realtime'
    out.mkdir(exist_ok=True)
    video_name=f'capture-{time.time_ns()}.avi'
    old = json.loads((BUILD / 'native/pal-movie-complete/route.json').read_text())
    route = []
    for row in old:
        if row['status']['round'] != 0:
            break
        key = row['actions'][0][0]
        frame = round(row['seconds'] * 49.8607598)
        if not route or key != route[-1][1]:
            route.append([frame, key])
    (out / 'keys.json').write_text(json.dumps(route, indent=2) + '\n')
    session = Session(plan.CARTRIDGE, out, 'pal', sound=True, video_name=video_name)
    recording = False
    log = []
    try:
        fd, base = locate(session)
        session.record()
        recording = True
        time.sleep(.2)
        session.tap('Return')
        time.sleep(.6)
        session.tap('Control_R')
        time.sleep(.5)
        memory = state(fd, base)
        host_start = int(memory[0x7a2]) + 256 * int(memory[0x7a3])
        started = time.monotonic()
        next_key = 0
        next_sample = 0
        next_control = 0
        returning = False
        dropped = False
        completed = False
        while time.monotonic() - started < 27:
            memory = state(fd, base)
            frame = ((int(memory[0x7a2]) + 256 * int(memory[0x7a3])) - host_start) & 65535
            if plan.v(memory, 'n_round') >= 1:
                completed = True
                break
            held = plan.v(memory, 'n_train')
            rescued = plan.v(memory, 'n_rescued').bit_count()
            if held + rescued == 8:
                returning = True
            if not returning:
                while next_key < len(route) and frame >= route[next_key][0]:
                    keyset(session, route[next_key][1])
                    next_key += 1
            elif frame >= next_control:
                next_control = frame + 8
                px, py = plan.xy(memory)
                if py >= 185:
                    dropped = True
                target_x = 264 if dropped else 130
                raw = plan.v(memory, 'n_vx', 31)
                velocity = -(raw if raw < 128 else raw - 256) / 16
                stopping_x = px + velocity * abs(velocity) / .375
                if plan.v(memory, 'n_exiting') or plan.v(memory, 'u_mode'):
                    key = 255
                elif abs(target_x - px) < 10 and abs(velocity) < .8:
                    key = 255
                else:
                    key = 191 if stopping_x < target_x else 127
                keyset(session, key)
            if frame >= next_sample:
                record = {'frame': frame, **plan.status(memory),
                          'screen': plan.v(memory, 'u_mode'), 'bonus': plan.v(memory, 'n_bonus'),
                          'renderer_fault':plan.v(memory,'r_fault'),'queue_overflow':plan.v(memory,'c_overflow')}
                log.append(record)
                print(json.dumps(record), flush=True)
                next_sample += 10
            time.sleep(.001)
        keyset(session, 255)
        session.capture().save(out / 'end.png')
        session.record()
        recording = False
        report = {'video':video_name,'standard': 'PAL', 'continuous_real_time_recording': True,
                  'input_method': 'rehearsed human-style direction holds and jump taps',
                  'game_state_modified': False, 'emulator_paused': False,
                  'level_completed': completed,
                  'all_chicks_rescued': any(row['rescued'] == 255 for row in log),
                  'results_screen_shown': any(row['screen'] == 3 for row in log),
                  'bonus_round_shown': any(row['bonus'] for row in log),
                  'lives_remaining': plan.v(state(fd, base), 'n_lives'),
                  'renderer_faults':max(row['renderer_fault'] for row in log),
                  'queue_overflow':max(row['queue_overflow'] for row in log),
                  'route': log}
        (out / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({k:v for k,v in report.items() if k != 'route'}), flush=True)
        assert completed and report['all_chicks_rescued'] and report['results_screen_shown']
        assert not report['bonus_round_shown']
        assert report['renderer_faults']==report['queue_overflow']==0
    finally:
        if recording and session.emu.poll() is None:
            keyset(session, 255)
            session.record()
        session.close()


if __name__ == '__main__':
    main()
