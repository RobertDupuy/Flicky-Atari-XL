; Four original score-popup actors were updated but absent from the display
; submission. Draw them last, preserving their original position and lifetime.
d_actor=$07f3
.segment "FIXED"
.export delivery_draw
delivery_draw:
    lda #27
    NATIVE_BANK
    jmp delivery_draw_bank
delivery_blit:
    jsr fast_draw_prepared
    lda #27
    NATIVE_BANK
    rts
.segment "BANK27"
delivery_draw_bank:
    lda #20
    sta d_actor
@actor:
    ldx d_actor
    lda n_flags,x
    bpl @next
    ldy n_popup_value,x
    lda delivery_value_index,y
    tay
    asl a
    asl a
    sta p_index
    sec
    lda n_xlo,x
    sbc delivery_radius,y
    sta p_left
    lda n_xhi,x
    sbc #0
    and #1
    sta p_left+1
    lda n_ylo,x
    sec
    sbc #3
    sta p_y
    lda p_left
    lsr a
    lsr a
    and #3
    ora p_index
    tay
    lda delivery_lo,y
    sta p_image
    lda delivery_hi,y
    sta p_image+1
    lda delivery_banks,y
    sta p_imagebank
    lda #1
    sta p_visible
    lda #0
    sta p_object_mode
    sta f_floor_mode
    jsr delivery_blit
@next:
    inc d_actor
    lda d_actor
    cmp #24
    bcc @actor
    rts
.include "delivery-data.s"
