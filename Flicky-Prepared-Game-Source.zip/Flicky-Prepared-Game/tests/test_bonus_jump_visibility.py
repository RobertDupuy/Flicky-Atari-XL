"""Arcade jump controls and the requested black scenery, including exceptions."""
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import BUILD
from native_engine import Engine
from check_bonus_player import FIELDS
from scenery_visibility import black_wall
from fast_ui_assets import FONT

def test_bonus_jump_matches_original_instructions_and_sprite_landings():
    n=Engine();gold=np.load(BUILD/'native/arcade-bonus-player-golden.npz')
    starts=list(gold['starts'])+[len(gold['inputs'])]
    for run,(begin,end) in enumerate(zip(starts,starts[1:])):
        n.lib.at_video_timing(0);n.call('native_reset');n.set('n_round',2)
        n.call('game_round_load');n.set('u_wait',0)
        for (name,index,_),value in zip(FIELDS,gold['initial'][run]):n.set(name,int(value),index)
        for tick in range(begin,end):
            n.set('n_input',int(gold['inputs'][tick]));n.call('bonus_player_step')
            actual=[n.get(name,index) for name,index,_ in FIELDS]
            np.testing.assert_array_equal(actual,gold['expected'][tick],err_msg=f'run {run}, tick {tick-begin}')

def test_jump_works_through_game_controls_and_net_tracks_airborne_player():
    n=Engine();report=[]
    for stage in (2,14,46):
        n.lib.at_video_timing(0);n.call('native_reset');n.set('n_round',stage)
        n.call('game_round_load');n.set('u_wait',0)
        ys=[];jumps=0;previous_ground=1
        for tick in range(240):
            fire=10<=tick<180 or 200<=tick<205
            n.set('n_input',251 if fire else 255);n.call('game_update')
            y=n.get('n_ylo',8);ys.append(y)
            ground=n.get('n_grounded')
            if previous_ground and not ground:jumps+=1
            previous_ground=ground
            assert n.get('b_net_y')==(y+7)&255
            if tick==10:assert n.get('n_sound_event')==0x84
            if tick%2==0:
                back=(tick//2)&1;n.set('r_back',back);n.call('native_render_submit')
                assert n.get('r_fault')==0,(stage,tick)
        assert min(ys)<=108 and jumps==2,(stage,min(ys),jumps)
        report.append(dict(round=stage+1,jumps=jumps,minimum_y=min(ys),renderer_faults=0))
    (BUILD/'native/bonus-jump-render.json').write_text(json.dumps(report,indent=2)+'\n')

def test_all_round_backgrounds_blacken_only_wall_art_and_preserve_20_to_22():
    n=Engine();n.lib.at_video_timing(0)
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    index=(BUILD/'scenery-index.bin').read_bytes();glyphs=(BUILD/'scenery-glyphs.bin').read_bytes()
    messages=json.loads((BUILD/'native/static-messages.json').read_text())['backgrounds']
    checked=0
    for stage in range(48):
        if stage%4==2:continue
        n.call('native_reset');n.set('n_round',stage);n.call('level_load');n.call('display_build')
        raw=maps[stage*1792:(stage+1)*1792]
        assert bytes(n.ram[0xc000:0xc700])==raw
        entry=messages[stage];text={}
        for i,ch in enumerate(entry['message']):
            if ch!=' ':
                text[entry['row']*32+entry['column']+i]=bytes([0]+[sum(int(v)<<(6-2*x) for x,v in enumerate(line)) for line in FONT[ch].split()]+[0,0])
        for cell in range(896):
            tile=int.from_bytes(raw[cell*2:cell*2+2],'little')&2047
            ptr=index[tile]+256*index[2048+tile]-0x8000+((index[4096+tile]&127)-9)*8192
            expected=bytes(8) if black_wall(stage,tile) else glyphs[ptr:ptr+8]
            expected=text.get(cell,expected)
            row,col=divmod(cell,32)
            for back in (0,1):
                code=int(n.ram[0x6000+back*4096+row*96+col])
                addr=0x2000+back*8192+row//4*1024+(code&127)*8
                assert bytes(n.ram[addr:addr+8])==expected,(stage+1,row,col,tile)
            checked+=1
        assert n.get('r_fault')==0
    assert checked==36*896
