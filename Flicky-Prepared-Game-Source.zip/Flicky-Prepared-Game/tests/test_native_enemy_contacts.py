"""Source-resolution enemy collision ownership, independent of Atari pixels."""
import ctypes as C
import json
import random
import subprocess
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine
from run_reference import Reference

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    e=Engine()
    yield e
    (BUILD/'native/enemy-contact-cycles.json').write_text(json.dumps(e.maximum,indent=2)+'\n')

def test_enemy_contacts_match_pixel_priority_and_clipping(native):
    v=Reference();v.lib.fm_coll.restype=C.POINTER(C.c_uint8)
    data={kind:json.loads((BUILD/f'native/{kind}-assets.json').read_text()) for kind in ('player','chick','cat')}
    r=random.Random(0xf920)
    for trial in range(2048):
        v.ram[0xc000:]=0
        native.call('native_reset')
        world=r.randrange(65536);native.set('n_world',world);native.set('n_world',world>>8,1)
        center=r.randrange(40,190)
        cluster=r.choice([8,256,500])
        for actor in range(11):
            kind='chick' if actor<8 else 'player' if actor==8 else 'cat'
            pose=r.randrange({'chick':9,'player':6,'cat':21}[kind])
            variant=r.randrange(2 if kind=='chick' or kind=='player' and pose<5 else 4 if kind=='player' else 1)
            facing=r.randrange(2);screen=256 if actor==8 else max(0,min(511,cluster+r.randrange(-28,29)))
            height=center+r.randrange(-16,17);offset=r.randrange(-3,4) if actor<8 else int(pose==3) if actor==8 else 0
            visible=int(r.randrange(12)!=0 or actor==8)
            native.set('n_flags',(0xb0|facing|(2 if kind=='cat' and pose>=18 else 0)) if visible else 0,actor)
            native.set('n_animation',[5,7,8][pose-18] if kind=='cat' and pose>=18 else pose,actor)
            native.set('n_frame',variant,actor);native.set('n_ylo',height,actor)
            native.set('n_draw_yoffset',offset,actor)
            native.set('n_enemy_contact',0,actor)
            if actor==8:native.set('n_pose',[0,0,2,3,1,1][pose],8)
            p=screen if actor==8 else (screen-world)&65535
            native.set('n_xlo',p,actor);native.set('n_xhi',p>>8,actor)
            if not visible:continue
            entry=data[kind]['records'][pose*{'chick':16,'player':32,'cat':8}[kind]+variant*8+facing*4]
            h=entry['height'];stride=entry['stride'];source=entry['source']
            flip=kind=='cat' and pose>=18
            if flip:source+=stride*(h-1)
            if facing:source=(source+stride-2)|0x8000
            delta=-stride if flip else stride
            source=(source-delta)&65535;top=(height+offset-h//2)&255;left=(screen-2*(stride-1))&511
            start=0xd000+actor*16
            v.ram[start:start+8]=[top,(top+h)&255,left&255,left>>8,delta&255,(delta>>8)&255,source&255,source>>8]
        v.lib.fm_render_snapshot(0)
        native.call('enemy_contacts')
        matrix=v.lib.fm_coll()
        for actor in range(8):
            expected=int(bool(matrix[9*32+actor] or matrix[10*32+actor]))
            assert native.get('n_enemy_contact',actor)==expected,(trial,actor,cluster)
        expected=int(bool(matrix[9*32+8]))+2*int(bool(matrix[10*32+8]))
        assert native.get('n_player_enemy')==expected,(trial,'player',cluster)


def test_lookup_single_actor_matches_silhouettes_without_pixel_scan(native):
    data={kind:json.loads((BUILD/f'native/{kind}-assets.json').read_text()) for kind in ('player','chick','cat')}
    shapes={}
    for kind,asset in data.items():
        for index in range(0,len(asset['records']),4):
            record=asset['records'][index];mid=asset['masks'][index]
            raw=(BUILD/f'native/{kind}-maskshift-{mid:03}-0.bin').read_bytes()
            radius=2*(record['stride']-1);height=record['height']
            pixels={(2*bit+sub-radius,y-height//2) for y in range(height) for bit in range(32)
                    if raw[y*4+bit//8]&(128>>(bit&7)) for sub in (0,1)}
            shapes[kind,index//4]=pixels
    r=random.Random(0xc0111de)
    for trial in range(8192):
        native.call('native_reset');native.set('n_flags',0,8)
        kind=r.choice(['player','chick','cat']);actor={'player':8,'chick':0,'cat':9}[kind]
        enemy=10 if actor==9 else 9
        pose=r.randrange({'player':6,'chick':9,'cat':21}[kind]);catpose=r.randrange(21)
        frame=r.randrange(4) if kind=='player' else r.randrange(2) if kind=='chick' else 0
        if kind=='player' and pose<5:frame&=1
        face=r.randrange(2);catface=r.randrange(2)
        dx=r.randrange(-48,49);dy=r.randrange(-32,33)
        native.set('n_world',0);native.set('n_world',0,1)
        for a,po,fr,fa,x,y in [(actor,pose,frame,face,256+dx,100+dy),(enemy,catpose,0,catface,256,100)]:
            cat=a>=9
            native.set('n_flags',0xb0|fa|(2 if cat and po>=18 else 0),a)
            native.set('n_animation',[5,7,8][po-18] if cat and po>=18 else po,a)
            native.set('n_frame',fr,a);native.set('n_xlo',x,a);native.set('n_xhi',x>>8,a);native.set('n_ylo',y,a)
            native.set('n_draw_yoffset',0,a);native.set('n_enemy_contact',0,a)
        if kind=='player':native.set('n_pose',[0,0,2,3,1,1][pose],actor)
        aindex=pose*({'player':8,'chick':4,'cat':2}[kind])+frame*2+face
        bindex=catpose*2+catface
        offset=int(kind=='player' and pose==3)
        expected=bool({(x+dx,y+dy+offset) for x,y in shapes[kind,aindex]}&shapes['cat',bindex])
        native.call('enemy_contacts')
        actual=native.get('n_player_enemy') if kind=='player' else native.get('n_enemy_contact',actor) if kind=='chick' else 0
        assert actual==int(expected and kind!='cat'),(trial,kind,pose,catpose,dx,dy)
    # Ordinary nearby one-on-one hits are table reads, with no mask expansion.
    native.call('native_reset');native.set('n_flags',0,8)
    for actor in (0,9):
        native.set('n_flags',0xb0,actor);native.set('n_animation',0,actor)
        native.set('n_frame',0,actor);native.set('n_ylo',100,actor)
        native.set('n_draw_yoffset',0,actor);native.set('n_enemy_contact',0,actor)
        native.set('n_xlo',8,actor);native.set('n_xhi',255,actor)
    elapsed=native.lib.at_call(native.labels['enemy_contacts'],0,0,0)
    assert 0<elapsed<3500,elapsed
    assert native.get('n_enemy_contact',0)==1
