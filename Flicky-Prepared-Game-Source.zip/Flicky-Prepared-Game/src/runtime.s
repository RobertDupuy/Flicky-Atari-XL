; Stage 1: deliberately slow, explicit Z80 architectural state.
; No OS zero-page dependencies: cartridge owns the machine after startup.
.segment "ZEROPAGE"
.exportzp z_a,z_f,z_b,z_c,z_d,z_e,z_h,z_l,z_sp,z_pc,z_r,z_cycles,z_m1
.exportzp z_operand,z_halted,z_fault,z_addr,z_input,z_output
z_a: .res 1
z_f: .res 1
z_b: .res 1
z_c: .res 1
z_d: .res 1
z_e: .res 1
z_h: .res 1
z_l: .res 1
z_sp: .res 2
z_pc: .res 2
z_r: .res 1
z_cycles: .res 4
z_m1: .res 4
z_operand: .res 1
z_halted: .res 1
z_fault: .res 1
z_addr: .res 2
z_host: .res 2
z_input: .res 1
z_output: .res 1
z_old: .res 1
z_result: .res 1
z_status: .res 1
z_kind: .res 1
z_temp: .res 1

.segment "CODE"
.export z_reset,z_tick,z_fetch,z_alu,z_inc8,z_dec8,z_read,z_write,z_read_hl,z_write_hl,z_in,z_out
z_reset:
    lda #0
    ldx #z_temp-z_a
@clear:
    sta z_a,x
    dex
    bpl @clear
    rts

; A = nominal Z80 T states. Track M1 separately for the System 1 divider.
z_tick:
    clc
    adc z_cycles
    sta z_cycles
    bcc @done
    inc z_cycles+1
    bne @done
    inc z_cycles+2
    bne @done
    inc z_cycles+3
@done:
    rts
z_fetch:
    inc z_m1
    bne @r
    inc z_m1+1
    bne @r
    inc z_m1+2
    bne @r
    inc z_m1+3
@r:
    lda z_r
    and #$80
    sta z_temp
    lda z_r
    clc
    adc #1
    and #$7f
    ora z_temp
    sta z_r
    rts

; X selects ADD ADC SUB SBC AND XOR OR CP. Decimal mode is always off.
z_alu:
    stx z_kind
    lda z_a
    sta z_old
    cpx #4
    bcs @logical
    cpx #2
    bcs @subtract
    cpx #0
    beq @add_no_carry
    lda z_f
    lsr a
    lda z_a
    jmp @add
@add_no_carry:
    clc
@add:
    adc z_operand
    jmp arithmetic_result
@subtract:
    cpx #2
    beq @sub_no_carry
    lda z_f
    eor #1
    lsr a
    lda z_a
    jmp @sub
@sub_no_carry:
    sec
@sub:
    sbc z_operand
    jmp arithmetic_result
@logical:
    cpx #7
    bne @not_cp
    sec
    sbc z_operand
    jmp arithmetic_result
@not_cp:
    cpx #4
    bne @not_and
    and z_operand
    tax
    lda z_parity_flags,x
    ora #$10
    jmp logical_result
@not_and:
    cpx #5
    bne @or
    eor z_operand
    jmp @logical_flags
@or:
    ora z_operand
@logical_flags:
    tax
    lda z_parity_flags,x
logical_result:
    sta z_f
    stx z_a
    rts
arithmetic_result:
    sta z_result
    php
    pla
    sta z_status
    ldx z_result
    lda z_sz_flags,x
    sta z_f
    lda z_old
    eor z_operand
    eor z_result
    and #$10
    ora z_f
    sta z_f
    lda z_status
    and #$40
    lsr a
    lsr a
    lsr a
    lsr a
    ora z_f
    sta z_f
    ldx z_kind
    cpx #2
    bcc @add_carry
    lda z_status
    eor #1
    and #1
    ora #2
    jmp @carry
@add_carry:
    lda z_status
    and #1
@carry:
    ora z_f
    sta z_f
    cpx #7
    beq @cp_flags
    lda z_result
    sta z_a
    rts
@cp_flags:
    lda z_f
    and #$d7
    sta z_f
    lda z_operand
    and #$28
    ora z_f
    sta z_f
    rts

; INC/DEC affect the specified operand, preserve virtual A and carry.
z_inc8:
    sta z_old
    clc
    adc #1
    tax
    lda z_sz_flags,x
    sta z_temp
    lda z_old
    and #$0f
    cmp #$0f
    bne @no_half
    lda z_temp
    ora #$10
    sta z_temp
@no_half:
    lda z_old
    cmp #$7f
    bne incdec_finish
    lda z_temp
    ora #4
    sta z_temp
    jmp incdec_finish
z_dec8:
    sta z_old
    sec
    sbc #1
    tax
    lda z_sz_flags,x
    ora #2
    sta z_temp
    lda z_old
    and #$0f
    bne @no_half
    lda z_temp
    ora #$10
    sta z_temp
@no_half:
    lda z_old
    cmp #$80
    bne incdec_finish
    lda z_temp
    ora #4
    sta z_temp
incdec_finish:
    lda z_f
    and #1
    ora z_temp
    sta z_f
    txa
    rts

; Diagnostic bus only: guest C000-EFFF -> host 4000-6FFF.
; Guest addresses never access Atari MMIO directly.
z_map:
    lda z_addr+1
    cmp #$c0
    bcc @fault
    cmp #$f0
    bcs @fault
    sec
    sbc #$80
    sta z_host+1
    lda z_addr
    sta z_host
    clc
    rts
@fault:
    lda #1
    sta z_fault
    sec
    rts
z_read_hl:
    lda z_l
    sta z_addr
    lda z_h
    sta z_addr+1
z_read:
    jsr z_map
    bcs @fault
    ldy #0
    lda (z_host),y
    rts
@fault:
    lda #$ff
    rts
z_write_hl:
    pha
    lda z_l
    sta z_addr
    lda z_h
    sta z_addr+1
    pla
z_write:
    pha
    jsr z_map
    bcs @fault
    pla
    ldy #0
    sta (z_host),y
    rts
@fault:
    pla
    rts
; Single diagnostic port, intentionally separate from the future Sega PIO.
z_in:
    lda z_addr
    beq @valid
    lda #3
    sta z_fault
    lda #$ff
    rts
@valid:
    lda z_input
    rts
z_out:
    lda z_addr
    beq @valid
    lda #3
    sta z_fault
    rts
@valid:
    lda z_a
    sta z_output
    rts

.segment "RODATA"
.align 256
z_sz_flags:
.repeat 256, I
    .byte (I & $a8) | ((I = 0) * $40)
.endrepeat
z_parity_flags:
.repeat 256, I
    .byte (I & $a8) | ((I = 0) * $40) | (((((I >> 0) ^ (I >> 1) ^ (I >> 2) ^ (I >> 3) ^ (I >> 4) ^ (I >> 5) ^ (I >> 6) ^ (I >> 7)) & 1) ^ 1) * 4)
.endrepeat
