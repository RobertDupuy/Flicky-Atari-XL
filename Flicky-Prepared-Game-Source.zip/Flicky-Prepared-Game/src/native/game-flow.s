; Native life and round transitions. Coordinates of unrescued chicks survive a
; lost life; a new round gets its own initial actor data and collision map.
n_flow=$07c2
n_flow_wait=$07c3
n_round_seconds=$07c7
n_round_clock=$07c9
n_flow_armed=$07ca
.segment "HIGHRAM"
.export game_flow_tick,game_life_restart,game_round_load
.export n_flow,n_flow_wait,n_round_seconds,n_round_clock
; Return A=1 while normal actor updates should run, zero during a transition.
game_flow_tick:
    lda n_flow
    bne @waiting
    lda n_life_lost
    beq @round
    lda #0
    sta n_life_lost
    dec n_lives
    beq @game_over
    lda #1
    sta n_flow
    lda #55
    bne @begin_wait
@game_over:
    lda #3
    sta n_flow
    lda #0
    sta n_flow_armed
    lda #$87
    sta n_sound_event
    lda #123
    bne @begin_wait
@round:
    lda n_round_complete
    beq @play
    lda n_flags+23
    bmi @play
    lda #2
    sta n_flow
    lda #$8e
    sta n_sound_event
    jsr game_time_bonus
    jsr message_result
    lda #240
@begin_wait:
    sta n_flow_wait
    lda #0
    rts
@play:
    lda #1
    rts
@waiting:
    lda n_flow_wait
    beq @finished_wait
    dec n_flow_wait
    lda #0
    rts
@finished_wait:
    lda n_flow
    cmp #1
    beq @life
    cmp #2
    beq @next_round
    lda n_input
    and #4
    beq @pressed
    lda #1
    sta n_flow_armed
    lda #0
    rts
@pressed:
    lda n_flow_armed
    beq @done
    jsr native_reset
    jsr game_round_load
    lda #0
    rts
@life:
    jsr game_life_restart
    lda #0
    rts
@next_round:
    inc n_round
    jsr game_round_load
@done:
    lda #0
    rts

game_time_bonus:
    lda n_bonus
    beq :+
    rts
:   
    ldy #5
    lda n_round_seconds+1
    bne @points
    lda n_round_seconds
    ldy #0
    cmp #20
    bcc @points
@step:
    iny
    sec
    sbc #10
    cmp #20
    bcc @points
    cpy #5
    bcc @step
@points:
    lda game_time_bonus_thousands,y
    sta u_time_bonus
    ; The Z80 score/table at $1671 is in tens of points. Native score
    ; bytes are actual points: 20,000 / 10,000 / 5,000 / 3,000 / 1,000.
    sed
    clc
    lda game_time_bonus_middle,y
    adc n_score+1
    sta n_score+1
    lda game_time_bonus_high,y
    adc n_score+2
    sta n_score+2
    cld
    rts
; All six awards have a zero low BCD byte.
game_time_bonus_thousands:
.byte $20,$10,$05,$03,$01,$00
game_time_bonus_middle:
.byte $00,$00,$50,$30,$10,$00
game_time_bonus_high:
.byte $02,$01,$00,$00,$00,$00

game_round_load:
    lda #0
    sta u_mode
    lda #1
    sta c_paused
    lda #0
    sta $d400
    sta $d40e
    jsr level_load
    jsr chicks_reset
    lda #0
    sta n_round_seconds
    sta n_round_seconds+1
    sta n_round_clock
    jmp game_life_restart_disabled

game_life_restart:
    lda #1
    sta c_paused
    lda #0
    sta $d400
    sta $d40e
game_life_restart_disabled:
    lda #0
    ldx #8
@actors:
    .repeat 16,I
        sta $0800+I*32,x
    .endrepeat
    .repeat 8,I
        sta $c700+I*32,x
    .endrepeat
    inx
    cpx #32
    bcc @actors
    ldx #0
@trail:
    sta $1b00,x
    sta $1c00,x
    inx
    bne @trail
    sta n_flow
    sta n_flow_wait
    sta n_life_lost
    sta n_train
    sta n_pickup
    sta n_delivered
    sta n_round_complete
    sta n_exiting
    sta n_ceiling
    sta n_contacts
    sta n_blocked
    sta n_collision_wait
    sta n_action
    sta n_player_enemy
    sta n_game_ticks
    sta n_world
    lda #$f8
    sta n_world
    lda #1
    sta n_world+1
    sta n_xhi+PLAYER
    sta n_grounded
    lda #$80
    sta n_flags+PLAYER
    lda #$81
    sta n_action_latch+PLAYER
    lda #$30
    sta n_target+CAMERA
    lda #2
    sta n_acceleration+CAMERA
    lda #39
    sta n_history_yindex
    sta n_history_xindex
    ldx n_layout
    lda native_player_start_y,x
    ldx n_bonus
    beq :+
    lda #$9f
:   sta n_ylo+PLAYER
    ; The source preserves free chicks but resets their animation descriptor.
    lda n_round
    and #$fc
    lsr a
    cmp #4
    bcc :+
    lda #4
:   eor #255
    clc
    adc #8
    sta c_temp
    ldx #0
@chick:
    txa
    asl a
    asl a
    asl a
    sta n_bob,x
    lda #5
    sta n_animation,x
    lda #0
    sta n_enemy_contact,x
    sta n_draw_yoffset,x
    sta n_frame,x
    txa
    cmp c_temp
    bcc :+
    beq :+
    inc n_frame,x
:   inx
    cpx #8
    bcc @chick
    jsr enemies_reset
    jsr objects_reset
    jsr bonus_reset
    jsr display_build
    jsr idle_reset
    jsr floor_cache_reset
    jsr ui_init
    jsr pmg_init
    jsr prime_floor_objects
    jsr prepared_terrain_load
    lda #0
    sta r_back
    sta r_pending
    sta r_pace_started
    sta r_interval
    jsr display_scroll
    lda #1
    sta r_back
    jsr display_scroll
    jsr quick_player_terrain
    jsr quick_contacts
    jsr display_theme
    jsr native_render_submit
    ; Install event-only fonts/raster code while the loading pause is active.
    ; The first visible bonus frame must not race a font copy or accrue input.
    jsr message_bonus_intro
    ; Loading is an intentional pause: discard queued input from before it.
    lda c_produced
    sta c_consumed
    lda c_produced+1
    sta c_consumed+1
    lda #0
    sta c_paused
    lda #$3d
    sta $d400
    lda #$c0
    sta $d40e
    lda #$82
    ldx n_bonus
    beq :+
    lda #$81
:   
    sta n_sound_event
    rts
