#!/usr/bin/env python3
"""Normal-speed native-game probe; legacy reference mode uses explicit turbo."""
import os,subprocess,time,json,sys,re
from Xlib import X,XK,display
from Xlib.ext import xtest
from PIL import Image
from build import ROOT,BUILD,executable
from hardware_model import HOST_FPS

def main():
    env=os.environ.copy();env['LD_LIBRARY_PATH']=str(ROOT.parent/'toolchain/root/usr/lib/x86_64-linux-gnu')
    env['DISPLAY']='127.0.0.1:105';env['SDL_VIDEODRIVER']='x11'
    native='--native' in sys.argv
    crowded='--crowded' in sys.argv
    out=BUILD/'native'/('emulator-crowded' if crowded else 'emulator') if native else BUILD/'game-emulator';out.mkdir(exist_ok=True)
    cartridge=BUILD/'native/flicky-native-dev.car' if native else BUILD/'flicky-compact.car'
    with (out/'xvfb.log').open('w') as xl:
        xvfb=subprocess.Popen([executable('Xvfb'),':105','-screen','0','900x700x24','-ac','-nolisten','unix','-nolisten','local','-listen','tcp'],env=env,stdout=xl,stderr=xl)
        try:
            time.sleep(1);d=display.Display(env['DISPLAY'])
            for standard in ['ntsc','pal']:
                with (out/(standard+'.log')).open('w') as log:
                    emu=subprocess.Popen([executable('atari800'),'-config',str(BUILD/'atari800.cfg'),'-xl','-xl-rev','altirra','-nobasic','-'+standard,'-nosound','-windowed','-no-video-accel','-stretch','2']+([] if native else ['-turbo'])+['-cart',str(cartridge)],env=env,stdin=subprocess.PIPE,stdout=log,stderr=log)
                    try:
                        time.sleep(3)
                        windows=[w for w in d.screen().root.query_tree().children if 'Atari' in (w.get_wm_name() or '')]
                        assert windows
                        w=windows[0];w.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync()
                        def key(name,down):
                            xtest.fake_input(d,X.KeyPress if down else X.KeyRelease,d.keysym_to_keycode(XK.string_to_keysym(name)));d.sync()
                        def capture(label):
                            g=w.get_geometry();data=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff)
                            im=Image.frombytes('RGB',(g.width,g.height),data.data,'raw','BGRX')
                            im.save(out/f'{standard}-{label}.png')
                            print(standard,label,'colors',len(im.getcolors(maxcolors=1000000)),flush=True)
                        capture('boot')
                        key('Control_R',True);time.sleep(.15);key('Control_R',False);time.sleep(.5)
                        if crowded:
                            # Start a reproducible full-flock gameplay scene, then
                            # run ordinary game code and input at normal speed.
                            key('F8',True);time.sleep(.1);key('F8',False);time.sleep(.15)
                            commands=['c 0707 00 01','c 0714 08 00','f 0800 0807 b0','f c700 c707 01',
                                      'c c720 00 01 02 03 04 05 06 07','f 0860 0868 c7',
                                      'f 1b00 1b27 c7','f 1b40 1ba7 00',
                                      'f 1bc0 1bc7 00','f 1bc8 1bcf 01',
                                      'c 0809 b0 b1','c 0829 50 90','c 0849 00 01',
                                      'c 0869 70 70','c c709 00 00','c c789 00 00',
                                      'c 0989 00 00','c 07a0 00 00 00 00','c 068e 00','cont']
                            emu.stdin.write(('\n'.join(commands)+'\n').encode());emu.stdin.flush();time.sleep(.1)
                        key('KP_6',True)
                        for i in range(1 if crowded else 12 if native else 4):
                            if native and i==1:key('Control_R',True)
                            if native and i==2:key('Control_R',False)
                            time.sleep(1 if native else 5)
                            if crowded or not native or i in (0,3,7,11):capture(f'play-{i}')
                        key('KP_6',False)
                        key('F8',True);time.sleep(.15);key('F8',False);time.sleep(.3)
                        emu.stdin.write(b'antic\ngtia\nm 0010\nm 0200\nm 1500\nm 1600\nm 2000\nm 4000\nm 0080\nm 0600\nm 0640\nm 0700\nm 0800\nm c000\nm c300\nm 7000\nquit\n');emu.stdin.flush();emu.wait(timeout=5)
                    finally:
                        if emu.poll() is None:emu.terminate();emu.wait(timeout=5)
            d.close()
            if native:
                results={}
                for mode in ('ntsc','pal'):
                    memory={}
                    dump=re.sub(r'\x1b\[[0-9;]*m','',(out/(mode+'.log')).read_text())
                    for match in re.finditer(r'(?m)^([0-9A-F]{4}):((?: [0-9A-F]{2}){16})',dump):
                        address=int(match[1],16)
                        for offset,value in enumerate(match[2].split()):memory[address+offset]=int(value,16)
                    word=lambda address:memory[address]+256*memory[address+1]
                    presented=word(0x07a0);frames=word(0x07a2)
                    results[mode]={'host_frames':frames,'presented_frames':presented,
                        'displayed_fps':round(presented*float(HOST_FPS[mode])/frames,3),
                        'logical_updates_produced':word(0x0680),'logical_updates_consumed':word(0x0682),
                        'queue_peak':memory[0x068e],'queue_overflow':memory[0x068d],
                        'renderer_fault':memory[0x064a]}
                (out/'throughput.json').write_text(json.dumps(results,indent=2)+'\n')
                print(json.dumps(results,indent=2),flush=True)
        finally:
            xvfb.terminate();xvfb.wait(timeout=5)
if __name__=='__main__':main()
