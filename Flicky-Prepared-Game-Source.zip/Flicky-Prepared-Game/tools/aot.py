#!/usr/bin/env python3
"""Translate reachable original Flicky instructions into banked NMOS 6502.

The generated program keeps the original Z80 ABI and memory/stack semantics.
Direct control transfers stay direct; indirect transfers use a checked map.
"""
import ctypes as C,json,re,sys
from pathlib import Path
from collections import deque,Counter
from run_reference import Reference
from build import ROOT,BUILD,executable

PAIR={'BC':('z_c','z_b'),'DE':('z_e','z_d'),'HL':('z_l','z_h'),'IX':('z_ix','z_ix+1'),'IY':('z_iy','z_iy+1'),'SP':('z_sp','z_sp+1'),'AF':('z_f','z_a')}
REG={x:'z_'+x.lower() for x in ['A','F','B','C','D','E','H','L','I','R']}
REG.update({'IXH':'z_ix+1','IXL':'z_ix','IYH':'z_iy+1','IYL':'z_iy'})
COND={'NZ':(0x40,False),'Z':(0x40,True),'NC':(1,False),'C':(1,True),'PO':(4,False),'PE':(4,True),'P':(0x80,False),'M':(0x80,True)}
ALU={'ADD':0,'ADC':1,'SUB':2,'SBC':3,'AND':4,'XOR':5,'OR':6,'CP':7}

def number(s):
    if s.endswith('h'):return int(s[:-1],16)
    return int(s)

def split(text):
    a=text.split(' ',1)
    return a[0],a[1].split(',') if len(a)>1 else []

def get_graph():
    r=Reference()
    r.lib.fm_disassemble.argtypes=[C.c_uint16,C.c_char_p,C.c_int]
    buf=C.create_string_buffer(128)
    roots={0,0x38}
    for f in (BUILD/'reference').glob('*profile.json'):
        if 'sound' not in f.name:roots|={int(s,16) for s in json.loads(f.read_text())}
    pending=deque(roots);ins={}
    while pending:
        pc=pending.popleft()
        if pc in ins:continue
        if not 0<=pc<0x8000:raise ValueError(f'Unexpected executable address {pc:04X}')
        end=r.lib.fm_disassemble(pc,buf,0)
        text=buf.value.decode();op,args=split(text)
        succ=[]
        if op in ['JP','JR','CALL','DJNZ']:
            dest=args[-1]
            if not dest.startswith('('):succ.append(number(dest))
            if op in ['CALL','DJNZ'] or len(args)>1:succ.append(end)
        elif op=='RET' or op in ['RETI','RETN']:
            if args:succ.append(end)
        elif op=='RST':succ+=[number(args[0]),end]
        else:succ.append(end)
        ins[pc]={'pc':pc,'end':end,'text':text,'op':op,'args':args,'successors':succ}
        pending.extend(succ)
    (BUILD/'reference/reachable.json').write_text(json.dumps(list(sorted(ins.values(),key=lambda x:x['pc'])),indent=2))
    return ins

def imm(v):return f'#${v&255:02x}'
def reg16(pair):return PAIR[pair]
def setaddr(n):return [f'lda {imm(n)}','sta z_addr',f'lda {imm(n>>8)}','sta z_addr+1']
def read8(s):
    if s in REG:return ['lda '+REG[s]]
    if not s.startswith('('):return ['lda '+imm(number(s))]
    inner=s[1:-1]
    if inner in ['HL','BC','DE']:return ['jsr read_'+inner.lower()]
    m=re.fullmatch(r'(IX|IY)([+-]\d+)',inner)
    if m:return ['lda '+imm(int(m[2])),'jsr read_'+m[1].lower()]
    n=number(inner)
    if 0xc000<=n<0xf000:
        n=n-0x6000 if 0xd000<=n<0xd800 else n
        return [f'lda ${n:04x}']
    return setaddr(n)+['jsr bus_read']
def write8(s):
    if s in REG:return ['sta '+REG[s]]
    inner=s[1:-1]
    if inner in ['HL','BC','DE']:return ['jsr write_'+inner.lower()]
    m=re.fullmatch(r'(IX|IY)([+-]\d+)',inner)
    if m:return ['ldx '+imm(int(m[2])),'jsr write_'+m[1].lower()]
    n=number(inner)
    if 0xe000<=n<0xf000 and n not in [0xeffc,0xeffd,0xefbd]:
        return ['pha']+setaddr(n)+['pla','jsr bus_write']
    if 0xc000<=n<0xf000:
        n=n-0x6000 if 0xd000<=n<0xd800 else n
        return [f'sta ${n:04x}']
    return ['pha']+setaddr(n)+['pla','jsr bus_write']
def read16(s):
    if s in PAIR:
        lo,hi=PAIR[s];return ['lda '+lo,'ldx '+hi]
    if s.startswith('('):
        n=number(s[1:-1])
        if 0xc000<=n<0xefff and n!=0xcfff and n!=0xd7ff:
            n=n-0x6000 if 0xd000<=n<0xd800 else n
            return [f'lda ${n:04x}',f'ldx ${n+1:04x}']
        return setaddr(n)+['jsr bus_read16']
    n=number(s);return ['lda '+imm(n),'ldx '+imm(n>>8)]
def write16(s):
    if s in PAIR:
        lo,hi=PAIR[s];return ['sta '+lo,'stx '+hi]
    n=number(s[1:-1])
    if 0xe000<=n<0xf000 and n!=0xeffc:
        return ['sta z_word','stx z_word+1']+setaddr(n)+['jsr bus_write16']
    if 0xc000<=n<0xefff and n!=0xcfff and n!=0xd7ff:
        n=n-0x6000 if 0xd000<=n<0xd800 else n
        return [f'sta ${n:04x}',f'stx ${n+1:04x}']
    return ['sta z_word','stx z_word+1']+setaddr(n)+['jsr bus_write16']

def condition(cc,skip):
    mask,yes=COND[cc]
    return ['lda z_f','and '+imm(mask),f'{"beq" if yes else "bne"} {skip}']

def native(ins,bankmap=None):
    pc,end,op,args=ins['pc'],ins['end'],ins['op'],ins['args'];out=[]
    terminal=False
    def jump(target):
        if bankmap and target not in bankmap:
            return [f'lda {imm(target)}',f'ldx {imm(target>>8)}','jmp dispatch_ax']
        if bankmap and bankmap[pc]==bankmap[target]:return [f'jmp g_{target:04x}']
        bank=bankmap[target] if bankmap else 0
        return ['jsr far_jump',f'.word g_{target:04x}',f'.byte {bank}']
    if op=='NOP':out=[]
    elif op=='LD':
        dst,src=args
        if dst in PAIR or src in PAIR:out=read16(src)+write16(dst)
        else:out=read8(src)+write8(dst)
    elif op in ALU:
        if args[0] in ['HL','IX','IY'] and len(args)==2:
            dst,src=args
            out=read16(src)+['sta z_word','stx z_word+1',f'ldx #{PAIR[dst][0]}',f'ldy #{0 if op=="ADD" else 1 if op=="ADC" else 2}','jsr alu16']
        else:
            out=read8(args[-1])+['sta z_operand',f'ldx #{ALU[op]}','jsr alu8']
    elif op in ['INC','DEC']:
        operand=args[0]
        if operand in PAIR:
            lo,hi=PAIR[operand]
            out=[f'inc {lo}',f'bne incdone_{pc:04x}',f'inc {hi}',f'incdone_{pc:04x}:'] if op=='INC' else [f'lda {lo}',f'bne decdone_{pc:04x}',f'dec {hi}',f'decdone_{pc:04x}:',f'dec {lo}']
        else:out=read8(operand)+['jsr '+('inc8' if op=='INC' else 'dec8')]+write8(operand)
    elif op in ['JP','JR','CALL','DJNZ','RST']:
        cc=args[0] if len(args)>1 else None
        if op=='DJNZ':out=['dec z_b',f'beq skip_{pc:04x}']
        elif cc:out=condition(cc,f'skip_{pc:04x}')
        if op in ['CALL','RST']:
            if bankmap and end not in bankmap:
                out += [f'lda {imm(end)}',f'ldx {imm(end>>8)}','jsr push_ax']
            else:
                out+=['jsr push_return',f'.word ${end:04x}',f'.word g_{end:04x}',f'.byte {bankmap[end] if bankmap else 0}']
        dest=args[-1]
        if dest.startswith('('):out+=read16(dest[1:-1])+['jmp dispatch_ax']
        else:out+=jump(number(dest))
        if cc or op=='DJNZ':out+=[f'skip_{pc:04x}:']
        else:terminal=True
    elif op in ['RET','RETI','RETN']:
        if args:out=condition(args[0],f'skip_{pc:04x}')
        out+=['jmp return_guest']
        if args:out+=[f'skip_{pc:04x}:']
        else:terminal=True
    elif op=='PUSH':out=read16(args[0])+['jsr push_ax']
    elif op=='POP':out=['jsr pop_ax']+write16(args[0])
    elif op=='EX':
        if args==['DE','HL']:
            out=['lda z_e','ldx z_l','sta z_l','stx z_e','lda z_d','ldx z_h','sta z_h','stx z_d']
        elif args==['AF',"AF'"]:out=['jsr ex_af']
        elif args[0]=='(SP)':out=[f'ldx #{PAIR[args[1]][0]}','jsr ex_sp']
        else:raise ValueError(ins)
    elif op=='EXX':out=['jsr exx']
    elif op in ['BIT','SET','RES']:
        bit,operand=number(args[0]),args[1]
        out=read8(operand)
        if op=='SET':out+=['ora '+imm(1<<bit)]+write8(operand)
        elif op=='RES':out+=['and '+imm(255^(1<<bit))]+write8(operand)
        else:out+=['ldx '+imm(bit),'jsr bit8']
    elif op in ['RLC','RRC','RL','RR','SLA','SRA','SLL','SRL','RLCA','RRCA','RLA','RRA']:
        rotates=['RLC','RRC','RL','RR','SLA','SRA','SLL','SRL']
        accumulator=op in ['RLCA','RRCA','RLA','RRA']
        n=['RLCA','RRCA','RLA','RRA'].index(op) if accumulator else rotates.index(op)
        operand='A' if accumulator else args[0]
        out=read8(operand)+['ldx '+imm(n+(8 if accumulator else 0)),'jsr rotate8']+write8(operand)
    elif op in ['CPL','SCF','CCF','NEG','DAA']:out=['jsr '+op.lower()]
    elif op in ['LDIR','LDDR','LDI','LDD']:out=['ldx '+imm((2 if op.startswith('LDD') else 0)+(1 if op.endswith('R') else 0)),'jsr block_ld']
    elif op in ['DI','EI']:out=['lda '+imm(op=='EI'),'sta z_iff']
    elif op=='IM':out=['lda '+imm(number(args[0])),'sta z_im']
    elif op=='HALT':out=['lda '+imm(end),'ldx '+imm(end>>8),'jmp guest_halt'];terminal=True
    elif op=='IN':
        dst,port=args
        if port=='(C)':out=['lda z_c','jsr port_in','jsr in_flags']+write8(dst)
        else:out=['lda '+imm(number(port[1:-1])),'jsr port_in']+write8(dst)
    elif op=='OUT':
        port,src=args
        out=read8(src)+['pha']
        out+=['lda z_c'] if port=='(C)' else ['lda '+imm(number(port[1:-1]))]
        out+=['tax','pla','jsr port_out']
    else:raise ValueError(f'Unsupported reachable instruction: {pc:04X} {ins["text"]}')
    return out,terminal

def size(lines):
    n=0
    for line in lines:
        if line.endswith(':'):continue
        parts=line.split(' ',1);op=parts[0];arg=parts[1] if len(parts)>1 else ''
        if op=='.word':n+=2
        elif op=='.byte':n+=1
        elif op in ['jmp','jsr']:n+=3
        elif op.startswith('b') and op in ['bne','beq','bcs','bcc','bmi','bpl','bvs','bvc']:n+=2
        elif not arg or arg=='a':n+=1
        elif arg.startswith('#') or 'z_' in arg:n+=2
        else:n+=3
    return n

def main():
    ins=get_graph();raw={pc:native(i) for pc,i in ins.items()}
    print('Reachable instructions',len(ins),'Preliminary native bytes',sum(size(v[0]) for v in raw.values()))
    print(Counter(i['op'] for i in ins.values()))
    # Initial allocation uses conservative far-jump sizes. Later pass can tighten.
    bankmap={};used=0;bank=4
    for pc in sorted(ins):
        amount=size(raw[pc][0])
        if used+amount>8080:bank+=1;used=0
        bankmap[pc]=bank;used+=amount
    lines=[]
    for bank in sorted(set(bankmap.values())):
        lines += [f'.segment "BANK{bank}"']
        pcs=[pc for pc in sorted(ins) if bankmap[pc]==bank]
        for idx,pc in enumerate(pcs):
            i=ins[pc]
            lines += [f'; {pc:04X}: {i["text"]}',f'.export g_{pc:04x}',f'g_{pc:04x}:']
            code,terminal=native(i,bankmap);lines+=['    '+x for x in code]
            if not terminal:
                nxt=pcs[idx+1] if idx+1<len(pcs) else None
                if nxt!=i['end']:
                    target=i['end'];lines+=['    jsr far_jump',f'    .word g_{target:04x}',f'    .byte {bankmap[target]}']
    (BUILD/'aot.s').write_text('\n'.join(lines)+'\n')
    (BUILD/'aot-banks.json').write_text(json.dumps({f'{pc:04X}':bank for pc,bank in bankmap.items()},indent=2))
    # Full-address dispatch table for the reference build. Keep it out of fixed
    # code and data banks; return caching avoids the lookup on normal CALL/RET.
    buckets={i:[] for i in range(128)}
    for pc in sorted(ins):buckets[pc>>8].append(pc)
    dbank=24;used=0;tables=[];headers=[]
    for page,pcs in buckets.items():
        if used+4*len(pcs)>8192:dbank+=1;used=0
        headers.append((dbank,len(pcs)))
        tables += [f'.segment "BANK{dbank}"',f'dispatch_page_{page}:']
        for pc in pcs:tables += [f'.byte ${pc&255:02x}',f'.word g_{pc:04x}',f'.byte {bankmap[pc]}']
        used+=4*len(pcs)
    tables += ['.segment "FIXED"','dispatch_lo:']+[f'.byte <dispatch_page_{p}' for p in range(128)]
    tables += ['dispatch_hi:']+[f'.byte >dispatch_page_{p}' for p in range(128)]
    tables += ['dispatch_bank:']+[f'.byte {b}' for b,n in headers]
    tables += ['dispatch_count:']+[f'.byte {n}' for b,n in headers]
    (BUILD/'dispatch.s').write_text('\n'.join(tables)+'\n')
    print('Last native bank',max(bankmap.values()))

if __name__=='__main__':main()
