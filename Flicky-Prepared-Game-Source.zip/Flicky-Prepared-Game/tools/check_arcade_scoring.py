#!/usr/bin/env python3
"""Cross-check MAME's staged scoring results with an independent Z80 core.

Requires the privately supplied, verified parent ROM. Saves input/output values
only, so the resulting golden fixture can be distributed without executable ROM.
"""
import argparse, csv, hashlib, json
from build import ROOT, BUILD
from native_oracle import Original

def bcd(value):
    return int(str(value),16)

def score(ram):
    return int(''.join(f'{int(v):02x}' for v in ram[0xc0cf:0xc0d2]))*10

def original_result(o,c):
    o.ram[:]=0
    o.ram[0xc000]=0x80
    o.ram[0xc002]=c['input_lives']
    o.ram[0xc00e]=c['input_milestone']
    text=f'{c["input_score"]//10:06d}'
    o.ram[0xc0cf:0xc0d2]=[int(text[i:i+2],16) for i in (0,2,4)]
    if c['kind']=='event':
        o.call(0x178d,af=c['event']<<8)
    else:
        o.ram[0xc010]=bcd(c['seconds']%60)
        o.ram[0xc011]=bcd(c['seconds']//60)
        regs=o.call(0x06f1,stop=0x0717)
        o.call(0x17a2,bc=regs[1])
    return dict(score=score(o.ram),lives=int(o.ram[0xc002]),milestone=int(o.ram[0xc00e]))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capture',type=str,default=str(BUILD/'mame-audit/scoring'))
    a=p.parse_args()
    from pathlib import Path
    capture=Path(a.capture)
    log=(capture/'mame.log').read_text()
    assert '[LUA ERROR]' not in log and '255' in log,log
    cases=[]
    for row in csv.DictReader((capture/'scoring.csv').open()):
        cases.append({k:v if k=='kind' else int(v) for k,v in row.items()})
    assert len(cases)==255
    o=Original()
    for i,c in enumerate(cases):
        actual=original_result(o,c)
        assert actual=={k:c[k] for k in actual},(i,c,actual)
        assert c['life_sound']==(0x90 if c['lives']>c['input_lives'] else 0),c
    fixture=dict(provenance=dict(emulator='MAME 0.264',driver='flicky',
        roms='Verified parent set: epr-5978a.116 CRC 296f1492; epr-5979a.109 CRC 64b03ef9',
        bonus_life_dip='30000 80000 160000',
        capture='Diagnostic RAM/register inputs; unmodified original score/time-bonus instructions',
        independent_z80_crosscheck=True,
        lua_sha256=hashlib.sha256((ROOT/'tools/arcade_scoring_mame.lua').read_bytes()).hexdigest()),cases=cases)
    out=ROOT/'tests/fixtures/arcade-scoring-mame.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(fixture,indent=2)+'\n')
    print(json.dumps(dict(mame_cases=len(cases),independent_z80_mismatches=0,fixture=str(out))))

if __name__=='__main__':main()
