; Prepared cat animation lookup, including upside-down hit poses.
p_cat_pose=$f8
.segment "FIXED"
.export cat_prepare,sprite_draw_cat,sprite_draw_cats,cat_terrain_contact
cat_prepare:
    stx p_actor
    lda #1
    sta p_visible
    ldy n_animation,x
    lda n_flags,x
    and #2
    beq @pose_ready
    cpy #5
    bne :+
    ldy #18
    bne @pose_ready
:   cpy #7
    bne :+
    ldy #19
    bne @pose_ready
:   cpy #8
    bne @pose_ready
    ldy #20
@pose_ready:
    sty p_cat_pose
    lda native_cat_radius,y
    sta p_sprite_width
    lda native_cat_height,y
    sta p_height
    lsr a
    sta n_step
    lda n_ylo,x
    sec
    sbc n_step
    clc
    adc #1
    sta p_y
    clc
    adc p_height
    bcc :+
    lda #0
    sta p_visible
:   clc
    lda n_xlo,x
    adc n_world
    sta p_screen
    lda n_xhi,x
    adc n_world+1
    sta p_screen+1
    sec
    lda p_screen
    sbc native_cat_radius,y
    sta p_screen
    lda p_screen+1
    sbc #0
    and #1
    sta p_screen+1
    beq @full_width
    lda p_screen
    cmp #208
    bcc @full_width
    eor #$ff
    clc
    adc #2
    lsr a
    jmp @clip
@full_width:
    lda #24
@clip:
    sta p_clip_count
    sec
    lda p_screen
    sbc n_world
    sta p_left
    lda p_screen+1
    sbc n_world+1
    sta p_left+1
    jsr sprite_mask_prefix
    lda p_clip_count
    clc
    adc #1
    lsr a
    sta n_step
    lda p_left
    lsr a
    lsr a
    and #3
    sta p_index
    clc
    adc n_step
    asl a
    tax
    lda native_prefix0,x
    sta p_draw_clip
    lda native_prefix1,x
    sta p_draw_clip+1
    lda native_prefix2,x
    sta p_draw_clip+2
    lda native_prefix3,x
    sta p_draw_clip+3
    ldx p_actor
    lda p_cat_pose
    asl a
    asl a
    asl a
    ora p_index
    sta p_index
    lda n_flags,x
    and #1
    asl a
    asl a
    ora p_index
    tax
    lda #5
    NATIVE_BANK
    lda native_cat_image_lo,x
    sta p_image
    lda native_cat_image_hi,x
    sta p_image+1
    lda native_cat_image_bank,x
    sta p_imagebank
    lda p_left
    and #2
    bne @odd
    lda native_cat_mask_lo0,x
    sta p_mask
    lda native_cat_mask_hi0,x
    sta p_mask+1
    lda native_cat_mask_bank0,x
    sta p_maskbank
    rts
@odd:
    lda native_cat_mask_lo1,x
    sta p_mask
    lda native_cat_mask_hi1,x
    sta p_mask+1
    lda native_cat_mask_bank1,x
    sta p_maskbank
    rts

cat_terrain_contact:
    jsr cat_prepare
    jmp sprite_terrain_test
sprite_draw_cat:
    jsr cat_prepare
    jmp sprite_draw_prepared
sprite_draw_cats:
    lda #9
    sta n_actor_cursor
@loop:
    ldx n_actor_cursor
    lda n_flags,x
    bpl @next
    jsr sprite_draw_cat
@next:
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #11
    bcc @loop
    rts
