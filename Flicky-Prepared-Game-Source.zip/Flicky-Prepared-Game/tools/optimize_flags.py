"""Conservative Z80 flag liveness; calls/returns/indirect flow are barriers.

Only the hot translation uses this pass. The cold interpreter and reference
translation keep full flags. Never remove a flag observed at either boundary.
"""
from aot import PAIR,COND,ALU,REG,number,read8,write8,read16,write16,native,imm

def effect(i):
    op,args=i['op'],i['args'];uses=defs=0
    if op in ['CALL','RST','RET','RETI','RETN','HALT']:return 255,255
    if op in ['JP','JR']:
        if args[-1].startswith('('):return 255,0
        if len(args)>1:uses|=COND[args[0]][0]
    elif op in ALU:
        uses=1 if op in ['ADC','SBC'] else 0
        defs=0x3b if op=='ADD' and args[0] in ['HL','IX','IY'] else 255
    elif op in ['INC','DEC']:defs=0 if args[0] in PAIR else 254
    elif op=='BIT':defs=254
    elif op in ['RLC','RRC','SLA','SRA','SLL','SRL','NEG']:defs=255
    elif op in ['RL','RR']:uses=1;defs=255
    elif op in ['RLCA','RRCA']:defs=0x3b
    elif op in ['RLA','RRA']:uses=1;defs=0x3b
    elif op=='DAA':uses=0x13;defs=0xfd
    elif op=='CPL':defs=0x3a
    elif op=='SCF':defs=0x3b
    elif op=='CCF':uses=1;defs=0x3b
    elif op in ['LDIR','LDDR','LDI','LDD']:defs=0x3e
    elif op=='IN' and args[-1]=='(C)':defs=254
    elif op=='LD' and args[0]=='A' and args[1] in ['I','R']:defs=254
    elif op=='EX' and args[0]=='AF':uses=defs=255
    elif op=='PUSH' and args[0]=='AF':uses=255
    elif op=='POP' and args[0]=='AF':defs=255
    return uses,defs

def annotate(ins):
    live={pc:255 for pc in ins}
    changed=True
    while changed:
        changed=False
        for pc,i in sorted(ins.items(),reverse=True):
            uses,defs=effect(i)
            out=0
            successors=i['successors']
            if not successors:out=255
            for nxt in successors:out|=live.get(nxt,255)
            new=uses|(out&~defs)
            if new!=live[pc]:live[pc]=new;changed=True
    for pc,i in ins.items():
        successors=i['successors'];out=0 if successors else 255
        for nxt in successors:out|=live.get(nxt,255)
        i['live_flags']=out

def flags_cz(kind):
    result=['php','pla']
    if kind=='subtract':result+=['eor #1']
    result+=['and #2' if kind=='logical' else 'and #3','tax','lda z_czflags,x','sta z_f']
    return result

def optimized(i,bankmap=None):
    op,args,pc=i['op'],i['args'],i['pc'];live=i.get('live_flags',255)
    if pc in [0x0af9,0x0b00]:
        # Original routines save AF/HL, count HL down to zero, restore AF/HL,
        # and return. They have no RAM/I/O effect. Eliminate CPU busy-work;
        # final wall-clock scheduling remains a separate port acceptance gate.
        return ['jmp return_guest'],True
    if op in ALU and not (len(args)==2 and args[0] in ['HL','IX','IY']):
        if live & ~0x41:return native(i,bankmap)
        operand=args[-1]
        if op=='CP' and not live:return [],False
        result=read8(operand)
        if op in ['ADD','AND','XOR','OR']:
            if op=='ADD':result+=['clc']
            result+=[{'ADD':'adc','AND':'and','XOR':'eor','OR':'ora'}[op]+' z_a']
        else:
            result+=['sta z_operand']
            if op in ['ADC','SBC']:result+=['lda z_f','lsr a']
            elif op=='SUB':result+=['sec']
            result+=['lda z_a',{'ADC':'adc','SBC':'sbc','SUB':'sbc','CP':'cmp'}[op]+' z_operand']
        if op!='CP':result+=['sta z_a']
        if live:result+=flags_cz('subtract' if op in ['CP','SUB','SBC'] else 'logical' if op in ['AND','OR','XOR'] else 'add')
        return result,False
    if op in ['INC','DEC'] and args[0] not in PAIR and not live:
        target=args[0]
        if target in REG:return [op.lower()+' '+REG[target]],False
        return read8(target)+(['clc','adc #1'] if op=='INC' else ['sec','sbc #1'])+write8(target),False
    if op=='BIT' and not (live&~1):return [],False
    return native(i,bankmap)
