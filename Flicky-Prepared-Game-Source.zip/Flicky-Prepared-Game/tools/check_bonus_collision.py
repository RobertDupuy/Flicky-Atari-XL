"""Check catch masks against independent System 1 sprite raster collisions."""
import ctypes as C,json,random
from build import BUILD
from native_engine import Engine
from native_oracle import Original
from run_reference import Reference
from arcade_bonus_assets import BIRD_DESCRIPTORS
from check_arcade_bonus import SLOTS

def main():
    n=Engine();n.lib.at_video_timing(0);n.set('n_round',2);n.call('game_round_load')
    o=Original();r=Reference();r.lib.fm_coll.restype=C.POINTER(C.c_uint8)
    masks=(BUILD/'native/arcade-bonus-catch.bin').read_bytes();rng=random.Random(2048);cases=0
    for net in range(4):
        for bird in range(8):
            points=[(0,0),(-32,0),(31,0),(0,-16),(0,15),(0,8),(0,-8)]
            points += [(rng.randrange(-28,28),rng.randrange(-12,12)) for _ in range(12)]
            for dx,dy in points:
                o.ram[:]=0;r.ram[0xd000:0xd400]=0;r.ram[0xd020]=255
                for slot,desc,face,x,y in [(0,BIRD_DESCRIPTORS[bird//2],bird&1,256+dx,120+dy),
                                         (1,(0x336b,0x3374)[net//2],net&1,256,120)]:
                    a=0xc300+slot*32;o.ram[a]=0x80|face;o.ram[a+1:a+3]=[desc&255,desc>>8]
                    o.ram[a+5]=slot;o.ram[a+7:a+10]=[x&255,x>>8,y]
                    o.call(0x43a4,ix=a)
                    r.ram[0xd000+slot*16:0xd008+slot*16]=o.ram[0xc101+slot*9:0xc109+slot*9]
                r.lib.fm_render_snapshot(0)
                expected=bool(r.lib.fm_coll()[32])
                index=(net*8+bird)*256+(dy+16)*8+(dx+32)//8
                assert bool(masks[index]&(1<<((dx+32)&7)))==expected,(net,bird,dx,dy,'prepared mask')
                for slot in SLOTS:n.set('n_flags',0x84,slot)
                n.ram[0x1c80:0x1cc0]=0;n.ram[0x1c80]=4
                n.set('n_flags',128,0);n.set('n_vy',48,0);n.set('b_caught',0);n.set('b_done',0)
                n.ram[0x1c00]= (256+dx)&255;n.ram[0x1c20]=(256+dx)>>8
                n.ram[0x1c40]=120+dy;n.ram[0x1c60]=bird
                n.set('b_net',net);n.ram[0x1be0:0x1be3]=[0,1,120]
                n.call('bonus_catch')
                assert bool(n.get('b_caught'))==expected,(net,bird,dx,dy,'6502 catch')
                for velocity in (0,255,180):
                    n.set('n_flags',128,0);n.set('n_vy',velocity,0);n.set('b_caught',0)
                    n.call('bonus_catch');assert n.get('b_caught')==0
                cases+=1
    # Multiple sprite owners, edge clipping, latched collision bits, and the
    # original's first-collision scan (which may reject an ascending bird).
    import numpy as np
    fixture_inputs=[];fixture_expected=[];crowded=0
    for case in range(420):
        net=rng.randrange(4);nx=rng.choice([0,8,16,256,496,504,511]);ny=160
        active=rng.randrange(2,9);latches=[0]*20
        birds=[]
        for i in range(20):
            bx=(nx+rng.randrange(-24,25))%512;by=ny+rng.randrange(-12,13)
            art=rng.randrange(8);velocity=rng.choice([0,32,48,180,255])
            birds.append([bx&255,bx>>8,by,art,velocity,128 if i<active else 132,4 if i<active else 0])
        for tick in range(4):
            r.ram[0xd000:0xd400]=0;r.ram[0xd1f0]=255;o.ram[:]=0
            for i,(lo,hi,y,art,vel,flags,visible) in enumerate(birds):
                a=0xc420+i*32;o.ram[a]=flags;o.ram[a+20]=vel
                if not visible:continue
                o.ram[a]=(flags&~1)|(art&1);desc=BIRD_DESCRIPTORS[art//2]
                o.ram[a+1:a+3]=[desc&255,desc>>8];o.ram[a+5]=9+i
                o.ram[a+7:a+10]=[lo,hi,y];o.call(0x43a4,ix=a)
                r.ram[0xd000+(9+i)*16:0xd008+(9+i)*16]=o.ram[0xc101+(9+i)*9:0xc109+(9+i)*9]
            a=0xc6c0;desc=(0x336b,0x3374)[net//2]
            o.ram[a]=128|(net&1);o.ram[a+1:a+3]=[desc&255,desc>>8];o.ram[a+5]=30
            o.ram[a+7:a+10]=[nx&255,nx>>8,ny];o.call(0x43a4,ix=a)
            r.ram[0xd1e0:0xd1e8]=o.ram[0xc20f:0xc217]
            r.lib.fm_render_snapshot(0)
            for i in range(20):o.ram[0xfbc9+i]=latches[i]|int(r.lib.fm_coll()[30*32+9+i])
            original_latches=list(latches)
            o.call(0x4152,ix=0xc6c0)
            expected_caught=255
            if o.ram[0xc03d]:
                expected_caught=next(i for i,b in enumerate(birds) if not b[5]&4 and o.ram[0xc420+i*32]&4)
            expected_latches=o.ram[0xfbc9:0xfbdd].tolist()
            data=[net,nx&255,nx>>8,ny]+original_latches+sum(birds,[])
            fixture_inputs.append(data);fixture_expected.append([expected_caught]+expected_latches)
            n.ram[0x1ca0:0x1cb4]=original_latches;n.set('b_caught',0);n.set('b_done',0)
            n.set('b_net',net);n.ram[0x1be0:0x1be3]=[nx&255,nx>>8,ny]
            for i,(lo,hi,y,art,vel,flags,visible) in enumerate(birds):
                slot=SLOTS[i];n.set('n_flags',flags,slot);n.set('n_vy',vel,slot)
                for base,value in [(0x1c00,lo),(0x1c20,hi),(0x1c40,y),(0x1c60,art),(0x1c80,visible)]:n.ram[base+slot]=value
            n.call('bonus_catch')
            actual=next((i for i,slot in enumerate(SLOTS) if not birds[i][5]&4 and n.get('n_flags',slot)&4),255)
            assert actual==expected_caught,(case,tick,net,nx,actual,expected_caught,birds)
            assert n.ram[0x1ca0:0x1cb4].tolist()==expected_latches,(case,tick,'latches')
            latches=expected_latches
            if expected_caught!=255:birds[expected_caught][5]|=4;birds[expected_caught][6]=0
            crowded+=1
    np.savez_compressed(BUILD/'native/arcade-bonus-collision-golden.npz',
                        inputs=np.array(fixture_inputs,dtype=np.uint8),expected=np.array(fixture_expected,dtype=np.uint8))
    report=dict(sprite_collision_cases=cases,ascending_or_stationary_rejections=cases*3,
                original_rom_sprite_raster=True,crowded_and_latched_cases=crowded,mismatches=0)
    (BUILD/'native/arcade-bonus-collision.json').write_text(json.dumps(report,indent=2)+'\n');print(report)

if __name__=='__main__':main()
