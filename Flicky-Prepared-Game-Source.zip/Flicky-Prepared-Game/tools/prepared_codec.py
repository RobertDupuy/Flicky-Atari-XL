"""Small deterministic host-side level-data codec."""
from collections import defaultdict

def compress(data):
    positions=defaultdict(list)
    output=bytearray(); literals=bytearray(); index=0
    def flush():
        while literals:
            count=min(127,len(literals))
            output.append(count);output.extend(literals[:count]);del literals[:count]
    while index<len(data):
        best_length=0;best_offset=0
        for previous in reversed(positions[data[index:index+3]]):
            length=0
            while length<130 and index+length<len(data) and data[previous+length]==data[index+length]:
                length+=1
            if length>best_length:best_length=length;best_offset=index-previous
            if length==130:break
        if best_length>=4:
            flush();output.extend((128+best_length-3,best_offset&255,best_offset>>8))
            count=best_length
        else:
            literals.append(data[index]);count=1
            if len(literals)==127:flush()
        for p in range(index,index+count):positions[data[p:p+3]].append(p)
        index+=count
    flush();output.append(0)
    return bytes(output)

def expand(stream):
    output=bytearray();p=0
    while True:
        token=stream[p];p+=1
        if not token:break
        if token<128:output.extend(stream[p:p+token]);p+=token
        else:
            distance=stream[p]|stream[p+1]<<8;p+=2
            for _ in range((token&127)+3):output.append(output[-distance])
    assert p==len(stream)
    return bytes(output)

