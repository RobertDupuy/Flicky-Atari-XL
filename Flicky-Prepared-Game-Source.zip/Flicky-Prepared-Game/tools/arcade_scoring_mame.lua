-- Diagnostic only: execute the original score/clear routines with staged RAM.
-- This is not a gameplay recording. No ROM bytes are written to the output.
local m=manager.machine
local cpu=m.devices[":maincpu"]
local s=cpu.spaces["program"]
local dir=assert(os.getenv("FLICKY_ORACLE_DIR"))
local out=assert(io.open(dir.."/scoring.csv","w"))
out:write("kind,input_score,event,seconds,input_lives,input_milestone,score,lives,milestone,life_sound\n")
local cases={}
local function milestone(score)
  if score<30000 then return 0 elseif score<80000 then return 1
  elseif score<160000 then return 2 else return 3 end
end
for _,score in ipairs({0,9990,10000,29990,30000,79990,80000,159990,160000,169990,200000,500000,950000}) do
  for event=1,14 do
    local index=milestone(score)
    table.insert(cases,{kind="event",score=score,event=event,seconds=0,lives=3+index,index=index})
  end
end
-- The original does not cap lives at nine.
table.insert(cases,{kind="event",score=29990,event=1,seconds=0,lives=9,index=0})
for _,seconds in ipairs({0,1,19,20,29,30,39,40,49,50,59,60,61,119,120,255,256,3599}) do
  for _,score in ipairs({0,29990,79990,159990}) do
    local index=milestone(score)
    table.insert(cases,{kind="time",score=score,event=0,seconds=seconds,lives=3+index,index=index})
  end
end
local function bcd(value) return math.floor(value/10)*16+value%10 end
local function unbcd(value) return math.floor(value/16)*10+value%16 end
local frame,index,life_sound=0,0,0
local tap=cpu.spaces["io"]:install_write_tap(0,0x1f,"extra_life_sound",function(offset,data,mask)
  if offset%256==0x18 and data==0x90 then life_sound=data end
end)
local function stage(c)
  life_sound=0
  s:write_u8(0xc000,0x80) -- active one-player game
  s:write_u8(0xc001,0)
  s:write_u8(0xc002,c.lives)
  s:write_u8(0xc004,0) -- inverted default bonus DIP: 30k / 80k / 160k
  s:write_u8(0xc00e,c.index)
  local units=c.score/10
  s:write_u8(0xc0d1,bcd(units%100))
  s:write_u8(0xc0d0,bcd(math.floor(units/100)%100))
  s:write_u8(0xc0cf,bcd(math.floor(units/10000)%100))
  s:write_u8(0xc010,bcd(c.seconds%60))
  s:write_u8(0xc011,bcd(math.floor(c.seconds/60)))
  local code
  if c.kind=="time" then
    -- DI; JP $06f1. Original code adds its time bonus, then HALTs.
    code={0xf3,0xc3,0xf1,0x06}
  else
    -- DI; LD A,event; CALL $178d; HALT; JR back to HALT.
    code={0xf3,0x3e,c.event,0xcd,0x8d,0x17,0x76,0x18,0xfd}
  end
  for i,v in ipairs(code) do s:write_u8(0xc800+i-1,v) end
  -- PC writes alone do not release the Z80's internal HALT state.
  cpu.state["HALT"].value=0
  cpu.state["IFF1"].value=0
  cpu.state["IFF2"].value=0
  cpu.state["SP"].value=0xcff0
  cpu.state["PC"].value=0xc800
end
emu.register_frame_done(function()
  assert(tap) -- Keep the tap alive for the entire capture (Lua GC owns it).
  frame=frame+1
  if frame<300 then return end
  if index>0 then
    local c=cases[index]
    local score=10*(unbcd(s:read_u8(0xc0cf))*10000+unbcd(s:read_u8(0xc0d0))*100+unbcd(s:read_u8(0xc0d1)))
    out:write(string.format("%s,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",c.kind,c.score,c.event,c.seconds,c.lives,c.index,
      score,s:read_u8(0xc002),s:read_u8(0xc00e),life_sound))
  end
  index=index+1
  if index>#cases then
    out:close();print("Original-ROM scoring cases:",#cases);m:exit();return
  end
  stage(cases[index])
end)
