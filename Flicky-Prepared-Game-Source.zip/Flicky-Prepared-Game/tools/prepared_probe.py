#!/usr/bin/env python3
"""Normal-speed Atari800 timing, input and capture for the actual cartridge.

The optional stress cartridge injects twelve actor poses before rendering.
Native player logic, collision tests, actor updates, scroll and music still run.
"""
import argparse,os,subprocess,time,json,re
from pathlib import Path
from Xlib import X,XK,display
from Xlib.ext import xtest
from PIL import Image
from build import ROOT,BUILD,executable
from hardware_model import HOST_FPS

def dumps(text):
    text=re.sub(r'\x1b\[[0-9;]*m','',text);blocks={}
    for match in re.finditer(r'(?m)^([0-9A-F]{4}):((?: [0-9A-F]{2}){16})',text):
        a=int(match[1],16);blocks.setdefault(a,[]).append([int(v,16)for v in match[2].split()])
    return blocks

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stress',action='store_true');ap.add_argument('--seconds',type=float,default=12);args=ap.parse_args()
    out=BUILD/'native'/('prepared-stress' if args.stress else 'prepared-play');out.mkdir(exist_ok=True)
    cartridge=BUILD/'native'/('flicky-stress-test.car' if args.stress else 'flicky-native-dev.car')
    env=os.environ.copy();env['LD_LIBRARY_PATH']=str(ROOT.parent/'toolchain/root/usr/lib/x86_64-linux-gnu')
    number=200+os.getpid()%2000
    while Path(f'/tmp/.X{number}-lock').exists():number+=1
    env['DISPLAY']=f'127.0.0.1:{number}';env['SDL_VIDEODRIVER']='x11'
    results={}
    with (out/'xvfb.log').open('w') as xl:
        xvfb=subprocess.Popen([executable('Xvfb'),f':{number}','-screen','0','900x700x24','-ac','-nolisten','unix','-nolisten','local','-listen','tcp'],env=env,stdout=xl,stderr=xl)
        try:
            time.sleep(.7);d=display.Display(env['DISPLAY'])
            for mode in ('ntsc','pal'):
                with (out/(mode+'.log')).open('w') as log:
                    emu=subprocess.Popen([executable('atari800'),'-config',str(ROOT/'tools/atari800.cfg'),'-xl','-xl-rev','altirra','-nobasic','-'+mode,'-nosound','-windowed','-no-video-accel','-stretch','2','-cart',str(cartridge)],env=env,stdin=subprocess.PIPE,stdout=log,stderr=log)
                    try:
                        time.sleep(2)
                        w=next(w for w in d.screen().root.query_tree().children if 'Atari' in (w.get_wm_name() or ''))
                        w.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync()
                        def key(name,down):
                            xtest.fake_input(d,X.KeyPress if down else X.KeyRelease,d.keysym_to_keycode(XK.string_to_keysym(name)));d.sync()
                        def capture():
                            g=w.get_geometry();data=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff)
                            return Image.frombytes('RGB',(g.width,g.height),data.data,'raw','BGRX')
                        def monitor(commands,resume=True):
                            key('F8',True);time.sleep(.04);key('F8',False);time.sleep(.1)
                            emu.stdin.write(('\n'.join(commands+(['cont']if resume else []))+'\n').encode());emu.stdin.flush();time.sleep(.1)
                        capture().save(out/f'{mode}-title.png')
                        key('Control_R',True);time.sleep(.1);key('Control_R',False);time.sleep(1.8)
                        monitor(['c 06e1 00 00','c 06e4 00','c 068e 00','m 07a0'])
                        key('Right',True);start=time.monotonic();frames=[];last=-1
                        while time.monotonic()-start<args.seconds:
                            elapsed=time.monotonic()-start;phase=int(elapsed*4)
                            if phase!=last:
                                key('Control_R',phase%4==2)
                                if phase==24:key('Right',False);key('Left',True)
                                if phase==36:key('Left',False);key('Right',True)
                                last=phase
                            if not args.stress and mode=='ntsc' and 2<=elapsed<6:frames.append(capture())
                            time.sleep(1/30)
                        key('Right',False);key('Left',False);key('Control_R',False)
                        capture().save(out/f'{mode}-play.png')
                        monitor(['antic','gtia','m 0640','m 0680','m 06e0','m 0700','m 07a0','m 0800','m 0860','m c700','quit'],False)
                        emu.wait(timeout=5)
                        if frames:frames[0].save(out/'Flicky-Prepared-Game.gif',save_all=True,append_images=frames[1:],duration=33,loop=0)
                    finally:
                        if emu.poll() is None:emu.terminate();emu.wait(timeout=5)
                data=dumps((out/(mode+'.log')).read_text());first,last=data[0x07a0][0],data[0x07a0][-1]
                word=lambda row,i:row[i]+256*row[i+1]
                host=(word(last,2)-word(first,2))&65535;shown=(word(last,0)-word(first,0))&65535
                state=data[0x06e0][-1];clock=data[0x0680][-1]
                results[mode]={'host_frames':host,'presented_frames':shown,'displayed_fps':round(shown*float(HOST_FPS[mode])/host,3),
                    'maximum_display_interval':state[4],'missed_two_refresh_deadlines':word(state,1),
                    'logic_produced':word(clock,0),'logic_consumed':word(clock,2),'queue_peak':clock[14],'queue_overflow':clock[13],
                    'renderer_fault':data[0x0640][-1][10],'stress_fixture':args.stress}
                print(mode,json.dumps(results[mode]),flush=True)
            d.close()
        finally:xvfb.terminate();xvfb.wait(timeout=5)
    (out/'timing.json').write_text(json.dumps(results,indent=2)+'\n')
    assert all(r['renderer_fault']==r['queue_overflow']==r['missed_two_refresh_deadlines']==0
        and r['maximum_display_interval']<=2 and r['queue_peak']<=3
        and ((r['logic_produced']-r['logic_consumed'])&65535)<=2 for r in results.values())
if __name__=='__main__':main()
