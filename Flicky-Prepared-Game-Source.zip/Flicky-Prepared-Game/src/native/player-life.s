; Enemy response and the original 96-tick grounded death animation.
n_lives=$07c0
n_life_lost=$07c1
.segment "FIXED"
.export player_enemy_response,player_death_update,n_lives,n_life_lost
player_enemy_response:
    lda #4
    NATIVE_BANK
    jmp player_enemy_response_bank
player_death_update:
    lda #4
    NATIVE_BANK
    jmp player_death_update_bank
.segment "BANK4"
player_enemy_response_bank:
    lda n_exiting
    beq :+
    rts
:
    lda n_player_enemy
    sta c_mask
    lda #0
    sta n_player_enemy
    lda n_bonus
    bne @done
    ldx #9
@cat:
    lsr c_mask
    bcc @next
    lda n_pause,x
    bne @next
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    and #1
    bne @right
    lda c_screen
    cmp #$f9
    bcc @next
    bcs @vertical
@right:
    lda c_screen
    cmp #7
    bcs @next
@vertical:
    lda n_ylo,x
    cmp n_ylo+PLAYER
    bcs @below
    clc
    adc #12
    cmp n_ylo+PLAYER
    bcc @next
    bcs @contact
@below:
    sec
    sbc #12
    cmp n_ylo+PLAYER
    bcs @next
@contact:
    lda n_chick_state,x
    and #$10
    bne @done
    lda n_flags+PLAYER
    and #4
    bne @done
    lda n_flags+PLAYER
    ora #4
    sta n_flags+PLAYER
    lda #$86
    sta n_sound_event
    lda #1
    sta n_frozen
    sta n_pose+PLAYER
    lda #0
    sta n_timer+PLAYER
    sta n_frame+PLAYER
    sta n_cycle+PLAYER
    lda #5
    sta n_animation+PLAYER
    rts
@next:
    inx
    cpx #11
    bcc @cat
@done:
    rts

player_death_update_bank:
    inc n_timer+PLAYER
    lda n_timer+PLAYER
    and #3
    bne @done
    inc n_cycle+PLAYER
    lda n_cycle+PLAYER
    cmp #24
    bcs @lost
    cmp #3
    bne @frame
    ldx #9
@hide:
    lda n_flags,x
    and #$7f
    sta n_flags,x
    inx
    cpx #12
    bcc @hide
    lda n_flags+24
    and #$df
    sta n_flags+24
    lda n_flags+25
    and #$7f
    sta n_flags+25
    lda n_flags+26
    and #$7f
    sta n_flags+26
    lda #7
@frame:
    and #7
    tay
    lda player_death_frames,y
    sta n_frame+PLAYER
@done:
    rts
@lost:
    lda n_flags+PLAYER
    and #$fb
    sta n_flags+PLAYER
    lda #1
    sta n_life_lost
    rts
player_death_frames:
.byte 0,0,1,2,3,2,3,2
