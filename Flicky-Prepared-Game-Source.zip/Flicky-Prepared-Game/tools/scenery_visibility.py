"""Readable scenery inks; retain every original collision-mask bit.

The six wall texture families used to pass through an RGB classifier which
turned gray walls into solid white and yellow walls into chick-colored fills.
Prepared native wall patterns reserve the bright inks for actors and edges.
"""
import json
from pathlib import Path
from build import BUILD

def black_wall(stage, code):
    """Match display_build's decorative-wall policy; stage is zero-based."""
    return stage%4!=2 and stage%48 not in (19,20,21) and 1<=code>>8<=6 and 0x80<=code&255<0xa0

def build(out):
    original_index=(BUILD/'tile-index.bin').read_bytes()
    original_glyphs=(BUILD/'tile-glyphs.bin').read_bytes()
    walls=(out/'scenery-wall-glyphs.bin').read_bytes()
    records=[];lookup={};index=bytearray(original_index)
    changed=0
    for code in range(2048):
        p=original_index[code]+256*original_index[code+2048]-0x8000+((original_index[code+4096]&127)-9)*8192
        record=original_glyphs[p:p+16];ink=original_index[code+4096]&128
        theme=code>>8;tile=code&255
        if 1<=theme<=6 and 0x80<=tile<0xa0:
            offset=((theme-1)*32+tile-0x80)*8
            record=walls[offset:offset+8]+record[8:];ink=0;changed+=1
        if record not in lookup:lookup[record]=len(records);records.append(record)
        n=lookup[record];address=0x8000+(n*16&8191)
        index[code]=address&255;index[code+2048]=address>>8
        index[code+4096]=9+n//512+ink
        assert record[8:]==original_glyphs[p+8:p+16]
    assert len(records)<=1024
    (BUILD/'scenery-index.bin').write_bytes(index)
    (BUILD/'scenery-glyphs.bin').write_bytes(b''.join(records))
    (out/'scenery-visibility.json').write_text(json.dumps(dict(wall_tiles_recolored=changed,
        original_collision_masks_unchanged=True,wall_inks=['black','dark theme accent'],
        bright_actor_inks_reserved=True,black_decorative_walls=True,
        preserved_rounds=[20,21,22],bonus_scenery_unchanged=True,
        shared_actor_palette_unchanged=True),indent=2)+'\n')

if __name__=='__main__':build(BUILD/'native')
