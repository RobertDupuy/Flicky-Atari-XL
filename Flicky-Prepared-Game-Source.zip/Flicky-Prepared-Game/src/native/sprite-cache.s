; Prepared ANTIC character animations. Each frame contains glyph identifiers
; for all eight vertical phases. The runtime places codes and uploads only
; cache misses; artwork alignment and pattern deduplication happen offline.
r_epoch=$064b
r_cache_hits=$072d
r_cache_misses=$072f
p_stamp_lo=$b5
p_stamp_hi=$b6
p_block=$b7
p_column_base=$b8
p_column_ptr=$ba
p_source_row=$c9
p_plane_span=$ca
p_column_span=$cb
p_meta=$bc
p_epoch=$be
p_cache_index=$bf
p_key_hi=$c1
p_cache_store=$c2
p_probes=$c3
p_stamp_mask=$cd
p_stamp_bits=$cf
p_recolor=$d2
p_clip_byte=$d3
p_frame=$e1
p_character=$e3
p_characters=$0a00
p_meta_y=$e4
p_screen_row=$e5
p_key_bg=$f6
p_key_epoch=$f7
.segment "FIXED"
sprite_table_init:
    lda #15
    NATIVE_BANK
    ldx #0
@copy:
    lda native_expand_hi,x
    sta $f400,x
    lda native_expand_lo,x
    sta $f500,x
    lda native_third_to_white_rom,x
    sta $f600,x
    inx
    bne @copy
@prefix:
    lda native_prefix_rom0,x
    sta $f700,x
    inx
    cpx #132
    bcc @prefix
    rts
sprite_draw_prepared:
    jmp fast_draw_prepared
cache_band_lo:
.repeat 7,I
    .byte <($6a80+I*192)
.endrepeat
cache_band_hi:
.repeat 7,I
    .byte >($6a80+I*192)
.endrepeat
