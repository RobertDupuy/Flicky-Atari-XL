"""Package the actual emulator screenshots and continuous PAL recordings."""
import base64,hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
from build import ROOT,BUILD

def encode(source,dest):
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-vf','format=rgb24,scale=1008:720:flags=neighbor',
        '-c:v','libx264','-preset','slow','-crf','15','-pix_fmt','yuv420p',
        '-c:a','aac','-b:a','160k','-movflags','+faststart',str(dest)],check=True)
    data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,width,height,r_frame_rate','-of','json',str(dest)]))
    assert any(s['codec_name']=='aac' for s in data['streams'])
    return dict(file=dest.name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),video=data,cuts=0,speed_changes=0)

def main():
    release=ROOT/'release';source=BUILD/'visibility-final';cards=[]
    archive=release/'Flicky-All-48-Rounds-Screenshots.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for mode in ('pal','ntsc'):
            for r in range(1,49):
                p=source/mode/f'round-{r:02d}.png';assert p.exists()
                z.write(p,f'{mode.upper()}/{p.name}')
                data=base64.b64encode(p.read_bytes()).decode()
                cards.append(f'<figure data-mode="{mode}"><figcaption>{mode.upper()} · Round {r:02d}'+(' · Bonus' if r%4==3 else '')+f'</figcaption><a href="data:image/png;base64,{data}" download="{mode}-round-{r:02d}.png"><img loading="lazy" alt="{mode.upper()} Round {r:02d}" src="data:image/png;base64,{data}"></a></figure>')
            name=f'Flicky-All-48-Rounds-{mode.upper()}.png';shutil.copy2(source/mode/'all-rounds.png',release/name);z.write(release/name,name)
        z.writestr('README.txt','Actual Atari800 cartridge screenshots. 48 numbered rounds in both PAL and NTSC. Diagnostic round selection, not played completion. The separate HTML gallery is self-contained.\n')
    html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Flicky · All 48 Rounds</title><style>body{background:#10141c;color:#f5f6f8;font:16px system-ui;margin:0}header{padding:24px;position:sticky;top:0;background:#10141cf5;z-index:1;border-bottom:1px solid #354052}h1{margin:0 0 8px;font-size:26px}p{margin:8px 0;color:#becada}button{font:inherit;border:1px solid #71819a;border-radius:8px;padding:9px 20px;margin:6px 8px 0 0;background:#202c40;color:white;cursor:pointer}button[aria-pressed=true]{background:#ffd672;color:#181b20}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(336px,1fr));gap:20px;padding:24px}figure{margin:0;background:black;border:1px solid #354052;border-radius:7px;overflow:hidden}figcaption{padding:10px 14px;background:#202c40}img{display:block;width:100%;height:auto;image-rendering:pixelated}figure[hidden]{display:none}</style><header><h1>Flicky · All 48 Rounds</h1><p>Actual cartridge output · Select PAL or NTSC. Click a screenshot to download it.</p><button data-select="pal" aria-pressed="true">PAL</button><button data-select="ntsc" aria-pressed="false">NTSC</button><button data-select="all" aria-pressed="false">Both</button><p>Round selection was used to capture every layout. Bonus rounds start at 3 and recur every fourth round.</p></header><main>'''+''.join(cards)+'''</main><script>function select(mode){document.querySelectorAll('figure').forEach(e=>e.hidden=mode!=='all'&&e.dataset.mode!==mode);document.querySelectorAll('button').forEach(e=>e.setAttribute('aria-pressed',e.dataset.select===mode))}document.querySelectorAll('button').forEach(e=>e.onclick=()=>select(e.dataset.select));select('pal');</script></html>'''
    (release/'Flicky-All-48-Rounds.html').write_text(html)
    shutil.copy2(source/'pal/round-04.png',release/'Flicky-Round-04-PAL.png')
    shutil.copy2(source/'intro-pal/intro-16.png',release/'Flicky-Arcade-Intro-PAL.png')
    movie=[]
    for folder,report,name in [(source/'intro-pal','capture.json','Flicky-Atari-XL-PAL-Arcade-Intro.mp4'),
          (BUILD/'native/pal-level-realtime','verification.json','Flicky-Atari-XL-PAL-Level-Complete.mp4')]:
        verification=json.loads((folder/report).read_text())
        movie.append(dict(**encode(folder/verification['video'],release/name),verification=verification))
    (ROOT/'evidence/visibility-movies.json').write_text(json.dumps(movie,indent=2)+'\n')
    print(json.dumps([dict(file=m['file'],duration=m['video']['format']['duration'],bytes=m['video']['format']['size']) for m in movie],indent=2))

if __name__=='__main__':main()
