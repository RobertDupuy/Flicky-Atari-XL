; Four-voice POKEY arrangement captured from the original sound Z80.
; NMI-owned state and scratch never overlap the main game state.
a_ptr = $10
a_slotptr = $12
a_mask = $14
a_reg = $15
a_slot = $16
a_savedbank = $17
a_command = $18
a_lo = $19
a_phase = $0200
a_step = $0202
a_pal = $0204
a_effect_policy = $0205
a_slots = $0220
a_queue_head = $0620
a_queue_tail = $0621
a_overflow = $0622
a_bank = $061f
.segment "FIXED"
.export audio_init,audio_enqueue,audio_vbi,audio_tick,audio_start
audio_init:
    lda #0
    ldx #$7f
@clear:
    sta $0200,x
    dex
    bpl @clear
    sta a_queue_head
    sta a_queue_tail
    sta a_overflow
    sta $d208
    sta $d201
    sta $d203
    sta $d205
    sta $d207
    lda #3
    sta $d20f
    lda $d014
    and #$0e
    beq @pal
    lda #190
    sta a_step
    rts
@pal:
    lda #1
    sta a_pal
    lda #<13454
    sta a_step
    lda #>13454
    sta a_step+1
    rts
audio_enqueue:
    pha
    lda a_queue_head
    clc
    adc #1
    and #15
    cmp a_queue_tail
    beq @full
    tax
    pla
    ldy a_queue_head
    sta $0630,y
    stx a_queue_head
    rts
@full:
    inc a_overflow
    pla
    rts
audio_vbi:
    lda a_bank
    sta a_savedbank
@queue:
    ldx a_queue_tail
    cpx a_queue_head
    beq @tick
    lda $0630,x
    jsr audio_start
    inc a_queue_tail
    lda a_queue_tail
    and #15
    sta a_queue_tail
    jmp @queue
@tick:
    jsr audio_tick
    clc
    lda a_phase
    adc a_step
    sta a_phase
    lda a_phase+1
    adc a_step+1
    sta a_phase+1
    bcc :+
    jsr audio_tick
:   jsr audio_output
    lda a_savedbank
    sta a_bank
    sta $d500
    rts
audio_start:
    cmp #0
    bne @command
    lda #0
    sta a_slots
    sta a_slots+32
    jmp audio_silence
@command:
    cmp #$81
    bcc @done
    cmp #$94
    bcs @done
    sec
    sbc #$81
    tay
    ldx #32
    lda audio_flags,y
    cmp #4
    beq @done
    sta a_effect_policy
    cmp #3
    bne :+
    lda #0
    sta a_slots
    beq @effect
:   cmp #1
    bne @effect
    lda #0
    sta a_slots+32
    sta a_effect_policy
    ldx #0
@effect:
    lda #1
    sta a_slots,x
    lda audio_banks,y
    sta a_slots+1,x
    lda audio_lo,y
    sta a_slots+2,x
    lda audio_hi,y
    sta a_slots+3,x
    lda audio_loop_lo,y
    sta a_slots+4,x
    lda audio_loop_hi,y
    sta a_slots+5,x
    lda #0
    sta a_slots+7,x
@done:
    rts
audio_tick:
    ldx #0
    jsr audio_stream
    ldx #32
    jmp audio_stream
audio_stream:
    lda a_slots,x
    beq @done
    lda a_slots+7,x
    beq @read
    dec a_slots+7,x
    bne @done
@read:
    jmp audio_execute_prepared
@done:
    rts
audio_output:
    ldx #0
@channel:
    lda a_slots+32
    beq @music
    lda a_effect_policy
    cmp #2
    bcs @effect
    lda a_slots+32+9,x
    and #15
    bne @effect
@music:
    lda a_slots
    beq @quiet
    lda a_slots+9,x
    sta $d201,x
    lda a_slots+8,x
    jmp @pitch
@effect:
    lda a_slots+32+9,x
    sta $d201,x
    lda a_slots+32+8,x
@pitch:
    ldy a_pal
    beq @store
    ; PAL's master clock is about 0.9% lower. Correct the largest divisors.
    cmp #166
    bcc :+
    sec
    sbc #1
:   cmp #55
    bcc @store
    sec
    sbc #1
@store:
    sta $d200,x
    jmp @next
@quiet:
    lda #0
    sta $d201,x
@next:
    inx
    inx
    cpx #8
    bne @channel
    rts
audio_silence:
    lda #0
    sta $d201
    sta $d203
    sta $d205
    sta $d207
    rts
