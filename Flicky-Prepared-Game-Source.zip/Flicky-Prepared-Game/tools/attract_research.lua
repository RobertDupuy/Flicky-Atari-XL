-- Unmodified, uncoined arcade attract sequence. Research only.
local m=manager.machine
local s=m.devices[":maincpu"].spaces["program"]
local screen=m.screens[":screen"]
local dir=assert(os.getenv("FLICKY_ORACLE_DIR"))
local f=0
emu.register_frame_done(function()
  f=f+1
  if f>=600 and f<=2400 and f%4==0 then
    local state=assert(io.open(dir..string.format("/state-%04d.bin",f),"wb"))
    for a=0xc000,0xefff do state:write(string.char(s:read_u8(a))) end
    state:close()
  end
  if f%30==0 then
    screen:snapshot(dir..string.format("/frame-%04d.png",f))
    local file=assert(io.open(dir..string.format("/ram-%04d.bin",f),"wb"))
    for a=0,65535 do file:write(string.char(s:read_u8(a))) end
    file:close()
  end
  if f>=2400 then m:exit() end
end)
