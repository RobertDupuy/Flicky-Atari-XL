; Bonus-only raster code lives below the display lists, outside both SIC!
; windows. No rendering, physics, collision or score work occurs in a DLI.
.import __BONUSDISPLAY_LOAD__
.segment "FIXED"
bonus_display_init:
    lda #16
    NATIVE_BANK
    jmp bonus_display_init_bank
.segment "BANK16"
bonus_display_init_bank:
    lda #0
    sta $d40e
    ldx #0
@copy:
    lda __BONUSDISPLAY_LOAD__,x
    sta $1000,x
    lda __BONUSDISPLAY_LOAD__+$100,x
    sta $1100,x
    inx
    bne @copy
    ; Additional palette boundaries, alongside the seven existing font DLIs.
    lda #$d4
    .repeat 2,B
        sta $1502+B*$80+21*3
        sta $1502+B*$80+25*3
        sta $1502+B*$80+26*3
    .endrepeat
    lda #<bonus_display_nmi
    sta $fffa
    lda #>bonus_display_nmi
    sta $fffb
    ; game_round_load enables DMA/NMI after the complete screen is installed.
    rts

.segment "BONUSDISPLAY"
bonus_display_nmi:
    sta $1b
    bit $d40f
    bmi bonus_display_dli
    ; Restore sky inks every VBI before the shared buffer-flip/input/audio path.
    lda #$9a
    sta $d017
.if PAL_MULTI_PROP
    lda #$1c
.else
    lda #$3c
.endif
    sta $d018
    lda #<bonus_dli_0
    sta bonus_display_dli+1
    lda #>bonus_dli_0
    sta bonus_display_dli+2
    lda $1b
    jmp sic_nmi
bonus_display_dli:
    jmp bonus_dli_0

.macro BONUS_NEXT next
    lda #<next
    sta bonus_display_dli+1
    lda #>next
    sta bonus_display_dli+2
    lda $1b
    rti
.endmacro
.macro BONUS_FONT next
    lda r_band
    sta $d40a
    sta $d409
    cld
    clc
    adc #4
    sta r_band
    BONUS_NEXT next
.endmacro
bonus_dli_0: BONUS_FONT bonus_dli_1
bonus_dli_1: BONUS_FONT bonus_dli_2
bonus_dli_2: BONUS_FONT bonus_dli_3
bonus_dli_3: BONUS_FONT bonus_dli_4
bonus_dli_4: BONUS_FONT bonus_dli_5
bonus_dli_5: BONUS_FONT bonus_dli_cats
bonus_dli_cats:
.if PAL_MULTI_PROP
    lda #$38
.else
    lda #$48
.endif
    sta $d40a
    sta $d017
.if PAL_MULTI_PROP
    lda #$1c
.else
    lda #$3c
.endif
    sta $d018
    BONUS_NEXT bonus_dli_6
bonus_dli_6:
    lda r_band
    sta $d40a
    sta $d409
.if PAL_MULTI_PROP
    lda #$1a
.else
    lda #$3a
.endif
    sta $d018
    BONUS_NEXT bonus_dli_floor
bonus_dli_floor:
.if PAL_MULTI_PROP
    lda #$a8
.else
    lda #$c8
.endif
    sta $d40a
    sta $d017
    BONUS_NEXT bonus_dli_floor_shade
bonus_dli_floor_shade:
.if PAL_MULTI_PROP
    lda #$a6
.else
    lda #$c6
.endif
    sta $d40a
    sta $d017
    BONUS_NEXT bonus_dli_0
    .res 512-(*-bonus_display_nmi),0
