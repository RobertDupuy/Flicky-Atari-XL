# Attract animation, scenery visibility and delivery awards

The 512 KB PAL and NTSC cartridges replace the static title with the original
arcade motorcycle, balloons, airplane, bombs and FLICKY letter unscrambling
sequence. The approved native redraw uses a 14-by-24-pixel motorcycle/rider
and a 20-by-25-pixel biplane/pilot, up from 12 by 20 and 17 by 21.
Both width and height increases stay within the approved 20% limit. The motorcycle, jumping Flicky and chicks remain separate animated
actors following the original positions. Research used the original uncoined MAME attract sequence; the Atari
runs prepared native data and handwritten 6502 code, with no arcade emulator.

The adaptation uses 160 by 224 color pixels, seven ANTIC character sets,
separate display buffers, scenery palette changes and four hardware players
multiplexed every eight scanlines. The sky uses two neighboring blue shades, blended across scanlines
24–55, with a steady richer blue below. This replaces the broad, high-contrast
blue bands. Rose balloons, deeper purple aircraft, stronger green foliage
and blue mountains improve contrast using actual GTIA palette values; the
emulator's color controls are unchanged. The sky DLI waits through the first
character-line DMA and finishes before the next interrupt. Raster code
writes only changing registers, and empty bands prepare player positions
before they become visible. The display and player DMA share the same
16-scanline origin, placing the entire 224-line intro inside the NTSC viewport.
It contains 315 sampled poses. Decoding
holds each completed picture until the next one is ready; playback is slower
than the arcade (about 30 seconds PAL and 34 seconds NTSC). The supplied video
is an unretimed recording of the actual cartridge. Fire can start the game
while the animation plays or after the settled logo.

Decorative wall backgrounds are now plain black, except the retained artwork
in rounds 20–22. This policy repeats with the 48-layout cycle. Only wall glyph
pixels are removed; shared blue inks remain available to actors and decorative
objects. Original tile collision masks, platforms and room geometry are
unchanged. Stationary chicks are baked against the same background policy so
their transparent areas cannot restore blue wall fragments. Hardware players have priority over
all playfield colors so scenery cannot hide Flicky or the cats. All 48 numbered
rounds were captured in both video standards through the ordinary round loader.
The screenshot gallery uses diagnostic round selection, not played completion.
Bonus rounds occur every fourth round, beginning with round 3.

The new scenery regression checks every background cell in all 36 ordinary
rounds, both display buffers, native messages and the three preserved layouts.
The refreshed gallery waits for the round loader to finish before capturing.

Delivery score actors now render native outlined digits. Original train awards
are 100, 200, 300, 400, 500, 1000, 2000 and 5000 points. The original positions,
four-actor history and lifetimes are retained; the last award is allowed to
finish before Round Clear. Values depend on the length of the delivered train,
so separate partial deliveries restart at 100.

Prepared builds need no original executable ROM. They include the converted
animation in build/native/attract-pixels.npz and corrected wall glyphs in
build/native/scenery-wall-glyphs.bin. The research-only tools can regenerate
those inputs when separately supplied original ROMs and MAME are available.

Validation covers every animation frame, player bitmap and raster program;
interrupts during stream decoding; buffer isolation; comparison of the actual
lossless Atari800 video with all prepared pixels and hardware overlays; all eight delivery labels
at all four horizontal phases; music/effect continuity; the original bonus
physics and scoring; and all 48 rooms. Emulator probes also check startup,
fire-to-start, bonus DLI boundaries and return from Round Clear.
