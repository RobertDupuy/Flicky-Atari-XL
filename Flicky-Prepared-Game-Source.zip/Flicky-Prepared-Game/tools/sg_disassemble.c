/* Host-side SG-1000 research tool; never included in the Atari cartridge. */
#define CHIPS_UTIL_IMPL
#include "../vendor/z80dasm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char rom[65536];
static unsigned cursor, length;
static char instruction[256];
static uint8_t next(void *unused) { return rom[(cursor++) & 65535]; }
static void emit(char c, void *unused) { instruction[length++] = c; }
int main(int argc, char **argv) {
    if (argc < 2) return 2;
    FILE *f=fopen(argv[1], "rb"); if (!f) return 2;
    unsigned size=fread(rom,1,sizeof rom,f); fclose(f);
    unsigned pc=argc>2?strtoul(argv[2],0,16):0;
    unsigned end=argc>3?strtoul(argv[3],0,16):size;
    while(pc<end) {
        cursor=pc;length=0;
        unsigned nextpc=z80dasm_op(pc,next,emit,0);
        instruction[length]=0;
        printf("%04X  ",pc);
        for(unsigned i=0;i<5;i++) {
            if(pc+i<cursor)printf("%02X ",rom[pc+i]);else printf("   ");
        }
        printf(" %s\n",instruction);
        if(nextpc<=pc)break;
        pc=nextpc;
    }
}
