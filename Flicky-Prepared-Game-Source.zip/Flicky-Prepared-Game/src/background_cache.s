; Cache clean background glyphs in otherwise unused stock-64K RAM pages.
; Guest collision-address aliases are intercepted by the bus, so host storage
; underneath F1xx and FCxx cannot be overwritten by a guest reset-latch write.
bg_dirty = $0610
bg_scroll = $0611
bg_yscroll = $0612
bg_valid = $0613
bg_full = $0614
.segment "FIXED"
cache_prepare:
    lda bg_valid
    beq @rebuild
    lda bg_dirty
    bne @rebuild
    lda r_bg_color
    cmp bg_scroll
    bne @rebuild
    lda $efbd
    cmp bg_yscroll
    bne @rebuild
    jsr cache_restore
    sec
    rts
@rebuild:
    clc
    rts
cache_buffer:
    lda r_backscreen
    and #4
    lsr a
    lsr a
    tax
    lda bg_full,x
    sta r_full
    txa
    lsr a
    ror a
    sta r_bufid
    rts
cache_restore:
    jsr cache_buffer
    lda #0
    sta r_cachepage
@page:
    lda r_cachepage
    asl a
    asl a
    asl a
    sta r_y
    jsr render_addresses
    ldx r_cachepage
    lda cache_pages,x
    sta r_cacheptr+1
    lda #0
    sta r_cacheptr
    sta r_col
@cell:
    lda r_col
    and #7
    tax
    lda render_pixelbits,x
    sta r_mask
    lda r_col
    lsr a
    lsr a
    lsr a
    sta r_index
    lda r_cachepage
    asl a
    asl a
    ora r_index
    tax
    lda $f680,x
    and r_mask
    beq :+
    lda #$80
:   sta r_ink
    lda r_cachepage
    and #3
    asl a
    asl a
    asl a
    asl a
    asl a
    ora r_col
    ora r_ink
    ldy r_col
    sta (r_screen),y
    lda r_full
    bne @copy
    txa
    ora r_bufid
    tax
    lda $f700,x
    and r_mask
    beq @next
@copy:
    lda r_col
    asl a
    asl a
    asl a
    tay
    ldx #8
@byte:
    lda (r_cacheptr),y
    sta (r_font),y
    iny
    dex
    bne @byte
@next:
    inc r_col
    lda r_col
    cmp #32
    bne @cell
    inc r_cachepage
    lda r_cachepage
    cmp #28
    beq :+
    jmp @page
:   ldy #0
@clean:
    tya
    ora r_bufid
    tax
    lda #0
    sta $f700,x
    iny
    cpy #112
    bne @clean
    lda r_backscreen
    and #4
    lsr a
    lsr a
    tax
    lda #0
    sta bg_full,x
    rts
cache_capture:
    lda #0
    sta r_font
    sta r_cacheptr
    sta r_cachepage
    lda r_backfont
    sta r_font+1
@page:
    ldx r_cachepage
    lda cache_pages,x
    sta r_cacheptr+1
    ldy #0
@copy:
    lda (r_font),y
    sta (r_cacheptr),y
    iny
    bne @copy
    inc r_font+1
    inc r_cachepage
    lda r_cachepage
    cmp #28
    bne @page
    lda #0
    sta r_screen
    lda r_backscreen
    sta r_screen+1
    ldx #0
@inkbyte:
    lda #0
    sta r_bitmap
    lda #8
    sta r_count
    ldy #0
@inkbit:
    lda (r_screen),y
    asl a
    rol r_bitmap
    inc r_screen
    bne :+
    inc r_screen+1
:   dec r_count
    bne @inkbit
    lda r_bitmap
    sta $f680,x
    inx
    cpx #112
    bne @inkbyte
    lda #0
    ldx #0
@dirty:
    sta $f700,x
    inx
    bne @dirty
    sta bg_dirty
    lda r_bg_color
    sta bg_scroll
    lda $efbd
    sta bg_yscroll
    lda #1
    sta bg_valid
    sta bg_full
    sta bg_full+1
    jsr cache_buffer
    lda #0
    sta bg_full,x
    rts
cache_mark:
    lda r_col
    and #7
    tax
    lda render_pixelbits,x
    sta r_mask
    lda r_col
    lsr a
    lsr a
    lsr a
    sta r_index
    lda r_y
    lsr a
    and #$7c
    ora r_index
    ora r_bufid
    tax
    lda $f700,x
    ora r_mask
    sta $f700,x
    rts
cache_pages:
    .byte $0f,$10,$13,$16,$17,$3c,$3d,$3e,$3f,$5c,$5d,$5e,$5f
    .byte $6c,$6d,$6e,$6f,$78,$79,$7a,$7b,$7c,$7d,$7e,$7f,$fc,$fd,$fe
