u_mode=$07ec
u_armed=$07ed
u_extra=$07ee
u_high=$0690
.segment "FIXED"
.export ui_init,ui_tick,ui_refresh,u_mode
ui_init:
    lda #15
    NATIVE_BANK
    jmp ui_init_bank
ui_tick:
    lda #15
    NATIVE_BANK
    jmp ui_tick_bank
ui_refresh:
    lda #15
    NATIVE_BANK
    jmp ui_refresh_bank
.segment "BANK15"
ui_init_bank:
    lda #255
    sta r_coarse_cache
    sta r_coarse_cache+1
    sta $e700
    ldx #89
@lists:
    lda native_dl0,x
    sta $1500,x
    lda native_dl1,x
    sta $1580,x
    dex
    bpl @lists
    lda #0
    sta $1503
    sta $1583
    lda #32
    sta $1506
    sta $1586
    lda #$1f
    sta $1504
    sta $1584
    sta $1507
    sta $1587
    ldx #0
@copy:
    .repeat 4,I
        lda ui_font+I*256,x
        sta $e000+I*256,x
        lda ui_title+I*256,x
        sta $e800+I*256,x
    .endrepeat
    txa
    asl a
    asl a
    asl a
    sta $f300,x
    txa
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    sta $f380,x
    inx
    bpl @copy
    ; The lookup occupies $f300-$f3ff; copy the remaining font/title halves.
@rest:
    .repeat 4,I
        lda ui_font+I*256,x
        sta $e000+I*256,x
        lda ui_title+I*256,x
        sta $e800+I*256,x
    .endrepeat
    inx
    bne @rest
    rts
ui_tick_bank:
    lda u_mode
    beq @playing
    cmp #3
    beq @playing
    cmp #2
    bne @title
    lda u_wait
    beq @intro_done
    dec u_wait
    lda #0
    rts
@intro_done:
    lda #0
    sta u_mode
    jsr ui_init_bank
@playing:
    lda #1
    rts
@title:
    lda n_input
    and #4
    beq @pressed
    lda #1
    sta u_armed
@wait:
    lda #0
    rts
@pressed:
    lda u_armed
    beq @wait
    lda #2
    rts

ui_refresh_bank:
    .repeat 8,I
        .if I<3
            lda n_score+I
        .elseif I=3
            lda n_lives
        .elseif I=4
            lda n_round
        .elseif I=5
            lda n_rescued
        .elseif I=6
            lda n_flow
        .else
            lda b_caught
        .endif
        cmp $e700+I
        bne @changed
    .endrepeat
    rts
@changed:
    .repeat 8,I
        .if I<3
            lda n_score+I
        .elseif I=3
            lda n_lives
        .elseif I=4
            lda n_round
        .elseif I=5
            lda n_rescued
        .elseif I=6
            lda n_flow
        .else
            lda b_caught
        .endif
        sta $e700+I
    .endrepeat
    ; BCD order is also unsigned lexical order from most significant byte.
    ldx #2
@high:
    lda n_score,x
    cmp u_high,x
    bcc @hud
    bne @record
    dex
    bpl @high
    bmi @hud
@record:
    ldx #2
@save:
    lda n_score,x
    sta u_high,x
    dex
    bpl @save
@hud:
    ldx #31
@template:
    lda ui_hud,x
    sta $1f00,x
    lda ui_status,x
    sta $1f20,x
    dex
    bpl @template
    lda n_score+2
    ldx #6
    jsr ui_bcd
    lda n_score+1
    jsr ui_bcd
    lda n_score
    jsr ui_bcd
    ldx #19
    lda u_high+2
    jsr ui_bcd
    lda u_high+1
    jsr ui_bcd
    lda u_high
    jsr ui_bcd
    lda n_lives
    clc
    adc #27
    sta $1f26
    lda n_round
    clc
    adc #1
    ldx #48
    jsr ui_decimal
    lda n_rescued
    ldy #0
@count:
    lsr a
    bcc :+
    iny
:   cmp #0
    bne @count
    tya
    clc
    adc #27
    sta $1f3b
    lda n_bonus
    beq @flow
    ldx #31
@bonus_text:
    lda ui_bonus,x
    sta $1f20,x
    dex
    bpl @bonus_text
    lda b_caught
    ldx #55
    jsr ui_decimal
@flow:
    lda n_flow
    cmp #3
    bne @clear
    ldx #31
@over:
    lda ui_game_over,x
    sta $1f20,x
    dex
    bpl @over
    rts
@clear:
    cmp #2
    bne @extra
    lda n_bonus
    bne @extra
    ldx #31
@clear_text:
    lda ui_clear,x
    sta $1f20,x
    dex
    bpl @clear_text
@extra:
    lda n_score+2
    cmp u_extra
    beq @done
    bcc @done
    sta u_extra
    lda n_lives
    cmp #9
    bcs @done
    inc n_lives
    lda #$8f
    sta n_sound_event
@done:
    rts
ui_bcd:
    pha
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #27
    sta $1f00,x
    inx
    pla
    and #15
    clc
    adc #27
    sta $1f00,x
    inx
    rts
ui_decimal:
    ldy #27
@ten:
    cmp #10
    bcc @digit
    sbc #10
    iny
    cpy #37
    bcc @ten
    ldy #27
    bne @ten
@digit:
    pha
    tya
    sta $1f00,x
    inx
    pla
    clc
    adc #27
    sta $1f00,x
    rts
