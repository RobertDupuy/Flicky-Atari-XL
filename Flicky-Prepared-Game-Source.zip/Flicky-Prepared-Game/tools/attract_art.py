"""Convert verified arcade attract frames to native character/PMG animation.

Research conversion consumes private MAME snapshots. Normal builds consume the
prepared native stream: no Z80 code, emulator, or original ROM runs on Atari.
"""
import argparse,ctypes as C,json
from collections import Counter
from pathlib import Path
import numpy as np
from PIL import Image
from build import BUILD,ROOT
from round_clear_art import LETTERS

SOURCE_PALETTES=((232,255,0,231,63),(232,51,19,229,63),(51,255,0,192,63))
PAL_PALETTES=((0x9c,0x0e,0,0x4c,0xee),(0x9c,0xba,0xb2,0x6c,0xec),(0xba,0x0e,0,0x8a,0xee))
NTSC_PALETTES=((0xac,0x0e,0,0x5c,0x2e),(0xac,0xca,0xc2,0x7c,0x2c),(0xca,0x0e,0,0x9a,0x2e))

def research():
    from run_reference import Reference
    r=Reference();r.lib.fm_sprite_picture.restype=C.POINTER(C.c_uint16)
    sprites=np.ctypeslib.as_array(r.lib.fm_sprite_picture(),shape=(224,256))
    frames=[];actors=[];times=[]
    for path in sorted((BUILD/'attract-research/mame').glob('state-*.bin')):
        r.ram[0xc000:0xf000]=np.frombuffer(path.read_bytes(),dtype=np.uint8)
        # The arcade's credit/HUD prompts are tile overlays. Keep the actual
        # scenery and sprite animation, with a native FIRE prompt below.
        r.ram[0xe800:0xef00]=0;r.lib.fm_render_snapshot(0)
        if np.sum(r.picture==232)<20000:continue
        frames.append(r.picture[:,::2].copy());actors.append(sprites.copy())
        times.append(int(path.stem.split('-')[1]))
    np.savez_compressed(BUILD/'attract-research/mame-frames.npz',frames=frames,sprites=actors,times=times)
    print('MAME intro:',len(times),'frames sampled:',times[0],times[-1],flush=True)

def compile_pixels(frames,sprites):
    rgb=np.array([[(v&7)*255/7,(v>>3&7)*255/7,(v>>6)*85] for v in range(256)])
    # Area samples keep thin source edges when moving from 256 to 160 colors.
    sx=np.minimum((np.arange(160)+.5)*256/160,255).astype(int)
    outputs=[];overlays=[];muxes=[];previews=[];conflicts=0
    for number,(frame,sp) in enumerate(zip(frames,sprites)):
        source=frame[:,sx];actors=sp[:,sx]
        pixels=np.zeros((224,160),dtype=np.uint8);pmg=np.zeros((4,256),dtype=np.uint8)
        mux=np.zeros((28,4,2),dtype=np.uint8)
        colors=rgb[source]
        for row in range(28):
            y=row*8;zone=0 if y<144 else 1 if y<184 else 2
            pal=rgb[list(SOURCE_PALETTES[zone])]
            values=colors[y:y+8];distance=np.sum((values[:,:,None,:]-pal[None,None,:,:])**2,axis=3)
            pixels[y:y+8]=np.argmin(distance,axis=2)
            if zone==0:
                gray=(values.max(axis=2)-values.min(axis=2)<50)&(values.min(axis=2)>70)
                pixels[y:y+8][gray]=1
            # Extra hardware colors are multiplexed independently in each
            # eight-scanline band. Four players cover four selected spans.
            actor=actors[y:y+8]!=0
            candidates=[]
            if zone==0:
                wanted=actor&(values[:,:,2]>values[:,:,0]*1.25)&(values[:,:,1]<160)&(values[:,:,2]>values[:,:,1]*1.1)
                candidates.append((wanted,0x8a,0x9a))
            elif zone==1:
                wanted=(values.min(axis=2)>220)
                candidates.append((wanted,0x0e,0x0e))
                wanted=actor&(values[:,:,2]>values[:,:,0]*1.25)&(values[:,:,1]<160)&(values[:,:,2]>values[:,:,1]*1.1)
                candidates.append((wanted,0x8a,0x9a))
            else:
                wanted=actor&(values[:,:,0]>160)&(values[:,:,1]<145)&(values[:,:,2]<145)
                candidates.append((wanted,0x38,0x48))
                wanted=actor&(values[:,:,2]>values[:,:,0]*1.25)&(values[:,:,1]<160)&(values[:,:,2]>values[:,:,1]*1.1)
                candidates.append((wanted,0x8a,0x9a))
            chosen=[]
            for player in range(4):
                best=None
                for ci,(wanted,pc,nc) in enumerate(candidates):
                    counts=wanted.sum(axis=0);sums=np.convolve(counts,np.ones(8,dtype=int),'valid')
                    x=int(np.argmax(sums));score=int(sums[x])
                    if score and (best is None or score>best[0]):best=(score,ci,x,pc,nc)
                if best is None:break
                _,ci,x,pc,nc=best;wanted=candidates[ci][0]
                mask=wanted[:,x:x+8].copy();wanted[:,x:x+8]=False
                chosen.append((x,pc,nc,mask))
            # Leftmost player gets the earliest DLI register stores.
            chosen.sort(key=lambda q:q[0])
            for player,(x,pc,nc,mask) in enumerate(chosen):
                pmg[player,16+y:16+y+8]=np.packbits(mask,axis=1)[:,0]
                mux[row,player]=[48+x,pc]
        # Native letterforms, without the arcade credit counters.
        pixels[208:224]=0
        message='FIRE TO PLAY';x=(160-(len(message)*6-1))//2
        for char in message:
            for yy,line in enumerate(LETTERS[char]):
                for xx,b in enumerate(line):
                    if b=='1':pixels[209+yy,x+xx]=1
            x+=6
        # A character can select PF2 or PF3, but not both. Keep gold actors;
        # substitute the nearest shared ink for the conflicting fourth ink.
        for row in range(28):
            zone=0 if row<18 else 1 if row<23 else 2
            pal=rgb[list(SOURCE_PALETTES[zone])]
            for col in range(40):
                a=pixels[row*8:row*8+8,col*4:col*4+4]
                if np.any(a==4) and np.any(a==3):
                    common=int(np.argmin(np.sum((pal[:3]-pal[3])**2,axis=1)))
                    conflicts+=np.sum(a==3);a[a==3]=common
        outputs.append(pixels);overlays.append(pmg);muxes.append(mux)
        if number%30==0:
            pic=np.empty((224,160,3),dtype=np.uint8)
            for row in range(28):
                zone=0 if row<18 else 1 if row<23 else 2
                pic[row*8:row*8+8]=rgb[list(SOURCE_PALETTES[zone])][pixels[row*8:row*8+8]]
                for player in range(4):
                    x,color=mux[row,player]
                    if not x:continue
                    x=int(x)-48
                    bits=np.unpackbits(pmg[player,16+row*8:16+row*8+8,None],axis=1).astype(bool)
                    pic[row*8:row*8+8,x:x+8][bits]=rgb[{0x8a:192,0x38:7,0x0e:255}[int(color)]]
            previews.append((number,pic))
    return np.array(outputs),np.array(overlays),np.array(muxes),previews

def patch(previous,current):
    """Absolute writes, with runs of a repeated byte encoded as short fills."""
    changed=np.flatnonzero(previous!=current);result=bytearray();i=0
    while i<len(changed):
        start=int(changed[i]);end=start+1;i+=1
        while i<len(changed) and changed[i]-end<4 and changed[i]-start<127:
            end=int(changed[i])+1;i+=1
        data=bytes(current[start:end]);length=len(data)
        if length>=4 and len(set(data))==1:result+=bytes([length|128,start&255,start>>8,data[0]])
        else:result+=bytes([length,start&255,start>>8])+data
    return result

def trial(pixels):
    # Stable per-band caches, separately for the two complete display buffers.
    cache=[[{} for _ in range(7)] for _ in range(2)]
    previous=[np.zeros(65536,dtype=np.uint8) for _ in range(2)]
    sizes=[];maximum=0;stream=bytearray();dictionary={bytes(8):0};optimized=bytearray()
    for f,pix in enumerate(pixels):
        back=f&1;mem=previous[back].copy();font=0x2000+back*8192;screen=0x6000+back*4096
        for band in range(7):
            cells=[]
            for row in range(band*4,band*4+4):
                for col in range(40):
                    a=pix[row*8:row*8+8,col*4:col*4+4];inverse=128 if np.any(a==4) else 0
                    a=np.where(a==4,3,a)
                    g=np.sum(a*np.array([64,16,4,1]),axis=1).astype(np.uint8).tobytes()
                    cells.append((g,inverse))
            needed=set(g for g,_ in cells);maximum=max(maximum,len(needed));assert len(needed)<=128,(f,band,len(needed))
            old=cache[back][band];new={g:slot for g,slot in old.items() if g in needed}
            free=[x for x in range(128) if x not in new.values()]
            for g in dict.fromkeys(g for g,_ in cells):
                if g not in new:new[g]=free.pop(0)
            cache[back][band]=new
            for g,slot in new.items():mem[font+band*1024+slot*8:font+band*1024+slot*8+8]=np.frombuffer(g,dtype=np.uint8)
            mem[screen+band*160:screen+band*160+160]=[new[g]|inverse for g,inverse in cells]
        data=patch(previous[back],mem);sizes.append(len(data)+1);stream+=data+bytes(1)
        old=previous[back].copy()
        addresses=[address for address in range(font,font+7168,8) if not np.array_equal(old[address:address+8],mem[address:address+8])]
        i=0
        while i<len(addresses):
            start=addresses[i];end=i+1
            while end<len(addresses) and addresses[end]==addresses[end-1]+8 and end-i<126:end+=1
            optimized+=bytes([128+end-i,start&255,start>>8])
            for address in addresses[i:end]:
                g=bytes(mem[address:address+8])
                if g not in dictionary:dictionary[g]=len(dictionary)
                optimized+=dictionary[g].to_bytes(2,'little')
            i=end
        old[font:font+7168]=mem[font:font+7168]
        optimized+=patch(old,mem)+bytes(1)
        previous[back]=mem
    (BUILD/'attract-research/trial.bin').write_bytes(stream)
    print('dictionary',len(dictionary)*8,'glyph stream',len(optimized),'sum',len(dictionary)*8+len(optimized),flush=True)
    print('stream estimate',sum(sizes),'max frame',max(sizes),'max font patterns',maximum,flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--research',action='store_true');a=p.parse_args()
    if a.research:research()
    # Keep the original conversion helpers for research, but regenerate the
    # approved native actors and current palette for every production input.
    from attract_redraw import main as redraw
    redraw()

if __name__=='__main__':main()
