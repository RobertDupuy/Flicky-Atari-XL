.include "memory.inc"
.segment "FIXED"
.export start,native_idle,native_tick,game_update
start:
    sei
    cld
    ldx #$ff
    txs
    lda #0
    sta $d40e
    sta $d400
    sta $d20e
    lda #$fe
    sta $d301
    jsr native_reset
    jsr level_load
    jsr chicks_reset
    jsr enemies_reset
    jsr objects_reset
    jsr bonus_reset
    jsr display_init
    jsr idle_reset
    jsr floor_cache_reset
    jsr ui_init
    jsr prepared_terrain_load
    lda #0
    sta u_high
    sta u_high+1
    sta u_high+2
    lda #1
    sta u_mode
    jsr quick_player_terrain
    jsr quick_contacts
    lda #$82
    jsr audio_enqueue
native_idle:
    ; Never let a newly available back buffer starve queued gameplay ticks.
    sec
    lda c_produced
    sbc c_consumed
    cmp #3
    bcs @logic
    ; Prepare the next picture immediately after a flip. Logic consumes its
    ; timestamped input records in the remaining budget; no logic ticks drop.
    lda r_pending
    ora r_pace_started
    bne @logic
    lda r_host_frames
    and #1
    bne @logic
    lda #1
    sta r_pace_started
    jsr native_acquire_back
    jsr native_render_submit
@logic:
    jsr clock_take_tick
    beq native_idle
    jsr game_update
    lda n_sound_event
    beq native_idle
    jsr audio_enqueue
    lda #0
    sta n_sound_event
    jmp native_idle
.export native_acquire_back,native_render_submit,native_present
native_acquire_back:
    lda r_pending
    bne native_acquire_back
    lda r_front
    eor #1
    sta r_back
    rts
native_present:
    jsr native_acquire_back
    jsr native_render_submit
@flip:
    lda r_pending
    bne @flip
    lda r_front
    eor #1
    sta r_back
    rts
native_render_submit:
    jsr ui_refresh
    lda u_mode
    beq :+
    jsr display_scroll
    lda #1
    sta r_pending
    rts
:   
.ifdef BENCHMARK
    jsr benchmark_render
.endif
    jsr fast_sprites_begin
    jsr idle_update
    jsr sprite_draw_objects
    jsr fast_draw_chicks
    jsr pmg_prepare
    jsr sprite_draw_net
    jsr display_scroll
    lda z:p_count_index
    and #127
    ldx r_back
    sta r_dirty_counts,x
    lda #1
    sta r_pending
    rts
native_tick:
    lda #0
    sta n_scroll_delta
    sta n_scroll_delta+1
    lda n_flags+PLAYER
    and #4
    beq :+
    lda #0
    sta n_vx+CAMERA
    beq @tick_done
:   jsr world_motion
@tick_done:
    inc n_game_ticks
    rts
game_update:
.ifdef BENCHMARK
    jsr benchmark_tick
.endif
    jsr ui_tick
    cmp #1
    beq @playing
    cmp #2
    beq :+
    rts
:   jsr native_reset
    jmp game_round_load
@playing:
    jsr game_flow_tick
    bne :+
    rts
:   inc n_round_clock
    lda n_round_clock
    cmp #60
    bcc :+
    lda #0
    sta n_round_clock
    inc n_round_seconds
    bne :+
    inc n_round_seconds+1
:   lda n_bonus
    beq :+
    jmp bonus_update
:   lda n_game_ticks
    and #1
    bne :+
    jsr chicks_update
:   
    lda n_flags+PLAYER
    and #4
    beq @live
    lda n_grounded
    beq @live
    jsr player_death_update
    jmp @enemies
@live:
    lda n_terrain_contact
    bne @contact
    lda n_collision_wait
    beq @delay
    lda #0
    sta n_grounded
    sta n_ceiling
    jmp @controls
@delay:
    inc n_collision_wait
    jmp @terrain
@contact:
    lda #0
    sta n_collision_wait
@terrain:
    jsr prepared_player_sample
    jsr player_contacts
@controls:
    jsr player_controls
    jsr player_enemy_response
@enemies:
    lda n_life_lost
    beq :+
    jsr game_flow_tick
    rts
:   jsr enemies_update
    jsr objects_update
    jsr train_record_tick
    jsr popup_update
    jsr native_tick
    jsr quick_player_terrain
    lda n_game_ticks
    and #1
    bne :+
    rts
:   
    jmp quick_contacts
cart_init:
    rts
n_player_enemy=$07b3
.export n_player_enemy
l_dx=$3a
l_dy=$3b
l_bank=$3c
l_result=$3d
.segment "FIXED"
pickup_bits: .byte 1,2,4,8,16,32,64,128
.include "sic.s"
.include "motion.s"
.include "player.s"
.include "player-life.s"
.include "game-flow.s"
.include "chicks.s"
.include "cats.s"
.include "prepared-cats.s"
.include "prepared-motion.s"
.include "prepared-terrain.s"
.include "levels.s"
.include "display.s"
.include "sprites.s"
.include "sprite-cache.s"
.include "idle-background.s"
.include "object-sprites.s"
.include "fast-contacts.s"
.include "fast-render.s"
.include "objects.s"
.include "floor-objects.s"
.include "ui.s"
.include "messages.s"
.include "bonus.s"
.include "fast-chicks.s"
.include "pmg.s"
.include "prepared-objects.s"
.include "prepared-objects-data.s"
.include "prepared-art.s"
.include "stamp-writers.s"
.include "stamp-blits.s"
.include "benchmark-fixture.s"
.include "clock.s"
.include "rescue-timer.s"
.include "../common/audio.s"
.include "data.s"
.include "floor-object-data.s"
.include "cat-spawn-data.s"
.include "idle-contacts.s"
.include "idle-characters.s"

.include "lookup-tables.s"
.include "audio-data.s"
.include "ui-data.s"
.include "message-data.s"
.include "fast-chick-data.s"
.include "pose-strips.s"
.include "prepared-terrain-data.s"
.segment "VECTORS"
.word sic_boot
.byte 0,4
.word cart_init
