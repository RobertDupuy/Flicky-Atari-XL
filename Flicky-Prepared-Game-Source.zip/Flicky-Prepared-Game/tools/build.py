#!/usr/bin/env python3
"""Build the ROM-free stage 1 diagnostic cartridge and CPU test image."""
from pathlib import Path
import json, os, shutil, struct, subprocess, sys
from translate import translate, decode

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT/'build'
PROGRAM = bytes.fromhex('21 00 c1 06 10 3e 00 c6 03 77 23 10 fa 32 00 c0 fe 30 20 07 db 00 e6 1f d3 00 76 3e ee d3 00 76')

# Original tiny diagnostic font, three logical pixels wide in four-pixel cells.
FONT = {
'A':['010','101','111','101','101'], 'B':['110','101','110','101','110'],
'C':['011','100','100','100','011'], 'D':['110','101','101','101','110'],
'E':['111','100','110','100','111'], 'F':['111','100','110','100','100'],
'G':['011','100','101','101','011'], 'H':['101','101','111','101','101'],
'I':['111','010','010','010','111'], 'J':['001','001','001','101','010'],
'K':['101','101','110','101','101'], 'L':['100','100','100','100','111'],
'M':['101','111','111','101','101'], 'N':['101','111','111','111','101'],
'O':['010','101','101','101','010'], 'P':['110','101','110','100','100'],
'Q':['010','101','101','111','011'], 'R':['110','101','110','101','101'],
'S':['011','100','010','001','110'], 'T':['111','010','010','010','010'],
'U':['101','101','101','101','111'], 'V':['101','101','101','101','010'],
'W':['101','101','111','111','101'], 'X':['101','101','010','101','101'],
'Y':['101','101','010','010','010'], 'Z':['111','001','010','100','111'],
'0':['111','101','101','101','111'], '1':['010','110','010','010','111'],
'2':['110','001','010','100','111'], '3':['110','001','010','001','110'],
'4':['101','101','111','001','001'], '5':['111','100','110','001','110'],
'6':['011','100','110','101','010'], '7':['111','001','010','010','010'],
'8':['010','101','010','101','010'], '9':['010','101','011','001','110'],
'-':['000','000','111','000','000'], ':':['000','010','000','010','000'],
'/':['001','001','010','100','100'], '.':['000','000','000','000','010'],
}

def executable(name):
    found = os.environ.get(name.upper()) or shutil.which(name)
    if not found:
        local = ROOT.parent/'toolchain/root/usr/bin'/name
        if local.exists(): found = str(local)
    if not found: raise SystemExit(f'{name} is required (install cc65 or set {name.upper()})')
    return found

def assemble(source, output, cfg=None):
    cfg = cfg or ROOT/'src/cart.cfg'
    subprocess.run([executable('ca65'), '-I', str(ROOT/'src'), '-I', str(BUILD), '--bin-include-dir', str(BUILD), str(source), '-o', str(output.with_suffix('.o'))],check=True)
    subprocess.run([executable('ld65'), '-C', str(cfg), str(output.with_suffix('.o')), '-o', str(output), '-Ln', str(output.with_suffix('.lbl')), '-m', str(output.with_suffix('.map'))],check=True)

def assets():
    chars=bytearray(1024)
    for key, rows in FONT.items():
        for y, row in enumerate(rows):
            chars[(ord(key)-32)*8+y+1] = sum((c=='1')<<(6-2*x) for x,c in enumerate(row))
    chars[124*8:125*8] = bytes([0x55]*8)
    chars[125*8:126*8] = bytes([0xaa]*8)
    chars[126*8:127*8] = bytes([0xff]*8)
    chars[127*8:128*8] = bytes([0x1b,0x1b,0x1b,0x1b,0x1b,0x1b,0x1b,0x1b])
    (BUILD/'charset.bin').write_bytes(chars)
    screen=bytearray(1024)
    def text(y, s, x=None):
        if len(s)>40: raise ValueError(s)
        x = (40-len(s))//2 if x is None else x
        screen[y*40+x:y*40+x+len(s)]=bytes(ord(c)-32 for c in s)
    text(1,'FLICKY XL - STAGE 1')
    text(3,'Z80 TO 6502 TRANSLATION LAB')
    text(5,'128 KB XEGS CART / 64 KB RAM')
    text(7,'ROM-FREE CPU DIAGNOSTIC')
    text(8,'CPU/BANK/CLOCK:',6)
    text(8,'WAIT',27)
    text(10,'607 Z80 T-STATES / 74 M1 FETCHES')
    text(12,'ANTIC 4 - FIVE COLORS')
    for i,c in enumerate([0,124,125,126,254]):
        for y in (14,15): screen[y*40+5+i*6:y*40+9+i*6]=bytes([c]*4)
    text(17,'HOLD JOYSTICK LEFT OR RIGHT')
    text(21,'ORIGINAL FLICKY ROM NOT INCLUDED')
    text(23,'FOUNDATION BUILD - NOT THE GAME')
    (BUILD/'screen.bin').write_bytes(screen)

def main():
    BUILD.mkdir(exist_ok=True)
    assets()
    (BUILD/'diagnostic.z80').write_bytes(PROGRAM)
    (BUILD/'guest.s').write_text(translate(PROGRAM))
    assemble(ROOT/'src/cart.s', BUILD/'fixed.bin')
    fixed=(BUILD/'fixed.bin').read_bytes()
    assert len(fixed)==8192
    rom=b''.join(bytes([i])+bytes([255])*8191 for i in range(15))+fixed
    car=b'CART'+struct.pack('>III',14,sum(rom)&0xffffffff,0)+rom
    (BUILD/'flicky-xl-stage1.car').write_bytes(car)
    (BUILD/'flicky-xl-stage1.rom').write_bytes(rom)
    metadata={
      'stage':'1: translation foundation, NOT Flicky gameplay',
      'cart_type':14,'cart_format':'XEGS 128 KB','rom_bytes':len(rom),
      'machine':'Atari 800XL, 64 KB','display':'ANTIC 4 only, 40x24 characters',
      'diagnostic_guest_bytes':len(PROGRAM),
      'translated_instructions':len(decode(PROGRAM,PROGRAM)),
      'guest_tstates_per_run':607,'guest_m1_per_run':74,
      'sega_roms_included':False,
    }
    (BUILD/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps(metadata,indent=2))

if __name__=='__main__': main()
