; Four hardware players: two color planes for Flicky, one silhouette per cat.
; Prepared bytes are staged in foreground. VBI installs a complete pose and
; its position together; no font mutation and no scenery compositing.
pm_y=$06b0
pm_x=$06b4
pm_old_y=$06b8
pm_gold_x=$06e5
pm_gold_lo=$06e9
pm_gold_hi=$06ea
pm_gold_oldlo=$06eb
pm_gold_oldhi=$06ec
pm_gold_oldy=$06ed
pm_actor=$06bc
pm_slot=$06bd
pm_index=$06be
pm_left=$06c0
pm_top=$06c2
pm_src_lo=$06c4
pm_src_hi=$06c8
pm_old_lo=$06d0
pm_old_hi=$06d4
pm_ptr=$da
pm_out=$dc
pm_nmi_ptr=$1d
pm_nmi_src=$1f
.segment "FIXED"
.export pmg_init,pmg_prepare,pmg_present,pm_y,pm_x
pmg_init:
    lda #0
    ldx #0
@clear:
    sta $0b00,x
    sta $0c00,x
    sta $0d00,x
    sta $0e00,x
    sta $0f00,x
    sta $db00,x
    sta $dc00,x
    sta $dd00,x
    sta $de00,x
    sta $df00,x
    inx
    bne @clear
    ldx #31
@cache:
    sta $1d00,x
    dex
    bpl @cache
    ldx #3
@state:
    sta pm_gold_x,x
    sta $d004,x
    sta pm_x,x
    sta pm_y,x
    sta pm_old_lo,x
    sta pm_old_hi,x
    sta pm_old_y,x
    sta $d000,x
    sta $d008,x
    dex
    bpl @state
    sta pm_gold_oldhi
    sta pm_gold_oldy
    ; All four players precede the playfield; keep fifth-player gold missiles.
    lda #$11
    sta $d01b
    lda #$d8
    sta $d407
    lda #$9a
    sta $d012
    lda #$0e
    sta $d013
    lda $d014
    and #$0e
    beq @pal_cat
    lda #$3c
    bne @cat_color
@pal_cat:
    lda #$1c
@cat_color:
    sta $d014
    sta $d015
    lda #3
    sta $d01d
    rts

pmg_prepare:
    lda #8
    NATIVE_BANK
    ldx #3
    lda #0
@hide:
    sta pm_x,x
    dex
    bpl @hide
    lda n_flags+PLAYER
    bmi :+
    jmp @cats
:
    ldx n_animation+PLAYER
    lda native_player_height,x
    lsr a
    sta n_step
    lda n_ylo+PLAYER
    sec
    sbc n_step
    clc
    adc #1
    sta pm_top
    lda n_pose+PLAYER
    cmp #3
    bne :+
    inc pm_top
:   sec
    lda n_xlo+PLAYER
    sbc native_player_radius,x
    sta pm_left
    lda n_xhi+PLAYER
    sbc #0
    sta pm_left+1
    txa
    asl a
    asl a
    asl a
    sta pm_index
    lda n_frame+PLAYER
    and #3
    asl a
    ora pm_index
    sta pm_index
    lda n_flags+PLAYER
    and #1
    ora pm_index
    tax
    lda pm_player_lo,x
    sta pm_ptr
    lda pm_player_hi,x
    sta pm_ptr+1
    lda #0
    sta pm_slot
    lda pm_player_offset0,x
    jsr pmg_position
    lda pm_player_offset1,x
    inc pm_slot
    jsr pmg_position
    sec
    lda pm_x
    sbc pm_player_offset0,x
    sta n_step
    lda pm_player_offset2,x
    clc
    adc n_step
    sta pm_gold_x+0
    lda pm_player_offset3,x
    clc
    adc n_step
    sta pm_gold_x+1
    lda pm_player_offset4,x
    clc
    adc n_step
    sta pm_gold_x+2
    lda pm_player_offset5,x
    clc
    adc n_step
    sta pm_gold_x+3
    lda pm_ptr
    sta pm_src_lo
    clc
    adc #24
    sta pm_src_lo+1
    lda pm_ptr+1
    sta pm_src_hi
    adc #0
    sta pm_src_hi+1
    lda pm_ptr
    clc
    adc #48
    sta pm_gold_lo
    lda pm_ptr+1
    adc #0
    sta pm_gold_hi
@cats:
    lda n_bonus
    beq :+
    jmp pmg_upload
:
    lda #9
    sta pm_actor
    lda #2
    sta pm_slot
@cat:
    ldx pm_actor
    lda n_flags,x
    bmi :+
    jmp @next
:
    ldy n_animation,x
    lda n_flags,x
    and #2
    beq :+
    lda pm_cat_flip,y
    tay
:   lda native_cat_height,y
    lsr a
    sta n_step
    lda n_ylo,x
    sec
    sbc n_step
    clc
    adc #1
    sta pm_top
    clc
    lda n_xlo,x
    adc n_world
    sta pm_left
    lda n_xhi,x
    adc n_world+1
    sta pm_left+1
    sec
    lda pm_left
    sbc native_cat_radius,y
    sta pm_left
    lda pm_left+1
    sbc #0
    and #1
    sta pm_left+1
    tya
    asl a
    sta pm_index
    lda n_flags,x
    and #1
    ora pm_index
    tax
    lda pm_cat_lo,x
    sta pm_ptr
    lda pm_cat_hi,x
    sta pm_ptr+1
    lda pm_cat_offset0,x
    jsr pmg_position
    ldy pm_slot
    lda pm_ptr
    sta pm_src_lo,y
    lda pm_ptr+1
    sta pm_src_hi,y
@next:
    inc pm_slot
    inc pm_actor
    lda pm_actor
    cmp #11
    bcs :+
    jmp @cat
:   jmp pmg_upload

; Input A=prepared color-plane X offset. The world is 512 source units wide,
; shown as 128 ANTIC color clocks. Vertical position remains scanline precise.
; Preserve X for second Flicky plane.
pmg_position:
    sta n_step
    ldy pm_slot
    lda pm_top
    cmp #16
    bcc @hidden
    cmp #209
    bcs @hidden
    clc
    adc #24
    sta pm_y,y
    lda pm_left+1
    and #1
    lsr a
    lda pm_left
    ror a
    lsr a
    clc
    adc #64
    clc
    adc n_step
    sta pm_x,y
@hidden:
    rts

; Hardware address registers change only when the matching character buffer
; is presented. All bitmap writes have already finished in the back PM buffer.
.segment "FIXED"
pmg_present:
    ldx r_front
    lda pm_base,x
    sta $d407
    ldx #3
@positions:
    lda pm_x,x
    sta $d000,x
    lda pm_gold_x,x
    ldy pm_x
    bne :+
    lda #0
:   sta $d004,x
    dex
    bpl @positions
    rts
pm_base: .byte $08,$d8

pmg_upload:
    lda #8
    NATIVE_BANK
    lda r_back
    beq :+
    jmp pm_upload_buffer1
:   jmp pm_upload_buffer0

.segment "BANK8"
pm_upload_buffer0:
    lda pm_x+0
    bne :+
    jmp pm_done0_0
:   lda pm_y+0
    cmp $1d00
    bne pm_upload0_0
    lda pm_src_lo+0
    cmp $1d05
    bne pm_upload0_0
    lda pm_src_hi+0
    cmp $1d0a
    bne pm_upload0_0
    jmp pm_done0_0
pm_upload0_0:
    ldx $1d00
    cpx pm_y+0
    beq @copy
    lda #0
    .repeat 18,I
        sta $0c00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+0
    sta pm_ptr
    sta $1d05
    lda pm_src_hi+0
    sta pm_ptr+1
    sta $1d0a
    lda pm_y+0
    sta $1d00
    tax
    ldy #0
    .repeat 18,I
        lda (pm_ptr),y
        sta $0c00+I,x
        .if I<17
            iny
        .endif
    .endrepeat
pm_done0_0:
    lda pm_x+1
    bne :+
    jmp pm_done0_1
:   lda pm_y+1
    cmp $1d01
    bne pm_upload0_1
    lda pm_src_lo+1
    cmp $1d06
    bne pm_upload0_1
    lda pm_src_hi+1
    cmp $1d0b
    bne pm_upload0_1
    jmp pm_done0_1
pm_upload0_1:
    ldx $1d01
    cpx pm_y+1
    beq @copy
    lda #0
    .repeat 18,I
        sta $0d00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+1
    sta pm_ptr
    sta $1d06
    lda pm_src_hi+1
    sta pm_ptr+1
    sta $1d0b
    lda pm_y+1
    sta $1d01
    tax
    ldy #0
    .repeat 18,I
        lda (pm_ptr),y
        sta $0d00+I,x
        .if I<17
            iny
        .endif
    .endrepeat
pm_done0_1:
    lda pm_x+2
    bne :+
    jmp pm_done0_2
:   lda pm_y+2
    cmp $1d02
    bne pm_upload0_2
    lda pm_src_lo+2
    cmp $1d07
    bne pm_upload0_2
    lda pm_src_hi+2
    cmp $1d0c
    bne pm_upload0_2
    jmp pm_done0_2
pm_upload0_2:
    ldx $1d02
    cpx pm_y+2
    beq @copy
    lda #0
    .repeat 21,I
        sta $0e00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+2
    sta pm_ptr
    sta $1d07
    lda pm_src_hi+2
    sta pm_ptr+1
    sta $1d0c
    lda pm_y+2
    sta $1d02
    tax
    ldy #0
    .repeat 21,I
        lda (pm_ptr),y
        sta $0e00+I,x
        .if I<20
            iny
        .endif
    .endrepeat
pm_done0_2:
    lda pm_x+3
    bne :+
    jmp pm_done0_3
:   lda pm_y+3
    cmp $1d03
    bne pm_upload0_3
    lda pm_src_lo+3
    cmp $1d08
    bne pm_upload0_3
    lda pm_src_hi+3
    cmp $1d0d
    bne pm_upload0_3
    jmp pm_done0_3
pm_upload0_3:
    ldx $1d03
    cpx pm_y+3
    beq @copy
    lda #0
    .repeat 21,I
        sta $0f00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+3
    sta pm_ptr
    sta $1d08
    lda pm_src_hi+3
    sta pm_ptr+1
    sta $1d0d
    lda pm_y+3
    sta $1d03
    tax
    ldy #0
    .repeat 21,I
        lda (pm_ptr),y
        sta $0f00+I,x
        .if I<20
            iny
        .endif
    .endrepeat
pm_done0_3:
    lda pm_x
    bne :+
    jmp pm_done0_4
:   lda pm_y
    cmp $1d04
    bne pm_upload0_4
    lda pm_gold_lo
    cmp $1d09
    bne pm_upload0_4
    lda pm_gold_hi
    cmp $1d0e
    bne pm_upload0_4
    jmp pm_done0_4
pm_upload0_4:
    ldx $1d04
    cpx pm_y
    beq @copy
    lda #0
    .repeat 18,I
        sta $0b00+I,x
    .endrepeat
@copy:
    lda pm_gold_lo
    sta pm_ptr
    sta $1d09
    lda pm_gold_hi
    sta pm_ptr+1
    sta $1d0e
    lda pm_y
    sta $1d04
    tax
    ldy #0
    .repeat 18,I
        lda (pm_ptr),y
        sta $0b00+I,x
        .if I<17
            iny
        .endif
    .endrepeat
pm_done0_4:
    rts
pm_upload_buffer1:
    lda pm_x+0
    bne :+
    jmp pm_done1_0
:   lda pm_y+0
    cmp $1d10
    bne pm_upload1_0
    lda pm_src_lo+0
    cmp $1d15
    bne pm_upload1_0
    lda pm_src_hi+0
    cmp $1d1a
    bne pm_upload1_0
    jmp pm_done1_0
pm_upload1_0:
    ldx $1d10
    cpx pm_y+0
    beq @copy
    lda #0
    .repeat 18,I
        sta $dc00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+0
    sta pm_ptr
    sta $1d15
    lda pm_src_hi+0
    sta pm_ptr+1
    sta $1d1a
    lda pm_y+0
    sta $1d10
    tax
    ldy #0
    .repeat 18,I
        lda (pm_ptr),y
        sta $dc00+I,x
        .if I<17
            iny
        .endif
    .endrepeat
pm_done1_0:
    lda pm_x+1
    bne :+
    jmp pm_done1_1
:   lda pm_y+1
    cmp $1d11
    bne pm_upload1_1
    lda pm_src_lo+1
    cmp $1d16
    bne pm_upload1_1
    lda pm_src_hi+1
    cmp $1d1b
    bne pm_upload1_1
    jmp pm_done1_1
pm_upload1_1:
    ldx $1d11
    cpx pm_y+1
    beq @copy
    lda #0
    .repeat 18,I
        sta $dd00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+1
    sta pm_ptr
    sta $1d16
    lda pm_src_hi+1
    sta pm_ptr+1
    sta $1d1b
    lda pm_y+1
    sta $1d11
    tax
    ldy #0
    .repeat 18,I
        lda (pm_ptr),y
        sta $dd00+I,x
        .if I<17
            iny
        .endif
    .endrepeat
pm_done1_1:
    lda pm_x+2
    bne :+
    jmp pm_done1_2
:   lda pm_y+2
    cmp $1d12
    bne pm_upload1_2
    lda pm_src_lo+2
    cmp $1d17
    bne pm_upload1_2
    lda pm_src_hi+2
    cmp $1d1c
    bne pm_upload1_2
    jmp pm_done1_2
pm_upload1_2:
    ldx $1d12
    cpx pm_y+2
    beq @copy
    lda #0
    .repeat 21,I
        sta $de00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+2
    sta pm_ptr
    sta $1d17
    lda pm_src_hi+2
    sta pm_ptr+1
    sta $1d1c
    lda pm_y+2
    sta $1d12
    tax
    ldy #0
    .repeat 21,I
        lda (pm_ptr),y
        sta $de00+I,x
        .if I<20
            iny
        .endif
    .endrepeat
pm_done1_2:
    lda pm_x+3
    bne :+
    jmp pm_done1_3
:   lda pm_y+3
    cmp $1d13
    bne pm_upload1_3
    lda pm_src_lo+3
    cmp $1d18
    bne pm_upload1_3
    lda pm_src_hi+3
    cmp $1d1d
    bne pm_upload1_3
    jmp pm_done1_3
pm_upload1_3:
    ldx $1d13
    cpx pm_y+3
    beq @copy
    lda #0
    .repeat 21,I
        sta $df00+I,x
    .endrepeat
@copy:
    lda pm_src_lo+3
    sta pm_ptr
    sta $1d18
    lda pm_src_hi+3
    sta pm_ptr+1
    sta $1d1d
    lda pm_y+3
    sta $1d13
    tax
    ldy #0
    .repeat 21,I
        lda (pm_ptr),y
        sta $df00+I,x
        .if I<20
            iny
        .endif
    .endrepeat
pm_done1_3:
    lda pm_x
    bne :+
    jmp pm_done1_4
:   lda pm_y
    cmp $1d14
    bne pm_upload1_4
    lda pm_gold_lo
    cmp $1d19
    bne pm_upload1_4
    lda pm_gold_hi
    cmp $1d1e
    bne pm_upload1_4
    jmp pm_done1_4
pm_upload1_4:
    ldx $1d14
    cpx pm_y
    beq @copy
    lda #0
    .repeat 18,I
        sta $db00+I,x
    .endrepeat
@copy:
    lda pm_gold_lo
    sta pm_ptr
    sta $1d19
    lda pm_gold_hi
    sta pm_ptr+1
    sta $1d1e
    lda pm_y
    sta $1d14
    tax
    ldy #0
    .repeat 18,I
        lda (pm_ptr),y
        sta $db00+I,x
        .if I<17
            iny
        .endif
    .endrepeat
pm_done1_4:
    rts
