"""Verify real, lossless Atari800 video against every prepared native frame."""
import argparse,json,subprocess
from collections import Counter
from pathlib import Path
import numpy as np
from build import BUILD
from attract_palette import row_palette,ntsc_color,PMG_ORIGIN

def frames(mode):
    z=np.load(BUILD/'native/attract-pixels.npz');out=[]
    for pix,pmg,mux in zip(z['pixels'],z['pmg'],z['mux']):
        expected=np.empty((224,160),np.uint8)
        for row in range(28):
            y=row*8;expected[y:y+8]=np.array(row_palette(row,mode),np.uint8)[pix[y:y+8]]
            for player,(pos,color)in enumerate(mux[row]):
                if not pos:continue
                x=int(pos)-48;bits=np.unpackbits(pmg[player,PMG_ORIGIN+y:PMG_ORIGIN+y+8,None],axis=1).astype(bool)
                expected[y:y+8,x:x+8][bits]=ntsc_color(int(color))if mode=='ntsc'else color
        out.append(expected)
    return np.array(out)

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('pal','ntsc'),required=True)
    p.add_argument('--folder',type=Path,required=True);a=p.parse_args()
    capture=json.loads((a.folder/'capture.json').read_text());video=a.folder/capture['video']
    info=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,pix_fmt','-of','json',str(video)]))['streams'][0]
    assert info['pix_fmt']=='pal8',info
    width,height=info['width'],info['height'];size=width*height+1024;top=8 if a.mode=='pal'else 0
    target=frames(a.mode);last=None;seen=Counter();errors=[];host=0;eligible=0;transitions=[]
    ff=subprocess.Popen(['ffmpeg','-v','error','-i',str(video),'-map','0:v:0','-pix_fmt','pal8','-f','rawvideo','-'],stdout=subprocess.PIPE)
    while True:
        data=ff.stdout.read(size)
        if not data:break
        assert len(data)==size
        host+=1;raw=np.frombuffer(data[:width*height],np.uint8).reshape(height,width)
        view=raw[top:top+224,8:328];sample=view[:,::2]
        if sample[0,0]!=row_palette(0,a.mode)[0]or sample[-1,0]!=row_palette(27,a.mode)[0]:continue
        eligible+=1
        indices=np.arange(len(target))if last is None else np.arange(max(0,last-1),min(len(target),last+4))
        differences=np.count_nonzero(target[indices]!=sample,axis=(1,2));at=int(np.argmin(differences));match=int(indices[at]);bad=int(differences[at])
        if bad:
            all_diff=np.count_nonzero(target!=sample,axis=(1,2));match=int(np.argmin(all_diff));bad=int(all_diff[match])
        full_bad=int(np.count_nonzero(view!=np.repeat(target[match],2,axis=1)))
        if full_bad:
            rows=np.flatnonzero(np.any(sample!=target[match],axis=1)).tolist()
            errors.append(dict(host_frame=host,source_index=match,pixels=full_bad,rows=rows))
            if len(errors)<=3:np.savez_compressed(a.folder/f'pixel-error-{len(errors)}.npz',actual=view,expected=np.repeat(target[match],2,axis=1))
        else:
            seen[match]+=1
            if match!=last:transitions.append([host,match])
            last=match
    assert ff.wait()==0
    report=dict(mode=a.mode,video=video.name,lossless_original_recording=True,
       host_frames=host,intro_host_frames_checked=eligible,prepared_frames_seen=len(seen),
       prepared_frames_total=len(target),missing_frames=sorted(set(range(len(target)))-set(seen)),
       mismatched_host_frames=len(errors),errors=errors,transitions=transitions,
       comparison='Every 320 x 224 visible pixel, including DLI colors and PMG overlays')
    (a.folder/'pixel-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in ('errors','transitions')},indent=2))
    assert not errors,errors[:6]
    assert len(seen)==len(target),report['missing_frames']

if __name__=='__main__':main()
