"""Run the independently maintained MAME System 1 driver for visual/state QA."""
import os,subprocess
from build import ROOT,BUILD
def main():
    out=BUILD/'mame-oracle';out.mkdir(exist_ok=True)
    env=os.environ.copy()
    env['LD_LIBRARY_PATH']=str(ROOT.parent/'toolchain/root/usr/lib/x86_64-linux-gnu')
    env['SDL_VIDEODRIVER']='dummy'
    env['SDL_AUDIODRIVER']='dummy'
    env['FLICKY_ORACLE_DIR']=str(out)
    exe=ROOT.parent/'qa-tools/mame'
    with (out/'mame.log').open('w') as log:
        subprocess.run([str(exe),'flicky','-rompath',str(BUILD/'mame-roms'),
            '-video','none','-sound','none','-nothrottle','-skip_gameinfo',
            '-autoboot_delay','0','-autoboot_script',str(ROOT/'tools/mame_oracle.lua'),
            '-seconds_to_run','20'],env=env,stdout=log,stderr=log,check=True)
    print((out/'mame.log').read_text())
if __name__=='__main__':main()
