"""Prepare every prop pose; vertical phases share padded row strips."""
import json
from pathlib import Path

def build(out:Path,strips):
    d=json.loads((out/'object-assets.json').read_text());records=[]
    for idx,image in enumerate(d['images']):
        meta=d['records'][idx];raw=(out/f'object-pixels-{image:03d}.bin').read_bytes();h,w=raw[:2]
        phase=meta['phase'];sw=(meta['width']+1)//2;ow=min(5,sw);oh=min(h,10)
        data=[]
        for oy in range(10):
            pixels=[0]*8
            if oy<oh:
                sy=round(oy*(h-1)/max(1,oh-1))
                for ox in range(ow):
                    sx=phase+round(ox*(sw-1)/max(1,ow-1))
                    pixels[phase+ox]=raw[4+2*(sy*w+sx//4)]>>(6-2*(sx&3))&3
            data += [sum(pixels[c*4+x]<<(6-2*x) for x in range(4)) for c in range(2)]
        records.append(strips.put(data))
    lines=[];dir_banks=[]
    for phase in range(1):
        db=2 if phase<3 else 5;dir_banks.append(db)
        lines += [f'.segment "BANK{db}"',f'obj_dir_{phase}:']
        for label,bank in records:
            lines += [f'.word {label}',f'.byte {bank}']
    for phase in range(1,4):lines += [f'obj_dir_{phase}=obj_dir_0'];dir_banks.append(2)
    lines+=['.segment "FIXED"','obj_dir_lo:','.lobytes '+','.join(f'obj_dir_{i}'for i in range(4)),
            'obj_dir_hi:','.hibytes '+','.join(f'obj_dir_{i}'for i in range(4)),
            'obj_dir_bank:','.byte '+','.join(map(str,dir_banks)),
            'obj_kind_index:','.byte '+','.join(str(i*12)for i in range(15))]
    (out/'prepared-objects-data.s').write_text('\n'.join(lines)+'\n')
    (out/'prepared-objects.json').write_text(json.dumps({'variants':len(records)*4,'unique_strips':len(set(records)),
        'stamp_bytes':44*len(set(records)),'directory_bytes':12*len(records)},indent=2)+'\n')
