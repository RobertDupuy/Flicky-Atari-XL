"""Exercise the original round loader, including bonus and palette variants.

Round selection is a test harness memory edit, never a shipping-game shortcut.
The native CPU and independent Z80 core receive the same seeded state and inputs.
"""
import ctypes as C,json,sys
import numpy as np
from run_native import Native,BUILD
from run_reference import Reference

def main():
    rounds=list(range(1,49))+[49,72,96,99]
    if len(sys.argv)>1:rounds=[int(v) for v in sys.argv[1:]]
    report=[]
    out=BUILD/'rounds';out.mkdir(exist_ok=True)
    for round_number in rounds:
        r=Reference();n=Native(True)
        r.lib.fm_collisions(0);r.lib.fm_registers.restype=C.POINTER(C.c_uint16)
        for f in range(340):r.frame(255,254 if 180<=f<190 else 239 if 210<=f<220 else 255)
        r.lib.fm_until_halt(255,255)
        r.ram[0xc018]=round_number-1
        r.ram[0xc008]=((round_number-1)//10)*16+(round_number-1)%10
        n.run()
        n.memory[0xc000:0xd000]=r.ram[0xc000:0xd000]
        n.memory[0x7000:0x7800]=r.ram[0xd000:0xd800]
        n.memory[0xd800:0xf000]=r.ram[0xd800:0xf000]
        registers=list(r.lib.fm_registers()[:12])
        for i,key in enumerate(['f','c','e','l','ix','iy','sp','pc']):
            a=n.labels['z_'+key];n.memory[a]=registers[i]&255;n.memory[a+1]=registers[i]>>8
        for i,offset in [(8,6),(9,0),(10,2),(11,4)]:
            a=n.labels['z_alt']+offset;n.memory[a]=registers[i]&255;n.memory[a+1]=registers[i]>>8
        n.memory[n.labels['z_iff']]=1
        # Start just before the original round/maze lookup and loader.
        n.memory[n.labels['z_pc']]=0x8e;n.memory[n.labels['z_pc']+1]=1
        n.lib.at_prefetch(n.labels['interp_next'])
        r.lib.fm_boundary_mode(1)
        r.lib.fm_seek(0x018e)
        cycles=[]
        for frame in range(12):
            if frame==0:cycles.append(n.run(1_000_000_000))
            else:
                cycles.append(n.resume(255,255,1_000_000_000))
                r.lib.fm_boundary_irq()
            r.lib.fm_until_halt(255,255)
            np.testing.assert_array_equal(n.memory[0xc000:0xcf80],r.ram[0xc000:0xcf80],err_msg=f'round {round_number}, update {frame}')
            np.testing.assert_array_equal(n.memory[0x7000:0x7800],r.ram[0xd000:0xd800],err_msg=f'round {round_number} sprite RAM')
            np.testing.assert_array_equal(n.memory[0xd800:0xf000],r.ram[0xd800:0xf000],err_msg=f'round {round_number} video RAM')
        (out/f'round-{round_number:02d}.bin').write_bytes(r.ram.tobytes())
        row={'round':round_number,'updates':12,'max_cpu_cycles':max(cycles),'bonus':int(r.ram[0xc02c]),'fault':int(n.memory[n.labels['z_fault']])}
        report.append(row);print(row,flush=True)
        (out/'sweep.json').write_text(json.dumps(report,indent=2))
if __name__=='__main__':main()
