#!/usr/bin/env python3
"""Internal full-translation reference image. Final shipping target stays 128 KB."""
from pathlib import Path
import subprocess,struct,json
from build import ROOT,BUILD,executable

def main():
    subprocess.run(['python3',str(ROOT/'tools/aot.py')],check=True)
    memory=['ZP: start=$80,size=$80,type=rw;']
    segments=['ZEROPAGE:load=ZP,type=zp;']
    for b in range(31):
        memory.append(f'M{b}:start=$8000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;')
        segments.append(f'BANK{b}:load=M{b},type=ro,optional=yes;')
    memory+=['MF:start=$A000,size=$1FFA,type=ro,file=%O,fill=yes,fillval=$FF;','MV:start=$BFFA,size=6,type=ro,file=%O,fill=yes;']
    segments+=['FIXED:load=MF,type=ro,align=$100;','VECTORS:load=MV,type=ro;']
    cfg='MEMORY {\n'+'\n'.join(memory)+'\n}\nSEGMENTS {\n'+'\n'.join(segments)+'\n}\n'
    (BUILD/'game.cfg').write_text(cfg)
    subprocess.run([executable('ca65'),'-I',str(ROOT/'src'),'-I',str(BUILD),str(ROOT/'src/game.s'),'-o',str(BUILD/'game.o')],check=True)
    subprocess.run([executable('ld65'),'-C',str(BUILD/'game.cfg'),str(BUILD/'game.o'),'-o',str(BUILD/'game-native.bin'),'-Ln',str(BUILD/'game.lbl'),'-m',str(BUILD/'game.map')],check=True)
    rom=bytearray((BUILD/'game-native.bin').read_bytes())
    assert len(rom)==262144
    def put(bank,name):
        data=(ROOT/'private-roms'/name).read_bytes()
        rom[bank*8192:bank*8192+len(data)]=data
    put(0,'maincpu-data.bin');put(12,'tiles.bin');put(18,'sprites.bin');put(22,'soundcpu.bin')
    (BUILD/'flicky-reference.car').write_bytes(b'CART'+struct.pack('>III',23,sum(rom)&0xffffffff,0)+rom)
    print('Internal reference cart:',len(rom),'bytes')

if __name__=='__main__':main()
