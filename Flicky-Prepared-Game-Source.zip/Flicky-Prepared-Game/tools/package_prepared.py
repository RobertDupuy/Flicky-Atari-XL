#!/usr/bin/env python3
"""Package the prepared native build without original executable ROM inputs."""
import hashlib,json,re,shutil,zipfile
from pathlib import Path
from build import ROOT,BUILD

def main():
    out=ROOT/'release';out.mkdir(exist_ok=True)
    files=set()
    for folder in ('src','tools','tests','vendor'):
        files.update(p for p in (ROOT/folder).rglob('*')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.c','.h','.s','.inc','.cfg'))
    for name in ('README.md','PREPARED_ENGINE.md','SG1000_STUDY.md','THIRD_PARTY.md','.gitignore'):
        files.add(ROOT/name)
    files.add(BUILD/'sg1000-disassembly.txt')
    files.update(p for p in (BUILD/'sg-study').iterdir()if p.suffix in ('.txt','.json','.md'))
    native=BUILD/'native';seen=set()
    def source(path):
        if path in seen:return
        seen.add(path);files.add(path)
        for kind,name in re.findall(r'\.(include|incbin)\s+"([^"]+)"',path.read_text()):
            candidates=[path.parent/name,ROOT/'src/native'/name,native/name]
            target=next((p.resolve() for p in candidates if p.is_file()),None)
            if target is None:raise FileNotFoundError((path,name))
            if kind=='include':source(target)
            else:files.add(target)
    source(ROOT/'src/native/game.s')
    for kind in ('player','chick','cat'):
        files.add(native/f'{kind}-data.s')
        files.update(native.glob(f'{kind}-image-*.bin'))
    for kind in ('player','chick','cat','object'):files.add(native/f'{kind}-assets.json')
    files.add(native/'maps-reference.bin')
    files.update(native.glob('object-pixels-*.bin'))
    for name in ('tile-index.bin','tile-glyphs.bin'):files.add(BUILD/name)
    files.update(p for p in (BUILD/'audio').iterdir()if p.suffix in ('.bin','.json','.npy'))
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True)
    for src,dst in [(native/'prepared-play/timing.json','normal-play.json'),
                    (native/'prepared-stress/timing.json','maximum-load.json'),
                    (native/'prepared-render-verification.json','render.json'),
                    (native/'round-acceptance.json','rounds.json'),
                    (native/'final-prepared-tests.xml','tests.xml'),
                    (native/'chick-reference-tests.xml','chick-reference-tests.xml')]:
        shutil.copy2(src,evidence/dst)
    for name in ('raster-before','raster-after'):
        src=native/name/'result.json'
        if src.exists():shutil.copy2(src,evidence/(name+'.json'))
    cartridge=out/'Flicky-Prepared-Game.car'
    shutil.copy2(native/'flicky-native-dev.car',cartridge)
    manifest={'cartridge':cartridge.name,'sha256':hashlib.sha256(cartridge.read_bytes()).hexdigest(),
        'bytes':cartridge.stat().st_size,'rom_bytes':524288,'mapper':'SIC! 512 KB','target_ram_bytes':65536,
        'original_executable_roms_included':False,'stress_fixture_in_playable_cartridge':False}
    (evidence/'release.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files.update(evidence.iterdir())
    archive=out/'Flicky-Prepared-Game-Source.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(files):z.write(p,Path('Flicky-Prepared-Game')/p.relative_to(ROOT))
    shutil.copy2(native/'prepared-play/Flicky-Prepared-Game.gif',out/'Flicky-Prepared-Game.gif')
    print(json.dumps({'source_files':len(files),'source_zip_bytes':archive.stat().st_size,**manifest},indent=2))

if __name__=='__main__':main()
