; Compact object frames are prepared once per changed pose/alignment in RAM.
; Their steady display path uses the same native character compositor.
o_record=$1e18
o_pixels=$1e20
o_key=$50
o_phase=$51
o_slot=$52
o_stride=$53
o_column=$54
o_line=$55
o_offset=$56
o_plane=$57
o_rows=$58
o_cells=$59
o_id=$5a
o_maskptr=$5c
o_bitptr=$5e
o_base=$60
n_object_pose_cache=$07cb
n_object_phase_cache=$07d1
n_object_cache_valid=$07d7
p_object_mode=$f9
.segment "FIXED"
.export object_prepare,sprite_draw_object,sprite_draw_objects
object_prepare:
    lda #15
    NATIVE_BANK
    jmp object_prepare_bank
sprite_draw_object:
    jsr object_prepare
    jsr sprite_draw_prepared
    lda #0
    sta p_object_mode
    rts
sprite_draw_objects:
    lda #12
    sta n_actor_cursor
@actor:
    ldx n_actor_cursor
    jsr floor_cached_object
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #18
    bcc @actor
    lda #12
    sta n_actor_cursor
@moving:
    ldx n_actor_cursor
    lda n_flags,x
    bpl :+
    lda n_chick_state,x
    beq :+
    jsr prepared_object
:   inc n_actor_cursor
    lda n_actor_cursor
    cmp #18
    bcc @moving
    rts
.segment "BANK15"
object_buffer_hi: .byte $5c,$5d,$5e,$5f,$ce,$cf
object_prepare_bank:
    stx p_actor
    txa
    sec
    sbc #12
    sta o_slot
    lda #1
    sta p_visible
    ; Only the default floor pose has a persistent glyph identity. Rotations,
    ; flips and held/thrown objects use identities valid for this draw epoch.
    lda n_flags,x
    and #3
    ora n_frame,x
    bne @transient
    lda n_chick_state,x
    and #$e0
    beq :+
@transient:
    lda #1
:   sta p_object_mode
    ldy n_animation,x
    lda native_object_height_draw,y
    sta p_height
    lsr a
    sta n_step
    lda n_ylo,x
    sec
    sbc n_step
    clc
    adc #1
    sta p_y
    clc
    adc p_height
    bcc :+
    lda #0
    sta p_visible
:   lda native_object_radius_draw,y
    sta p_sprite_width
    clc
    lda n_xlo,x
    adc n_world
    sta p_screen
    lda n_xhi,x
    adc n_world+1
    sta p_screen+1
    sec
    lda p_screen
    sbc p_sprite_width
    sta p_screen
    lda p_screen+1
    sbc #0
    and #1
    sta p_screen+1
    beq @full
    lda p_screen
    cmp #208
    bcc @full
    eor #255
    clc
    adc #2
    lsr a
    jmp @clip
@full:
    lda #24
@clip:
    sta p_clip_count
    sec
    lda p_screen
    sbc n_world
    sta p_left
    lda p_screen+1
    sbc n_world+1
    sta p_left+1
    jsr sprite_mask_prefix
    lda p_clip_count
    clc
    adc #1
    lsr a
    sta n_step
    lda p_left
    lsr a
    lsr a
    and #3
    sta p_index
    clc
    adc n_step
    asl a
    tax
    lda native_prefix0,x
    sta p_draw_clip
    lda native_prefix1,x
    sta p_draw_clip+1
    lda native_prefix2,x
    sta p_draw_clip+2
    lda native_prefix3,x
    sta p_draw_clip+3
    ldx p_actor
    lda n_animation,x
    asl a
    sta o_key
    asl a
    clc
    adc o_key
    clc
    adc n_frame,x
    sta o_key
    lda n_flags,x
    and #2
    beq :+
    clc
    lda o_key
    adc #3
    sta o_key
:   lda o_key
    asl a
    sta o_key
    lda n_flags,x
    and #1
    ora o_key
    sta o_key
    lda p_y
    and #7
    asl a
    asl a
    ora p_index
    sta o_phase
    lda p_object_mode
    beq :+
    lda o_phase
    ora #$80
    sta o_phase
:
    ldx o_slot
    lda #0
    sta p_image
    lda object_buffer_hi,x
    sta p_image+1
    lda #15
    sta p_imagebank
    lda n_object_cache_valid,x
    beq @new
    lda n_object_pose_cache,x
    cmp o_key
    bne @new
    lda n_object_phase_cache,x
    cmp o_phase
    bne @new
    rts
@new:
    lda #1
    sta n_object_cache_valid,x
    lda o_key
    sta n_object_pose_cache,x
    lda o_phase
    sta n_object_phase_cache,x
    jsr object_read_record
    lda o_record+1
    sta n_src
    lda o_record+2
    sta n_src+1
    lda o_record+3
    sta z:l_bank
    lda o_record
    sta n_token
    lda #<o_pixels
    sta n_dst
    lda #>o_pixels
    sta n_dst+1
    jsr sic_read_block
    jmp object_build_frame

; o_key is the facing/rotation index; p_index is the horizontal pixel phase.
object_read_record:
    lda o_key
    sta n_ptr
    lda #0
    sta n_ptr+1
    asl n_ptr
    rol n_ptr+1
    asl n_ptr
    rol n_ptr+1
    lda n_ptr
    ora p_index
    sta n_ptr
    sta n_src
    lda n_ptr+1
    sta n_src+1
    .repeat 3
        asl n_src
        rol n_src+1
    .endrepeat
    sec
    lda n_src
    sbc n_ptr
    sta n_src
    lda n_src+1
    sbc n_ptr+1
    sta n_src+1
    clc
    lda n_src
    adc #<native_object_records
    sta n_src
    lda n_src+1
    adc #>native_object_records
    sta n_src+1
    lda #13
    sta z:l_bank
    lda #7
    sta n_token
    lda #<o_record
    sta n_dst
    lda #>o_record
    sta n_dst+1
    jmp sic_read_block

object_build_frame:
    ldy #0
    lda o_pixels
    sta (p_image),y
    iny
    lda o_pixels+1
    sta (p_image),y
    asl a
    sta o_stride
    iny
    lda o_pixels+2
    sta (p_image),y
    iny
    lda o_pixels
    clc
    adc #14
    sta (p_image),y
    sta o_plane
    lda p_y
    and #7
    clc
    adc o_pixels
    clc
    adc #7
    lsr a
    lsr a
    lsr a
    sta o_rows
    tax
    lda #0
@cell_count:
    clc
    adc o_pixels+1
    dex
    bne @cell_count
    sta o_cells
    asl a
    clc
    adc #23
    ldy #4
    sta (p_image),y
    sta o_base
    iny
    lda #0
    sta (p_image),y
    ldy #6
@map_pointer:
    lda #22
    sta (p_image),y
    iny
    lda #0
    sta (p_image),y
    iny
    cpy #22
    bcc @map_pointer
    lda o_rows
    sta (p_image),y
    iny
    ; Floor objects share exact kind/vertical-phase/horizontal-phase IDs.
    ; Generic player/chick/cat IDs are below $4000; these occupy $4000..$5dff.
    ; Other poses require current-epoch hits and use per-object IDs above 30000.
    lda p_object_mode
    bne @moving_id
    lda o_phase
    asl a
    asl a
    asl a
    asl a
    sta o_id
    lda o_phase
    lsr a
    lsr a
    lsr a
    lsr a
    sta o_id+1
    ldx p_actor
    lda n_animation,x
    asl a
    ora o_id+1
    ora #$40
    sta o_id+1
    jmp @ids_ready
@moving_id:
    lda o_slot
    clc
    adc #4
    asl a
    asl a
    asl a
    asl a
    clc
    adc #<30000
    sta o_id
    lda #>30000
    adc #0
    sta o_id+1
@ids_ready:
    ldx o_cells
@ids:
    lda o_id
    sta (p_image),y
    iny
    lda o_id+1
    sta (p_image),y
    iny
    inc o_id
    bne :+
    inc o_id+1
:   dex
    bne @ids
    lda o_base
    sta o_maskptr
    lda p_image+1
    sta o_maskptr+1
    lda #0
    sta o_column
@column:
    clc
    lda o_maskptr
    adc o_plane
    sta o_bitptr
    lda o_maskptr+1
    adc #0
    sta o_bitptr+1
    ldy #0
@top:
    lda #255
    sta (o_maskptr),y
    lda #0
    sta (o_bitptr),y
    iny
    cpy #7
    bcc @top
    lda #0
    sta o_line
    lda o_column
    asl a
    clc
    adc #3
    sta o_offset
@line:
    ldx o_offset
    lda o_pixels,x
    sta (o_maskptr),y
    lda o_pixels+1,x
    sta (o_bitptr),y
    iny
    lda o_offset
    clc
    adc o_stride
    sta o_offset
    inc o_line
    lda o_line
    cmp o_pixels
    bcc @line
@bottom:
    lda #255
    sta (o_maskptr),y
    lda #0
    sta (o_bitptr),y
    iny
    cpy o_plane
    bcc @bottom
    clc
    lda o_bitptr
    adc o_plane
    sta o_maskptr
    lda o_bitptr+1
    adc #0
    sta o_maskptr+1
    inc o_column
    lda o_column
    cmp o_pixels+1
    bcc @column
    rts
