#!/usr/bin/env python3
"""Verify the real round-clear scoring path and display in normal-speed Atari800.

Only the completion flag and elapsed time are staged. The cartridge executes
its own flow, scoring, screen transition and next-round loader normally.
"""
import argparse, hashlib, json, os, time
from build import ROOT, BUILD
from native_engine import Engine
from raster_probe import Session
from attract_probe import observe_ram

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=('ntsc','pal'),required=True)
    mode=p.parse_args().mode
    cart=ROOT/'release'/f'Flicky-Atari-XL-{mode.upper()}-JatariCart-512K.car'
    n=Engine(cart,BUILD/'variants-jcart'/mode/'native.lbl')
    out=BUILD/'arcade-result'/mode;s=Session(cart,out,mode,True);fd=None
    try:
        deadline=time.monotonic()+15
        while True:
            try:fd,base=observe_ram(s,cart,n);break
            except RuntimeError:
                assert time.monotonic()<deadline,'bootstrap timeout'
                time.sleep(.1)
        read=lambda:os.pread(fd,65536,base)
        get=lambda m,k,i=0:m[n.labels[k]+i]
        # The RAM signature exists before startup has initialized u_mode.
        # Wait for the real intro/input loop, not its initial zero bytes.
        deadline=time.monotonic()+15
        while get(read(),'u_mode')!=1 or get(read(),'it_frame')<5:
            assert time.monotonic()<deadline,'intro startup timeout'
            time.sleep(.1)
        s.tap('Control_R');deadline=time.monotonic()+10
        while get(read(),'u_mode')!=0 or get(read(),'result_active'):
            assert time.monotonic()<deadline,'start timeout'
            time.sleep(.1)
        time.sleep(1)
        def write(label,values,index=0):
            return f'c {n.labels[label]+index:04x} '+bytes(values).hex(' ')
        s.monitor([write('n_round_seconds',[0,0]),write('n_round_clock',[0]),
                   write('n_round_complete',[1]),write('n_rescued',[255]),write('n_flags',[0],23)])
        deadline=time.monotonic()+10
        while not get(read(),'result_active') or read()[0x6000+26*40+14:0x6000+26*40+26]!=b'20000 POINTS':
            assert time.monotonic()<deadline,('result initialization timeout',
                {k:get(read(),k) for k in ('u_mode','result_active','n_flow','n_round_complete','n_round','c_overflow')})
            time.sleep(.03)
        m=read();assert [get(m,'n_score',i) for i in range(3)]==[0,0,2]
        deadline=time.monotonic()+2
        while True:
            try:s.capture().save(out/'time-bonus-20000.png');break
            except StopIteration:
                assert time.monotonic()<deadline,'capture window timeout'
                time.sleep(.05)
        deadline=time.monotonic()+8
        while get(read(),'result_active') or get(read(),'n_round')!=1:
            assert time.monotonic()<deadline,'next-round timeout'
            time.sleep(.05)
        time.sleep(.5);m=read()
        assert not get(m,'r_fault') and not get(m,'c_overflow')
        s.capture().save(out/'round-2.png')
        result=dict(mode=mode,sha256=hashlib.sha256(cart.read_bytes()).hexdigest(),
                    emulator='Atari800 7.2.1',normal_speed=True,
                    diagnostic='Round-completion flag and zero elapsed time; normal cartridge execution thereafter',
                    awarded_points=20000,displayed_text='20000 POINTS',next_round=2,
                    renderer_faults=0,input_overflow=0,physical_hardware_tested=False)
        (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result),flush=True)
    finally:
        if fd is not None:os.close(fd)
        s.close()

if __name__=='__main__':main()
