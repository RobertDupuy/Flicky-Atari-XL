; Compact Z80 compatibility path. M1 and operand fetches use separate ROM views.
; Same register/flag/bus ABI as the independently tested static translation.
.segment "LOWZP": zeropage
i_op: .res 1
i_prefix: .res 1
i_memready: .res 1
i_plainhl: .res 1
i_indexaddr: .res 2
i_dst: .res 1
i_value: .res 1
i_pair: .res 1
i_target: .res 2
i_cbop: .res 1
i_cbreg: .res 1
.segment "INTERPRETER"
.export interp_next,interp_fetch,interp_m1
interp_next:
    lda #0
    sta i_prefix
    sta i_memready
    sta i_plainhl
interp_prefix:
    jsr interp_m1
    sta i_op
    tax
    lda i_dispatch_lo,x
    sta z_jump
    lda i_dispatch_hi,x
    sta z_jump+1
    jmp (z_jump)
interp_m1:
    inc z_r
    lda z_r
    and #$7f
    sta z_r
    ; The 315-5051 transform is invertible: derive the M1 view from data.
    ldx z_pc
    lda i_convert_lo,x
    sta i_cbop
    ldx z_pc+1
    lda i_convert_hi,x
    ora i_cbop
    sta i_cbop
    jsr interp_fetch
    pha
    tax
    lda i_convert_value,x
    ora i_cbop
    tax
    pla
    and #$57
    ora i_conversion,x
    rts
interp_fetch:
    lda z_pc
    sta z_addr
    lda z_pc+1
    sta z_addr+1
    jsr bus_read
interp_advance:
    inc z_pc
    bne :+
    inc z_pc+1
:   rts
interp_word:
    jsr interp_fetch
    pha
    jsr interp_fetch
    tax
    pla
    rts
interp_target:
    jsr interp_word
    sta i_target
    stx i_target+1
    rts
; A is the 0..7 register field. Indexed memory fetches its displacement once.
i_read:
    and #7
    cmp #6
    beq @memory
    tax
    cpx #4
    bcc @plain
    cpx #6
    bcs @plain
    lda i_plainhl
    bne @plain
    lda i_prefix
    beq @plain
    cpx #4
    beq :+
    tax
    lda $00,x
    rts
:   tax
    lda $01,x
    rts
@plain:
    lda i_registers,x
    tax
    lda $00,x
    rts
@memory:
    jsr i_memaddr
    jmp bus_read
i_write:
    ; A value, X register field. No temporary shared with the bus helpers.
    sta i_value
    txa
    and #7
    tax
    cpx #6
    beq @memory
    cpx #4
    bcc @plain
    cpx #6
    bcs @plain
    lda i_plainhl
    bne @plain
    lda i_prefix
    beq @plain
    cpx #4
    beq :+
    tax
    lda i_value
    sta $00,x
    rts
:   tax
    lda i_value
    sta $01,x
    rts
@plain:
    lda i_registers,x
    tax
    lda i_value
    sta $00,x
    rts
@memory:
    jsr i_memaddr
    lda i_value
    jmp bus_write
i_memaddr:
    lda i_prefix
    bne @indexed
    lda z_l
    sta z_addr
    lda z_h
    sta z_addr+1
    rts
@indexed:
    lda i_memready
    bne @ready
    jsr interp_fetch
    ldx i_prefix
    pha
    clc
    adc $00,x
    sta i_indexaddr
    pla
    bpl :+
    lda #$ff
    bmi :++
:   lda #0
:   adc $01,x
    sta i_indexaddr+1
    inc i_memready
@ready:
    lda i_indexaddr
    sta z_addr
    lda i_indexaddr+1
    sta z_addr+1
    rts
i_getpair:
    lda i_op
    lsr a
    lsr a
    lsr a
    lsr a
    and #3
    tax
    lda i_pairs,x
    cpx #2
    bne :+
    ldx i_prefix
    beq :+
    txa
:   tax
    stx i_pair
    rts
i_gethl:
    ldx i_prefix
    bne :+
    ldx #z_l
:   rts
i_pushpair:
    jsr i_getpair
    cpx #z_sp
    bne :+
    ldx #z_f
:   stx i_pair
    rts
i_condition:
    ; A condition 0..7, return carry set if true. Guest flags are untouched.
    and #7
    tax
    lda z_f
    and i_masks,x
    beq @zero
    txa
    and #1
    bne @true
    clc
    rts
@zero:
    txa
    and #1
    beq @true
    clc
    rts
@true:
    sec
    rts
i_opcode_condition:
    lda i_op
    lsr a
    lsr a
    lsr a
    jmp i_condition
i_jump_target:
    lda i_target
    sta z_pc
    lda i_target+1
    sta z_pc+1
.ifdef HYBRID
    lda z_pc
    ldx z_pc+1
    jmp dispatch_ax
.else
    jmp interp_next
.endif
i_nop:
    jmp interp_next
i_dd:
    lda #z_ix
    sta i_prefix
    jmp interp_prefix
i_fd:
    lda #z_iy
    sta i_prefix
    jmp interp_prefix
i_ld8:
    lda i_op
    and #7
    cmp #6
    bne :+
    inc i_plainhl
:   lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    sta i_dst
    cmp #6
    bne :+
    inc i_plainhl
:   lda i_op
    jsr i_read
    ldx i_dst
    jsr i_write
    jmp interp_next
i_ldn:
    lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    sta i_dst
    cmp #6
    bne :+
    jsr i_memaddr
:   jsr interp_fetch
    ldx i_dst
    jsr i_write
    jmp interp_next
i_alu:
    lda i_op
    jsr i_read
    jmp i_doalu
i_alun:
    jsr interp_fetch
i_doalu:
    sta z_operand
    lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    tax
    jsr alu8
    jmp interp_next
i_inc8:
    lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    sta i_dst
    jsr i_read
    jsr inc8
    ldx i_dst
    jsr i_write
    jmp interp_next
i_dec8:
    lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    sta i_dst
    jsr i_read
    jsr dec8
    ldx i_dst
    jsr i_write
    jmp interp_next
i_ld16:
    jsr i_getpair
    jsr interp_word
    stx i_value
    ldx i_pair
    sta $00,x
    lda i_value
    sta $01,x
    jmp interp_next
i_inc16:
    jsr i_getpair
    inc $00,x
    bne :+
    inc $01,x
:   jmp interp_next
i_dec16:
    jsr i_getpair
    lda $00,x
    bne :+
    dec $01,x
:   dec $00,x
    jmp interp_next
i_add16:
    jsr i_getpair
    lda $00,x
    sta z_word
    lda $01,x
    sta z_word+1
    jsr i_gethl
    ldy #0
    jsr alu16
    jmp interp_next
i_stbc:
    lda z_a
    jsr write_bc
    jmp interp_next
i_stde:
    lda z_a
    jsr write_de
    jmp interp_next
i_ldbc:
    jsr read_bc
    sta z_a
    jmp interp_next
i_ldde:
    jsr read_de
    sta z_a
    jmp interp_next
i_absaddr:
    jsr interp_word
    sta z_addr
    stx z_addr+1
    rts
i_sthl:
    jsr i_absaddr
    jsr i_gethl
    lda $00,x
    sta z_word
    lda $01,x
    sta z_word+1
    jsr bus_write16
    jmp interp_next
i_ldhl:
    jsr i_absaddr
    jsr bus_read16
    stx i_value
    pha
    jsr i_gethl
    pla
    sta $00,x
    lda i_value
    sta $01,x
    jmp interp_next
i_stabs:
    jsr i_absaddr
    lda z_a
    jsr bus_write
    jmp interp_next
i_ldabs:
    jsr i_absaddr
    jsr bus_read
    sta z_a
    jmp interp_next
i_rot_a:
    lda i_op
    lsr a
    lsr a
    lsr a
    ora #8
    tax
    lda z_a
    jsr rotate8
    sta z_a
    jmp interp_next
i_exaf:
    jsr ex_af
    jmp interp_next
i_exx:
    jsr exx
    jmp interp_next
i_exde:
    lda z_e
    ldx z_l
    sta z_l
    stx z_e
    lda z_d
    ldx z_h
    sta z_h
    stx z_d
    jmp interp_next
i_exsp:
    jsr i_gethl
    jsr ex_sp
    jmp interp_next
i_daa:
    jsr daa
    jmp interp_next
i_cpl:
    jsr cpl
    jmp interp_next
i_scf:
    jsr scf
    jmp interp_next
i_ccf:
    jsr ccf
    jmp interp_next
i_jrcc:
    jsr interp_fetch
    sta i_value
    lda i_op
    lsr a
    lsr a
    lsr a
    and #3
    jsr i_condition
    bcs i_relative
    jmp interp_next
i_djnz:
    jsr interp_fetch
    sta i_value
    dec z_b
    bne i_relative
    jmp interp_next
i_jr:
    jsr interp_fetch
    sta i_value
i_relative:
    clc
    lda i_value
    adc z_pc
    sta z_pc
    lda #0
    bit i_value
    bpl :+
    lda #$ff
:   adc z_pc+1
    sta z_pc+1
.ifdef HYBRID
    lda z_pc
    ldx z_pc+1
    jmp dispatch_ax
.else
    jmp interp_next
.endif
i_jpcc:
    jsr interp_target
    jsr i_opcode_condition
    bcc :+
    jmp i_jump_target
:   jmp interp_next
i_jp:
    jsr interp_target
    jmp i_jump_target
i_jphl:
    jsr i_gethl
    lda $00,x
    sta z_pc
    lda $01,x
    sta z_pc+1
.ifdef HYBRID
    lda z_pc
    ldx z_pc+1
    jmp dispatch_ax
.else
    jmp interp_next
.endif
i_callcc:
    jsr interp_target
    jsr i_opcode_condition
    bcs i_call_target
    jmp interp_next
i_call:
    jsr interp_target
i_call_target:
    lda z_pc
    ldx z_pc+1
    jsr push_ax
    jmp i_jump_target
i_rst:
    lda i_op
    and #$38
    sta i_target
    lda #0
    sta i_target+1
    jmp i_call_target
i_retcc:
    jsr i_opcode_condition
    bcs i_ret
    jmp interp_next
i_ret:
    jsr pop_ax
    jmp dispatch_ax
i_pop:
    jsr i_pushpair
    jsr pop_ax
    stx i_value
    ldx i_pair
    sta $00,x
    lda i_value
    sta $01,x
    jmp interp_next
i_push:
    jsr i_pushpair
    lda $00,x
    pha
    lda $01,x
    tax
    pla
    jsr push_ax
    jmp interp_next
i_di:
    lda #0
    sta z_iff
    jmp interp_next
i_ei:
    lda #1
    sta z_iff
    jmp interp_next
i_sphl:
    jsr i_gethl
    lda $00,x
    sta z_sp
    lda $01,x
    sta z_sp+1
    jmp interp_next
i_in:
    jsr interp_fetch
    jsr port_in
    sta z_a
    jmp interp_next
i_out:
    jsr interp_fetch
    tax
    lda z_a
    jsr port_out
    jmp interp_next
i_halt:
    lda z_pc
    ldx z_pc+1
    jmp guest_halt
i_cb:
    lda i_prefix
    beq @ordinary
    jsr i_memaddr
    jsr interp_fetch
    jmp @opcode
@ordinary:
    jsr interp_m1
@opcode:
    sta i_cbop
    and #7
    sta i_cbreg
    lda i_prefix
    beq :+
    lda #6
    bne :++
:   lda i_cbreg
:   jsr i_read
    sta i_value
    lda i_cbop
    lsr a
    lsr a
    lsr a
    and #7
    tax
    lda i_cbop
    and #$c0
    beq @rotate
    cmp #$40
    beq @bit
    cmp #$80
    beq @reset
    lda bit_masks,x
    ora i_value
    jmp @write
@reset:
    lda bit_masks,x
    eor #$ff
    and i_value
    jmp @write
@bit:
    lda i_value
    jsr bit8
    jmp interp_next
@rotate:
    lda i_value
    jsr rotate8
@write:
    sta i_value
    lda i_prefix
    beq @regwrite
    lda i_value
    ldx #6
    jsr i_write
    lda i_cbreg
    cmp #6
    bne :+
    jmp interp_next
:   lda #0
    sta i_prefix
@regwrite:
    lda i_value
    ldx i_cbreg
    jsr i_write
    jmp interp_next
i_ed:
    lda #0
    sta i_prefix
    jsr interp_m1
    sta i_op
    and #$c7
    cmp #$40
    bne :+
    jmp i_ed_in
:   cmp #$41
    bne :+
    jmp i_ed_out
:   lda i_op
    and #$cf
    cmp #$42
    beq i_ed_sbc
    cmp #$4a
    beq i_ed_adc
    cmp #$43
    beq i_ed_store
    cmp #$4b
    beq i_ed_load
    lda i_op
    and #$c7
    cmp #$44
    bne :+
    jsr neg
    jmp interp_next
:   cmp #$45
    bne :+
    jmp i_ret
:   lda i_op
    cmp #$46
    beq i_ed_im
    cmp #$56
    beq i_ed_im
    cmp #$5e
    beq i_ed_im
    and #$e7
    cmp #$a0
    bne :+
    jmp i_ed_block
:   jmp dispatch_fail
i_ed_im:
    lda i_op
    cmp #$46
    bne :+
    lda #0
    beq :++
:   and #8
    lsr a
    lsr a
    lsr a
    clc
    adc #1
:   sta z_im
    jmp interp_next
i_ed_sbc:
    ldy #2
    bne i_ed_arith
i_ed_adc:
    ldy #1
i_ed_arith:
    sty i_value
    jsr i_getpair
    lda $00,x
    sta z_word
    lda $01,x
    sta z_word+1
    ldx #z_l
    ldy i_value
    jsr alu16
    jmp interp_next
i_ed_store:
    jsr i_getpair
    jsr i_absaddr
    ldx i_pair
    lda $00,x
    sta z_word
    lda $01,x
    sta z_word+1
    jsr bus_write16
    jmp interp_next
i_ed_load:
    jsr i_getpair
    jsr i_absaddr
    jsr bus_read16
    stx i_value
    ldx i_pair
    sta $00,x
    lda i_value
    sta $01,x
    jmp interp_next
i_ed_in:
    lda z_c
    jsr port_in
    jsr in_flags
    pha
    lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    tax
    pla
    cpx #6
    beq :+
    jsr i_write
:   jmp interp_next
i_ed_out:
    lda i_op
    lsr a
    lsr a
    lsr a
    and #7
    cmp #6
    beq :+
    jsr i_read
    jmp :++
:   lda #0
:   ldx z_c
    jsr port_out
    jmp interp_next
i_ed_block:
    lda i_op
    and #8
    lsr a
    lsr a
    sta i_value
    lda i_op
    and #$10
    lsr a
    lsr a
    lsr a
    lsr a
    ora i_value
    tax
    jsr block_ld
    jmp interp_next
i_registers: .byte z_b,z_c,z_d,z_e,z_h,z_l,0,z_a
i_pairs: .byte z_c,z_e,z_l,z_sp
i_masks: .byte $40,$40,1,1,4,4,$80,$80
.include "interpreter_tables.s"
