#!/usr/bin/env python3
"""Validate the MAME parent 'flicky' set and prepare independent opcode/data views.

No game ROMs are supplied or downloaded by this project. This importer is not
yet a full-game cartridge builder. Output stays outside the diagnostic build.
"""
from pathlib import Path
import argparse, hashlib, json, zipfile, zlib

ROOT=Path(__file__).resolve().parents[1]
# Sega 315-5051 conversion table and algorithm adapted from MAME.
# Copyright Nicola Salmoria, David Haywood; BSD-3-Clause, see THIRD_PARTY.md.
TABLE=[
 [0x08,0x88,0x00,0x80],[0xa0,0x80,0xa8,0x88],
 [0x80,0x00,0xa0,0x20],[0x88,0x80,0x08,0x00],
 [0xa0,0x80,0xa8,0x88],[0x28,0x08,0x20,0x00],
 [0x28,0x08,0x20,0x00],[0xa0,0x80,0xa8,0x88],
 [0x08,0x88,0x00,0x80],[0x80,0x00,0xa0,0x20],
 [0x80,0x00,0xa0,0x20],[0x88,0x80,0x08,0x00],
 [0x28,0x08,0x20,0x00],[0x28,0x08,0x20,0x00],
 [0x28,0x08,0x20,0x00],[0x88,0x80,0x08,0x00],
 [0x08,0x88,0x00,0x80],[0xa8,0x88,0x28,0x08],
 [0xa8,0x88,0x28,0x08],[0x80,0x00,0xa0,0x20],
 [0x28,0x08,0x20,0x00],[0x88,0x80,0x08,0x00],
 [0xa8,0x88,0x28,0x08],[0x88,0x80,0x08,0x00],
 [0x08,0x88,0x00,0x80],[0x80,0x00,0xa0,0x20],
 [0xa8,0x88,0x28,0x08],[0x80,0x00,0xa0,0x20],
 [0x28,0x08,0x20,0x00],[0x28,0x08,0x20,0x00],
 [0x08,0x88,0x00,0x80],[0x88,0x80,0x08,0x00],
]

def decode_byte(address, value, m1):
    row=(address&1)|((address>>3)&2)|((address>>6)&4)|((address>>9)&8)
    col=((value>>3)&1)|((value>>4)&2)
    xor=0
    if value&0x80:
        col=3-col
        xor=0xa8
    return (value&0x57)|(TABLE[2*row+(0 if m1 else 1)][col]^xor)

def decrypt(raw):
    if len(raw)!=0x8000: raise ValueError('Parent Flicky main program must be exactly 32 KB')
    return tuple(bytes(decode_byte(a,v,m1) for a,v in enumerate(raw)) for m1 in [True,False])

def validate(files, manifest):
    errors=[]
    for entry in manifest['files']:
        name=entry['name']
        if name not in files:
            errors.append(f'Missing {name}')
            continue
        blob=files[name]
        if len(blob)!=entry['size'] or f'{zlib.crc32(blob)&0xffffffff:08x}'!=entry['crc32'] or hashlib.sha1(blob).hexdigest()!=entry['sha1']:
            errors.append(f'Wrong revision or damaged file: {name}')
    if errors: raise ValueError('\n'.join(errors))

def import_set(source, destination):
    manifest=json.loads((ROOT/'config/flicky-roms.json').read_text())
    names={row['name'] for row in manifest['files']}
    # Historic ROM archives omit the hyphen in epr-5978a / epr-5979a.
    # Names are only an alias; all three content checks below remain mandatory.
    aliases={name.replace('-',''):name for name in names}
    def canonical(name):
        return aliases.get(name.lower().replace('-',''))
    files={}
    if source.is_dir():
        for p in source.rglob('*'):
            if p.is_file() and canonical(p.name):
                name=canonical(p.name)
                if name in files: raise ValueError(f'Ambiguous duplicate {name}')
                files[name]=p.read_bytes()
    else:
        with zipfile.ZipFile(source) as z:
            for info in z.infolist():
                name=canonical(Path(info.filename).name)
                if name in names:
                    if name in files: raise ValueError(f'Ambiguous duplicate {name}')
                    # Reject wrong-size compressed entries before allocating their contents.
                    expected=next(e['size'] for e in manifest['files'] if e['name']==name)
                    if info.file_size!=expected: raise ValueError(f'Wrong file size: {name}')
                    files[name]=z.read(info)
    validate(files,manifest)
    regions={}
    for entry in manifest['files']:
        region=entry['region']
        size=entry['offset']+entry['size']
        data=regions.setdefault(region,bytearray())
        if len(data)<size: data.extend(bytes(size-len(data)))
        data[entry['offset']:size]=files[entry['name']]
    opcodes,data=decrypt(regions['maincpu'])
    output={k+'.bin':bytes(v) for k,v in regions.items()}
    output.update({'maincpu-opcodes.bin':opcodes,'maincpu-data.bin':data})
    destination.mkdir(parents=True,exist_ok=True)
    for name,blob in output.items(): (destination/name).write_bytes(blob)
    (destination/'verified-set.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return output

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path,help='flicky.zip or a folder containing its ROM chips')
    p.add_argument('--out',type=Path,default=ROOT/'private-roms')
    args=p.parse_args()
    try: result=import_set(args.source,args.out)
    except (ValueError,OSError,zipfile.BadZipFile) as error: p.exit(1,str(error)+'\n')
    print('Verified parent Flicky set. Prepared: '+', '.join(result))
    print('Next: identify executable spans, extend the CPU/bus, and capture reference traces.')

if __name__=='__main__': main()
