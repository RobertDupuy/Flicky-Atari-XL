; Native cat state and terrain rules. Actor slots 9 and 10.
; Coordinates use the same world-relative representation as native chicks.
e_y=$50
e_half=$51
e_radius=$52
e_mask=$53
e_row=$54
e_mode=$55
e_saved=$56
e_count=$58
e_list=$59
e_delay=$5a
e_length=$5b
e_reverse=$5c
e_old=$5d
e_attr=$5e
e_jump=$5f
e_compare=$60
n_spawn_x=$07a4
n_spawn_y=$07a6
n_difficulty=$07a7
n_spawn_delay=$07a8
n_frozen=$07a9
n_enemy_points=$07aa
n_spawn_clock=$07ab
n_elapsed_seconds=$07ac
n_spawn_wait=$07ad
n_door_timers=$07ae
n_spawn_door=$07b0
.segment "FIXED"
.export cat_spawn,cat_update,cat_sample_terrain,cat_terrain,cat_animation,cat_floor
.export enemies_reset,enemies_update,enemies_spawn,cat_spawn_door,n_spawn_clock,n_elapsed_seconds,n_spawn_wait,n_door_timers
.export n_spawn_x,n_spawn_y,n_difficulty,n_spawn_delay,n_frozen,n_enemy_points
.export n_game_ticks
.export e_mask,e_row,e_attr,e_mode,e_list,e_delay,e_length,e_reverse
cat_spawn:
    lda #3
    NATIVE_BANK
    jmp cat_spawn_bank
cat_update:
    lda #3
    NATIVE_BANK
    jmp cat_update_bank
cat_sample_terrain:
    lda #3
    NATIVE_BANK
    jmp cat_sample_bank
cat_terrain:
    lda #3
    NATIVE_BANK
    jmp cat_terrain_bank
cat_animation:
    lda #3
    NATIVE_BANK
    jmp cat_animate
cat_floor:
    lda #3
    NATIVE_BANK
    jmp cat_floor_bank

enemies_reset:
    lda #3
    NATIVE_BANK
    jmp enemies_reset_bank
enemies_update:
    lda #3
    NATIVE_BANK
    jmp enemies_update_bank
cat_spawn_door:
    lda #3
    NATIVE_BANK
    jmp cat_spawn_door_bank
enemies_spawn:
    lda #3
    NATIVE_BANK
    jmp enemies_spawn_bank
.segment "BANK3"
cat_heights: .byte 20,20,20,20,20,20,20,20,20,8,5,3,9,11,14,21,18,18
cat_radii: .byte 16,18,18,20,20,12,12,20,18,8,6,6,12,12,12,18,18,20
cat_walk: .byte 0,1,2,3,4,2,1
cat_jump: .byte 0,1,15,16
cat_turn: .byte 0,6,5,6
cat_spin: .byte 5,7,8,7,5,7,8,7
cat_stop: .byte 9,10,11
cat_spawn_poses: .byte 12,13,14,0
cat_list_lo: .lobytes cat_walk,cat_jump,cat_turn,cat_spin,cat_stop,cat_spawn_poses
cat_list_hi: .hibytes cat_walk,cat_jump,cat_turn,cat_spin,cat_stop,cat_spawn_poses
cat_rotation: .byte 0,0,0,2,3,3,1,1
cat_jump_right:
    .byte $30,$d8,$2d,$df,$18,$d8,$18,$d4,$20,$d8,$20,$dc,$18,$d6,$18,$d4
    .byte $06,$da,$17,$da,$12,$d8,$1c,$d8,$18,$de,$18,$d8,$30,$d8,$0c,$d8
    .byte $10,$d6,$08,$d6,$18,$db,$0c,$dc,$28,$d8,$14,$d4,$14,$d8,$1a,$d8
    .byte $16,$d4,$20,$dc,$18,$d2,$10,$d2,$20,$d4,$14,$d4,$16,$d4,$0c,$d4
    .byte $28,$c0,$18,$d6,$0c,$d2,$18,$d2
cat_jump_left:
    .byte $d0,$d8,$e0,$df,$e8,$d8,$e8,$d4,$e0,$d8,$e0,$dc,$e8,$d6,$e4,$dc
    .byte $fa,$da,$e9,$da,$ee,$d8,$e0,$d8,$e8,$de,$e8,$d8,$d0,$d8,$f4,$d8
    .byte $f0,$d6,$f8,$d6,$e8,$d8,$f0,$dc,$d8,$d8,$ec,$d4,$ec,$d8,$e6,$d8
    .byte $ea,$d4,$e0,$dc,$e8,$d2,$f0,$d2,$e0,$d4,$ec,$d4,$ea,$d4,$f4,$d4
    .byte $d8,$d4,$e8,$d6,$f4,$d2,$e8,$d2

cat_spawn_bank:
    lda #$b0
    sta n_flags,x
    lda #12
    sta n_animation,x
    lda #0
    sta n_target,x
    sta n_acceleration,x
    sta n_frame,x
    sta n_bob,x
    sta n_pose,x
    sta n_vx,x
    sta n_fx,x
    sta n_vy,x
    sta n_fy,x
    sta n_timer,x
    sta n_cycle,x
    sta n_chain,x
    sta n_draw_yoffset,x
    sta n_chick_state,x
    sta n_enemy_contact,x
    sta n_chick_contact,x
    sec
    lda n_spawn_x
    sbc n_world
    sta n_xlo,x
    lda n_spawn_x+1
    and #1
    sbc n_world+1
    sta n_xhi,x
    jsr cat_floor_bank
    sec
    sbc #4
    sta n_ylo,x
    lda #1
    sta n_pause,x
    lda #8
    sta n_timer,x
    lda n_difficulty
    and #$40
    bne @hard
    lda n_round
    lsr a
    clc
    adc #$20
    clc
    adc n_spawn_delay
    cmp #$30
    bcc @speed
    lda #$30
    bne @speed
@hard:
    lda n_round
    clc
    adc #$20
    clc
    adc n_spawn_delay
    cmp #$40
    bcc @speed
    lda #$40
@speed:
    sta n_chain,x
    txa
    and #1
    beq @left
    lda #$b1
    sta n_flags,x
    lda #8
    sta n_acceleration,x
    rts
@left:
    lda n_chain,x
    eor #$ff
    clc
    adc #1
    sta n_chain,x
    lda #$f8
    sta n_acceleration,x
    rts

; Find a sufficiently tall empty gap, then its floor, as in $73cc.
cat_floor_bank:
    ldy n_animation,x
    lda cat_heights,y
    sec
    sbc #1
    lsr a
    sta e_half
    lsr a
    lsr a
    clc
    adc #1
    sta e_count
    sta e_length
    lda n_spawn_y
    sec
    sbc e_half
    sta e_y
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
    sta c_screen+1
    jsr cat_tile
@gap:
    ldy #0
    lda (n_ptr),y
    and #$10
    beq @empty
    lda e_length
    sta e_count
    bne @next
@empty:
    dec e_count
    beq @floor
@next:
    jsr cat_down
    jmp @gap
@floor:
    jsr cat_down
    ldy #0
    lda (n_ptr),y
    and #$10
    beq @floor
    ldy n_animation,x
    lda cat_heights,y
    lsr a
    sta e_half
    lda e_row
    asl a
    asl a
    asl a
    sec
    sbc e_half
    sec
    sbc #1
    rts

; e_y and world-relative c_screen -> tile attribute pointer and row.
cat_tile:
    lda e_y
    lsr a
    lsr a
    lsr a
    sta e_row
    lda e_y
    and #$18
    asl a
    asl a
    asl a
    sta n_ptr
    lda e_y
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #$c0
    sta n_ptr+1
    lda c_screen+1
    lsr a
    lda c_screen
    ror a
    lsr a
    lsr a
    and #$3e
    ora #1
    ora n_ptr
    sta n_ptr
    rts
cat_down:
    inc e_row
    clc
    lda n_ptr
    adc #64
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   rts
cat_up:
    dec e_row
    sec
    lda n_ptr
    sbc #64
    sta n_ptr
    bcs :+
    dec n_ptr+1
:   rts
cat_right:
    lda n_ptr
    and #$c0
    sta e_saved
    lda n_ptr
    clc
    adc #2
    and #$3f
    ora e_saved
    sta n_ptr
    rts
cat_sample:
    ldy #0
    lda (n_ptr),y
    and #$10
    cmp #$10
    rol e_mask
    rts

; Modes 0 left/up, 1 left/down, 2 right/down, 3 right/up.
; Upward probes use the carry-set branch required by cat terrain response.
cat_sample_bank:
    ldy n_animation,x
    lda cat_heights,y
    lsr a
    sta e_half
    lda cat_radii,y
    sta e_radius
    lda #0
    sta e_mask
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
    sta c_screen+1
    lda e_mode
    cmp #2
    bcs @right
    cmp #1
    lda n_ylo,x
    bcc :+
    sec
    sbc #7
:   clc
    adc e_half
    sta e_y
    ; Z80 SBC uses the carry from the Y addition as an extra borrow.
    lda #0
    adc e_radius
    sta e_radius
    sec
    lda c_screen
    sbc e_radius
    sta c_screen
    lda c_screen+1
    sbc #0
    sta c_screen+1
    jsr cat_tile
    lda e_mode
    bne @left_down
    jsr cat_sample
    jsr cat_up
    jsr cat_sample
    jsr cat_up
    jsr cat_sample
    jsr cat_right
    jmp cat_sample
@left_down:
    jsr cat_sample
    jsr cat_down
    jsr cat_sample
    jsr cat_right
    jmp cat_sample
@right:
    lda n_ylo,x
    clc
    adc e_half
    ldy e_mode
    cpy #3
    bne :+
    sec
    sbc #16
    jmp @right_y
:   clc
    adc #1
@right_y:
    sta e_y
    ; Rightward horizontal addition's carry is computed in screen space.
    clc
    lda c_screen
    adc n_world
    sta c_screen
    lda c_screen+1
    adc n_world+1
    sta c_screen+1
    clc
    lda c_screen
    adc e_radius
    sta c_screen
    lda c_screen+1
    adc #0
    sta c_screen+1
    lda #16
    adc #0
    sta e_radius
    sec
    lda c_screen
    sbc e_radius
    sta c_screen
    lda c_screen+1
    sbc #0
    sta c_screen+1
    sec
    lda c_screen
    sbc n_world
    sta c_screen
    lda c_screen+1
    sbc n_world+1
    sta c_screen+1
    jsr cat_tile
    lda n_ptr
    pha
    lda n_ptr+1
    pha
    lda e_row
    pha
    jsr cat_sample
    jsr cat_right
    jsr cat_sample
    lda e_mode
    cmp #3
    beq @right_up
    jsr cat_up
    jsr cat_sample
    jmp @restore
@right_up:
    jsr cat_down
    jsr cat_sample
    jsr cat_down
    jsr cat_sample
@restore:
    pla
    sta e_row
    pla
    sta n_ptr+1
    pla
    sta n_ptr
    lda e_mask
    rts

; Table-driven native animation; C is set only when its index wraps.
cat_animate:
    dec n_timer,x
    beq @advance
    lda e_reverse
    clc
    rts
@advance:
    lda e_delay
    sta n_timer,x
    ldy e_list
    lda cat_list_lo,y
    sta n_ptr
    lda cat_list_hi,y
    sta n_ptr+1
    ldy n_bob,x
    lda (n_ptr),y
    sta n_animation,x
    lda e_reverse
    bne @reverse
    iny
    tya
    cmp e_length
    bcc @store
    lda #0
    beq @wrap
@reverse:
    tya
    beq @reverse_wrap
    sec
    sbc #1
    clc
    bcc @store
@reverse_wrap:
    lda e_length
    sec
    sbc #1
@wrap:
    sec
@store:
    sta n_bob,x
    rts

cat_update_bank:
    lda n_flags,x
    and #$20
    bne @active
    lda n_flags,x
    and #$7f
    sta n_flags,x
    rts
@active:
    lda n_frozen
    beq :+
    jmp cat_done
:
    lda n_chick_state,x
    and #$10
    beq :+
    jmp cat_dying
:
    lda n_chick_state,x
    bpl :+
    jmp cat_hit
:
    lda n_pause,x
    beq :+
    jmp cat_emerge
:
    jsr cat_terrain_bank
    lda n_chick_state,x
    and #4
    beq :+
    jmp cat_airborne
:
    lda n_chick_state,x
    and #2
    beq :+
    jmp cat_anticipate
:
    lda n_chick_state,x
    and #8
    bne @accelerate
    lda n_ylo+PLAYER
    clc
    adc #8
    cmp n_ylo,x
    bcs @ledge
    jsr cat_high_jump
@ledge:
    lda n_chick_state,x
    and #2
    beq :+
    jmp cat_anticipate
:
    lda n_chick_state,x
    and #$40
    bne @check_accel
    lda n_action_latch,x
    bne @chase
    lda n_chick_state,x
    and #1
    beq @check_accel
@chase:
    jsr cat_chase
@check_accel:
    lda n_chick_state,x
    and #$40
    beq cat_walking
@accelerate:
    jsr motion_accelerate
    bcc @after_accel
    lda n_chick_state,x
    and #8
    bne @turn
    lda n_chick_state,x
    and #$bf
    sta n_chick_state,x
    jmp @after_accel
@turn:
    lda #2
    sta e_list
    lda #10
    sta e_delay
    lda #4
    sta e_length
    lda #0
    sta e_reverse
    jsr cat_animate
    bcs @turned
    cmp #3
    bne @after_accel
    lda n_flags,x
    eor #1
    sta n_flags,x
    jmp @after_accel
@turned:
    lda n_chick_state,x
    and #$f7
    sta n_chick_state,x
    lda n_chain,x
    sta n_target,x
    bpl @after_accel
    dec n_vx,x
@after_accel:
    lda n_chick_state,x
    and #8
    bne cat_move
cat_walking:
    lda #0
    sta e_list
    sta e_reverse
    lda #7
    sta e_length
    lda #2
    sta e_delay
    jsr cat_animate
    jmp cat_facing
cat_airborne:
    lda n_vy,x
    bpl @down
    lda #16
    bne @pose
@down:
    lda #17
@pose:
    sta n_animation,x
cat_facing:
    lda n_flags,x
    and #$fe
    ldy n_vx,x
    bpl :+
    ora #1
:   sta n_flags,x
cat_move:
    inc n_enemy_contact,x
    bne :+
    jsr cat_speed_up
:   jsr motion_integrate
cat_done:
    ; The source normalizes screen X to nine bits after every update.
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    and #1
    sta c_screen+1
    sec
    lda c_screen
    sbc n_world
    sta n_xlo,x
    lda c_screen+1
    sbc n_world+1
    sta n_xhi,x
    rts

cat_hit:
    lda #$50
    sta n_chick_state,x
    lda #5
    sta n_animation,x
    lda #0
    sta n_bob,x
    sta n_pose,x
    lda #1
    sta n_timer,x
cat_dying:
    lda n_chick_state,x
    and #$40
    beq @stop
    lda #3
    sta e_list
    lda #2
    sta e_delay
    lda #8
    sta e_length
    lda n_bob,x
    sta e_old
    lda n_vx,x
    bmi :+
    lda #0
:   sta e_reverse
    jsr cat_animate
    lda n_bob,x
    cmp e_old
    beq @terrain
    ldy n_pose,x
    tya
    clc
    adc #1
    pha
    lda n_vx,x
    bpl @positive
    pla
    sec
    sbc #2
    jmp @phase
@positive:
    pla
@phase:
    and #7
    sta n_pose,x
    lda n_flags,x
    and #$fc
    ora cat_rotation,y
    sta n_flags,x
@terrain:
    jsr cat_terrain_bank
    lda n_chick_state,x
    and #4
    beq :+
    jmp cat_move
:
    jsr motion_accelerate
    bcs :+
    jmp cat_move
:
    lda n_chick_state,x
    and #$bf
    sta n_chick_state,x
    lda #0
    sta n_bob,x
    lda #1
    sta n_timer,x
    lda n_flags,x
    and #$fc
    sta n_flags,x
    lda #$fc
    sta n_vy,x
@stop:
    lda #4
    sta e_list
    lda #3
    sta e_length
    lda #10
    sta e_delay
    lda #0
    sta e_reverse
    jsr cat_animate
    bcs :+
    jmp cat_move
:
    lda n_flags,x
    and #$df
    sta n_flags,x
    ; Bonus-object production consumes this event in the round controller.
    stx n_enemy_points
    rts

cat_anticipate:
    lda #1
    sta e_list
    lda #5
    sta e_delay
    lda #4
    sta e_length
    lda #0
    sta e_reverse
    jsr cat_animate
    bcs :+
    jmp cat_done
:
    lda n_chain,x
    sta n_vx,x
    lda n_draw_yoffset,x
    sta n_vy,x
    lda n_chick_state,x
    and #$fd
    sta n_chick_state,x
    jmp cat_done

cat_emerge:
    lda n_bob,x
    bne @grow
    dec n_timer,x
    beq :+
    jmp cat_done
:
    lda n_pose,x
    cmp #4
    beq @start
    inc n_pose,x
    lda #4
    sta n_timer,x
    lda n_flags,x
    eor #1
    sta n_flags,x
    jmp cat_done
@start:
    lda #1
    sta n_timer,x
@grow:
    lda #5
    sta e_list
    lda #6
    sta e_delay
    lda #4
    sta e_length
    lda #0
    sta e_reverse
    jsr cat_animate
    bcs :+
    jmp cat_done
:
    lda #0
    sta n_pause,x
    lda #2
    sta n_bob,x
    lda #1
    sta n_timer,x
    lda #$48
    sta n_chick_state,x
    lda #2
    sta e_list
    lda #20
    sta e_delay
    jsr cat_animate
    jmp cat_done

cat_high_jump:
    lda e_attr
    and #$60
    sta e_jump
    lda n_vx,x
    bpl @right
    lda e_jump
    cmp #$20
    bne @done
    lda #1
    sta e_jump
    jmp cat_layout_jump
@right:
    lda e_jump
    cmp #$40
    bne @done
    lda #0
    sta e_jump
    jmp cat_layout_jump
@done:
    rts

; Ledge pursuit, with the source's tile visibility and jump choices.
cat_chase:
    lda n_ylo+PLAYER
    clc
    adc #8
    cmp n_ylo,x
    bcs :+
    jmp cat_short_jump
:
    sec
    sbc #16
    cmp n_ylo,x
    bcc :+
    jmp cat_short_jump
:
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    sta c_screen+1
    sec
    lda n_xlo+PLAYER
    sbc c_screen
    sta e_saved
    lda n_xhi+PLAYER
    sbc c_screen+1
    sta e_saved+1
    bcc @player_left
    jsr cat_line_clear
    lda n_vx,x
    bmi @turn_right
    lda n_chick_state,x
    and #1
    bne :+
    jmp @done
:
    lda e_mask
    beq :+
    jmp cat_short_jump
:
    lda #$30
    jmp cat_direct_jump
@turn_right:
    lda e_mask
    bne @done
    lda #8
    bne @turn
@player_left:
    lda e_saved
    eor #$ff
    clc
    adc #1
    sta e_saved
    lda e_saved+1
    eor #$ff
    adc #0
    sta e_saved+1
    lda n_xlo+PLAYER
    sta c_screen
    lda n_xhi+PLAYER
    sta c_screen+1
    jsr cat_line_clear
    lda n_vx,x
    bpl @turn_left
    lda n_chick_state,x
    and #1
    beq @done
    lda e_mask
    beq :+
    jmp cat_short_jump
:
    lda #$d0
    jmp cat_direct_jump
@turn_left:
    lda e_mask
    bne @done
    lda #$f8
@turn:
    sta n_acceleration,x
    lda n_vx,x
    eor #$ff
    clc
    adc #1
    sta n_chain,x
    lda n_chick_state,x
    ora #$48
    sta n_chick_state,x
    lda #0
    sta n_bob,x
    sta n_target,x
    lda #2
    sta e_list
    lda #3
    sta e_length
    lda #20
    sta e_delay
    lda #0
    sta e_reverse
    jmp cat_animate
@done:
    rts

cat_line_clear:
    ; c_screen is the left endpoint in screen coordinates; distance in e_saved.
    .repeat 4
    lsr e_saved+1
    ror e_saved
    .endrepeat
    lda e_saved
    sta e_count
    sec
    lda c_screen
    sbc n_world
    sta c_screen
    lda c_screen+1
    sbc n_world+1
    sta c_screen+1
    lda n_ylo+PLAYER
    sta e_y
    jsr cat_tile
@scan:
    ldy #0
    lda (n_ptr),y
    and #$10
    bne @finish
    clc
    lda n_ptr
    adc #2
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   dec e_count
    bne @scan
    lda #0
@finish:
    sta e_mask
    rts

cat_jump_setup:
    lda #0
    sta n_bob,x
    sta e_reverse
    lda #1
    sta e_list
    lda #20
    sta e_delay
    lda #4
    sta e_length
    jsr cat_animate
    ; If already accelerating, the source leaves C at the list length (4).
    lda #4
    sta e_compare
    lda n_chick_state,x
    and #$40
    bne :+
    lda n_vx,x
    sta n_target,x
    sta e_compare
:   lda n_chick_state,x
    ora #$42
    sta n_chick_state,x
    rts
cat_layout_jump:
    jsr cat_jump_setup
    lda n_layout
    asl a
    tay
    lda e_jump
    bne @left
    lda cat_jump_right+1,y
    sta n_draw_yoffset,x
    lda cat_jump_right,y
    jmp cat_jump_velocity
@left:
    lda cat_jump_left+1,y
    sta n_draw_yoffset,x
    lda cat_jump_left,y
    jmp cat_jump_velocity
cat_direct_jump:
    pha
    jsr cat_jump_setup
    lda #$f0
    sta n_draw_yoffset,x
    pla
    jmp cat_jump_velocity
cat_short_jump:
    lda n_chick_state,x
    and #1
    beq @done
    jsr cat_jump_setup
    lda #$f8
    sta n_draw_yoffset,x
    lda #$24
    ldy n_layout
    cpy #24
    bcc :+
    lda #$1c
:   ldy e_compare
    bpl :+
    eor #$ff
    clc
    adc #1
:   sta n_chain,x
    ; This path compares the layout byte, exactly as the source does.
    lda n_layout
    jmp cat_jump_acceleration
@done:
    rts
cat_jump_velocity:
    sta n_chain,x
cat_jump_acceleration:
    sec
    sbc e_compare
    bvc @no_overflow
    bcs @positive
    bcc @negative
@no_overflow:
    bcc @positive
@negative:
    lda #$ff
    bne @store
@positive:
    lda #1
@store:
    sta n_acceleration,x
    lda #0
    sta n_vx,x
    sta n_vy,x
    rts

cat_speed_up:
    lda n_round
    cmp #32
    bcc :+
    lda #31
:   and #$1c
    clc
    adc #$c0
    sta n_enemy_contact,x
    lda n_vx,x
    bmi @negative
    clc
    adc #1
    cmp #$50
    bcs @done
    pha
    lda n_difficulty
    and #$40
    beq @positive_normal
    pla
    clc
    adc #1
    bne @store
@positive_normal:
    pla
    jmp @store
@negative:
    sec
    sbc #1
    cmp #$b0
    bcs @done
    pha
    lda n_difficulty
    and #$40
    beq @negative_normal
    pla
    sec
    sbc #1
    jmp @store
@negative_normal:
    pla
@store:
    sta n_vx,x
@done:
    rts

cat_terrain_bank:
    lda #0
    sta e_attr
    lda n_vx,x
    bmi @left
    bne @right
    lda n_flags,x
    and #1
    beq @right
@left:
    lda n_vy,x
    bpl @left_down
    lda #0
    sta e_mode
    jsr cat_sample_bank
    lda e_mask
    bne :+
    jmp cat_fall
:
    and #$0c
    bne :+
    jmp cat_bounce
:
    jsr cat_reverse
    jmp cat_fall
@left_down:
    lda #1
    sta e_mode
    jsr cat_sample_bank
    jsr cat_above
    lda e_mask
    bne :+
    jmp cat_fall
:
    and #4
    beq cat_floor_response
    lda e_mask
    and #1
    bne cat_land_reverse
    jsr cat_reverse
    jmp cat_fall
@right:
    lda n_vy,x
    bmi @right_up
    lda #2
    sta e_mode
    jsr cat_sample_bank
    jsr cat_above
    lda e_mask
    beq cat_fall
    and #1
    beq cat_floor_response
    lda e_mask
    and #4
    bne cat_land_reverse
    jsr cat_reverse
    jmp cat_fall
@right_up:
    lda #3
    sta e_mode
    jsr cat_sample_bank
    lda e_mask
    beq cat_fall
    and #3
    beq cat_bounce
    jsr cat_reverse
    jmp cat_fall
cat_land_reverse:
    jsr cat_snap_floor
    jsr cat_reverse
    lda n_chick_state,x
    and #$fa
    sta n_chick_state,x
    rts
cat_floor_response:
    lda n_chick_state,x
    and #$fa
    sta n_chick_state,x
    lda e_mask
    and #2
    bne cat_snap_floor
    lda n_chick_state,x
    and #$40
    bne cat_snap_floor
    jsr cat_snap_floor
    lda n_chick_state,x
    ora #1
    sta n_chick_state,x
    rts
cat_bounce:
    lda n_vy,x
    bpl cat_fall
    eor #$ff
    clc
    adc #1
    sta n_vy,x
cat_fall:
    jsr motion_gravity
    lda n_chick_state,x
    ora #4
    sta n_chick_state,x
    rts
cat_reverse:
    lda n_vx,x
    eor #$ff
    clc
    adc #1
    sta n_vx,x
    lda n_target,x
    eor #$ff
    clc
    adc #1
    sta n_target,x
    lda n_acceleration,x
    eor #$ff
    clc
    adc #1
    sta n_acceleration,x
    rts
cat_snap_floor:
    ldy n_animation,x
    lda cat_heights,y
    lsr a
    sta e_half
    lda e_row
    asl a
    asl a
    asl a
    sec
    sbc e_half
    sta n_ylo,x
    lda #0
    sta n_vy,x
    rts
cat_above:
    ; Preserve the floor pointer and row for the subsequent landing snap.
    sec
    lda n_ptr
    sbc #64
    sta e_saved
    lda n_ptr+1
    sbc #0
    sta e_saved+1
    ldy #0
    lda (e_saved),y
    sta e_attr
    rts

enemies_reset_bank:
    lda #255
    sta pc_lastcol
    sta pc_lastcol+1
    sta pc_lastrow
    sta pc_lastrow+1
    lda #0
    sta pc_cooldown
    sta pc_cooldown+1
    sta n_flags+9
    sta n_flags+10
    sta n_door_timers
    sta n_door_timers+1
    sta n_spawn_clock
    sta n_elapsed_seconds
    sta n_spawn_wait
    sta n_spawn_delay
    sta n_frozen
    sta n_enemy_points
    rts

enemies_update_bank:
    lda n_bonus
    beq :+
    rts
:   lda n_game_ticks
    and #1
    bne @schedule
    ldx #9
    lda n_flags,x
    bpl :+
    jsr prepared_cat_tick
:   ldx #10
    lda n_flags,x
    bpl :+
    jsr prepared_cat_tick
:
@schedule:
    lda n_exiting
    beq :+
    rts
:   inc n_spawn_clock
    lda n_spawn_clock
    cmp #60
    bcc enemies_spawn_bank
    lda #0
    sta n_spawn_clock
    lda n_elapsed_seconds
    cmp #255
    beq enemies_spawn_bank
    inc n_elapsed_seconds
enemies_spawn_bank:
    lda n_game_ticks
    and #7
    bne @population
    lda n_flags+PLAYER
    and #4
    bne @population
    lda #0
    sta n_spawn_door
@door:
    ldy n_spawn_door
    lda n_door_timers,y
    beq @next_door
    cmp #17
    bcc @advance
    lda #0
    sta n_door_timers,y
    sta n_spawn_wait
    tya
    clc
    adc #9
    tax
    jmp cat_spawn_door_bank
@advance:
    clc
    adc #1
    sta n_door_timers,y
@next_door:
    inc n_spawn_door
    lda n_spawn_door
    cmp #2
    bcc @door
@population:
    lda n_flags+9
    and n_flags+10
    bmi @done
    lda n_flags+9
    ora n_flags+10
    bpl @open
    lda n_game_ticks
    and #127
    bne @seconds
    lda n_spawn_delay
    cmp #255
    beq @seconds
    inc n_spawn_delay
@seconds:
    lda n_spawn_clock
    bne @done
    inc n_spawn_wait
    ldy n_round
    cpy #8
    bcc :+
    ldy #7
:   lda n_spawn_wait
    cmp native_cat_spawn_delays,y
    bcc @done
@open:
    ldy #0
    lda n_flags+9
    bpl :+
    iny
:   lda n_door_timers,y
    bne @done
    lda #1
    sta n_door_timers,y
@done:
    rts

cat_spawn_door_bank:
    txa
    sec
    sbc #9
    sta e_old
    lda n_layout
    asl a
    clc
    adc e_old
    tay
    clc
    lda native_cat_door_xlo,y
    adc n_world
    sta n_spawn_x
    lda native_cat_door_xhi,y
    adc n_world+1
    and #1
    sta n_spawn_x+1
    lda native_cat_door_y,y
    sta n_spawn_y
    lda n_elapsed_seconds
    cmp #30
    lda #0
    rol a
    sta n_action_latch,x
    jmp cat_spawn_bank

; Decisions and terrain response run at 30 Hz. The intervening 60 Hz step
; advances the chosen movement and animation timer; hits/emergence remain live.
.segment "BANK3"
cat_scheduled_update:
    lda n_game_ticks
    and #1
    beq @full
    lda n_chick_state,x
    and #$92
    ora n_pause,x
    ora n_frozen
    bne @full
    lda n_timer,x
    cmp #2
    bcc :+
    dec n_timer,x
:   lda n_chick_state,x
    and #4
    beq :+
    jsr motion_gravity
:   lda n_chick_state,x
    and #$48
    beq :+
    jsr motion_accelerate
:   jmp cat_move
@full:
    jmp cat_update_bank
