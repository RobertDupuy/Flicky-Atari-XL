"""Small native ANTIC-4 font, title composition, and HUD strings."""
from pathlib import Path

FONT = {
'A':'010 101 111 101 101','B':'110 101 110 101 110','C':'011 100 100 100 011',
'D':'110 101 101 101 110','E':'111 100 110 100 111','F':'111 100 110 100 100',
'G':'011 100 101 101 011','H':'101 101 111 101 101','I':'111 010 010 010 111',
'J':'001 001 001 101 010','K':'101 101 110 101 101','L':'100 100 100 100 111',
'M':'101 111 111 101 101','N':'101 111 111 111 101','O':'010 101 101 101 010',
'P':'110 101 110 100 100','Q':'010 101 101 111 011','R':'110 101 110 101 101',
'S':'011 100 010 001 110','T':'111 010 010 010 010','U':'101 101 101 101 111',
'V':'101 101 101 101 010','W':'101 101 111 111 101','X':'101 101 010 101 101',
'Y':'101 101 010 010 010','Z':'111 001 010 100 111',
'0':'111 101 101 101 111','1':'010 110 010 010 111','2':'110 001 010 100 111',
'3':'110 001 010 001 110','4':'101 101 111 001 001','5':'111 100 110 001 110',
'6':'011 100 111 101 111','7':'111 001 010 010 010','8':'111 101 111 101 111',
'9':'111 101 111 001 110',':':'000 010 000 010 000','!':'010 010 010 000 010',
'+':'000 010 111 010 000','-':'000 000 111 000 000','/':'001 001 010 100 100',
}
CHARS=' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:!+-/'
def text(s): return bytes(CHARS.index(c) for c in s)

def build(out:Path):
    font=bytearray(1024)
    for c,pattern in FONT.items():
        rows=[0]+[sum(int(v)<<(6-2*i) for i,v in enumerate(row)) for row in pattern.split()]+[0,0]
        n=CHARS.index(c); font[n*8:n*8+8]=bytes(rows)
    font[62*8:63*8]=bytes([0xaa]*8)
    font[63*8:64*8]=bytes([0x55,0xff,0xff,0xff,0xff,0xff,0xff,0])
    screen=bytearray(1024)
    def line(row,s):
        start=row*32+(32-len(s))//2;screen[start:start+len(s)]=text(s)
    line(2,'ATARI XL EDITION')
    for i,c in enumerate('FLICKY'):
        for y,row in enumerate(FONT[c].split()):
            for x,v in enumerate(row):
                if v=='1':screen[(5+y)*32+4+i*4+x]=191
    line(11,'RESCUE THE WHOLE FLOCK')
    # Enlarge the already converted native Flicky artwork, preserving its inks.
    raw=(out/'player-image-000.bin').read_bytes(); h,w,ink=raw[:3]
    pixels=[]
    for y in range(h):
        row=[]
        for x in range(w):
            b=raw[4+2*(y*w+x)]
            for shift in (6,4,2,0):row.extend([(b>>shift)&3]*2)
        pixels.extend([row,row])
    glyph=64
    for by in range((len(pixels)+7)//8):
        for bx in range((len(pixels[0])+3)//4):
            data=bytes(sum((pixels[by*8+y][bx*4+x] if by*8+y<len(pixels) and bx*4+x<len(pixels[0]) else 0)<<(6-2*x) for x in range(4)) for y in range(8))
            if not any(data):continue
            assert glyph<128
            font[glyph*8:glyph*8+8]=data
            screen[(13+by)*32+12+bx]=glyph|ink;glyph+=1
    line(20,'PRESS FIRE TO PLAY')
    line(23,'MOVE LEFT / RIGHT')
    line(24,'FIRE TO JUMP AND THROW')
    line(26,'48 ROUNDS  -  BONUS CATCHES')
    (out/'ui-font.bin').write_bytes(font)
    (out/'ui-title.bin').write_bytes(screen)
    strings={
        'hud':'SCORE 000000  BEST 000000',
        'status':'LIVES 3   ROUND 01   FLOCK 0/8   ',
        'game_over':'  GAME OVER - FIRE TO RESTART   ',
        'clear':'  ROUND CLEAR!  TIME BONUS      ',
        'bonus':'  BONUS CATCH!  CAUGHT 00/20     ',
    }
    lines=['.segment "BANK15"','ui_font: .incbin "ui-font.bin"','ui_title: .incbin "ui-title.bin"']
    for key,s in strings.items():
        s=s.rstrip()
        assert len(s)<=32,(key,len(s))
        lines += ['ui_'+key+':','.byte '+','.join(map(str,text(s.ljust(32))))]
    from character_atlas import CharacterAtlas
    atlas=CharacterAtlas(out)
    net=['1111111111111111','1001010101010001','1000101010101001','0100010101000010',
         '0011111111111100','0000000110000000','0000000110000000','0000000110000000']
    for phase in range(4):
        width=(16+phase+3)//4;raw=bytearray([8,width,128])
        for row in net:
            row='0'*phase+row+'0'*(width*4-phase-16)
            for c in range(width):
                bits=sum(int(v)<<(6-2*i) for i,v in enumerate(row[c*4:c*4+4]))
                raw.extend((255^(bits*3),bits))
        name=f'bonus-net-{phase}.bin';(out/name).write_bytes(atlas.convert(raw))
        lines+=['.segment "BANK6"',f'bonus_net_{phase}: .incbin "{name}"']
    lines+=['bonus_net_lo: .lobytes bonus_net_0,bonus_net_1,bonus_net_2,bonus_net_3',
            'bonus_net_hi: .hibytes bonus_net_0,bonus_net_1,bonus_net_2,bonus_net_3']
    (out/'ui-data.s').write_text('\n'.join(lines)+'\n')
