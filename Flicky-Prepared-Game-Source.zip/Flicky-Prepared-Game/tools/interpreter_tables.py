#!/usr/bin/env python3
"""Generate the compact decoder dispatch table (one handler per opcode family)."""
from build import BUILD
from import_roms import decode_byte

def handler(o):
    if 0x40<=o<0x80:return 'i_halt' if o==0x76 else 'i_ld8'
    if 0x80<=o<0xc0:return 'i_alu'
    if o<0x40:
        if o&15==1:return 'i_ld16'
        if o&15==3:return 'i_inc16'
        if o&15==9:return 'i_add16'
        if o&15==11:return 'i_dec16'
        if o&7==4:return 'i_inc8'
        if o&7==5:return 'i_dec8'
        if o&7==6:return 'i_ldn'
    if o>=0xc0:
        if o&7==0:return 'i_retcc'
        if o&15==1:return 'i_pop'
        if o&7==2:return 'i_jpcc'
        if o&7==4:return 'i_callcc'
        if o&15==5:return 'i_push'
        if o&7==6:return 'i_alun'
        if o&7==7:return 'i_rst'
    return {
        0:'i_nop',2:'i_stbc',0x12:'i_stde',0xa:'i_ldbc',0x1a:'i_ldde',
        7:'i_rot_a',15:'i_rot_a',23:'i_rot_a',31:'i_rot_a',8:'i_exaf',
        0x10:'i_djnz',0x18:'i_jr',0x20:'i_jrcc',0x28:'i_jrcc',0x30:'i_jrcc',0x38:'i_jrcc',
        0x22:'i_sthl',0x2a:'i_ldhl',0x32:'i_stabs',0x3a:'i_ldabs',
        0x27:'i_daa',0x2f:'i_cpl',0x37:'i_scf',0x3f:'i_ccf',
        0xc3:'i_jp',0xc9:'i_ret',0xcd:'i_call',0xcb:'i_cb',0xed:'i_ed',
        0xdd:'i_dd',0xfd:'i_fd',0xd3:'i_out',0xdb:'i_in',0xd9:'i_exx',
        0xe3:'i_exsp',0xe9:'i_jphl',0xeb:'i_exde',0xf3:'i_di',0xf9:'i_sphl',0xfb:'i_ei'
    }[o]

def main():
    names=[handler(i) for i in range(256)]
    text='.segment "INTERPRETER"\ni_dispatch_lo:\n'+''.join('.byte <'+x+'\n' for x in names)
    text+='i_dispatch_hi:\n'+''.join('.byte >'+x+'\n' for x in names)
    conversion=[]
    for row in range(16):
        addr=(row&1)|((row&2)<<3)|((row&4)<<6)|((row&8)<<9)
        lut={}
        for raw in range(256):
            data=decode_byte(addr,raw,False);op=decode_byte(addr,raw,True)
            index=((data>>3)&1)|((data>>4)&2)|((data>>5)&4)
            assert index not in lut or lut[index]==(op&0xa8)
            lut[index]=op&0xa8
        conversion.extend(lut[k] for k in range(8))
    arrays={
        'i_conversion':conversion,
        'i_convert_value':[((v>>3)&1)|((v>>4)&2)|((v>>5)&4) for v in range(256)],
        'i_convert_lo':[((v&1)<<3)|(v&16) for v in range(256)],
        'i_convert_hi':[((v&1)<<5)|((v&16)<<2) for v in range(256)]}
    for name,values in arrays.items():
        text+=name+':\n'+''.join('.byte '+str(v)+'\n' for v in values)
    (BUILD/'interpreter_tables.s').write_text(text)
if __name__=='__main__':main()
