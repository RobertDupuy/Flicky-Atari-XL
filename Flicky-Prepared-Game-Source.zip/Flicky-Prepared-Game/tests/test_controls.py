import ctypes as C,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from run_native import Native

def machine():
    n=Native(True)
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    n.memory[0x604]=n.memory[0x60c]=255
    n.memory[n.labels['z_pc']]=0x68;n.memory[n.labels['z_pc']+1]=7
    return n
def poll(n):
    assert n.lib.at_call(n.labels['host_controls'],0,0,0)>0
    return int(n.memory[n.labels['z_system']])

def test_start_sequences_in_guest_ticks():
    for button,expected in [(1,[254]*8+[255]*8+[239]*8),
                            (2,[254]*8+[255]*8+[254]*8+[255]*8+[223]*8)]:
        n=machine();n.memory[0x606]=button
        assert [poll(n) for _ in range(len(expected))]==expected
        assert poll(n)==255
        assert n.memory[0x606]==0

def test_held_directions_short_fire_and_second_controller():
    n=machine()
    for value in [127,191,255,127,191]:
        n.memory[0x604]=value
        for _ in range(100):
            poll(n);assert n.memory[n.labels['z_p1']]==value
    n.memory[0x604]=255;n.memory[0x605]=1
    poll(n);assert n.memory[n.labels['z_p1']]==251
    poll(n);assert n.memory[n.labels['z_p1']]==255
    n.memory[0x60c]=127
    poll(n);assert n.memory[n.labels['z_p1']]==255
    n.memory[0xc001]=1
    poll(n);assert n.memory[n.labels['z_p1']]==127
