"""Precompose the fixed seesaws/cats into nine original animation states."""
from build import BUILD

def build(out):
    maps=(out/'maps-reference.bin').read_bytes()[2*1792:3*1792]
    index=(BUILD/'tile-index.bin').read_bytes();glyphs=(BUILD/'tile-glyphs.bin').read_bytes()
    base=[]
    for row in range(20,28):
        for y in range(8):
            line=[]
            for col in range(32):
                t=int.from_bytes(maps[(row*32+col)*2:(row*32+col)*2+2],'little')&2047
                a=index[t]+256*index[t+2048]-0x8000+((index[t+4096]&127)-9)*8192
                bits=glyphs[a+y]
                for x in range(4):
                    v=(bits>>(6-2*x))&3
                    line.append((3 if index[t+4096]&128 else 4) if v==3 else v)
            base.append(line)
    # Restore the arcade floor's brick joints. They were lost when the old
    # general-purpose color projection flattened both greens into one ink.
    floor=(out/'arcade-bonus-floor.bin').read_bytes()
    assert len(floor)==16*128
    for y in range(16):base[48+y]=list(floor[y*128:(y+1)*128])
    board_pose=(4,2,0,2,4,2,0,2,0);face=(0,0,0,1,1,1,0,0,0)
    cat_pose=(0,2,2,4,4,4,2,2,0);cat_y=(198,197,195,194,192,194,195,197,198)
    import json
    meta=json.loads((out/'arcade-bonus-assets.json').read_text())['poses']
    cats=json.loads((out/'arcade-bonus-cat-colors.json').read_text())
    lines=[];bank=30;used=0;banks=[];labels=[];sizes=[]
    for state in range(9):
        pixels=[r.copy() for r in base]
        for side in range(2):
            for art,cx,cy in [(8+board_pose[state]+(side^face[state]),(152,392)[side],200),
                              (14+cat_pose[state]+(side^1),(192,352)[side],cat_y[state])]:
                left=(cx-meta[art]['radius'])//4;top=cy-meta[art]['height']//2+1-160
                if art>=14:
                    for y,row in enumerate(cats[art-14]):
                        for x,value in enumerate(row):
                            if value!=255:pixels[top+y][left+x]=value
                    continue
                data=(out/f'arcade-bonus-art-{art:02d}-0.bin').read_bytes()
                h,w,ink,span=data[:4];p=int.from_bytes(data[4:6],'little')
                for y in range(h):
                    for x in range(w*4):
                        shift=6-2*(x&3);c=x//4
                        mask=(data[p+c*span*2+7+y]>>shift)&3
                        value=(data[p+c*span*2+span+7+y]>>shift)&3
                        if mask!=3:
                            if art<14:
                                # Beam red, bright edge white. Its original
                                # black pivot silhouette remains untouched.
                                value=2 if value==3 else 1 if value==2 else value
                            pixels[top+y][left+x]=(3 if ink else 4) if value==3 else value
        payload=bytearray();screen=bytearray();counts=[]
        for band in range(2):
            patterns=[];ids={}
            for row in range(4):
                for col in range(32):
                    cell=[pixels[band*32+row*8+y][col*4:col*4+4] for y in range(8)]
                    ink=0 if any(4 in line for line in cell) else 128
                    g=bytes(sum((3 if v==(4 if ink==0 else 3) else 1 if v in (3,4) else v)<<(6-2*x)
                                for x,v in enumerate(line)) for line in cell)
                    if g not in ids:ids[g]=len(patterns);patterns.append(g)
                    screen.append(ids[g]|ink)
            assert len(patterns)<64,(state,band,len(patterns))
            raw=b''.join(patterns);assert len(raw)<256
            payload+=len(raw).to_bytes(2,'little')+raw;counts.append(len(patterns))
        payload+=screen
        if used+len(payload)>8192:bank+=1;used=0
        assert bank==30
        name=f'arcade-bonus-apparatus-{state}.bin';(out/name).write_bytes(payload)
        label=f'ab_apparatus_{state}';labels.append(label);banks.append(bank);used+=len(payload);sizes.append(len(payload))
        lines += [f'.segment "BANK{bank}"',f'{label}: .incbin "{name}"']
    lines += ['.segment "BANK28"','ab_apparatus_lo: .lobytes '+','.join(labels),
              'ab_apparatus_hi: .hibytes '+','.join(labels),'ab_apparatus_bank: .byte '+','.join(map(str,banks))]
    (out/'arcade-bonus-background-data.s').write_text('\n'.join(lines)+'\n')
    print('Prepared apparatus:',sum(sizes),'bytes')
