#!/usr/bin/env python3
"""Unpack the distributed source and reproduce both Type 110 cartridges."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from build import ROOT,executable

def main():
    clean=Path(tempfile.mkdtemp(prefix='jcart-clean-',dir=ROOT.parent))
    with zipfile.ZipFile(ROOT/'release/Flicky-Prepared-Game-Source.zip')as z:
        assert not any('/private-roms/'in n or '/mame-roms/'in n or '/tools/rom/'in n for n in z.namelist())
        z.extractall(clean)
    project=clean/'Flicky-Prepared-Game';env=os.environ.copy();env.pop('FLICKY_BENCHMARK',None)
    env['CA65']=executable('ca65');env['LD65']=executable('ld65')
    with (clean/'rebuild.log').open('w')as log:
        subprocess.run([sys.executable,'tools/build_variants.py','--mapper','jcart'],cwd=project,env=env,stdout=log,stderr=log,check=True)
    result=[]
    for mode in ('NTSC','PAL'):
        name=f'Flicky-Atari-XL-{mode}-JatariCart-512K.car'
        actual=(project/'release'/name).read_bytes()
        assert actual==(ROOT/'release'/name).read_bytes(),name
        result.append(dict(file=name,bytes=len(actual),sha256=hashlib.sha256(actual).hexdigest(),byte_identical=True,original_rom_inputs_required=False))
    (ROOT/'evidence/jcart-clean-rebuild.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
