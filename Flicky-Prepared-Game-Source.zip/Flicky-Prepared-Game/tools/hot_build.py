#!/usr/bin/env python3
"""Keep measured gameplay blocks native; execute cold paths compactly."""
import json
from build import BUILD
from aot import size
from optimize_flags import annotate,optimized as native

def main():
    graph={i['pc']:i for i in json.loads((BUILD/'reference/reachable.json').read_text())}
    selected={int(k,16) for k in json.loads((BUILD/'reference/active-profile.json').read_text())}
    selected|={0x0af9,0x0b00}
    ins={pc:graph[pc] for pc in selected if pc in graph}
    # Unknown/cold successors retain every flag, including undocumented bits.
    annotate(ins)
    pcs=sorted(ins);banks={};bank=4;used=0
    for idx,pc in enumerate(pcs):
        code,terminal=native(ins[pc])
        amount=size(code)+2
        if not terminal and (idx+1==len(pcs) or pcs[idx+1]!=ins[pc]['end']):amount+=7
        if used+amount>7800:bank+=1;used=0
        banks[pc]=bank;used+=amount
    assert bank<=6,'Hot translation must leave bank 7 for its checked map'
    lines=[]
    for bank in sorted(set(banks.values())):
        lines += [f'.segment "BANK{bank}"',f'hot_bank_start{bank}:']
        page=[pc for pc in pcs if banks[pc]==bank]
        for idx,pc in enumerate(page):
            i=ins[pc];lines += [f'; {pc:04X}: {i["text"]}',f'.export g_{pc:04x}',f'g_{pc:04x}:']
            code,terminal=native(i,banks);lines+=['    '+s for s in code]
            if not terminal and (idx+1==len(page) or page[idx+1]!=i['end']):
                target=i['end']
                lines += [f'    lda #${target&255:02x}',f'    ldx #${target>>8:02x}','    jmp dispatch_ax']
    lines += ['.segment "BANK7"','hot_bank_start7:']
    counts=[]
    for high in range(128):
        entries=[pc for pc in pcs if pc>>8==high];counts.append(len(entries))
        lines.append(f'hot_page_{high}:')
        for pc in entries:lines += [f'.byte ${pc&255:02x}',f'.word g_{pc:04x}',f'.byte {banks[pc]}']
    lines += ['.segment "FIXED"','z_czflags: .byte 0,1,$40,$41','hot_lo:']+[f'.byte <hot_page_{p}' for p in range(128)]
    lines += ['hot_hi:']+[f'.byte >hot_page_{p}' for p in range(128)]
    lines += ['hot_count:']+[f'.byte {n}' for n in counts]
    (BUILD/'hot.s').write_text('\n'.join(lines)+'\n')
    (BUILD/'hot-banks.json').write_text(json.dumps({f'{pc:04X}':b for pc,b in banks.items()},indent=2))
    print('Hot instructions:',len(pcs),'native banks:',sorted(set(banks.values())))
if __name__=='__main__':main()
