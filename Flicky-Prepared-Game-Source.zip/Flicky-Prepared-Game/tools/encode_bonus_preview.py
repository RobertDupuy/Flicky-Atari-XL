"""Encode the continuous PAL bonus recording without cuts or speed changes."""
import hashlib,json,subprocess
from build import ROOT,BUILD

def main():
    folder=BUILD/'arcade-bonus/pal-realtime'
    verification=json.loads((folder/'verification.json').read_text())
    source=folder/verification['video']
    movie=ROOT/'release/Flicky-Atari-XL-PAL-Arcade-Bonus-Preview.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),
                    '-vf','scale=1008:720:flags=neighbor','-c:v','libx264',
                    '-preset','slow','-crf','15','-pix_fmt','yuv420p',
                    '-c:a','aac','-b:a','160k','-movflags','+faststart',str(movie)],check=True)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries',
                'format=duration,size:stream=codec_name,width,height,r_frame_rate,sample_rate',
                '-of','json',str(movie)]))
    assert float(probe['format']['duration'])>17
    assert any(s['codec_name']=='aac' for s in probe['streams'])
    report=dict(file=movie.name,sha256=hashlib.sha256(movie.read_bytes()).hexdigest(),
                cartridge_sha256=hashlib.sha256((ROOT/'release/Flicky-Atari-XL-PAL-512K.car').read_bytes()).hexdigest(),
                video=probe,verification=verification,cuts=0,speed_changes=0,
                source='Continuous normal-speed Atari800 video and POKEY sound')
    (ROOT/'evidence/bonus-pal-movie.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
