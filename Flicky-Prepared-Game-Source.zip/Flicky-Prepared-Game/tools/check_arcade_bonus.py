"""Compare native bonus actors with the actual decrypted arcade instructions.

Research-only: requires the user's separately supplied verified MAME ROM set.
The reusable golden traces contain data only and ship with the source project.
"""
import json
import numpy as np
from build import BUILD,ROOT
from native_engine import Engine
from native_oracle import Original

SLOTS=list(range(8))+list(range(11,23))
FIELDS={0:'n_flags',7:'n_xlo',8:'n_xhi',9:'n_ylo',10:'n_yhi',11:'n_target',
        12:'n_acceleration',16:'n_timer',18:'n_vx',19:'n_fx',20:'n_vy',21:'n_fy',
        22:'n_cycle',23:'n_bob',26:'n_chick_state',28:'n_action_latch'}

def main():
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    n=Engine();n.lib.at_video_timing(0);r=Original();report=[];gold=[]
    for stage in range(2,64,4):
        n.call('native_reset');n.set('n_round',stage);n.call('game_round_load')
        initial=((stage+1)&12)//4 if stage+1<16 else 0
        pattern=((stage+1)&60)//2
        while pattern>=24:pattern-=22
        ptr=int.from_bytes(rom[0x159e+pattern:0x15a0+pattern],'little')
        r.ram[:]=0;r.ram[0xc042:0xc044]=[ptr&255,ptr>>8]
        for i in range(20):
            a=0xc420+i*32;p=0x145e+initial*80+i*4;vx=rom[p+2]
            r.ram[a]=0x80|int(vx>=128)
            r.ram[a+1:a+3]=[0xb4,0x33]
            r.ram[a+5]=9+i
            r.ram[a+7:a+9]=list(rom[p:p+2]);r.ram[a+9]=201
            r.ram[a+11]=(vx+(-1 if vx>=128 else 1))&255
            r.ram[a+18]=vx;r.ram[a+20]=rom[p+3];r.ram[a+28]=int(vx>=128)
            r.call(0x4060,ix=a)
        frames=[]
        for tick in range(1200):
            frame=[]
            for i,slot in enumerate(SLOTS):
                a=0xc420+i*32
                for off,name in FIELDS.items():
                    actual=n.get(name,slot);expected=int(r.ram[a+off])
                    if off==0:actual&=0x8f;expected&=0x8f
                    assert actual==expected,(stage+1,tick,i,name,actual,expected)
                desc=int(r.ram[a+1])+256*int(r.ram[a+2])
                expected_anim={0x339e:3,0x33a9:4,0x33b4:5,0x33bf:6}[desc]
                assert n.get('n_animation',slot)==expected_anim,(stage,tick,i,'art')
                frame.extend([int(r.ram[a+off]) for off in FIELDS]+[expected_anim])
            frames.append(frame)
            if all(r.ram[0xc420+i*32]&4 for i in range(20)):break
            for i,slot in enumerate(SLOTS):
                r.call(0x4060,ix=0xc420+i*32)
                n.call('bonus_bird_step',x=slot)
        else:raise AssertionError(('unfinished',stage))
        gold.append(np.array(frames,dtype=np.uint8))
        report.append(dict(round=stage+1,ticks=len(frames),birds=20,fields_per_bird=17,
                           source_routine='4060',pattern=f'{ptr:04x}',initial_table=initial))
        print(report[-1],flush=True)
    out=BUILD/'native';np.savez_compressed(out/'arcade-bonus-golden.npz',**{f'r{x["round"]}':v for x,v in zip(report,gold)})
    (out/'arcade-bonus-differential.json').write_text(json.dumps(dict(rounds=report,
        actor_states=sum(x['ticks']*20 for x in report),mismatches=0),indent=2)+'\n')

if __name__=='__main__':main()
