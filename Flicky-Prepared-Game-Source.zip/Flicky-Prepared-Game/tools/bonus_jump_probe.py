"""Normal-speed emulator check using ordinary keyboard presses in the bonus.

The bonus is selected before observation; no state writes occur during play.
"""
import argparse,json,time,os
from pathlib import Path
from native_engine import Engine
from raster_probe import Session
from capture_skillful import locate,state,keyset

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('pal','ntsc'),required=True)
    p.add_argument('--cartridge',type=Path,required=True);p.add_argument('--labels',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    n=Engine(a.cartridge,a.labels);s=Session(a.cartridge,a.output,a.mode,True)
    log=[];fd=None
    def get(m,k,i=0):return int(m[n.labels[k]+i])
    try:
        s.tap('Control_R');time.sleep(.2);fd,base=locate(s)
        load=n.labels['game_round_load'];idle=n.labels['native_idle']
        # Startup may still expose the intro's upper-ROM window. Restore the
        # shared kernel explicitly, as the level-gallery selector does.
        code=bytes([0xa9,0x60,0x8d,0x1f,6,0x8d,0,0xd5,0x20,load&255,load>>8,
                    0xa9,1,0x8d,0xff,5,0x4c,idle&255,idle>>8])
        s.monitor([f'c {n.labels["n_round"]:04x} 02','c 05ff 00',
            'c 05d0 '+code[:16].hex(' '),'c 05e0 '+code[16:].hex(' '),
            'cont 05d0'],resume=False)
        deadline=time.monotonic()+15
        while not state(fd,base)[0x05ff]:
            if time.monotonic()>deadline:raise RuntimeError('Bonus loader did not finish')
            time.sleep(.03)
        time.sleep(1.2)
        start=time.monotonic();captured=False
        while time.monotonic()-start<8:
            t=time.monotonic()-start
            key=251 if 1<=t<3.4 or 4.5<=t<4.65 else 255
            keyset(s,key)
            m=state(fd,base)
            log.append(dict(seconds=t,key=key,y=get(m,'n_ylo',8),vy=get(m,'n_vy',8),
                grounded=get(m,'n_grounded'),net_y=get(m,'b_net_y'),
                fault=get(m,'r_fault'),overflow=get(m,'c_overflow')))
            if not captured and get(m,'n_ylo',8)<=109:
                s.capture().save(a.output/'jump.png');captured=True
            time.sleep(.015)
        keyset(s,255);s.capture().save(a.output/'landed.png')
        jumps=sum(before['grounded'] and not after['grounded'] for before,after in zip(log,log[1:]))
        result=dict(mode=a.mode,normal_speed=True,state_edits_during_play=0,
            minimum_y=min(v['y'] for v in log),jumps=jumps,
            final_grounded=log[-1]['grounded'],final_y=log[-1]['y'],
            renderer_faults=max(v['fault'] for v in log),clock_overflow=max(v['overflow'] for v in log),
            asynchronous_net_sample_differences=sum(v['net_y']!=v['y']+7 for v in log),
            net_sample_note='Live RAM reads may interrupt a logic tick; completed-tick attachment is checked by the CPU regression test.')
        (a.output/'input-log.json').write_text(json.dumps(log,indent=2)+'\n')
        (a.output/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
        assert jumps==2 and result['minimum_y']<=109 and result['final_grounded']==1
        assert not result['renderer_faults'] and not result['clock_overflow']
        print(json.dumps(result,indent=2))
    finally:
        if fd is not None:os.close(fd)
        s.close()

if __name__=='__main__':main()
