; Bounded compositor: one mask/ink operation per occupied scanline, no hash
; probes and no per-pixel priority calculation. The scene wraps in 32 columns.
; Idle birds retain four pinned glyphs. Moving birds use codes 64..95;
; the generic actors use the frame-local pool 96..127.
.segment "HIGHRAM"
.export fast_sprites_begin,fast_draw_prepared
fast_sprites_begin:
    jsr sprites_restore
    ldx #6
    lda #96
@pool:
    sta r_next_glyph,x
    dex
    bpl @pool
    rts

fast_draw_prepared:
    lda p_visible
    bne :+
    rts
:   lda p_imagebank
    NATIVE_BANK
    ldy #1
    lda (p_image),y
    sta p_width
    iny
    lda (p_image),y
    sta p_ink
    iny
    lda (p_image),y
    sta p_plane_span
    asl a
    sta p_column_span
    iny
    lda (p_image),y
    clc
    adc p_image
    sta p_column_base
    iny
    lda (p_image),y
    adc p_image+1
    sta p_column_base+1
    lda p_y
    and #7
    asl a
    clc
    adc #6
    tay
    lda (p_image),y
    clc
    adc p_image
    sta p_frame
    iny
    lda (p_image),y
    adc p_image+1
    sta p_frame+1
    ldy #0
    lda (p_frame),y
    sta p_block
    lda #1
    sta p_character
    lda p_y
    and #7
    eor #7
    sta p_source_row
    lda p_y
    and #$f8
    sta p_y
    lda p_left+1
    lsr a
    lda p_left
    ror a
    lsr a
    lsr a
    lsr a
    sta p_index
@row:
    lda p_y
    cmp #224
    bcc :+
    rts
:   lsr a
    lsr a
    lsr a
    sta r_row
    tax
    lda native_row_lo,x
    sta p_screen_row
    lda r_back
    asl a
    asl a
    asl a
    asl a
    sta n_step
    clc
    adc #$60
    adc native_row_hi,x
    sta r_screen+1
    lda r_row
    lsr a
    lsr a
    sta r_band_index
    tax
    clc
    adc #$ec
    sta p_negative_mask+1
    lda #0
    sta p_negative_mask
    lda cache_band_lo,x
    sta p_meta
    lda cache_band_hi,x
    clc
    adc n_step
    sta p_meta+1
    txa
    asl a
    asl a
    sta p_fontbase
    lda n_step
    asl a
    clc
    adc #$20
    adc p_fontbase
    sta p_fontbase
    lda p_column_base
    clc
    adc p_source_row
    sta p_stamp_mask
    lda p_column_base+1
    adc #0
    sta p_stamp_mask+1
    lda p_stamp_mask
    clc
    adc p_plane_span
    sta p_stamp_bits
    lda p_stamp_mask+1
    adc #0
    sta p_stamp_bits+1
    lda p_index
    sta r_column
    lda p_width
    sta p_slot
@cell:
    ldy p_character
    lda (p_frame),y
    iny
    ora (p_frame),y
    tax
    iny
    sty p_character
    txa
    bne :+
    jmp @next
:   lda p_screen_row
    clc
    adc r_column
    sta r_screen
    ldy #0
    lda (r_screen),y
    sta p_bg
    and #127
    sta p_code
    cmp #64
    bcs @nonblank_background
    tay
    lda (p_negative_mask),y
    bmi @blank_background
@nonblank_background:
    lda #0
    sta p_recolor
    lda p_code
    jsr fast_font_address
    lda r_font
    sta p_fontold
    lda r_font+1
    sta p_fontold+1
    jmp @classify
@blank_background:
    lda #1
    sta p_recolor
@classify:
    lda p_code
    cmp #64
    bcc @allocate
    cmp #96
    bcs @blit
    sec
    sbc #64
    lsr a
    lsr a
    tax
    lda i_active
    and pickup_bits,x
    beq @blit
@allocate:
    lda z:f_floor_mode
    bne @floor_allocate
    jsr sprite_dirty_add
    ldx r_band_index
    lda r_next_glyph,x
    cmp #128
    bcc :+
    inc r_fault
    jmp @next
:   inc r_next_glyph,x
    sta p_code
    jsr fast_font_address
    jmp @blit
@floor_allocate:
    ldx r_band_index
    lda r_back
    beq :+
    txa
    clc
    adc #7
    tax
:   lda r_static_next,x
    cmp #64
    bcc :+
    inc r_fault
    jmp @next
:   inc r_static_next,x
    sta p_code
    jsr fast_font_address
@blit:
    lda z:f_floor_mode
    beq :+
    jsr fast_floor_pin
:   
    lda p_recolor
    beq @masked
    ldy #0
    .repeat 8,I
        lda (p_stamp_bits),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
    jmp @write
@masked:
    lda p_bg
    and #$80
    cmp p_ink
    beq @same_ink
    ldy #0
    .repeat 8,I
        lda (p_fontold),y
        tax
        lda $f600,x
        and (p_stamp_mask),y
        ora (p_stamp_bits),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
    jmp @write
@same_ink:
    ldy #0
    .repeat 8,I
        lda (p_fontold),y
        and (p_stamp_mask),y
        ora (p_stamp_bits),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
@write:
    lda p_code
    ora p_ink
    jsr sprite_write_cell
@next:
    lda p_stamp_mask
    clc
    adc p_column_span
    sta p_stamp_mask
    bcc :+
    inc p_stamp_mask+1
:   lda p_stamp_bits
    clc
    adc p_column_span
    sta p_stamp_bits
    bcc :+
    inc p_stamp_bits+1
:   inc r_column
    lda r_column
    and #31
    sta r_column
    dec p_slot
    beq :+
    jmp @cell
:   lda p_source_row
    clc
    adc #8
    sta p_source_row
    lda p_y
    clc
    adc #8
    sta p_y
    dec p_block
    beq :+
    jmp @row
:   rts

fast_font_address:
    tax
    lda $f300,x
    sta r_font
    lda $f380,x
    clc
    adc p_fontbase
    sta r_font+1
    rts
