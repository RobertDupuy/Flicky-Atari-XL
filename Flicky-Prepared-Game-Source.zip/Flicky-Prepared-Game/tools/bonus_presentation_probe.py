"""Real ANTIC/GTIA bonus art, score typography and DLI boundary verification.

This is a diagnostic display check: states are selected in the emulator monitor.
Continuous ordinary-input bonus play is separately recorded by capture_arcade_bonus.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from build import BUILD
from native_engine import Engine
from raster_probe import Session

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['pal','ntsc'],required=True)
    ap.add_argument('--cartridge',type=Path,required=True);ap.add_argument('--labels',type=Path)
    ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    n=Engine(a.cartridge,a.labels);s=Session(a.cartridge,a.output,a.mode)
    def poke(name,values):return f'c {n.labels[name]:04x} '+ ' '.join(f'{v:02x}' for v in values)
    def memory(address,data):
        # Atari800's monitor has a short line buffer; never send long rows.
        return [f'c {address+i:04x} '+bytes(data[i:i+16]).hex(' ') for i in range(0,len(data),16)]
    def call(names):
        code=[]
        for name in names:
            p=n.labels[name];code += [0x20,p&255,p>>8]
        code += [0x4c,0xf0,5]
        return ['c 05d0 '+' '.join(f'{v:02x}'for v in code),'cont 05d0']
    def runs(im,x):
        p=np.asarray(im)[:,x];starts=[0]+[i for i in range(1,len(p)) if not np.array_equal(p[i],p[i-1])]
        return [dict(y=i,rgb=p[i].tolist())for i in starts]
    try:
        time.sleep(1);s.tap('Control_R');time.sleep(1.5)
        # Pause only the logic clock in this static diagnostic, not NMI/ANTIC.
        load=n.labels['game_round_load'];pause=0x068f
        code=[0x20,load&255,load>>8,0xa9,1,0x8d,pause&255,pause>>8,0x4c,0xf0,5]
        s.monitor(['c 05f0 4c f0 05',poke('n_round',[2]),'c 05d0 '+' '.join(f'{v:02x}' for v in code),'cont 05d0'],resume=False)
        time.sleep(1.5)
        poses=[]
        for state in range(9):
            s.monitor([poke('b_seesaw',[state]),poke('r_back',[0]),*call(['native_render_submit'])],resume=False)
            time.sleep(.2);name=f'apparatus-{state}.png';s.capture().save(a.output/name);poses.append(name)
        # Exercise the actual 20-catch native score path, then its event patch.
        commands=[poke('b_caught',[20]),poke('b_done',[20]),poke('u_wait',[0])]
        for i in list(range(8))+list(range(11,23)):commands.append(f'c {n.labels["n_flags"]+i:04x} 84')
        s.monitor(commands+call(['bonus_update','message_result','native_render_submit']),resume=False)
        time.sleep(.1);s.capture().save(a.output/'perfect.png')
        # A diagnostic font pattern keeps PAL/NTSC DMA and all bonus DLIs live.
        commands=[poke('r_front',[0,1,0]),'c d000 00 00 00 00 00 00 00 00','c e000 '+'00 '*8]
        for base in (0x2000,0x4000):
            for band in range(7):
                glyphs=[0x55]*8+[0xaa]*8+[0xff]*8+[(0x55,0xaa,0xff)[band%3]]*8
                commands+=memory(base+band*1024,glyphs)
        commands+=memory(0x1f00,bytes(64))
        row=bytes([3]*8+[1]*8+[2]*8+[130]*8)*3
        for base in (0x6000,0x7000):
            for y in range(28):commands+=memory(base+y*96,row)
        commands.append('cont 05f0');s.monitor(commands,resume=False);time.sleep(.1)
        im=s.capture();im.save(a.output/'raster.png')
        pf1=runs(im,240);pf2=runs(im,368);gold=runs(im,496)
        origin=32 if a.mode=='pal' else 16
        # The emulator's standard NTSC viewport crops the final eight game
        # scanlines. Check only visible transitions; PAL exposes all four.
        expected1=[y for y in [0,origin+32,origin+352,origin+416,origin+432] if y<im.height]
        # The platform and cat highlight share an ink; line 176 changes the
        # launcher ink, while line 192 adds the darker orange body shade.
        changes2=[0,origin+32,origin+384]
        expected2=[y for y in changes2 if y<im.height]
        assert [r['y']for r in pf1]==expected1,(a.mode,pf1)
        assert [r['y']for r in pf2]==expected2,(a.mode,pf2)
        assert [r['y']for r in gold]==[0,origin+32],(a.mode,gold)
        data=np.asarray(im)
        # No partial first scanline / late color store within either color bar.
        for x1,x2 in ((208,336),(336,464),(464,592)):
            assert np.all(data[origin+32:,x1:x2]==data[origin+32:,x1:x1+1]),(x1,x2)
        white=data[origin+40,144]
        for y in range(16,min(224,(im.height-origin)//2)):
            ink=(y//32)%3
            expected=white if ink==0 else data[origin+y*2,240 if ink==1 else 368]
            assert np.all(data[origin+y*2:origin+y*2+2,80:208]==expected),(a.mode,'font deadline',y)
        report=dict(mode=a.mode,diagnostic_state_selection=True,apparatus_states=poses,
                    perfect_result='perfect.png',palette_transition_rows=[176,192,208,216],
                    visible_palette_transition_rows=[y for y in (176,192,208,216) if origin+y*2<im.height],
                    viewport_height=im.height,
                    pf1_runs=pf1,pf2_runs=pf2,gold_runs=gold,
                    correct_scanline_boundaries=True,correct_font_boundaries=True,partial_scanline_errors=0,
                    original_gameplay_routines_modified=False)
        (a.output/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
    finally:s.close()

if __name__=='__main__':main()
