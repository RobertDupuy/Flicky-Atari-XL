"""Bake all 4x4 solid-tile neighbourhoods; geometry is never rebuilt per tick."""
from prepared_codec import compress,expand

def build(out):
    maps=(out/'maps-reference.bin').read_bytes();lines=[];banks=[];bank=13;used=0
    for level in range(48):
        m=maps[level*1792:(level+1)*1792];planes=[bytearray(),bytearray()]
        for row in range(28):
            for col in range(32):
                bits=sum(bool(m[((row+dy)*32+((col+dx)&31))*2+1]&16)<<(dy*4+dx)for dy in range(4)for dx in range(4)if row+dy<28)
                planes[0].append(bits&255);planes[1].append(bits>>8)
        for p,plane in enumerate(planes):
            data=compress(bytes(plane));assert expand(data)==plane
            if used+len(data)>8192:bank+=1;used=0
            assert bank<=14
            used+=len(data);banks.append(bank);i=level*2+p;name=f'terrain-{i:02}.lz';(out/name).write_bytes(data)
            lines += [f'.segment "BANK{bank}"',f'terrain_{i}:',f'.incbin "{name}"']
    lines+=['.segment "FIXED"','terrain_bank:','.byte '+','.join(map(str,banks)),'terrain_lo:','.lobytes '+','.join(f'terrain_{i}'for i in range(96)),'terrain_hi:','.hibytes '+','.join(f'terrain_{i}'for i in range(96))]
    for name,high in [('rect_mask_lo',False),('rect_mask_hi',True)]:
        values=[]
        for h in range(1,5):
            for w in range(1,5):
                mask=sum(1<<(r*4+c)for r in range(h)for c in range(w));values.append((mask>>8 if high else mask)&255)
        lines += [name+':','.byte '+','.join(map(str,values))]
    lines+=['.segment "BANK4"']
    for name,mapping in [('contact_low',[(0,7),(4,6),(1,3),(2,2),(6,1)]),('contact_high',[(0,5),(1,4),(2,0)])]:
        lines += [name+':','.byte '+','.join(str(sum(((v>>a)&1)<<b for a,b in mapping))for v in range(256))]
    for high in (0,1):
        lines += [f'contact_column{high}:','.byte '+','.join(str(((240-(v+high*256))//16)&31)for v in range(256))]
    (out/'prepared-terrain-data.s').write_text('\n'.join(lines)+'\n')
