"""Assemble actual gameplay and a labeled, separately selected bonus round."""
import hashlib
import json
import subprocess
from build import ROOT, BUILD


def main():
    movie = ROOT / 'release/Flicky-Atari-XL-NTSC-Gameplay-Bonus.mp4'
    source = BUILD / 'native/ntsc-512-movie/capture.avi'
    bonus = BUILD / 'native/ntsc-512-bonus-movie/capture.avi'
    filters = (
        '[0:v]trim=duration=24,setpts=PTS-STARTPTS,fps=60,'
        'scale=1008:672:flags=neighbor,pad=1008:720:0:24,setsar=1,'
        "drawtext=text='FLICKY - NTSC 512K':fontcolor=white:fontsize=16:"
        "x=(w-tw)/2:y=3:enable='lt(t,3)'[gamev];"
        '[0:a]atrim=duration=24,asetpts=PTS-STARTPTS[gamea];'
        '[1:v]trim=duration=20.25,setpts=PTS-STARTPTS,fps=60,'
        'scale=1008:672:flags=neighbor,pad=1008:720:0:24,setsar=1,'
        "drawtext=text='NTSC BONUS ROUND - separate demonstration':"
        'fontcolor=white:fontsize=16:x=(w-tw)/2:y=700[bonusv];'
        '[1:a]atrim=duration=20.25,asetpts=PTS-STARTPTS[bonusa];'
        '[gamev][gamea][bonusv][bonusa]concat=n=2:v=1:a=1[v][a]'
    )
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                    '-i', str(source), '-i', str(bonus), '-filter_complex', filters,
                    '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'slow',
                    '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k',
                    '-movflags', '+faststart', str(movie)], check=True)
    probe = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-show_entries',
        'format=duration,size:stream=index,codec_name,width,height,r_frame_rate,sample_rate',
        '-of', 'json', str(movie)]))
    report = {
        'file': movie.name, 'sha256': hashlib.sha256(movie.read_bytes()).hexdigest(),
        'cartridge_sha256': hashlib.sha256((ROOT / 'release/Flicky-Atari-XL-NTSC-512K.car').read_bytes()).hexdigest(),
        'video': probe, 'normal_gameplay_seconds': 24,
        'bonus_demonstration': json.loads((bonus.parent / 'result.json').read_text()),
        'bonus_section_seconds': 20.25, 'bonus_section_labeled': True,
        'source': 'Atari800 native recording, actual game graphics and POKEY audio',
    }
    (ROOT / 'evidence/movie-ntsc.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
