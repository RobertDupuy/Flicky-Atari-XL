; Bounded pursuit: choose actions at decision points and tile boundaries.
; Jump/fall/death displacements and all poses are prepared on the host.
pc_lastcol=$1d80
pc_lastrow=$1d82
pc_cooldown=$1d84
.segment "BANK3"
prepared_cat_tick:
    lda n_frozen
    beq :+
    rts
:   lda n_flags,x
    and #$20
    bne :+
    lda #0
    sta n_flags,x
    rts
:   lda n_pause,x
    beq :+
    jmp cat_update_bank
:   lda n_chick_state,x
    bpl :+
    jmp pc_hit
:
    and #$10
    beq :+
    jmp pc_dying
:   lda pc_cooldown-9,x
    beq :+
    dec pc_cooldown-9,x
:   lda n_chick_state,x
    and #4
    bne @travel
    txa
    asl a
    asl a
    asl a
    asl a
    clc
    adc n_game_ticks
    and #31
    bne @travel
    ; Shortest direction around the wrapping room.
    sec
    lda n_xlo+PLAYER
    sbc n_world
    sta c_screen
    lda n_xhi+PLAYER
    sbc n_world+1
    sta c_screen+1
    sec
    lda c_screen
    sbc n_xlo,x
    lda c_screen+1
    sbc n_xhi,x
    and #1
    sta e_mode
    lda n_flags,x
    and #$fc
    ora e_mode
    sta n_flags,x
    lda n_ylo+PLAYER
    clc
    adc #16
    cmp n_ylo,x
    bcs @travel
    lda pc_cooldown-9,x
    bne @travel
    jsr pc_jump
@travel:
    ldy n_round
    lda pc_speed,y
    sta n_step
    lda #0
    sta n_count
    lda n_flags,x
    and #1
    beq :+
    lda n_step
    eor #255
    clc
    adc #1
    sta n_step
    dec n_count
:   lda n_step
    clc
    adc n_xlo,x
    sta n_xlo,x
    lda n_xhi,x
    adc n_count
    and #1
    sta n_xhi,x
    lda n_flags,x
    and #1
    tay
    lda pc_velocity,y
    sta n_vx,x
    ; One wall/floor decision per crossed map column.
    lda n_xhi,x
    lsr a
    lda n_xlo,x
    ror a
    lsr a
    lsr a
    lsr a
    cmp pc_lastcol-9,x
    beq @vertical
    sta pc_lastcol-9,x
    jsr pc_side
@vertical:
    lda n_chick_state,x
    and #4
    bne pc_air
    lda n_game_ticks
    lsr a
    lsr a
    and #7
    tay
    lda pc_walk_pose,y
    sta n_animation,x
    rts

pc_hit:
    lda #$10
    sta n_chick_state,x
    lda #24
    sta n_timer,x
    lda #0
    sta n_bob,x
pc_dying:
    ldy n_bob,x
    lda pc_death_dy,y
    clc
    adc n_ylo,x
    sta n_ylo,x
    lda pc_death_pose,y
    sta n_animation,x
    inc n_bob,x
    dec n_timer,x
    beq @remove
    lda n_ylo,x
    cmp #222
    bcc @done
@remove:
    lda #0
    sta n_flags,x
@done:
    rts

pc_jump:
    lda #4
    sta n_chick_state,x
    lda #0
    sta n_bob,x
    lda #36
    sta pc_cooldown-9,x
    lda #255
    sta pc_lastrow-9,x
    rts
pc_fall:
    lda #4
    sta n_chick_state,x
    lda #18
    sta n_bob,x
    lda #255
    sta pc_lastrow-9,x
    rts
pc_air:
    ldy n_bob,x
    lda pc_jump_dy,y
    sta n_step
    clc
    adc n_ylo,x
    sta n_ylo,x
    lda pc_jump_pose,y
    sta n_animation,x
    lda pc_jump_next,y
    sta n_bob,x
    lda n_step
    bmi @up
    lda n_ylo,x
    clc
    adc #10
    bne @probe
@up:
    lda n_ylo,x
    sec
    sbc #10
@probe:
    cmp #224
    bcs @done
    sta e_y
    lsr a
    lsr a
    lsr a
    cmp pc_lastrow-9,x
    beq @done
    sta pc_lastrow-9,x
    jsr pc_center
    jsr cat_tile
    ldy #0
    lda (n_ptr),y
    and #$10
    beq @done
    lda n_step
    bmi @ceiling
    lda e_row
    asl a
    asl a
    asl a
    sec
    sbc #10
    sta n_ylo,x
    lda #0
    sta n_chick_state,x
    sta n_vy,x
    rts
@ceiling:
    lda e_row
    asl a
    asl a
    asl a
    clc
    adc #18
    sta n_ylo,x
    jmp pc_fall
@done:
    rts

pc_center:
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
    sta c_screen+1
    rts
pc_side:
    jsr pc_center
    lda n_flags,x
    and #1
    beq @right
    sec
    lda c_screen
    sbc #16
    sta c_screen
    lda c_screen+1
    sbc #0
    jmp @x
@right:
    clc
    lda c_screen
    adc #16
    sta c_screen
    lda c_screen+1
    adc #0
@x:
    and #1
    sta c_screen+1
    lda n_ylo,x
    sta e_y
    jsr cat_tile
    ldy #0
    lda (n_ptr),y
    and #$10
    beq @floor
    lda n_flags,x
    eor #1
    sta n_flags,x
    lda n_chick_state,x
    and #4
    bne @done
    lda pc_cooldown-9,x
    bne @done
    jmp pc_jump
@floor:
    lda n_chick_state,x
    and #4
    bne @done
    jsr pc_center
    lda n_ylo,x
    clc
    adc #10
    sta e_y
    jsr cat_tile
    ldy #0
    lda (n_ptr),y
    and #$10
    bne @done
    jmp pc_fall
@done:
    rts
pc_velocity: .byte $20,$e0
pc_walk_pose: .byte 0,1,2,3,4,2,1,0
