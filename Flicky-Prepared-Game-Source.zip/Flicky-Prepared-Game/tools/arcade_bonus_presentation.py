"""Compile original bonus lettering/results into event-only screen patches."""
from pathlib import Path

def build(out):
    maps=(out/'maps-reference.bin').read_bytes()[2*1792:3*1792]
    tiles=[int.from_bytes(maps[i:i+2],'little')&2047 for i in range(0,len(maps),2)]
    base=[len(set(tiles[b*128:(b+1)*128])) for b in range(7)]
    overlays=(out/'arcade-bonus-overlays.bin').read_bytes()
    font=(out/'arcade-bonus-font.bin').read_bytes()
    rows=(5,9,12,14)
    chars={band:set() for band in (1,2,3)}
    for count in range(21):
        data=overlays[count*896:(count+1)*896]
        for row in rows:chars[row//4].update(data[row*32:row*32+32])
    for s in chars.values():s.discard(0)
    codes={b:{c:base[b]+i for i,c in enumerate(sorted(s))} for b,s in chars.items()}
    assert all(base[b]+len(s)<48 for b,s in chars.items())
    def block(a,data):
        assert 0<len(data)<256
        return a.to_bytes(2,'little')+bytes([len(data)])+bytes(data)
    init=bytearray()
    for b,mapping in codes.items():
        for c,code in mapping.items():
            g=font[c*8:c*8+8]
            if c==47:g=bytes(v*3 for v in g)
            for back in (0,1):init+=block(0x2000+back*8192+b*1024+code*8,g)
    init+=bytes(2)
    lines=['.segment "BANK27"','ab_message_font: .incbin "arcade-bonus-message-font.bin"']
    (out/'arcade-bonus-message-font.bin').write_bytes(init)
    total=len(init)
    for count in range(21):
        data=overlays[count*896:(count+1)*896];patch=bytearray()
        for row in rows:
            src=data[row*32:row*32+32]
            occupied=[i for i,v in enumerate(src) if v]
            if not occupied:continue
            lo,hi=min(occupied),max(occupied)+1
            # Blank cells in these rows all use background code zero.
            line=bytes((codes[row//4][v]|(128 if v==47 else 0)) if v else 0 for v in src[lo:hi])
            patch+=block(0x1600+row*32+lo,line)
            for back in (0,1):
                for wrap in range(3):patch+=block(0x6000+back*4096+row*96+wrap*32+lo,line)
        patch+=bytes(2);total+=len(patch)
        name=f'arcade-bonus-result-{count:02d}.bin';(out/name).write_bytes(patch)
        lines += [f'ab_message_{count}: .incbin "{name}"']
    lines += ['ab_message_lo: .lobytes '+','.join(f'ab_message_{i}' for i in range(21)),
              'ab_message_hi: .hibytes '+','.join(f'ab_message_{i}' for i in range(21)),
              f'ab_tally_code={codes[1][47]|128}']
    (out/'arcade-bonus-message-data.s').write_text('\n'.join(lines)+'\n')
    print('Arcade bonus text patches:',total,'bytes')
