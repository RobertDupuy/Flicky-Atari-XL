; Native sprite data and original-resolution terrain contacts.
p_image=$6c
p_mask=$6e
p_maskbank=$70
p_imagebank=$71
p_left=$72
p_y=$74
p_height=$75
p_width=$76
p_ink=$77
p_index=$78
p_bytes=$79
p_maskbits=$7a
p_shift=$7e
p_half=$7f
p_dilate=$80
p_bg=$c0
p_fontold=$84
p_dirty=$86
p_cell=$88
p_code=$89
p_row_y=$8a
p_pair=$8b
p_keep=$8c
p_count_index=$8d
p_saved_count=$8e
p_fontbase=$8f
p_slot=$90
p_cachedrow=$91
p_negative_mask=$93
p_clip_mask=$97
p_actor=$9b
p_screen=$9c
p_clip_count=$9e
p_draw_clip=$9f
p_visible=$a3
p_mask_bytes=$c4
p_sprite_width=$c5
p_contact_cache=$c6
p_negative_count=$c8
p_cachelo=$0a00
p_cachehi=$0a04
p_cachecode=$0a08
p_cachescreenlo=$0a0c
p_cachescreenhi=$0a10
p_cachevalid=$0a14
r_dirty_counts=$0660
r_dirty_end=$0664
r_next_glyph=$0670

.segment "FIXED"
.export n_terrain_contact,r_dirty_counts
sprite_mask_prefix:
    lda p_left
    lsr a
    and #7
    clc
    adc p_clip_count
    tax
    lda native_prefix0,x
    sta p_clip_mask
    lda native_prefix1,x
    sta p_clip_mask+1
    lda native_prefix2,x
    sta p_clip_mask+2
    lda native_prefix3,x
    sta p_clip_mask+3
    lda n_world+1
    bmi @positive
    lda p_left+1
    bpl @positive
    sec
    lda #0
    sbc p_left
    tax
    lda #0
    sbc p_left+1
    bne @all_negative
    txa
    cmp #48
    bcs @all_negative
    clc
    adc #1
    lsr a
    tax
    jmp @prefix
@all_negative:
    ldx #24
    bne @prefix
@positive:
    ldx #0
@prefix:
    stx n_step
    lda p_left
    lsr a
    and #7
    clc
    adc n_step
    tax
    stx p_negative_count
    lda native_prefix0,x
    sta p_negative_mask
    lda native_prefix1,x
    sta p_negative_mask+1
    lda native_prefix2,x
    sta p_negative_mask+2
    lda native_prefix3,x
    sta p_negative_mask+3
    lda p_left+1
    and #1
    sta p_left+1
    rts

sprite_terrain_bounds:
    lda p_left
    lsr a
    and #7
    clc
    adc p_sprite_width
    clc
    adc #8
    lsr a
    lsr a
    lsr a
    sta p_mask_bytes
    lda p_y
    cmp #224
    bcs @empty
    and #7
    clc
    adc p_height
    clc
    adc #7
    lsr a
    lsr a
    lsr a
    sta n_count
    lda p_y
    and #$18
    asl a
    asl a
    asl a
    sta n_ptr
    lda p_y
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #>n_map
    sta n_ptr+1
    lda p_left+1
    lsr a
    lda p_left
    ror a
    lsr a
    lsr a
    and #$3e
    ora #1
    sta n_column
@row:
    ldy n_column
    ldx p_mask_bytes
@column:
    lda (n_ptr),y
    and #$10
    bne @solid
    tya
    clc
    adc #2
    and #63
    tay
    dex
    bne @column
    clc
    lda n_ptr
    adc #64
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   lda n_ptr+1
    cmp #$c7
    bcs @empty
    dec n_count
    bne @row
@empty:
    lda #0
    rts
@solid:
    lda #1
    rts

sprites_restore:
    ldx r_back
    lda r_dirty_counts,x
    sta n_remaining
    lda #0
    sta r_dirty_counts,x
    txa
    beq :+
    lda #128
:   tax
    stx p_count_index
@restore:
    lda n_remaining
    beq @done
    lda $3c00,x
    sta r_screen
    lda $3d00,x
    sta r_screen+1
    lda $3e00,x
    ldy #0
    sta (r_screen),y
    ldy #32
    sta (r_screen),y
    ldy #64
    sta (r_screen),y
    inx
    dec n_remaining
    bne @restore
@done:
    rts
sprite_dirty_add:
    ldx r_back
    lda r_dirty_counts,x
    cmp #127
    bcc :+
    inc r_fault
    rts
:   inc r_dirty_counts,x
    ldx p_count_index
    lda r_screen
    sta $3c00,x
    lda r_screen+1
    sta $3d00,x
    lda p_bg
    sta $3e00,x
    inc p_count_index
    rts

sprite_screen_address:
    ldx r_row
    lda native_row_lo,x
    clc
    adc r_column
    sta r_screen
    lda native_row_hi,x
    ldx r_back
    adc screen_buffer_hi,x
    sta r_screen+1
    rts
screen_buffer_hi: .byte $60,$70
sprite_font_address:
    sta r_temp
    asl a
    asl a
    asl a
    sta r_font
    lda r_temp
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc p_fontbase
    sta r_font+1
    rts
sprite_write_cell:
    ldy #0
    sta (r_screen),y
    ldy #32
    sta (r_screen),y
    ldy #64
    sta (r_screen),y
    rts
