#!/usr/bin/env python3
"""Build and retain both 512 KB cartridge variants from the shared source."""
import json, hashlib, os, shutil, subprocess, sys
from build import ROOT, BUILD

def main():
    release=ROOT/'release';release.mkdir(exist_ok=True)
    env=os.environ.copy();env.pop('FLICKY_BENCHMARK',None)
    results=[]
    for mode in ('ntsc','pal'):
        subprocess.run([sys.executable,str(ROOT/'tools/build_native.py'),'--prepared','--variant',mode],env=env,check=True)
        out=BUILD/'variants'/mode;out.mkdir(parents=True,exist_ok=True)
        for name in ('native.lbl','manifest.json'):shutil.copy2(BUILD/'native'/name,out/name)
        dest=release/f'Flicky-Atari-XL-{mode.upper()}-512K.car'
        shutil.copy2(BUILD/'native/flicky-native-dev.car',dest)
        data=dest.read_bytes()
        assert len(data)==524304 and data[:8]==b'CART\0\0\0\x38'
        assert int.from_bytes(data[8:12],'big')==sum(data[16:])&0xffffffff
        results.append({'filename':dest.name,'sha256':hashlib.sha256(data).hexdigest(),
            'rom_bytes':524288,'mapper':'SIC! 512 KB','mode':mode,
            'moving_prop_limit':6 if mode=='pal' else 1,'stress_fixture':False})
    # Preserve the published default filename as the NTSC build.
    shutil.copy2(release/'Flicky-Atari-XL-NTSC-512K.car',release/'Flicky-Prepared-Game.car')
    (release/'variants.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
