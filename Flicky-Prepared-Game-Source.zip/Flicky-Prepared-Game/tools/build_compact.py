#!/usr/bin/env python3
"""Build the 128 KB XEGS cartridge using the compact compatibility decoder."""
import subprocess,struct
from build import ROOT,BUILD,executable
from interpreter_tables import main as tables
from assets import main as assets
from hot_build import main as hot
from audio_pack import main as audio

def main():
    tables()
    hot()
    audio()
    if not (BUILD/"tile-index.bin").exists():assets()
    memory=['ZP:start=$80,size=$80,type=rw;','LZP:start=$20,size=$60,type=rw;','IRAM:start=$6000,size=$0C00,type=rw,file="";']
    segments=['ZEROPAGE:load=ZP,type=zp;','LOWZP:load=LZP,type=zp;']
    for b in range(15):
        if b==10:
            memory.append('M10:start=$8000,size=$1000,type=ro,file=%O,fill=yes,fillval=$FF;')
            memory.append('MI:start=$9000,size=$1000,type=ro,file=%O,fill=yes,fillval=$FF;')
            segments.append('INTERPRETER:load=MI,run=IRAM,type=ro;')
        else:
            memory.append(f'M{b}:start=$8000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;')
        segments.append(f'BANK{b}:load=M{b},type=ro,optional=yes;')
    memory+=['MF:start=$A000,size=$1FFA,type=ro,file=%O,fill=yes,fillval=$FF;','MV:start=$BFFA,size=6,type=ro,file=%O,fill=yes;']
    segments+=['FIXED:load=MF,type=ro,align=$100;','VECTORS:load=MV,type=ro;']
    (BUILD/'compact.cfg').write_text('MEMORY {\n'+'\n'.join(memory)+'\n}\nSEGMENTS {\n'+'\n'.join(segments)+'\n}\n')
    subprocess.run([executable('ca65'),'-D','COMPACT=1','-D','HYBRID=1','-I',str(ROOT/'src'),'-I',str(BUILD),str(ROOT/'src/game.s'),'-o',str(BUILD/'compact.o')],check=True)
    subprocess.run([executable('ld65'),'-C',str(BUILD/'compact.cfg'),str(BUILD/'compact.o'),'-o',str(BUILD/'compact.bin'),'-Ln',str(BUILD/'compact.lbl'),'-m',str(BUILD/'compact.map')],check=True)
    rom=bytearray((BUILD/'compact.bin').read_bytes());assert len(rom)==131072
    for bank,name in [(0,'maincpu-data.bin')]:
        data=(ROOT/'private-roms'/name).read_bytes();rom[bank*8192:bank*8192+len(data)]=data
    # The tail of bank 8 contains sound records, not tile-table padding.
    rom[8*8192:8*8192+0x1a00]=(BUILD/'tile-index.bin').read_bytes()[:0x1a00]
    glyphs=(BUILD/'tile-glyphs.bin').read_bytes()
    assert len(glyphs)<=0x2a00, 'Tile glyphs overlap reserved audio space'
    rom[9*8192:9*8192+len(glyphs)]=glyphs
    sprites=(ROOT/'private-roms/sprites.bin').read_bytes()
    rom[11*8192:15*8192]=sprites
    (BUILD/'flicky-compact.car').write_bytes(b'CART'+struct.pack('>III',14,sum(rom)&0xffffffff,0)+rom)
    print('Compact cartridge:',len(rom),'bytes')
if __name__=='__main__':main()
