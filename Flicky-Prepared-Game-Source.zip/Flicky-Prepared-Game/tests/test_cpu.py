"""Differential tests: NMOS 6502 output vs a separately authored Z80 core."""
import ctypes as C
from pathlib import Path
import random, subprocess, sys
import pytest
from py65.devices.mpu6502 import MPU

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from build import BUILD, PROGRAM, assemble
from translate import translate, Unsupported, decode

class Result(C.Structure):
    _fields_=[(x,C.c_uint8) for x in 'a f b c d e h l r'.split()]+[(x,C.c_uint16) for x in ['sp','pc']]+[('ticks',C.c_uint32)]

@pytest.fixture(scope='module')
def harness():
    subprocess.run([sys.executable,str(ROOT/'tools/build.py')],check=True,capture_output=True)
    subprocess.run(['gcc','-std=c11','-O2','-shared','-fPIC',str(ROOT/'tests/reference.c'),'-o',str(BUILD/'reference.so')],check=True)
    ref=C.CDLL(str(BUILD/'reference.so')).reference_run
    ref.argtypes=[C.POINTER(C.c_uint8),C.c_uint,C.POINTER(C.c_uint8),C.POINTER(Result),C.POINTER(Result),C.c_uint]
    labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (BUILD/'fixed.lbl').read_text().splitlines() if line.startswith('al ')}
    mem=[0]*65536
    mem[0xa000:0xc000]=(BUILD/'fixed.bin').read_bytes()
    m=MPU(memory=mem)
    return m,labels,ref

def call(m,labels,name,a=0,x=0):
    m.a,m.x,m.y,m.p,m.sp,m.pc=a,x,0,0x20,0xfd,labels[name]
    m.memory[0x1fe]=0xff
    m.memory[0x1ff]=1
    before=m.processorCycles
    for _ in range(100000):
        if m.pc==0x200: return m.processorCycles-before
        m.step()
    raise AssertionError(f'6502 routine {name} did not return (PC={m.pc:04X})')

def reference(ref,program,**state):
    memory=(C.c_uint8*65536)()
    src=(C.c_uint8*len(program))(*program)
    initial=Result(**state)
    out=Result()
    assert ref(src,len(program),memory,C.byref(initial),C.byref(out),100000)
    return out,memory

@pytest.mark.parametrize('kind',range(8))
def test_alu_against_independent_z80(harness,kind):
    m,labels,ref=harness
    rng=random.Random(5800+kind)
    cases=[(a,b,c) for a in range(256) for b in [0,1,15,16,127,128,255] for c in [0,1]]
    cases += [(rng.randrange(256),rng.randrange(256),rng.randrange(256)) for _ in range(500)]
    for a,b,f in cases:
        expected,_=reference(ref,bytes([0x80+kind*8,0x76]),a=a,b=b,f=f)
        m.memory[labels['z_a']]=a
        m.memory[labels['z_f']]=f
        m.memory[labels['z_operand']]=b
        call(m,labels,'z_alu',x=kind)
        assert (m.memory[labels['z_a']],m.memory[labels['z_f']])==(expected.a,expected.f),(kind,a,b,f)

@pytest.mark.parametrize('dec',[False,True])
def test_inc_dec_against_independent_z80(harness,dec):
    m,labels,ref=harness
    for n in range(256):
        for carry in [0,1]:
            expected,_=reference(ref,bytes([0x05 if dec else 0x04,0x76]),a=91,b=n,f=carry)
            m.memory[labels['z_f']]=carry
            m.memory[labels['z_a']]=91
            call(m,labels,'z_dec8' if dec else 'z_inc8',a=n)
            assert (m.a,m.memory[labels['z_f']],m.memory[labels['z_a']])==(expected.b,expected.f,91)

def test_translated_program_memory_branch_and_clock(harness):
    m,labels,ref=harness
    expected,mem=reference(ref,PROGRAM)
    call(m,labels,'z_reset')
    m.memory[labels['z_input']]=255
    cycles=call(m,labels,'guest_entry')
    for reg in 'a f b c d e h l'.split():
        assert m.memory[labels['z_'+reg]]==getattr(expected,reg),reg
    assert m.memory[0x4000:0x4200]==list(mem[0xc000:0xc200])
    assert m.memory[labels['z_output']]==31
    assert m.memory[labels['z_fault']]==0
    assert m.memory[labels['z_halted']]==1
    assert int.from_bytes(bytes(m.memory[labels['z_cycles']:labels['z_cycles']+4]),'little')==607
    assert int.from_bytes(bytes(m.memory[labels['z_m1']:labels['z_m1']+4]),'little')==74
    assert m.memory[labels['z_r']]==74
    (BUILD/'cpu-measurement.json').write_text(__import__('json').dumps({'guest_nominal_tstates':607,'guest_m1_fetches':74,'host_6502_cycles_no_DMA':cycles,'note':'Synthetic diagnostic, not game performance'},indent=2)+'\n')

def test_m1_and_cycle_wrap(harness):
    m,l,_=harness
    call(m,l,'z_reset')
    m.memory[l['z_r']]=255
    m.memory[l['z_m1']:l['z_m1']+4]=[255,255,255,0]
    call(m,l,'z_fetch')
    assert m.memory[l['z_r']]==128
    assert m.memory[l['z_m1']:l['z_m1']+4]==[0,0,0,1]
    m.memory[l['z_cycles']:l['z_cycles']+4]=[255,255,255,0]
    call(m,l,'z_tick',a=13)
    assert m.memory[l['z_cycles']:l['z_cycles']+4]==[12,0,0,1]

def test_guest_mmio_never_leaks_to_atari(harness):
    m,l,_=harness
    call(m,l,'z_reset')
    m.memory[l['z_addr']]=0
    m.memory[l['z_addr']+1]=0xd4
    m.memory[0xd400]=0x22
    call(m,l,'z_write',a=0xa5)
    assert m.memory[0x5400]==0xa5
    assert m.memory[0xd400]==0x22
    m.memory[l['z_addr']+1]=0xf0
    call(m,l,'z_write',a=3)
    assert m.memory[l['z_fault']]==1

def test_separate_operand_view():
    assert 'lda #$76' in translate(bytes([0x3e,0,0x76]),bytes([0,0x76,0]))

@pytest.mark.parametrize('program',[b'\xdd\x21\x00\xc0',b'\xed\xb0',b'\xcd\x00\x00',b'\x3e',b'\xc3\x01\x00'])
def test_incomplete_translation_fails_closed(program):
    with pytest.raises(Unsupported): translate(program)

def test_cart_container_and_only_mode4():
    import struct
    raw=(BUILD/'flicky-xl-stage1.car').read_bytes()
    assert len(raw)==131072+16 and raw[:4]==b'CART'
    assert struct.unpack('>III',raw[4:16])==(14,sum(raw[16:])&0xffffffff,0)
    source=(ROOT/'src/cart.s').read_text()
    # The assembled list is checked too, so an accidental opcode change fails.
    fixed=(BUILD/'fixed.bin').read_bytes()
    signature=bytes([0x70]*3+[0x44,0,0x24]+[4]*23+[0x41])
    assert fixed.count(signature)==1
    screen=(BUILD/'screen.bin').read_bytes()
    assert 126 in screen and 254 in screen
