; Prepared arcade attract animation. Gameplay is idle; fonts, PMG and raster
; programs have independent front/back buffers. All execution stays in RAM
; while the SIC upper cartridge window supplies animation data.
it_source=$30
it_destination=$32
it_dictionary=$34
it_history=$36
it_match=$38
it_flags=$3a
it_bits=$3b
it_remaining=$3c
it_chunk=$3d
it_stream_bank=$3e
it_back=$3f
it_ready=$40
it_finished=$41
it_last_tick=$42
it_frame=$43
it_late=$45
it_count=$47
it_value=$48
it_temp=$49
it_limit=$4a
it_front=$4b
it_gid=$4c
it_previous_gid=$4e
it_last_tick_high=$50
.export attract_init,attract_work,attract_nmi,it_frame,it_late,it_finished
.import __INTRO_LOAD__
.segment "FIXED"
attract_init:
    lda #16
    NATIVE_BANK
    jmp attract_load
.segment "BANK16"
attract_load:
    lda #0
    sta $d40e
    sta $d400
    lda #1
    sta c_paused
    lda #19
    sta l_bank
    lda #>__INTRO_LOAD__
    sta n_src+1
    lda #$10
    sta n_dst+1
    lda #10
    sta n_remaining
    lda #0
    sta n_src
    sta n_dst
    lda #128
    sta n_token
@half:
    jsr sic_read_block
    lda n_src
    eor #128
    sta n_src
    sta n_dst
    bne @half
    inc n_src+1
    inc n_dst+1
    dec n_remaining
    bne @half
    jmp attract_setup

.segment "INTRO"
attract_begin:
attract_work:
    jmp attract_work_impl
attract_nmi:
    ; Keep the DLI dispatch at the vector target: two extra JMPs consume
    ; six precious cycles before the final character-line WSYNC.
    sta $1b
    bit $d40f
    bpl attract_vbi
    jmp ($0051)
attract_vbi:
    jmp attract_nmi_impl
attract_setup:
    jmp attract_setup_impl

attract_setup_impl:
    lda #0
    ldx #21
@state:
    sta it_flags,x
    dex
    bpl @state
    sta it_source
    sta it_destination
    sta it_history
    lda #$e0
    sta it_history+1
    lda #$20
    sta it_destination+1
    ldx #96
    jsr attract_clear_pages
    lda #$0b
    sta it_destination+1
    ldx #5
    jsr attract_clear_pages
    lda #$c0
    sta it_destination+1
    ldx #16
    jsr attract_clear_pages
    lda #$db
    sta it_destination+1
    ldx #5
    jsr attract_clear_pages
    lda #$e0
    sta it_destination+1
    ldx #16
    jsr attract_clear_pages
    ldx #0
@lists:
    lda attract_dl0,x
    sta $6500,x
    lda attract_dl1,x
    sta $6580,x
    inx
    cpx #88
    bcc @lists
    lda #0
    ldx #3
@hardware:
    sta $d000,x
    sta $d004,x
    sta $d008,x
    dex
    bpl @hardware
    sta $d00c
    sta $d404
    sta r_pending
    lda #1
    sta u_mode
    sta result_active
    sta $d01b
    lda #3
    sta $d01d
    ldx #0
    jsr attract_select_chunk
    jsr attract_decode
    jsr attract_publish
    jsr attract_decode
    jsr attract_frame_setup
    lda #<attract_nmi
    sta $fffa
    lda #>attract_nmi
    sta $fffb
    lda c_produced
    sta c_consumed
    sta it_last_tick
    lda c_produced+1
    sta c_consumed+1
    sta it_last_tick_high
    ; Start the new display in vertical blank. Enabling DLIs in the middle of
    ; the old game list can deliver its final interrupt at line 247 and mask
    ; the following VBI, leaving the new raster chain two rows out of phase.
    lda #0
    sta $d40f
    lda #$40
    sta $d40e
@blank:
    bit $d40f
    bvc @blank
    lda #0
    sta c_paused
    lda #$3e
    sta $d400
    lda #$c0
    sta $d40e
    lda #16
    NATIVE_BANK
    rts

attract_clear_pages:
    lda #0
    ldy #0
@page:
    sta (it_destination),y
    iny
    bne @page
    inc it_destination+1
    dex
    bne @page
    rts

attract_work_impl:
    lda it_ready
    ora it_finished
    bne @done
    lda $061f
    pha
    lda it_stream_bank
    sta $061f
    sta $d500
    jsr attract_decode
    pla
    sta $061f
    sta $d500
@done:
    rts

attract_decode:
    lda it_frame+1
    cmp #>IT_FRAME_COUNT
    bne @command
    lda it_frame
    cmp #<IT_FRAME_COUNT
    bne @command
    lda #1
    sta it_finished
    rts
@command:
    jsr attract_byte
    bne :+
    inc it_frame
    bne @ready
    inc it_frame+1
@ready:
    lda #1
    sta it_ready
    rts
:
    cmp #255
    beq @fill
    sta it_count
    jsr attract_address
    lda it_count
    bmi @glyphs
@literal:
    jsr attract_byte
    ldy #0
    sta (it_destination),y
    inc it_destination
    bne :+
    inc it_destination+1
:
    dec it_count
    bne @literal
    jmp @command
@fill:
    jsr attract_byte
    sta it_count
    jsr attract_address
    jsr attract_byte
    sta it_value
@fill_byte:
    lda it_value
    ldy #0
    sta (it_destination),y
    inc it_destination
    bne :+
    inc it_destination+1
:
    dec it_count
    bne @fill_byte
    jmp @command
@glyphs:
    and #127
    sta it_count
@glyph:
    jsr attract_byte
    bmi @absolute_id
    cmp #64
    bcc @positive_id
    ora #128
    ldx #255
    bne @relative_id
@positive_id:
    ldx #0
@relative_id:
    clc
    adc it_previous_gid
    sta it_gid
    txa
    adc it_previous_gid+1
    sta it_gid+1
    jmp @have_id
@absolute_id:
    and #127
    sta it_gid
    jsr attract_byte
    lsr a
    sta it_gid+1
    bcc @have_id
    lda it_gid
    ora #128
    sta it_gid
@have_id:
    lda it_gid
    sta it_previous_gid
    lda it_gid+1
    sta it_previous_gid+1
    lsr a
    lsr a
    clc
    adc #20
    ora #$20
    sta $061f
    sta $d500
    lda it_gid
    asl a
    asl a
    asl a
    sta it_dictionary
    lda it_gid+1
    and #3
    asl a
    asl a
    asl a
    sta it_temp
    lda it_gid
    .repeat 5
        lsr a
    .endrepeat
    ora it_temp
    ora #$a0
    sta it_dictionary+1
    .repeat 8,I
        ldy #I
        lda (it_dictionary),y
        sta (it_destination),y
    .endrepeat
    lda it_stream_bank
    sta $061f
    sta $d500
    clc
    lda it_destination
    adc #8
    sta it_destination
    bcc :+
    inc it_destination+1
:
    dec it_count
    beq :+
    jmp @glyph
:
    jmp @command

attract_address:
    jsr attract_byte
    sta it_destination
    jsr attract_byte
    sta it_destination+1
    rts
attract_advance:
    inc it_destination
    bne :+
    inc it_destination+1
:   rts

; LZ history is a 4096-byte RAM ring. Matches are bounded to 3..18 bytes;
; source pages may span any of the prepared SIC bank fragments.
attract_byte:
    lda it_remaining
    bne @match
    lda it_bits
    bne @flag
    jsr attract_fetch
    sta it_flags
    lda #8
    sta it_bits
@flag:
    dec it_bits
    lsr it_flags
    bcc @reference
    jsr attract_fetch
    jmp @history
@reference:
    jsr attract_fetch
    sta it_match
    jsr attract_fetch
    pha
    and #15
    clc
    adc #3
    sta it_remaining
    pla
    .repeat 4
        lsr a
    .endrepeat
    sta it_match+1
    ; encoded distance is actual distance minus one.
    clc
    lda it_history
    sbc it_match
    sta it_match
    lda it_history+1
    sbc it_match+1
    and #15
    ora #$e0
    sta it_match+1
@match:
    ldy #0
    lda (it_match),y
    inc it_match
    bne :+
    inc it_match+1
    pha
    lda it_match+1
    and #15
    ora #$e0
    sta it_match+1
    pla
:
    dec it_remaining
@history:
    ldy #0
    sta (it_history),y
    inc it_history
    bne :+
    inc it_history+1
    pha
    lda it_history+1
    and #15
    ora #$e0
    sta it_history+1
    pla
:   ora #0
    rts

attract_fetch:
    ldy #0
    lda (it_source),y
    inc it_source
    bne @done
    inc it_source+1
    pha
    lda it_source+1
    cmp it_limit
    bne :+
    inc it_chunk
    ldx it_chunk
    jsr attract_select_chunk
:   pla
@done:
    rts
attract_select_chunk:
    lda it_stream_banks,x
    sta it_stream_bank
    sta $061f
    sta $d500
    lda it_stream_lo,x
    sta it_source
    lda it_stream_hi,x
    sta it_source+1
    lda it_stream_end,x
    sta it_limit
    rts

attract_nmi_impl:
    lda $061f
    sta $1c
    lda $d500
    sta $1a
    ora #$40
    sta $061f
    sta $d500
    lda $1b
    pha
    txa
    pha
    tya
    pha
    cld
    inc r_vbis
    inc r_host_frames
    bne :+
    inc r_host_frames+1
:
    sec
    lda c_produced
    sbc it_last_tick
    tax
    lda c_produced+1
    sbc it_last_tick_high
    bne @due
    txa
    cmp #4
    bcc @setup
@due:
    lda it_ready
    beq @setup
    lda it_last_tick
    clc
    adc #4
    sta it_last_tick
    bcc :+
    inc it_last_tick_high
:
    jsr attract_publish
@setup:
    jsr attract_frame_setup
    jmp display_read_input

attract_publish:
    lda it_back
    sta it_front
    eor #1
    sta it_back
    lda #0
    sta it_ready
    rts

attract_frame_setup:
    ldx it_front
    lda attract_dl_low,x
    sta $d402
    lda #$65
    sta $d403
    lda attract_font_high,x
    sta $d409
    lda attract_pmg_high,x
    sta $d407
    lda #0
    sta $51
    sta $1d
    lda attract_raster_high,x
    sta $52
    ora #7
    sta $1e
    ldx #0
    ldy #0
@players:
    lda ($1d),y
    sta $d012,x
    iny
    lda ($1d),y
    sta $d000,x
    iny
    inx
    cpx #4
    bcc @players
.if PAL_MULTI_PROP
    lda #$84
.else
    lda #$94
.endif
    sta $d01a
    lda #$0e
    sta $d016
    lda #0
    sta $d017
.if PAL_MULTI_PROP
    lda #$4c
.else
    lda #$5c
.endif
    sta $d018
.if PAL_MULTI_PROP
    lda #$ee
.else
    lda #$2e
.endif
    sta $d019
    rts

attract_dl_low: .byte $00,$80
attract_font_high: .byte $20,$40
attract_pmg_high: .byte $08,$d8
attract_raster_high: .byte $c0,$c8
.macro ATTRACT_DL screen,self
    ; One blank row places all 224 artwork lines inside the NTSC viewport.
    .byte $70
    .repeat 28,I
        .byte $44 | ((I<27)*$80)
        .word screen+I*40
    .endrepeat
    .byte $41
    .word self
.endmacro
attract_dl0: ATTRACT_DL $6000,$6500
attract_dl1: ATTRACT_DL $7000,$6580
.include "attract-data.s"
.segment "INTRO"
    .res $a00-(*-attract_begin),0
