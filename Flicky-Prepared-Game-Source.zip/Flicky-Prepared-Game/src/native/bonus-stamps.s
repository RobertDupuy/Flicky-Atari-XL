; Exact arcade bird columns, composed into the current band's shared pool.
.segment "FIXED"
bonus_stamp:
    lda #31
    NATIVE_BANK
    jsr bonus_stamp_bank
    lda #28
    NATIVE_BANK
    rts
.segment "BANK31"
bonus_stamp_bank:
    lda b_art
    asl a
    asl a
    sta p_index
    lda p_left
    lsr a
    lsr a
    and #3
    ora p_index
    tax
    lda ab_strip_lo,x
    sta p_image
    lda ab_strip_hi,x
    sta p_image+1
    txa
    sta p_index
    lda p_y
    and #7
    sta p_source_row
    .repeat 5
        asl a
    .endrepeat
    ora p_index
    tax
    lda ab_strip_flags,x
    sta p_block
    lda p_source_row
    eor #7
    sta p_source_row
    lda p_y
    lsr a
    lsr a
    lsr a
    sta r_row
    lda p_left+1
    lsr a
    lda p_left
    ror a
    lsr a
    lsr a
    lsr a
    sta p_index
@row:
    lda r_row
    cmp #28
    bcc :+
    rts
:   lsr a
    lsr a
    sta r_band_index
    clc
    adc #$ec
    sta p_negative_mask+1
    lda #0
    sta p_negative_mask
    lda r_band_index
    asl a
    asl a
    clc
    adc #$20
    ldx r_back
    beq :+
    adc #$20
:   sta p_fontbase
    ldx r_row
    lda native_row_lo,x
    clc
    adc p_index
    sta r_screen
    lda native_row_hi,x
    adc #$60
    ldx r_back
    beq :+
    adc #$10
:   sta r_screen+1
    lda p_image
    clc
    adc p_source_row
    sta n_ptr
    lda p_image+1
    adc #0
    sta n_ptr+1
    lda #2
    sta p_slot
@cell:
    lsr p_block
    bcs :+
    jmp @next
:   clc
    lda n_ptr
    adc #26
    sta n_src
    lda n_ptr+1
    adc #0
    sta n_src+1
    ldy #0
    lda (r_screen),y
    sta p_bg
    and #127
    sta p_code
    jsr fast_font_address
    lda r_font
    sta p_fontold
    lda r_font+1
    sta p_fontold+1
    lda p_code
    cmp #64
    bcs @composite
    jsr sprite_dirty_add
    ldx r_band_index
    lda r_next_glyph,x
    cmp #128
    bcc :+
    inc r_fault
    jmp @next
:   inc r_next_glyph,x
    sta p_code
    jsr fast_font_address
@composite:
    lda p_bg
    and #127
    cmp #64
    bcs @masked
    tay
    lda (p_negative_mask),y
    bpl @masked
    ldy #0
    .repeat 8,I
        lda (n_src),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
    jmp @write
@masked:
    lda p_bg
    bmi @gold
    ldy #0
    .repeat 8,I
        lda (p_fontold),y
        tax
        lda $f600,x
        and (n_ptr),y
        ora (n_src),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
    jmp @write
@gold:
    ldy #0
    .repeat 8,I
        lda (p_fontold),y
        and (n_ptr),y
        ora (n_src),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
@write:
    lda p_code
    ora #128
    ldy #0
    sta (r_screen),y
    ldy #32
    sta (r_screen),y
    ldy #64
    sta (r_screen),y
@next:
    clc
    lda n_ptr
    adc #52
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   lda p_index
    cmp #31
    bne :+
    lsr p_block
    lda #1
    sta p_slot
:   inc r_screen
    dec p_slot
    beq :+
    jmp @cell
:   inc r_row
    lda p_source_row
    clc
    adc #8
    sta p_source_row
    lda p_block
    beq :+
    jmp @row
:   rts
