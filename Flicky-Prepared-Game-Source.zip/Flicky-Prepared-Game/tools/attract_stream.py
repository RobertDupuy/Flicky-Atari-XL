"""Build a native two-buffer cinematic, shared glyphs and bounded LZ stream."""
from collections import defaultdict,deque
import json
import numpy as np
from build import BUILD
from attract_palette import (row_palette,display_palette,sky_color,gradient_row,
    raster_row_size,ntsc_color,PMG_ORIGIN,GRADIENT_BASE,GRADIENT_STRIDE)

def lz(data):
    data=bytes(data)
    positions=defaultdict(deque);out=bytearray();p=0
    while p<len(data):
        flagpos=len(out);out.append(0);flags=0
        for bit in range(8):
            if p==len(data):break
            key=data[p:p+3];q=positions[key]
            while q and p-q[0]>4096:q.popleft()
            best=0;distance=0
            for prev in reversed(q):
                n=3
                while n<18 and p+n<len(data) and data[prev+n]==data[p+n]:n+=1
                if n>best:best=n;distance=p-prev
                if best==18:break
            if best>=3:
                d=distance-1;out+=bytes([d&255,((d>>8)<<4)|(best-3)]);count=best
            else:flags|=1<<bit;out.append(data[p]);count=1
            for i in range(p,p+count):positions[data[i:i+3]].append(i)
            p+=count
        out[flagpos]=flags
    return bytes(out)

def unlz(data,length):
    out=bytearray();p=0
    while len(out)<length:
        flags=data[p];p+=1
        for bit in range(8):
            if len(out)==length:break
            if flags>>bit&1:out.append(data[p]);p+=1
            else:
                lo,hi=data[p:p+2];p+=2;d=1+lo+((hi>>4)<<8)
                for _ in range((hi&15)+3):out.append(out[-d])
    assert p==len(data)
    return bytes(out)

def byte_patches(old,new):
    changed=np.flatnonzero(old!=new);out=bytearray();i=0
    while i<len(changed):
        start=int(changed[i]);end=start+1;i+=1
        while i<len(changed) and changed[i]-end<4 and changed[i]-start<127:
            end=int(changed[i])+1;i+=1
        data=bytes(new[start:end])
        if len(data)>=4 and len(set(data))==1:out+=bytes([255,len(data),start&255,start>>8,data[0]])
        else:out+=bytes([len(data),start&255,start>>8])+data
    return out

def raster(mux,back,mode,pmg=None):
    base=0xc000+back*2048;offset=0;out=bytearray(2048)
    for row in range(1,28):
        size=raster_row_size(row)
        code=bytearray();last_value=None
        def store(address,value):
            nonlocal last_value
            if value!=last_value:code.extend([0xa9,value]);last_value=value
            code.extend([0x8d,address&255,address>>8])
        changes=[]
        for player,(x,color) in enumerate(mux[row]):
            ox,oc=mux[row-1,player];writes=[]
            if color!=oc:writes.append((0xd012+player,ntsc_color(int(color))if mode=='ntsc'else int(color)))
            if x!=ox:writes.append((0xd000+player,int(x)))
            changes.append((player,writes))
        # A player with no pixels on the preceding last scanline can safely
        # be configured before WSYNC. This avoids ANTIC's 80-DMA-cycle first
        # character line while preserving every pixel of the preceding row.
        early=set();budget=2
        if pmg is not None:
            for player,writes in changes:
                if writes and len(writes)<=budget and not pmg[player,PMG_ORIGIN+row*8-1] and pmg[player,PMG_ORIGIN+row*8]:
                    for address,value in writes:store(address,value)
                    budget-=len(writes);early.add(player)
        code.extend([0x8d,0x0a,0xd4]) # WSYNC
        if row%4==0:store(0xd409,0x20+back*0x20+(row//4)*4)
        for address,value,old in zip((0xd01a,0xd016,0xd017,0xd018,0xd019),display_palette(row*8,mode),display_palette(row*8-1,mode)):
            if value!=old:store(address,value)
        # Changes for invisible first scanlines may run after live players.
        if pmg is not None:
            changes.sort(key=lambda item:(not bool(pmg[item[0],PMG_ORIGIN+row*8]),int(mux[row,item[0],0])))
        for player,writes in changes:
            if player not in early:
                for address,value in writes:store(address,value)
        nxt=base+offset+size
        code.extend([0xa9,nxt&255,0x85,0x51,0xa9,nxt>>8,0x85,0x52])
        if gradient_row(row):
            address=GRADIENT_BASE+(row-1)*GRADIENT_STRIDE
            code.extend([0x4c,address&255,address>>8])
        else:code.extend([0xa5,0x1b,0x40])
        assert len(code)<=size,(row,len(code),size)
        out[offset:offset+len(code)]=code;offset+=size
    assert offset<2048
    return out

def build(out,mode):
    art=np.load(out/'attract-pixels.npz');pixels=art['pixels'];pmg=art['pmg'];mux=art['mux']
    cache=[[{} for _ in range(7)] for _ in range(2)]
    previous=[np.zeros(65536,dtype=np.uint8) for _ in range(2)]
    dictionary={bytes(8):0};stream=bytearray();sizes=[];max_patterns=0;last_id=0
    for f,pix in enumerate(pixels):
        back=f&1;mem=previous[back].copy();font=0x2000+back*8192;screen=0x6000+back*4096
        for band in range(7):
            cells=[]
            for row in range(band*4,band*4+4):
                for col in range(40):
                    a=pix[row*8:row*8+8,col*4:col*4+4];inverse=128 if np.any(a==4) else 0
                    a=np.where(a==4,3,a)
                    g=np.sum(a*np.array([64,16,4,1]),axis=1).astype(np.uint8).tobytes()
                    cells.append((g,inverse))
            needed=set(g for g,_ in cells);max_patterns=max(max_patterns,len(needed));assert len(needed)<=128
            old=cache[back][band];new={g:slot for g,slot in old.items() if g in needed}
            free=[x for x in range(128) if x not in new.values()]
            for g in dict.fromkeys(g for g,_ in cells):
                if g not in new:new[g]=free.pop(0)
            cache[back][band]=new
            for g,slot in new.items():mem[font+band*1024+slot*8:font+band*1024+slot*8+8]=np.frombuffer(g,dtype=np.uint8)
            mem[screen+band*160:screen+band*160+160]=[new[g]|inverse for g,inverse in cells]
        pm=0x0c00 if back==0 else 0xdc00;mem[pm:pm+1024]=pmg[f].flatten()
        dl=0xc000+back*2048
        # Each frame contains a compact raster program that writes only the
        # registers that change. It never repeats eight unnecessary stores
        # on ANTIC's expensive first character scanline.
        mem[dl:dl+2048]=np.frombuffer(raster(mux[f],back,mode,pmg[f]),dtype=np.uint8)
        table=mux[f,:,:,::-1].copy()
        if mode=='ntsc':
            table[:,:,0]=np.array([ntsc_color(int(c))for c in table[:,:,0].flatten()],np.uint8).reshape(28,4)
        # Only the first band's registers are needed by VBI; subsequent
        # bands are already represented by the exact raster program.
        mem[dl+0x700:dl+0x708]=table[0].flatten()
        old=previous[back].copy();begin=len(stream)
        addresses=[a for a in range(font,font+7168,8) if not np.array_equal(old[a:a+8],mem[a:a+8])]
        i=0
        while i<len(addresses):
            start=addresses[i];end=i+1
            while end<len(addresses) and addresses[end]==addresses[end-1]+8 and end-i<126:end+=1
            stream+=bytes([128+end-i,start&255,start>>8])
            for a in addresses[i:end]:
                g=bytes(mem[a:a+8])
                if g not in dictionary:dictionary[g]=len(dictionary)
                identifier=dictionary[g];delta=identifier-last_id
                if -64<=delta<=63:stream.append(delta&127)
                else:stream+=bytes([128|(identifier&127),identifier>>7])
                last_id=identifier
            i=end
        old[font:font+7168]=mem[font:font+7168]
        stream+=byte_patches(old,mem)+bytes(1);sizes.append(len(stream)-begin);previous[back]=mem
    glyphs=b''.join(dictionary)
    assert len(glyphs)<=8*8192,('Intro glyph dictionary allocation',len(glyphs))
    encoded=lz(stream);assert unlz(encoded,len(stream))==stream
    print('Animation bytes:',len(glyphs),'glyphs;',len(stream),'commands;',len(encoded),'compressed',flush=True)
    lines=[]
    for i in range((len(glyphs)+8191)//8192):
        name=f'attract-glyphs-{i}.bin';(out/name).write_bytes(glyphs[i*8192:(i+1)*8192])
        lines += [f'.segment "UPPER{20+i}"',f'.incbin "{name}"']
    # Space budgets include alignment and leave room for current native code.
    regions=[('UPPER'+str(i),8192) for i in range(28,32)]
    regions += [('UPPER19',5632),('UPPER18',5632),('UPPER9',8192),('UPPER8',3072),
                ('UPPER1',3072),('UPPER2',3072),('UPPER3',1024),('UPPER17',1024),
                ('BANK20',8192),('BANK7',3584),('BANK9',3584),('BANK15',3072),
                ('BANK30',3072),('BANK31',3840),('BANK27',4864),('BANK6',3072),
                ('BANK2',3840),('BANK3',1792),('BANK19',2048),('BANK26',2816),('UPPER16',6144),
                ('BANK24',5120),('BANK28',1792)]
    last_dictionary_bank=20+(len(glyphs)-1)//8192
    regions.extend((f'UPPER{i}',8192)for i in range(last_dictionary_bank+1,28))
    spare=(8192-((len(glyphs)-1)%8192+1))//256*256
    if spare:regions.append((f'UPPER{last_dictionary_bank}',spare))
    cursor=0;selectors=[];names=[];lengths=[]
    for region,capacity in regions:
        if cursor==len(encoded):break
        data=encoded[cursor:cursor+capacity];cursor+=len(data)
        data+=bytes((-len(data))%256)
        name=f'attract-stream-{len(names):02d}.bin';(out/name).write_bytes(data)
        label=f'it_stream_{len(names)}';names.append(label);lengths.append(len(data))
        selectors.append((0x20 if region.startswith('UPPER') else 0x60)|int(region.lstrip('UPPERBANK')))
        lines += [f'.segment "{region}"','.align 256',f'{label}: .incbin "{name}"']
    assert cursor==len(encoded),('Animation stream does not fit',len(encoded),cursor)
    lines+=['.segment "INTRO"','it_stream_banks: .byte '+','.join(map(str,selectors)),
            'it_stream_lo: .lobytes '+','.join(names),'it_stream_hi: .hibytes '+','.join(names),
            'it_stream_end: .byte '+','.join(f'>({n}+{size})' for n,size in zip(names,lengths)),
            f'IT_FRAME_COUNT = {len(pixels)}']
    lines += [f'IT_INITIAL_BG = {display_palette(0,mode)[0]}',
              f'IT_BALLOON_COLOR = {display_palette(0,mode)[3]}']
    (out/'attract-data.s').write_text('\n'.join(lines)+'\n')
    gradient=['.segment "INTRO"',f'.res ${GRADIENT_BASE-0x1000:04x}-(*-attract_begin),0']
    for row in range(1,18):
        gradient += [f'it_gradient_{row}:',f'.assert *=${GRADIENT_BASE+(row-1)*GRADIENT_STRIDE:04x},error,"Sky gradient entry moved"',
            'stx $1f',f'ldx #{(PMG_ORIGIN+row*8+2)//2}',
            ': cpx $d40b','bne :-',f'ldx #{row}','jmp it_gradient_lines']
    gradient += ['it_gradient_lines:']
    for line in range(3,7):
        gradient += ['sta $d40a',f'lda it_sky_line_{line},x','sta $d01a']
    gradient += ['ldx $1f','lda $1b','rti']
    for line in range(3,7):
        gradient += [f'it_sky_line_{line}: .byte '+','.join(str(display_palette(row*8+line,mode)[0])for row in range(18))]
    (out/'attract-gradient.s').write_text('\n'.join(gradient)+'\n')
    report=dict(frames=len(pixels),source_frames=[int(art['times'][0]),int(art['times'][-1])],
        arcade_ticks_per_frame=4,display_color_pixels=[160,224],glyph_bytes=len(glyphs),
        command_bytes=len(stream),compressed_command_bytes=len(encoded),maximum_frame_commands=max(sizes),
        maximum_patterns_in_font=max_patterns,hardware_players=4,player_multiplex_rows=8,
        scenery_palette_changes=[144,184],sky_blend_ranges=[[24,55]],
        sky_colors=sorted(set(display_palette(y,mode)[0]for y in range(144))),
        scanline_blended_sky=True,mountains='blue',
        pmg_scanline_origin=PMG_ORIGIN,variant=mode,old_title_removed=True,source='MAME original track with approved native-scale actors')
    (out/'attract-art.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Attract:',report,flush=True)

if __name__=='__main__':build(BUILD/'native','pal')
