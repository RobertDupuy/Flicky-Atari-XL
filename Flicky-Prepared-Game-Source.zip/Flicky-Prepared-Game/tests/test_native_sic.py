"""Real SIC bootstrap and interrupted upper-ROM transfers, without shortcuts."""
import subprocess
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    return Engine()

def test_native_sic_boot_copies_common_kernel_to_underlying_ram(native):
    rom=(BUILD/'native/flicky-native-dev.car').read_bytes()
    assert len(rom)==524304 and int.from_bytes(rom[4:8],'big')==native.cart_type
    base=0x8000 if native.cart_type==110 else 0xa000
    offset=16 if native.cart_type==110 else 16+8192
    assert bytes(native.ram[base:base+8192])==rom[offset:offset+8192]
    assert native.lib.at_cart_control()==native.ram[0x061f]
    assert native.lib.at_cart_control()==(33 if native.cart_type==110 else 0x70)
    load=native.labels['__HIGHRAM_LOAD__']
    length=native.labels['__HIGHRAM_SIZE__']
    start=16+(31*8192+load-0xa000 if native.cart_type==110 else 15*16384+load-0x8000)
    assert bytes(native.ram[0xf800:0xf800+length])==rom[start:start+length]
    # Boot also prepares both cinematic buffers before enabling ANTIC.
    assert native.boot_cycles<3_000_000

def test_native_sic_upper_glyph_copy_survives_nmi_at_every_cycle(native):
    rom=(BUILD/'native/flicky-native-dev.car').read_bytes()[16:]
    base=0x8000 if native.cart_type==110 else 0xa000
    kernel=bytes(native.ram[base:base+8192])
    native.set('i_bank',0x81)
    native.set('i_glyph',0x40);native.set('i_glyph',0xa0,1)
    native.set('r_font',0);native.set('r_font',0x3f,1)
    offset=2*8192 if native.cart_type==110 else 3*8192
    expected=rom[offset+64:offset+72]
    # Sweep every cycle of the copy, including either side of mapper/shadow
    # stores. Each NMI can also use POKEY's separately banked stream data.
    for delay in range(1,190):
        native.ram[0x3f00:0x3f08]=0
        native.lib.at_force_nmi(delay)
        native.call('sic_read_glyph')
        if delay>120:
            # Ensure a later armed interrupt is consumed before the next case.
            native.call('native_reset')
        assert bytes(native.ram[0x3f00:0x3f08])==expected,delay
        assert native.lib.at_cart_control()==native.ram[0x061f]==(13 if native.cart_type==110 else 0x66),delay
        assert bytes(native.ram[base:base+8192])==kernel,delay
