#!/usr/bin/env python3
"""Package the reproducible personal development tree without tool binaries."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def main():
    destination = ROOT.parent / 'Flicky-XL-Development-Checkpoint.zip'
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source in sorted(ROOT.rglob('*')):
            relative = source.relative_to(ROOT)
            if not source.is_file() or any(p in ('__pycache__', '.pytest_cache', '.git') for p in relative.parts):
                continue
            if source.suffix in ('.o', '.so', '.pyc'):
                continue
            archive.write(source, Path('flicky-xl') / relative)
    print(destination, destination.stat().st_size)

if __name__ == '__main__':
    main()
