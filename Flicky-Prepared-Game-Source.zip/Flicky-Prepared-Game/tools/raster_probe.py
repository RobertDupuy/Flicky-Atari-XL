#!/usr/bin/env python3
"""Check real ANTIC font-boundary timing with a diagnostic screen in Atari800.

The monitor freezes foreground code and installs diagnostic RAM, never changes
the cartridge. Every font band has a distinct scanline signature. A late DLI
therefore produces an objectively wrong scanline, including at the HUD edge.
"""
import argparse, os, subprocess, time, json, secrets
from pathlib import Path
import numpy as np
from PIL import Image
from Xlib import X, XK, display
from Xlib.ext import xtest
from build import ROOT, BUILD, executable

class Session:
    def __init__(self, cartridge, out, mode='ntsc', sound=False, video_name='capture.avi'):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.env=os.environ.copy()
        self.env['LD_LIBRARY_PATH']=str(ROOT.parent/'toolchain/root/usr/lib/x86_64-linux-gnu')
        number=1000+secrets.randbelow(40000)
        while Path(f'/tmp/.X{number}-lock').exists():number+=1
        self.env.update(DISPLAY=f'127.0.0.1:{number}',SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy')
        self.log=(self.out/'emulator.log').open('w')
        self.xlog=(self.out/'xvfb.log').open('w')
        self.xvfb=subprocess.Popen([executable('Xvfb'),f':{number}','-screen','0','900x700x24','-ac','-nolisten','unix','-nolisten','local','-listen','tcp'],env=self.env,stdout=self.xlog,stderr=self.xlog)
        time.sleep(.6)
        if self.xvfb.poll() is not None:
            raise RuntimeError('Xvfb failed: '+(self.out/'xvfb.log').read_text())
        self.d=display.Display(self.env['DISPLAY'])
        self.emu=subprocess.Popen([executable('atari800'),'-config',str(ROOT/'tools/atari800.cfg'),'-xl','-xl-rev','altirra','-nobasic','-'+mode,'-sound' if sound else '-nosound','-windowed','-no-video-accel','-stretch','2','-scanlines','0','-no-showstats','-vcodec','zmbv','-acodec','pcm','-vname',str(self.out/video_name),'-cart',str(cartridge)],env=self.env,stdin=subprocess.PIPE,stdout=self.log,stderr=self.log)
        time.sleep(2)
        self.w=next(w for w in self.d.screen().root.query_tree().children if 'Atari' in (w.get_wm_name()or''))
        self.w.set_input_focus(X.RevertToParent,X.CurrentTime);self.d.sync()
    def key(self,name,down):
        xtest.fake_input(self.d,X.KeyPress if down else X.KeyRelease,self.d.keysym_to_keycode(XK.string_to_keysym(name)));self.d.sync()
    def tap(self,name):
        self.key(name,True);time.sleep(.06);self.key(name,False)
    def record(self):
        self.key('Alt_L',True);self.tap('v');self.key('Alt_L',False)
    def capture(self):
        self.w=next(w for w in self.d.screen().root.query_tree().children if 'Atari' in (w.get_wm_name()or''))
        g=self.w.get_geometry();data=self.w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff)
        return Image.frombytes('RGB',(g.width,g.height),data.data,'raw','BGRX')
    def monitor(self,commands,resume=True):
        self.tap('F8');time.sleep(.1)
        self.emu.stdin.write(('\n'.join(commands+(['cont']if resume else []))+'\n').encode());self.emu.stdin.flush();time.sleep(.2)
    def close(self):
        if self.emu.poll()is None:
            self.emu.terminate()
            try:self.emu.wait(timeout=2)
            except subprocess.TimeoutExpired:self.emu.kill();self.emu.wait(timeout=2)
        self.d.close();self.xvfb.terminate();self.xvfb.wait(timeout=5)
        self.log.close();self.xlog.close()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--cartridge',type=Path,default=BUILD/'native/flicky-native-dev.car');ap.add_argument('--output',type=Path,default=BUILD/'native/raster-probe');ap.add_argument('--check',action='store_true');args=ap.parse_args()
    report={}
    for mode in ('ntsc','pal'):
        s=Session(args.cartridge,args.output/mode,mode)
        try:
            s.tap('Control_R');time.sleep(1.5)
            commands=['c 05f0 4c f0 05','c 0640 00 01 00','c 06e0 00','c d000 00 00 00 00 00 00 00 00']
            # Character zero is constant inside each band, alternating inks.
            for bank in (0x2000,0x4000):
                for band in range(7):
                    value=(0x55,0xaa,0xff)[band%3]
                    commands.append(f'c {bank+band*1024:04x} '+' '.join([f'{value:02x}']*8))
            commands.append('c e000 00 00 00 00 00 00 00 00')
            for base,size in ((0x1f00,64),(0x6000,28*96),(0x7000,28*96)):
                for a in range(base,base+size,16):commands.append(f'c {a:04x} '+'00 '*16)
            commands.append('cont 05f0')
            s.monitor(commands,resume=False);time.sleep(.5)
            frame=s.capture();frame.save(args.output/mode/'bands.png')
            a=np.asarray(frame);x=a.shape[1]//2
            # Store the exact vertical runs, rather than guessing TV crop offsets.
            runs=[];start=0
            for y in range(1,a.shape[0]+1):
                if y==a.shape[0]or not np.array_equal(a[y,x],a[start,x]):
                    runs.append({'y':start,'height':y-start,'rgb':a[start,x].tolist()});start=y
            report[mode]={'height':a.shape[0],'runs':runs}
            expected=[48,80,144,208,272,336,400] if mode=='ntsc' else [64,96,160,224,288,352,416]
            report[mode]['expected_band_starts']=expected
            report[mode]['correct_band_boundaries']=[r['y']for r in runs[1:]]==expected
            s.monitor(['antic','m 0640','quit'],resume=False);s.emu.wait(timeout=5)
            print(mode,json.dumps(report[mode]),flush=True)
        finally:s.close()
    (args.output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    if args.check:assert all(r['correct_band_boundaries']for r in report.values()),report
if __name__=='__main__':main()
