; Native artwork lookup uses full source coordinates for contacts and a
; separate ANTIC projection for display. X is a chick index, 0..7.
.segment "FIXED"
.export chick_prepare,chick_terrain_contact,sprite_draw_chick,sprite_draw_chicks
.export chick_contacts,n_idle_clear,n_idle_xlo,n_idle_xhi,n_idle_y
chick_contacts:
    lda #0
    sta n_actor_cursor
@loop:
    ldx n_actor_cursor
    lda n_flags,x
    bpl @next
    lda n_chick_contact,x
    bne @next
    lda n_chick_state,x
    and #3
    bne @test
    lda n_idle_clear
    and pickup_bits,x
    beq @test
    lda n_xlo,x
    cmp n_idle_xlo,x
    bne @test
    lda n_xhi,x
    and #1
    cmp n_idle_xhi,x
    bne @test
    lda n_ylo,x
    cmp n_idle_y,x
    bne @test
    lda n_animation,x
    cmp #5
    beq @next
    cmp #6
    beq @next
@test:
    jsr chick_terrain_contact
@next:
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #8
    bcc @loop
    rts
chick_prepare:
    stx p_actor
    lda #1
    sta p_visible
    ldy n_animation,x
    lda native_chick_radius,y
    sta p_sprite_width
    lda native_chick_height,y
    sta p_height
    lsr a
    sta n_step
    lda n_ylo,x
    clc
    adc n_draw_yoffset,x
    sec
    sbc n_step
    clc
    adc #1
    sta p_y
    clc
    adc p_height
    bcc :+
    lda #0
    sta p_visible
:   clc
    lda n_xlo,x
    adc n_world
    sta p_screen
    lda n_xhi,x
    adc n_world+1
    sta p_screen+1
    sec
    lda p_screen
    sbc native_chick_radius,y
    sta p_screen
    lda p_screen+1
    sbc #0
    and #1
    sta p_screen+1
    beq @full_width
    lda p_screen
    cmp #208
    bcc @full_width
    eor #$ff
    clc
    adc #2
    lsr a
    jmp @clip
@full_width:
    lda #24
@clip:
    sta p_clip_count
    sec
    lda p_screen
    sbc n_world
    sta p_left
    lda p_screen+1
    sbc n_world+1
    sta p_left+1
    jsr sprite_mask_prefix
    lda p_clip_count
    clc
    adc #1
    lsr a
    sta n_step
    lda p_left
    lsr a
    lsr a
    and #3
    sta p_index
    clc
    adc n_step
    asl a
    tax
    lda native_prefix0,x
    sta p_draw_clip
    lda native_prefix1,x
    sta p_draw_clip+1
    lda native_prefix2,x
    sta p_draw_clip+2
    lda native_prefix3,x
    sta p_draw_clip+3
    ldx p_actor
    lda n_animation,x
    asl a
    asl a
    asl a
    asl a
    ora p_index
    sta p_index
    lda n_frame,x
    and #1
    asl a
    asl a
    asl a
    ora p_index
    sta p_index
    lda n_flags,x
    and #1
    asl a
    asl a
    ora p_index
    tax
    lda #5
    NATIVE_BANK
    lda native_chick_image_lo,x
    sta p_image
    lda native_chick_image_hi,x
    sta p_image+1
    lda native_chick_image_bank,x
    sta p_imagebank
    lda p_left
    and #2
    bne @odd
    lda native_chick_mask_lo0,x
    sta p_mask
    lda native_chick_mask_hi0,x
    sta p_mask+1
    lda native_chick_mask_bank0,x
    sta p_maskbank
    rts
@odd:
    lda native_chick_mask_lo1,x
    sta p_mask
    lda native_chick_mask_hi1,x
    sta p_mask+1
    lda native_chick_mask_bank1,x
    sta p_maskbank
    rts

chick_terrain_contact:
    jsr chick_prepare
    jsr sprite_terrain_cached
    ldx p_actor
    ora n_chick_contact,x
    sta n_chick_contact,x
    rts
sprite_draw_chick:
    jsr chick_prepare
    jmp sprite_draw_prepared
sprite_draw_chicks:
    lda #0
    sta n_actor_cursor
@loop:
    ldx n_actor_cursor
    lda n_flags,x
    bpl @next
    lda i_active
    and pickup_bits,x
    bne @next
    jsr sprite_draw_chick
@next:
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #8
    bcc @loop
    rts
