"""Build four-character stamps for all fifteen props, rotations and alignments."""
import json
from pathlib import Path

def build(out:Path):
    d=json.loads((out/'object-assets.json').read_text());frames=[];ids={};indices=[]
    for py in (0,2,4,6):
        row=[]
        for idx,image in enumerate(d['images']):
            meta=d['records'][idx];raw=(out/f'object-pixels-{image:03d}.bin').read_bytes();h,w=raw[:2]
            # Width-six and height-twelve prop poses are reduced once, offline.
            phase=meta['phase'];sw=(meta['width']+1)//2;ow=min(5,sw);oh=min(h,10)
            pixels=[]
            for oy in range(oh):
                sy=round(oy*(h-1)/max(1,oh-1));r=[]
                for ox in range(ow):
                    sx=phase+round(ox*(sw-1)/max(1,ow-1))
                    r.append(raw[4+2*(sy*w+sx//4)]>>(6-2*(sx&3))&3)
                pixels.append([0]*phase+r+[0]*(8-phase-ow))
            glyph=[]
            for cy in range(2):
                for cx in range(2):
                    for sy in range(8):
                        y=cy*8+sy-py
                        glyph.append(sum(pixels[y][cx*4+x]<<(6-2*x) for x in range(4)) if 0<=y<oh else 0)
            b=bytes(glyph)
            if b not in ids:ids[b]=len(frames);frames.append(b)
            row.append(ids[b])
        indices.append(row)
    lines=[];banks=[];regions=[2,6,7,19,20,21,22,23,24,25,26,27];region=0;bank=regions[region];used=0
    for i,b in enumerate(frames):
        if used+len(b)>8192:region+=1;bank=regions[region];used=0
        used+=len(b);banks.append(bank)
        lines += [f'.segment "BANK{bank}"',f'obj_stamp_{i}:','.byte '+','.join(map(str,b))]
    dir_banks=[]
    for py,row in enumerate(indices):
        db=28 if py<3 else 29;dir_banks.append(db)
        lines += [f'.segment "BANK{db}"',f'obj_dir_{py}:']
        for i in row:lines+=[f'.word obj_stamp_{i}',f'.byte {banks[i]}']
    lines+=['.segment "FIXED"','obj_dir_lo:','.lobytes '+','.join(f'obj_dir_{i}'for i in range(4)),
            'obj_dir_hi:','.hibytes '+','.join(f'obj_dir_{i}'for i in range(4)),
            'obj_dir_bank:','.byte '+','.join(map(str,dir_banks)),
            'obj_kind_index:','.byte '+','.join(str(i*12)for i in range(15))]
    (out/'prepared-objects-data.s').write_text('\n'.join(lines)+'\n')
    (out/'prepared-objects.json').write_text(json.dumps({'variants':sum(map(len,indices)),'unique_stamps':len(frames),'stamp_bytes':32*len(frames),'directory_bytes':3*sum(map(len,indices)),'last_bank':bank},indent=2)+'\n')
