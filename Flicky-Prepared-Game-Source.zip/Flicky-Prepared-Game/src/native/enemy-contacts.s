; Enemy-to-actor contacts at original source-clock resolution. Process prior
; actors from front to back, removing covered pixels after each actor so the
; same ownership rule as the source collision hardware is retained.
q_enemy=$07b1
q_target=$07b2
n_player_enemy=$07b3
q_enemy_x=$07b4
q_enemy_y=$07b6
.segment "HIGHRAM"
.export enemy_contacts,enemy_contacts_pixel,n_player_enemy
enemy_contacts_pixel:
    lda $061f
    pha
    lda #9
    sta q_enemy
@enemy:
    ldx q_enemy
    lda n_flags,x
    and #$a0
    cmp #$a0
    beq :+
    jmp @next_enemy
:   clc
    lda n_xlo,x
    adc n_world
    sta q_enemy_x
    lda n_xhi,x
    adc n_world+1
    and #1
    sta q_enemy_x+1
    lda n_ylo,x
    sta q_enemy_y
    jsr cat_prepare
    lda p_visible
    bne :+
    jmp @next_enemy
:   lda p_y
    sta q_player_y
    lda p_height
    sta q_player_height
    jsr sprite_screen_mask
    lda p_screen+1
    lsr a
    lda p_screen
    ror a
    lsr a
    lsr a
    and #$3e
    sta q_window
    lda p_maskbank
    NATIVE_BANK
    lda #0
    sta q_offset
@enemy_row:
    jsr sprite_expand_mask
    ldx #0
    ldy q_offset
@store:
    txa
    clc
    adc q_window
    cmp #64
    lda #0
    bcs :+
    lda q_row,x
:   sta q_remaining,y
    iny
    inx
    cpx #8
    bcc @store
    sty q_offset
    dec p_height
    bne @enemy_row
    lda q_enemy
    sec
    sbc #1
    sta q_target
@target:
    ldx q_target
    lda n_flags,x
    bmi :+
    jmp @next_target
:   cpx #9
    bcc :+
    and #$20
    bne :+
    jmp @next_target
:   cpx #PLAYER
    beq @player_center
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    and #1
    jmp @center_high
@player_center:
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
@center_high:
    sta c_screen+1
    sec
    lda c_screen
    sbc q_enemy_x
    sta q_temp
    lda c_screen+1
    sbc q_enemy_x+1
    beq @positive_x
    cmp #255
    beq :+
    jmp @next_target
:   lda q_temp
    cmp #208
    bcs @vertical
    jmp @next_target
@positive_x:
    lda q_temp
    cmp #49
    bcc @vertical
    jmp @next_target
@vertical:
    lda n_ylo,x
    cpx #PLAYER
    bcs :+
    clc
    adc n_draw_yoffset,x
:   sec
    sbc q_enemy_y
    clc
    adc #32
    cmp #65
    bcc :+
    jmp @next_target
:   cpx #PLAYER
    beq @prepare_player
    bcs @prepare_cat
    jsr chick_prepare
    jmp @prepared
@prepare_cat:
    jsr cat_prepare
    jmp @prepared
@prepare_player:
    jsr player_prepare
@prepared:
    lda p_visible
    bne :+
    jmp @next_target
:   jsr sprite_screen_mask
    lda p_maskbank
    NATIVE_BANK
    sec
    lda p_y
    sbc q_player_y
    bcs @start_row
    eor #255
    clc
    adc #1
    cmp p_height
    bcc :+
    jmp @next_target
:   sta q_temp
    lda p_height
    sec
    sbc q_temp
    sta p_height
    lda q_temp
    asl a
    asl a
    clc
    adc p_mask
    sta p_mask
    bcc :+
    inc p_mask+1
:   lda #0
@start_row:
    cmp q_player_height
    bcc :+
    jmp @next_target
:   sta q_temp
    asl a
    asl a
    asl a
    sta q_offset
    lda q_player_height
    sec
    sbc q_temp
    cmp p_height
    bcc :+
    lda p_height
:   sta q_rows
    lda p_screen+1
    lsr a
    lda p_screen
    ror a
    lsr a
    lsr a
    and #$3e
    sec
    sbc q_window
    sta q_column
    lda #0
    sta q_hit
@row:
    jsr sprite_expand_mask
    lda q_column
    sta q_temp
    ldx #0
@byte:
    lda q_temp
    cmp #8
    bcs @skip
    clc
    adc q_offset
    tay
    lda q_row,x
    and q_remaining,y
    beq @skip
    lda #1
    sta q_hit
    lda q_row,x
    eor #255
    and q_remaining,y
    sta q_remaining,y
@skip:
    inc q_temp
    inx
    cpx #8
    bcc @byte
    clc
    lda q_offset
    adc #8
    sta q_offset
    dec q_rows
    bne @row
    lda q_hit
    beq @next_target
    ldx q_target
    jsr enemy_latch_contact
@next_target:
    dec q_target
    bmi @next_enemy
    jmp @target
@next_enemy:
    inc q_enemy
    lda q_enemy
    cmp #11
    beq @done
    jmp @enemy
@done:
    pla
.ifdef NATIVE_JCART
    sta $061f
    CART_WRITE
.else
    NATIVE_BANK
.endif
    rts

enemy_latch_contact:
    cpx #PLAYER
    bcc @chick
    bne @done
    ldy q_enemy
    lda #1
    cpy #9
    beq :+
    asl a
:   ora n_player_enemy
    sta n_player_enemy
    rts
@chick:
    lda #1
    sta n_enemy_contact,x
@done:
    rts

; A single overlap has no ownership ambiguity. The ROM intervals resolve that
; case without reading animation masks. Crowded/edge/hole cases use exact pixels.
l_dx=$3a
l_dy=$3b
l_bank=$3c
l_result=$3d
q_directory=$07b8
q_directory_bank=$07ba
q_reflect=$07bb
q_matches=$07bc
q_match=$07bd
q_edge=$07be
q_target_y=$07bf
.segment "FIXED"
enemy_contacts:
    lda #5
    NATIVE_BANK
    jmp enemy_contacts_lookup

.segment "BANK5"
enemy_contacts_lookup:
    lda #9
    sta q_enemy
@enemy:
    ldx q_enemy
    lda n_flags,x
    and #$a0
    cmp #$a0
    beq :+
    jmp @next_enemy
:   lda n_flags,x
    and #1
    sta q_reflect
    jsr collision_cat_index
    tay
    lda native_collision_cat_directory,y
    tay
    lda native_collision_directory_lo,y
    sta q_directory
    lda native_collision_directory_hi,y
    sta q_directory+1
    lda native_collision_directory_bank,y
    sta q_directory_bank
    clc
    lda n_xlo,x
    adc n_world
    sta q_enemy_x
    lda n_xhi,x
    adc n_world+1
    and #1
    sta q_enemy_x+1
    lda n_ylo,x
    sta q_enemy_y
    lda #0
    sta q_matches
    lda q_enemy
    sec
    sbc #1
    sta q_target
@target:
    ldx q_target
    lda n_flags,x
    bmi :+
    jmp @next_target
:   cpx #9
    bcc :+
    and #$20
    bne :+
    jmp @next_target
:   cpx #PLAYER
    beq @player_center
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    and #1
    jmp @center_high
@player_center:
    lda n_xlo,x
    sta c_screen
    lda n_xhi,x
@center_high:
    sta c_screen+1
    sec
    lda c_screen
    sbc q_enemy_x
    sta l_dx
    lda c_screen+1
    sbc q_enemy_x+1
    beq @positive_x
    cmp #255
    beq :+
    jmp @next_target
:   lda l_dx
    cmp #208
    bcs @vertical
    jmp @next_target
@positive_x:
    lda l_dx
    cmp #49
    bcc @vertical
    jmp @next_target
@vertical:
    lda n_ylo,x
    cpx #PLAYER
    beq @player_y
    bcs @y_ready
    clc
    adc n_draw_yoffset,x
    jmp @y_ready
@player_y:
    ldy n_animation,x
    cpy #3
    bne @y_ready
    clc
    adc #1
@y_ready:
    sta q_target_y
    sec
    sbc q_enemy_y
    sta l_dy
    clc
    adc #32
    cmp #65
    bcc :+
    jmp @next_target
:   lda l_dx
    clc
    adc #64
    sta l_dx
    lda q_reflect
    beq :+
    lda #128
    sec
    sbc l_dx
    sta l_dx
:   jsr collision_actor_shape
    sta n_step
    asl a
    clc
    adc n_step
    clc
    adc q_directory
    sta n_src
    lda q_directory+1
    adc #0
    sta n_src+1
    lda q_directory_bank
    sta l_bank
    jsr sic_collision_query
    beq @next_target
    cmp #2
    beq @fallback
    lda q_enemy_y
    cmp #32
    bcc @fallback
    cmp #224
    bcs @fallback
    lda q_target_y
    cmp #32
    bcc @fallback
    cmp #224
    bcs @fallback
    lda q_enemy_x+1
    lsr a
    lda q_enemy_x
    ror a
    cmp #12
    bcc @fallback
    cmp #244
    bcs @fallback
    lda c_screen+1
    lsr a
    lda c_screen
    ror a
    cmp #12
    bcc @fallback
    cmp #244
    bcs @fallback
    inc q_matches
    lda q_matches
    cmp #2
    bcs @fallback
    lda q_target
    sta q_match
@next_target:
    dec q_target
    bmi @resolved
    jmp @target
@resolved:
    lda q_matches
    beq @next_enemy
    ldx q_match
    jsr enemy_latch_contact
@next_enemy:
    inc q_enemy
    lda q_enemy
    cmp #11
    bcs @done
    jmp @enemy
@done:
    rts
@fallback:
    jmp enemy_contacts_pixel

; X actor, return the global silhouette ID with normalized facing.
collision_actor_shape:
    cpx #PLAYER
    bcc @chick
    beq @player
    jsr collision_cat_index
    eor q_reflect
    tay
    lda native_collision_cat_shape,y
    rts
@player:
    lda n_animation,x
    asl a
    asl a
    asl a
    sta n_step
    lda n_frame,x
    and #3
    asl a
    ora n_step
    sta n_step
    lda n_flags,x
    and #1
    eor q_reflect
    ora n_step
    tay
    lda native_collision_player_shape,y
    rts
@chick:
    lda n_animation,x
    asl a
    asl a
    sta n_step
    lda n_frame,x
    and #1
    asl a
    ora n_step
    sta n_step
    lda n_flags,x
    and #1
    eor q_reflect
    ora n_step
    tay
    lda native_collision_chick_shape,y
    rts
collision_cat_index:
    ldy n_animation,x
    lda n_flags,x
    and #2
    beq @pose
    cpy #5
    bne :+
    ldy #18
    bne @pose
:   cpy #7
    bne :+
    ldy #19
    bne @pose
:   cpy #8
    bne @pose
    ldy #20
@pose:
    tya
    asl a
    sta n_step
    lda n_flags,x
    and #1
    ora n_step
    rts
