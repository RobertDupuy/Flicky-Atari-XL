; ANTIC 4 background renderer: immutable shared glyphs and hardware scrolling.
; 32 visible columns; HSCROL fetches 40. Each RAM row repeats its 32 columns
; three times so every wrapped 40-byte window stays inside that row.
r_map=$50
r_base=$52
r_font=$54
r_glyph=$56
r_table=$58
r_band_index=$5a
r_cell=$5b
r_tile=$5c
r_ink=$5e
r_unique=$5f
r_screen=$60
r_screen2=$62
r_temp=$64
r_row=$65
r_column=$66
r_solid=$67
r_maskcache=$68
r_collision=$6a
r_front=$0640
r_back=$0641
r_pending=$0642
r_band=$0643
r_vbis=$0644
r_input=$0645
r_fire=$0646
r_fine=$0648
r_fault=$064a
r_background=$1600
r_presented=$07a0
r_host_frames=$07a2
r_pace_started=$06e0
r_deadline_misses=$06e1
r_interval=$06e3
r_max_interval=$06e4
r_coarse_cache=$1d30
r_blank_code=$0698
r_static_next=$06a0

.segment "FIXED"
.export display_init,display_build,display_scroll,display_nmi
.export r_front,r_back,r_pending,r_vbis,r_input,r_fire,r_fault,r_background,r_presented,r_host_frames
display_init:
    lda #0
    sta r_pace_started
    sta r_deadline_misses
    sta r_deadline_misses+1
    sta r_interval
    sta r_max_interval
    sta r_presented
    sta r_presented+1
    sta r_host_frames
    sta r_host_frames+1
    ldx #63
@state:
    sta $0640,x
    dex
    bpl @state
    lda #1
    sta r_back
    lda #$ff
    sta r_input
    ldx #0
@lists:
    lda native_dl0,x
    sta $1500,x
    lda native_dl1,x
    sta $1580,x
    inx
    cpx #90
    bne @lists
    jsr display_build
    lda #0
    sta r_back
    jsr display_scroll
    lda #1
    sta r_back
    jsr display_scroll
    lda #<sic_nmi
    sta $fffa
    lda #>sic_nmi
    sta $fffb
    lda #0
    sta $d01a
    sta $d01b
    sta $d01d
    sta $d402
    lda #$15
    sta $d403
    lda #$20
    sta r_band
    sta $d409
    lda #2
    sta $d401
    lda #$0e
    sta $d016
    lda #$9a
    sta $d017
    lda #$06
    sta $d018
    lda $d014
    and #$0e
    beq @pal_gold
    lda #$2e
    bne @gold
@pal_gold:
    lda #$ee
@gold:
    sta $d019
    jsr pmg_init
    jsr audio_init
    jsr clock_init
    lda #$3d
    sta $d400
    lda #$c0
    sta $d40e
    rts

display_build:
    lda #0
    ldx #0
@cache_clear:
    .repeat 6,I
        sta $6a00+I*256,x
        sta $7a00+I*256,x
    .endrepeat
    inx
    bne @cache_clear
    ; Clear both font pools before making the first display visible.
    lda #0
    sta r_epoch
    sta r_epoch+1
    sta r_font
    lda #$20
    sta r_font+1
    ldx #64
    ldy #0
    lda #0
@clear:
    sta (r_font),y
    iny
    bne @clear
    inc r_font+1
    dex
    bne @clear
    lda #0
    sta r_band_index
@band:
    pha
    ldx r_band_index
    lda #255
    sta r_blank_code,x
    pla
    sta r_map
    lda r_band_index
    clc
    adc #>n_map
    sta r_map+1
    lda r_band_index
    and #1
    beq :+
    lda #$80
:   sta r_base
    lda r_band_index
    lsr a
    clc
    adc #>r_background
    sta r_base+1
    lda #0
    sta r_cell
    sta r_unique
@cell:
    lda r_cell
    asl a
    tay
    lda (r_map),y
    sta r_tile
    iny
    lda (r_map),y
    pha
    and #$10
    sta r_solid
    pla
    and #7
    sta r_tile+1
    ldx #0
@find:
    cpx r_unique
    beq @new
    lda $0a00,x
    cmp r_tile
    bne @next
    lda $0a40,x
    cmp r_tile+1
    bne :+
    jmp @found
:   
@next:
    inx
    bne @find
@new:
    cpx #64
    bcc :+
    inc r_fault
    rts
:   inc r_unique
    lda r_tile
    sta $0a00,x
    sta r_table
    lda r_tile+1
    sta $0a40,x
    ora #$80
    sta r_table+1
    lda #12
    NATIVE_BANK
    ldy #0
    lda (r_table),y
    sta r_glyph
    lda r_table+1
    clc
    adc #8
    sta r_table+1
    lda (r_table),y
    sta r_glyph+1
    lda r_table+1
    clc
    adc #8
    sta r_table+1
    lda (r_table),y
    pha
    and #$80
    sta $0a80,x
    pla
    and #$7f
    NATIVE_BANK
    jsr display_glyph_address
    lda #0
    sta n_token
    ldy #7
@copy_glyph:
    lda (r_glyph),y
    sta (r_font),y
    sta (r_screen2),y
    ora n_token
    sta n_token
    dey
    bpl @copy_glyph
    lda n_token
    bne :+
    txa
    ldy r_band_index
    sta r_blank_code,y
:   
    lda #0
    sta n_src
    lda r_band_index
    clc
    adc #$ec
    sta n_src+1
    lda #0
    cmp n_token
    rol a
    tay
    tya
    pha
    txa
    tay
    pla
    sta (n_src),y
    jsr display_mask_address
    ldy #7
@copy_mask:
    tya
    clc
    adc #8
    tay
    lda (r_glyph),y
    pha
    tya
    sec
    sbc #8
    tay
    pla
    sta (r_maskcache),y
    dey
    bpl @copy_mask
@found:
    txa
    ora $0a80,x
    ldy r_cell
    sta (r_base),y
    jsr display_mask_address
    lda r_cell
    and #31
    sta r_collision
    lda r_cell
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    sta r_temp
    lda r_band_index
    asl a
    asl a
    clc
    adc r_temp
    adc #$d8
    sta r_collision+1
    ldx #0
@collision_row:
    lda #0
    ldy r_solid
    beq @collision_store
    txa
    tay
    lda (r_maskcache),y
@collision_store:
    ldy #0
    sta (r_collision),y
    clc
    lda r_collision
    adc #32
    sta r_collision
    inx
    cpx #8
    bne @collision_row
    inc r_cell
    bmi :+
    jmp @cell
:   
    ldx r_band_index
    lda r_unique
    sta r_static_next,x
    sta r_static_next+7,x
    inc r_band_index
    lda r_band_index
    cmp #7
    beq @screens
    lda #0
    jmp @band
@screens:
    lda #0
    sta r_row
    sta r_base
    lda #>r_background
    sta r_base+1
@screen_row:
    ldx r_row
    lda native_row_lo,x
    sta r_screen
    lda native_row_hi,x
    clc
    adc #$60
    sta r_screen+1
    ldx #0
@screen_cell:
    txa
    tay
    lda (r_base),y
    sta r_temp
    sta (r_screen),y
    tya
    clc
    adc #32
    tay
    lda r_temp
    sta (r_screen),y
    tya
    clc
    adc #32
    tay
    lda r_temp
    sta (r_screen),y
    inx
    cpx #32
    bne @screen_cell
    clc
    lda r_base
    adc #32
    sta r_base
    bcc :+
    inc r_base+1
:   inc r_row
    lda r_row
    cmp #28
    bne @screen_row
    lda #0
    sta r_screen
    sta r_screen2
    lda #$60
    sta r_screen+1
    lda #$70
    sta r_screen2+1
    ldx #11
    ldy #0
@copy_screen:
    lda (r_screen),y
    sta (r_screen2),y
    iny
    bne @copy_screen
    inc r_screen+1
    inc r_screen2+1
    dex
    bne @copy_screen
    jsr message_background
    jmp sprite_table_init

display_mask_address:
    txa
    asl a
    asl a
    asl a
    sta r_maskcache
    txa
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #$13
    sta r_maskcache+1
    rts

; X = glyph number within r_band_index. Both font-buffer addresses returned.
display_glyph_address:
    txa
    asl a
    asl a
    asl a
    sta r_font
    sta r_screen2
    txa
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    sta r_temp
    lda r_band_index
    asl a
    asl a
    clc
    adc #$20
    adc r_temp
    sta r_font+1
    clc
    adc #$20
    sta r_screen2+1
    rts

display_scroll:
    lda n_world
    lsr a
    lsr a
    and #3
    ldx r_back
    sta r_fine,x
    lda n_world+1
    lsr a
    lda n_world
    ror a
    lsr a
    lsr a
    lsr a
    eor #$ff
    sec
    sbc #3
    and #31
    sta r_column
    ldx r_back
    cmp r_coarse_cache,x
    bne @changed_scroll
    lda u_mode
    bne @changed_scroll
    rts
@changed_scroll:
    lda r_column
    sta r_coarse_cache,x
    lda r_back
    beq :+
    lda #$80
:   sta r_table
    lda #$15
    sta r_table+1
    lda r_back
    asl a
    asl a
    asl a
    asl a
    clc
    adc #$60
    sta r_temp
    lda u_mode
    bne @title
    ldy #9
    ldx #2
@row:
    lda native_row_lo,x
    clc
    adc r_column
    sta (r_table),y
    iny
    lda native_row_hi,x
    clc
    adc r_temp
    sta (r_table),y
    iny
    iny
    inx
    cpx #28
    bne @row
    rts
@title:
    ldy #2
    ldx #0
@title_row:
    lda #$44
    sta (r_table),y
    iny
    txa
    and #7
    .repeat 5
        asl a
    .endrepeat
    sta (r_table),y
    iny
    txa
    lsr a
    lsr a
    lsr a
    clc
    adc #$e8
    sta (r_table),y
    iny
    inx
    cpx #28
    bne @title_row
    rts

display_nmi:
    pha
    cld
    bit $d40f
    bpl :+
    jmp @dli
:
    txa
    pha
    tya
    pha
    inc r_vbis
    inc r_host_frames
    bne :+
    inc r_host_frames+1
:   inc r_interval
    lda n_bonus
    bne @bonus_present
    lda r_host_frames
    and #1
    bne @front
    jmp @check_picture
@bonus_present:
    lda r_pending
    bne @flip
    lda r_interval
    cmp #2
    bcc @front
@check_picture:
    lda r_pending
    bne @flip
    lda r_pace_started
    beq @front
    inc r_deadline_misses
    bne @front
    inc r_deadline_misses+1
    jmp @front
@flip:
    lda r_interval
    cmp r_max_interval
    bcc :+
    sta r_max_interval
:   lda #0
    sta r_interval
    sta r_pace_started
    inc r_presented
    bne :+
    inc r_presented+1
:   lda r_back
    sta r_front
    lda #0
    sta r_pending
    jsr pmg_present
@front:
    ldx r_front
    lda r_fine,x
    sta $d404
    txa
    beq :+
    lda #$80
:   sta $d402
    lda #$15
    sta $d403
    ; Prepare the first gameplay font while the beam is in vertical blank.
    ; DLI only consumes it; no buffer choice or address math on its deadline.
    txa
    .repeat 5
        asl a
    .endrepeat
    clc
    adc #$20
    sta r_band
    lda #$e0
    sta $d409
    lda #$ff
    sta r_input
    lda $d300
    and #4
    bne :+
    lda r_input
    and #$7f
    sta r_input
:   lda $d300
    and #8
    bne :+
    lda r_input
    and #$bf
    sta r_input
:   lda $d010
    bne :+
    lda r_input
    and #$fb
    sta r_input
    lda #1
    sta r_fire
:   jsr clock_vbi
    jsr audio_vbi
    pla
    tay
    pla
    tax
    pla
    jmp sic_nmi_return
@dli:
    lda r_band
    sta $d40a
    sta $d409
    clc
    adc #4
    sta r_band
    pla
    jmp sic_nmi_return

native_row_lo:
.repeat 28,I
    .byte <(I*96)
.endrepeat
native_row_hi:
.repeat 28,I
    .byte >(I*96)
.endrepeat
.macro NATIVE_DL screen, self
    .byte $70,$70
    .repeat 28,I
        .if I=0
            .byte $44
        .elseif I=1
            .byte $c4
        .elseif I .mod 4 = 3 .and I<24
            .byte $d4
        .else
            .byte $54
        .endif
        .word screen+I*96
    .endrepeat
    .byte $41
    .word self
    .byte 0
.endmacro
native_dl0: NATIVE_DL $6000,$1500
native_dl1: NATIVE_DL $7000,$1580

; Scenery accents are selected once at a round transition. Actor inks stay
; blue/white/gold; platform accents vary through the six original themes.
.segment "FIXED"
display_theme:
    lda #16
    NATIVE_BANK
    jmp display_theme_bank
.segment "BANK16"
display_theme_bank:
    lda n_bonus
    beq @ordinary
    lda #$3c
    ldx $d014
    txa
    and #$0e
    beq @pal
    lda #$3c
    bne @set
@pal:
    lda #$1c
    bne @set
@ordinary:
    ldx n_theme
    lda display_theme_ink,x
@set:
    sta $d018
    rts
display_theme_ink: .byte $06,$36,$c6,$86,$46,$16,$a6
