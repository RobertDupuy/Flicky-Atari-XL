"""Original, native-resolution Round Clear art; no enlarged actor sprite.

The screen mixes 320-dot ANTIC 2 lettering with 160-dot, five-color ANTIC 4
art. Seven character sets, row palettes and PMG masks are prepared at build
time. Coordinates below are television dots (two dots per color pixel).
"""
import json
from PIL import Image, ImageDraw
import numpy as np

# Small, deterministic lettering source: no host fonts or original ROM needed.
LETTERS = {
' ':['00000']*7,
'A':'01110 10001 10001 11111 10001 10001 10001'.split(),
'B':'11110 10001 10001 11110 10001 10001 11110'.split(),
'C':'01111 10000 10000 10000 10000 10000 01111'.split(),
'D':'11110 10001 10001 10001 10001 10001 11110'.split(),
'E':'11111 10000 10000 11110 10000 10000 11111'.split(),
'F':'11111 10000 10000 11110 10000 10000 10000'.split(),
'G':'01111 10000 10000 10111 10001 10001 01111'.split(),
'H':'10001 10001 10001 11111 10001 10001 10001'.split(),
'I':'11111 00100 00100 00100 00100 00100 11111'.split(),
'K':'10001 10010 10100 11000 10100 10010 10001'.split(),
'L':'10000 10000 10000 10000 10000 10000 11111'.split(),
'M':'10001 11011 10101 10101 10001 10001 10001'.split(),
'N':'10001 11001 10101 10011 10001 10001 10001'.split(),
'O':'01110 10001 10001 10001 10001 10001 01110'.split(),
'P':'11110 10001 10001 11110 10000 10000 10000'.split(),
'R':'11110 10001 10001 11110 10100 10010 10001'.split(),
'S':'01111 10000 10000 01110 00001 00001 11110'.split(),
'T':'11111 00100 00100 00100 00100 00100 00100'.split(),
'U':'10001 10001 10001 10001 10001 10001 01110'.split(),
'X':'10001 10001 01010 00100 01010 10001 10001'.split(),
'Y':'10001 10001 01010 00100 00100 00100 00100'.split(),
'=':'00000 00000 11111 00000 11111 00000 00000'.split(),
'!':'00100 00100 00100 00100 00100 00000 00100'.split(),
'0':'01110 10001 10011 10101 11001 10001 01110'.split(),
'1':'00100 01100 00100 00100 00100 00100 01110'.split(),
'2':'01110 10001 00001 00010 00100 01000 11111'.split(),
'3':'11110 00001 00001 01110 00001 00001 11110'.split(),
'4':'00010 00110 01010 10010 11111 00010 00010'.split(),
'5':'11111 10000 10000 11110 00001 00001 11110'.split(),
'6':'01110 10000 10000 11110 10001 10001 01110'.split(),
'7':'11111 00001 00010 00100 01000 01000 01000'.split(),
'8':'01110 10001 10001 01110 10001 10001 01110'.split(),
'9':'01110 10001 10001 01111 00001 00001 01110'.split(),
}

def lettering(draw, y, text, scale=1):
    x=(320-(len(text)*6-1)*scale)//2
    for c in text:
        for yy,row in enumerate(LETTERS[c]):
            for xx,bit in enumerate(row):
                if bit=='1':draw.rectangle((x+xx*scale,y+yy*scale,x+(xx+1)*scale-1,y+(yy+1)*scale-1),fill=1)
        x+=6*scale

ART_SCALE=0.60

def art_x(x):return round(80+(x-80)*ART_SCALE)
def art_y(y):return round(112+(y-112)*ART_SCALE)

class ScaledDraw:
    """Rasterize the original paths at their final size, without enlarging pixels."""
    def __init__(self,draw,scale):self.draw=draw;self.scale=scale
    def point(self,p):return (160+(p[0]-160)*self.scale,112+(p[1]-112)*self.scale)
    def polygon(self,points,**kwargs):self.draw.polygon([self.point(p)for p in points],**kwargs)
    def ellipse(self,box,**kwargs):self.draw.ellipse((*self.point(box[:2]),*self.point(box[2:])),**kwargs)
    def rectangle(self,box,**kwargs):self.draw.rectangle((*self.point(box[:2]),*self.point(box[2:])),**kwargs)
    def line(self,points,**kwargs):
        pts=list(zip(points[::2],points[1::2]))
        self.draw.line([self.point(p)for p in pts],**kwargs)

def picture(scale=ART_SCALE):
    im=Image.new('L',(320,224));d=ScaledDraw(ImageDraw.Draw(im),scale)
    def path(color,*commands):
        points=[];last=(0,0)
        for cmd in commands:
            if len(cmd)==2:points.append(cmd);last=cmd
            else:
                x0,y0=last;x1,y1,x2,y2,x3,y3=cmd
                for j in range(1,33):
                    t=j/32;s=1-t
                    points.append((s*s*s*x0+3*s*s*t*x1+3*s*t*t*x2+t*t*t*x3,
                                   s*s*s*y0+3*s*s*t*y1+3*s*t*t*y2+t*t*t*y3))
                last=(x3,y3)
        d.polygon(points,fill=color)
    # Wings are individually drawn at this resolution, with separated feathers.
    path(3,(116,120),(93,117,69,108,56,88),(50,78,46,81,49,91),
         (39,76,35,79,42,94),(30,82,27,86,36,101),
         (28,96,29,104,41,115),(60,132,85,141,117,142))
    path(2,(107,123),(83,119,64,108,50,94),(58,115,78,129,109,131))
    path(1,(74,116),(64,111,56,106,50,101),(54,110,63,117,74,120))
    path(0,(48,96),(55,102,63,108,70,110),(60,106,54,103,48,99))
    path(0,(43,106),(52,114,61,119,70,122),(57,118,49,113,43,109))
    path(3,(204,120),(222,111,234,96,243,81),(251,70,257,74,250,86),
         (261,70,269,75,260,90),(274,78,279,85,264,100),
         (280,91,284,98,267,111),(249,128,228,136,207,140))
    path(2,(213,124),(232,116,246,103,257,86),(248,111,235,124,215,133))
    path(1,(248,108),(256,103,263,98,267,91),(265,100,258,108,250,113))
    path(0,(261,91),(255,100,250,104,245,108),(253,104,259,99,263,95))
    path(0,(267,104),(259,111,251,116,244,119),(254,116,263,111,269,107))
    # Tail peeks out below the raised wing.
    path(3,(197,148),(221,146,235,150,244,143),(241,153,233,160,222,162),
         (235,161,237,163,238,164),(228,172,213,170,199,165))
    path(2,(209,156),(222,155,228,155,234,153),(227,160,218,161,209,161))
    # Blue body and a pear-shaped white bib, not a scaled sprite outline.
    path(3,(122,104),(100,123,96,149,106,164),(118,182,190,184,208,165),
         (222,150,216,124,199,108))
    path(2,(119,115),(102,138,105,159,117,167),(113,148,120,127,135,119))
    path(1,(145,111),(122,128,116,148,126,166),(137,179,181,180,197,165),
         (210,151,200,125,182,115))
    path(2,(133,166),(149,176,178,174,192,165),(186,179,149,182,133,170))
    # Head, three tapered crown feathers and a lightly shaded forehead.
    path(3,(107,108),(90,94,92,65,111,52),(107,44,101,39,105,36),
         (114,35,124,43,129,47),(125,36,130,32,137,34),
         (143,37,146,42,148,46),(148,36,155,34,159,40),
         (161,43,162,47,163,49),(196,44,219,60,219,84),
         (220,104,202,122,179,125),(151,131,125,122,107,108))
    path(2,(107,73),(110,59,124,53,143,54),(164,50,189,52,201,65),
         (183,59,166,60,153,62),(131,56,118,65,111,77))
    path(1,(117,61),(120,56,128,53,135,54),(130,56,124,59,121,63))
    path(2,(111,96),(111,105,116,112,127,116),(119,118,106,111,104,103))
    # Eyes retain one-color-pixel edges and tiny catchlights.
    d.ellipse((122,65,155,102),fill=0);d.ellipse((124,65,155,100),fill=1)
    d.ellipse((162,63,196,101),fill=0);d.ellipse((164,63,195,100),fill=1)
    d.ellipse((141,76,153,95),fill=0);d.ellipse((179,74,192,94),fill=0)
    d.rectangle((143,78,146,82),fill=1);d.rectangle((181,76,184,80),fill=1)
    # Beak is a fine, rounded silhouette; warm shade comes from hardware P2.
    path(0,(149,100),(158,93,180,94,198,101),(209,106,208,111,196,116),
         (183,124,163,119,154,113),(148,111,145,106,149,100))
    path(4,(150,101),(162,96,179,97,196,102),(205,105,205,109,194,110),
         (176,112,158,109,150,106))
    path(4,(158,112),(170,116,185,117,196,113),(191,120,172,122,163,116))
    d.line((157,101,177,99,190,102),fill=1,width=1)
    # Two feet have independent toes, dark separators and small glints.
    path(4,(128,176),(126,180,123,182,116,183),(103,182,99,186,106,188),
         (111,190,120,189,126,189),(136,192,149,189,149,186),
         (147,182,137,182,137,177))
    path(4,(178,177),(177,182,174,183,169,185),(164,190,178,191,188,188),
         (201,191,218,188,214,185),(210,181,200,184,191,176))
    d.line((112,185,125,185),fill=1);d.line((184,184,195,185),fill=1)
    d.line((128,185,132,188),fill=0);d.line((195,185,198,188),fill=0)
    # Small feather strokes and warm stars, all on the native pixel grid.
    d.line((119,140,116,151,119,157),fill=0)
    d.line((207,139,210,149,207,156),fill=0)
    for x,y in ((58,57),(265,47),(81,160),(250,174)):
        x|=1;d.line((x-5,y,x+5,y),fill=4);d.line((x,y-4,x,y+4),fill=4)
    return im

def build(out):
    raw=picture();pix=np.asarray(raw.resize((160,224),Image.Resampling.NEAREST)).copy()
    header=Image.new('L',(320,32));h=ImageDraw.Draw(header)
    lettering(h,5,'ROUND CLEAR!',2);lettering(h,25,'TAKE PIOPIO HOME')
    screen=bytearray(1120);fonts=bytearray();counts=[];adjusted=0
    for band in range(6):
        patterns=[bytes(8)];lookup={patterns[0]:0}
        for row in range(band*4,band*4+4):
            for col in range(40):
                if band==0:
                    a=np.asarray(header)[row*8:row*8+8,col*8:col*8+8]
                    g=bytes(sum(int(v)<<(7-i) for i,v in enumerate(line)) for line in a);inverse=0
                else:
                    a=pix[row*8:row*8+8,col*4:col*4+4].copy();inverse=128 if np.any(a==4) else 0
                    if inverse:
                        adjusted+=int(np.sum(a==3));a[a==3]=2;a[a==4]=3
                        pix[row*8:row*8+8,col*4:col*4+4]=np.where(a==3,4,a)
                    g=bytes(sum(int(v)<<(6-2*i) for i,v in enumerate(line)) for line in a)
                if g not in lookup:lookup[g]=len(patterns);patterns.append(g)
                assert len(patterns)<=128,(band,len(patterns))
                screen[row*40+col]=lookup[g]|inverse
        fonts+=b''.join(patterns)+bytes(1024-8*len(patterns));counts.append(len(patterns))
    # Bottom font is ASCII so the earned award is patched as five characters.
    footer=bytearray(1024)
    for c,rows in LETTERS.items():
        footer[ord(c)*8:ord(c)*8+7]=bytes(int(row,2)<<2 for row in rows)
    fonts+=footer;counts.append(len(LETTERS))
    for row,text in ((24,'TIME BONUS'),(26,'00000 POINTS')):
        x=(40-len(text))//2;screen[row*40+x:row*40+x+len(text)]=text.encode()
    # Independent hardware colors. PF0/PF1 mask the players, permitting thin
    # blue shadows and colored cheeks without recoloring white eyes or bib.
    pm=bytearray(1280)
    pm_x=[art_x(x)for x in (52,55,82,99)]
    pm_size=[0,0,1,0];pm_width=[8,8,16,8]
    def player(i,y,a,b):
        y=art_y(y);a=art_x(a);b=art_x(b)
        for bit in range(8):
            x=pm_x[i]+bit*(pm_width[i]//8)
            if a<=x<=b and pix[y,x]==3:
                pm[(i+1)*256+24+y]|=128>>bit
    for y in range(119,165):
        # Curved dark-blue edge on the left flank, never a rectangular slab.
        edge=52+int(((y-142)/20)**2)
        player(0,y,edge,edge+3)
    for i,cx in ((1,59),(3,103)):
        for y in range(100,107):
            radius=max(0,4-abs(y-103))
            player(i,y,cx-radius,cx+radius)
    # A smaller cheek can cross an inverse-character boundary. Keep its
    # hardware highlight on the nearest visible blue pixel after encoding.
    for i,ox in ((1,59),(3,103)):
        if any(pm[(i+1)*256:(i+2)*256]):continue
        cx,cy=art_x(ox),art_y(103)
        candidates=[(abs(x-cx)+abs(y-cy),x,y)for y in range(cy-6,cy+4)
                    for x in range(pm_x[i],pm_x[i]+8)if pix[y,x]==3]
        assert candidates,('Scaled cheek',i)
        _,x,y=min(candidates);pm[(i+1)*256+24+y]|=128>>(x-pm_x[i])
    # P2 shadows the lower part of the golden upper beak (PF3 is behind P2).
    for y in range(105,111):
        lo,hi=((92,98),(88,99),(84,99),(82,99),(84,97),(88,95))[y-105]
        y=art_y(y);lo=art_x(lo);hi=art_x(hi)
        for bit in range(8):
            x=pm_x[2]+2*bit
            if lo<=x<=hi and pix[y,x]==4 and pix[y,min(159,x+1)]==4:
                pm[3*256+24+y]|=128>>bit
    # Each missile supplies one extra precise feather / cheek / toe detail.
    missile_x=[]
    for i,(ox,oy) in enumerate(((36,108),(62,105),(96,186),(105,102))):
        cx,cy=art_x(ox),art_y(oy);ink=4 if i==2 else 3
        candidates=[(abs(x-cx)+abs(y-cy),x,y)for y in range(cy-3,cy+4)
                    for x in range(cx-3,cx+4)if pix[y,x]==pix[y,x+1]==ink]
        assert candidates,('Scaled missile detail',i,cx,cy)
        _,x,y=min(candidates);missile_x.append(x);pm[24+y]|=3<<(2*i)
    assert all(any(v & (3<<(2*i)) for v in pm[:256]) for i in range(4))
    (out/'round-clear-fonts.bin').write_bytes(fonts)
    (out/'round-clear-screen.bin').write_bytes(screen+bytes(1280-len(screen)))
    (out/'round-clear-pmg.bin').write_bytes(pm)
    # The runtime DLI selects one palette and font at each character row.
    pf1=[];pf2=[]
    for row in range(28):
        if row<4 or row>=24:pf1.append(0x0e);pf2.append(0)
        else:
            pf1.append(0xae if row*8<art_y(104) else 0xac if row*8<art_y(144) else 0xaa)
            pf2.append(0x9a if row*8<art_y(96) else 0x98 if row*8<art_y(152) else 0x96)
    # Immediate operands keep all three deadline writes in the left border.
    # No table lookup or register save is needed in the DLI itself.
    lines=['.segment "RESULT"']
    for row in range(1,28):
        next_row=row+1 if row<27 else 1
        lines += [f'result_dli_{row}:']
        def ink(v):
            if v>=0x90:
                return ['.if PAL_MULTI_PROP',f'    lda #${v-0x10:02x}', '.else',f'    lda #${v:02x}', '.endif']
            return [f'    lda #${v:02x}']
        lines += ink(pf2[row])+['    sta $d40a','    sta $d018',f'    lda #${0x20+4*(row//4):02x}','    sta $d409']
        lines += ink(pf1[row])+['    sta $d017',f'    lda #<result_dli_{next_row}','    sta result_dli+1',f'    lda #>result_dli_{next_row}','    sta result_dli+2','    lda $1b','    rti']
    lines += ['result_player_x:','.byte '+','.join(str(48+x) for x in pm_x),
           'result_player_size:','.byte '+','.join(map(str,pm_size)),
           'result_missile_x:','.byte '+','.join(str(48+x) for x in missile_x),
           '.segment "UPPER17"','result_fonts:','.incbin "round-clear-fonts.bin"',
           '.segment "UPPER18"','result_screen:','.incbin "round-clear-screen.bin"',
           'result_pmg:','.incbin "round-clear-pmg.bin"']
    (out/'round-clear-data.s').write_text('\n'.join(lines)+'\n')
    report={'color_resolution':[160,224],'lettering_resolution':[320,224],
            'portrait_linear_scale':ART_SCALE,'portrait_reduction_percent':40,
            'art_source':'Original native-resolution paths, not the gameplay sprite',
            'character_counts':counts,'font_bytes':len(fonts),'pmg_bytes':len(pm),
            'dli_palette_rows':28,'gold_cell_blue_adjustments':adjusted,
            'player_bytes_used':[sum(bool(v) for v in pm[(i+1)*256:(i+2)*256]) for i in range(4)],
            'missile_bytes_used':sum(bool(v) for v in pm[:256]),
            'missile_rows_used':[sum(bool(v & (3<<(2*i))) for v in pm[:256]) for i in range(4)]}
    (out/'round-clear-art.json').write_text(json.dumps(report,indent=2)+'\n')
    # Design preview only; release previews are captured from real ANTIC/GTIA.
    rgb=np.array([(0,0,0),(245,247,244),(100,200,248),(34,115,207),(255,211,72)],dtype=np.uint8)
    preview=Image.fromarray(rgb[pix]).resize((320,224),Image.Resampling.NEAREST)
    preview.paste(Image.fromarray(rgb[np.asarray(header)]),(0,0))
    preview.resize((960,672),Image.Resampling.NEAREST).save(out/'round-clear-design.png')
    return report

if __name__=='__main__':
    from build import BUILD
    print(json.dumps(build(BUILD/'native'),indent=2))
