; Static room lettering and bonus/result screens are prepared in cartridge ROM.
; The gameplay frame loop never draws text. Load-time copies preserve collision
; maps and exclude the cells occupied by precomposed stationary chicks.
u_wait=$07ef
u_time_bonus=$07f2
.segment "FIXED"
.export message_background,message_bonus_intro,message_result,u_wait,u_time_bonus
message_background:
    lda #16
    NATIVE_BANK
    jmp message_prepare
message_copy:
    NATIVE_BANK
@block:
    jsr level_byte
    sta n_dst
    jsr level_byte
    sta n_dst+1
    beq @done
    jsr level_byte
    sta n_remaining
@byte:
    jsr level_byte
    ldy #0
    sta (n_dst),y
    inc n_dst
    bne :+
    inc n_dst+1
:   dec n_remaining
    bne @byte
    beq @block
@done:
    rts
message_bonus_intro:
    lda n_bonus
    beq :+
    jmp bonus_message_intro
:
    lda #24
    NATIVE_BANK
    jmp message_intro_bank
message_result:
    lda n_bonus
    beq :+
    jmp bonus_message_result
:
    lda #24
    NATIVE_BANK
    jmp message_result_bank
.segment "BANK16"
message_prepare:
    lda n_round
@mod:
    cmp #48
    bcc @select
    sec
    sbc #48
    bcs @mod
@select:
    tax
    lda message_lo,x
    sta n_src
    lda message_hi,x
    sta n_src+1
    lda message_banks,x
    jmp message_copy
.segment "BANK24"
message_intro_bank:
    lda n_bonus
    bne :+
    rts
:   ldx #0
    jsr message_screen_copy
    lda #90
    sta u_wait
    lda #2
    sta u_mode
    rts
message_result_bank:
    ldx #1
    lda n_bonus
    beq @copy
    inx
    lda b_caught
    cmp #20
    bne @copy
    inx
@copy:
    jsr message_screen_copy
    lda n_bonus
    beq @time
    lda b_caught
    ldx #0
@tens:
    cmp #10
    bcc @digits
    sec
    sbc #10
    inx
    bne @tens
@digits:
    clc
    adc #27
    sta $e800+9*32+18
    sta $e800+21*32+21
    txa
    clc
    adc #27
    sta $e800+9*32+17
    sta $e800+21*32+20
    jmp @show
@time:
    lda u_time_bonus
    and #15
    clc
    adc #27
    sta $e800+23*32+12
    lda u_time_bonus
    .repeat 4
        lsr a
    .endrepeat
    clc
    adc #27
    sta $e800+23*32+11
@show:
    lda #3
    sta u_mode
    rts
message_screen_copy:
    lda message_screen_lo,x
    sta n_src
    lda message_screen_hi,x
    sta n_src+1
    lda #0
    sta n_dst
    lda #$e8
    sta n_dst+1
    ldx #4
    ldy #0
@page:
    lda (n_src),y
    sta (n_dst),y
    iny
    bne @page
    inc n_src+1
    inc n_dst+1
    dex
    bne @page
    lda #0
    ldx #3
@hide:
    sta pm_x,x
    sta pm_gold_x,x
    dex
    bpl @hide
    lda #255
    sta r_coarse_cache
    sta r_coarse_cache+1
    rts
