#!/usr/bin/env python3
"""Execute the real 6502 compositor and inspect its ANTIC character buffers."""
import ctypes as C,sys
import numpy as np
from PIL import Image
from run_native import Native
from run_reference import Reference
from build import BUILD

COLORS=np.array([[0,0,0],[240,240,240],[40,135,245],[255,210,55],[230,60,55]],dtype=np.uint8)
def decode(memory,font=0x2000,screen=0x1800):
    pixels=np.zeros((224,128),dtype=np.uint8)
    for y in range(224):
        for x in range(128):
            code=int(memory[screen+(y>>3)*32+(x>>2)])
            value=(int(memory[font+(y>>3)*256+(x>>2)*8+(y&7)])>>(6-(x&3)*2))&3
            pixels[y,x]=4 if value==3 and code&128 else value
    return pixels

def main():
    frame=int(sys.argv[1]) if len(sys.argv)>1 else 600
    snapshot=np.fromfile(BUILD/f'reference/ram-{frame:05d}.bin',dtype=np.uint8)
    n=Native(True);r=Reference()
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    n.memory[0xc000:0xd000]=snapshot[0xc000:0xd000]
    n.memory[0x7000:0x7800]=snapshot[0xd000:0xd800]
    n.memory[0xd800:0xf000]=snapshot[0xd800:0xf000]
    r.ram[:]=snapshot
    r.lib.fm_render_snapshot(0)
    n.lib.at_call(n.labels['render_init'],0,0,0)
    cycles=n.lib.at_call(n.labels['render_frame'],0,0,0)
    assert cycles>0
    print('Native compositor cycles',cycles)
    pixels=decode(n.memory)
    Image.fromarray(COLORS[pixels]).resize((512,448),Image.Resampling.NEAREST).save(BUILD/'native-antic.png')
    np.save(BUILD/'render-memory.npy',n.memory)
    for name,base,size in [('mix',0xf000,64),('coll',0xf800,1024)]:
        fn=getattr(r.lib,'fm_'+name);fn.restype=C.POINTER(C.c_uint8)
        expected=np.ctypeslib.as_array(fn(),shape=(size,))
        diff=np.where(n.memory[base:base+size]!=expected)[0]
        print(name,'differences',len(diff),'entries',diff[:20].tolist())
        assert len(diff)==0

if __name__=='__main__':main()
