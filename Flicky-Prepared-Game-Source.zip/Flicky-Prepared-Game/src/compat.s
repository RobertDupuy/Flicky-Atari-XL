; Full-game Z80 compatibility ABI. Original guest addresses are preserved.
.setcpu "6502"
.macro SELECT_BANK
.ifdef COMPACT
    ; Publish the bank first. NMI may switch banks at any instruction boundary.
    sta $061f
.endif
    sta $d500
.endmacro
.segment "ZEROPAGE"
z_c: .res 1
z_b: .res 1
z_e: .res 1
z_d: .res 1
z_l: .res 1
z_h: .res 1
z_f: .res 1
z_a: .res 1
z_ix: .res 2
z_iy: .res 2
z_sp: .res 2
z_pc: .res 2
z_i: .res 1
z_r: .res 1
z_iff: .res 1
z_im: .res 1
z_alt: .res 8
z_addr: .res 2
z_host: .res 2
z_word: .res 2
z_jump: .res 2
z_stream: .res 2
z_cur_bank: .res 1
z_operand: .res 1
z_old: .res 1
z_result: .res 1
z_status: .res 1
z_kind: .res 1
z_temp: .res 1
z_byte: .res 1
z_offset: .res 1
z_dst: .res 1
z_old16: .res 2
z_result16: .res 2
z_mixsum: .res 1
z_collsum: .res 1
z_p1: .res 1
z_p2: .res 1
z_system: .res 1
z_video: .res 1
z_sound: .res 1
z_halted: .res 1
z_fault: .res 1
z_frames: .res 2
z_block: .res 1
z_hash: .res 1
z_limit: .res 1
z_src: .res 2
z_dest: .res 2
z_count: .res 1
z_ret: .res 5
z_scratch_end:
.exportzp z_c,z_b,z_e,z_d,z_l,z_h,z_f,z_a,z_ix,z_iy,z_sp,z_pc,z_iff,z_addr
.exportzp z_halted,z_fault,z_frames,z_p1,z_p2,z_system,z_cur_bank,z_video,z_sound
.exportzp z_word,z_alt,z_i,z_r,z_im
.segment "FIXED"
.export compat_reset,dispatch_ax,guest_halt,guest_resume
.export alu8,inc8,dec8,alu16,rotate8,bit8,daa,block_ld,push_ax,pop_ax
compat_reset:
    cld
    lda #0
    ldx #z_scratch_end-z_c-1
@clear: sta z_c,x
    dex
    bpl @clear
    lda #$ff
    ldx #15
@registers: sta z_c,x
    dex
    bpl @registers
    sta z_p1
    sta z_p2
    sta z_system
.ifdef HYBRID
    ldx #0
@cache:
    sta $f600,x
    sta $0c00,x
    inx
    bne @cache
.endif
    rts

; Jump out of a bank through an inline {native-address,bank} descriptor.
far_jump:
    pla
    sta z_stream
    pla
    sta z_stream+1
    ldy #1
    lda (z_stream),y
    sta z_jump
    iny
    lda (z_stream),y
    sta z_jump+1
    iny
    lda (z_stream),y
    sta z_cur_bank
    SELECT_BANK
    jmp (z_jump)

.ifdef COMPACT
dispatch_ax:
.ifdef HYBRID
    jmp hot_dispatch
.endif
    sta z_pc
    stx z_pc+1
    jmp interp_next
dispatch_fail:
    lda #1
    sta z_fault
    jmp host_stop
.else
; Hash checked dispatch map: only executable guest addresses are accepted.
dispatch_ax:
    sta z_pc
    stx z_pc+1
    cpx #$80
    bcs dispatch_fail
    lda dispatch_bank,x
    SELECT_BANK
    lda dispatch_lo,x
    sta z_stream
    lda dispatch_hi,x
    sta z_stream+1
    lda dispatch_count,x
    sta z_limit
    beq dispatch_fail
@next:
    ldy #0
    lda (z_stream),y
    cmp z_pc
    bne @advance
    iny
    lda (z_stream),y
    sta z_jump
    iny
    lda (z_stream),y
    sta z_jump+1
    iny
    lda (z_stream),y
    sta z_cur_bank
    SELECT_BANK
    jmp (z_jump)
@advance:
    clc
    lda z_stream
    adc #4
    sta z_stream
    bcc :+
    inc z_stream+1
:   dec z_limit
    bne @next
dispatch_fail:
    lda #1
    sta z_fault
    jmp host_stop

.endif

push_return:
    pla
    sta z_stream
    pla
    sta z_stream+1
    ldy #1
    ldx #0
@read:
    lda (z_stream),y
    sta z_ret,x
    iny
    inx
    cpx #5
    bne @read
    ; Return to the instruction after the five-byte descriptor.
    clc
    lda z_stream
    adc #5
    tax
    lda z_stream+1
    adc #0
    pha
    txa
    pha
    lda z_ret
    ldx z_ret+1
    jsr push_ax
    ldx z_sp
    lda z_ret
    sta $0800,x
    lda z_ret+1
    sta $0900,x
    lda z_ret+2
    sta $0a00,x
    lda z_ret+3
    sta $0b00,x
    lda z_ret+4
    sta $0c00,x
    rts
return_guest:
    lda z_sp
    sta z_hash
    jsr pop_ax
    sta z_pc
    stx z_pc+1
    ldx z_hash
    cmp $0800,x
    bne @slow
    lda z_pc+1
    cmp $0900,x
    bne @slow
    lda $0a00,x
    sta z_jump
    lda $0b00,x
    sta z_jump+1
    lda $0c00,x
    cmp #32
    bcs @slow
    sta z_cur_bank
    SELECT_BANK
    jmp (z_jump)
@slow:
    lda z_pc
    ldx z_pc+1
    jmp dispatch_ax

guest_halt:
    sta z_pc
    stx z_pc+1
    lda #1
    sta z_halted
    inc z_frames
    bne :+
    inc z_frames+1
:   jmp host_frame
guest_resume:
    lda #0
    sta z_halted
    lda z_iff
    beq @no_irq
    lda z_pc
    ldx z_pc+1
    jsr push_ax
    lda #0
    sta z_iff
    ldx #0
    lda #$38
    jmp dispatch_ax
@no_irq:
    lda z_pc
    ldx z_pc+1
    jmp dispatch_ax

; Guest ROM data is in banks 0-3. Sprite RAM D000-D7FF maps to host 7000-77FF.
; C000-CFFF and D800-EFFF use RAM underneath the disabled Atari OS ROM.
bus_map:
    lda z_addr
    sta z_host
    lda z_addr+1
    cmp #$80
    bcs @ram
    pha
    and #$1f
    ora #$80
    sta z_host+1
    pla
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    SELECT_BANK
    rts
@ram:
    cmp #$d0
    bcc @done
    cmp #$d8
    bcs @done
    sec
    sbc #$60
@done:
    sta z_host+1
    rts
bus_read:
    lda z_addr+1
    cmp #$f0
    bcs read_collision
    cmp #$80
    bcc @read
    cmp #$c0
    bcc @empty
@read:
    jsr bus_map
    ldy #0
    lda (z_host),y
    pha
    lda z_cur_bank
    SELECT_BANK
    pla
    rts
@empty:
    lda #$ff
    rts
read_collision:
    cmp #$f4
    bcc @mix
    cmp #$f8
    bcc @empty
    cmp #$fc
    bcs @empty
    and #3
    ora #$f8
    sta z_host+1
    lda z_addr
    sta z_host
    lda z_collsum
    jmp @fetch
@mix:
    lda z_addr
    and #63
    sta z_host
    lda #$f0
    sta z_host+1
    lda z_mixsum
@fetch:
    lsr a
    ror a
    ora #$7e
    ldy #0
    ora (z_host),y
    rts
@empty:
    lda #$ff
    rts
bus_write:
    pha
    lda z_addr+1
    cmp #$c0
    bcc @ignore
    cmp #$f0
    bcs @collision
    jsr bus_map
    pla
    ldy #0
.ifdef COMPACT
    cmp (z_host),y
    beq @unchanged
    sta (z_host),y
    pha
    lda z_addr+1
    cmp #$e0
    bcc @clean
    cmp #$ef
    bne @dirty
    lda z_addr
    cmp #$fc
    beq @clean
    cmp #$fd
    beq @clean
    cmp #$bd
    beq @clean
@dirty:
    lda #1
    sta $0610
@clean:
    pla
@unchanged:
.else
    sta (z_host),y
.endif
    rts
@collision:
    cmp #$f4
    bcc @mix
    cmp #$f8
    bcc @mix_reset
    cmp #$fc
    bcs @sprite_reset
    and #3
    ora #$f8
    sta z_host+1
    lda z_addr
    sta z_host
    jmp @clear
@mix:
    lda z_addr
    and #63
    sta z_host
    lda #$f0
    sta z_host+1
@clear:
    lda #0
    ldy #0
    sta (z_host),y
@ignore:
    pla
    rts
@mix_reset:
    lda #0
    sta z_mixsum
    pla
    rts
@sprite_reset:
    lda #0
    sta z_collsum
    pla
    rts
bus_read16:
    jsr bus_read
    pha
    inc z_addr
    bne :+
    inc z_addr+1
:   jsr bus_read
    tax
    pla
    rts
bus_write16:
    lda z_word
    jsr bus_write
    inc z_addr
    bne :+
    inc z_addr+1
:   lda z_word+1
    jmp bus_write

.macro PAIR_ACCESS name, lo, hi
.ident(.concat("read_",name)):
    lda lo
    sta z_addr
    lda hi
    sta z_addr+1
    jmp bus_read
.ident(.concat("write_",name)):
    pha
    lda lo
    sta z_addr
    lda hi
    sta z_addr+1
    pla
    jmp bus_write
.endmacro
PAIR_ACCESS "hl",z_l,z_h
PAIR_ACCESS "bc",z_c,z_b
PAIR_ACCESS "de",z_e,z_d

.macro INDEX_ACCESS name, reg
.ident(.concat("addr_",name)):
    tax
    clc
    adc reg
    sta z_addr
    txa
    bpl :+
    lda #$ff
    bmi :++
:   lda #0
:   adc reg+1
    sta z_addr+1
    rts
.ident(.concat("read_",name)):
    jsr .ident(.concat("addr_",name))
    jmp bus_read
.ident(.concat("write_",name)):
    pha
    txa
    jsr .ident(.concat("addr_",name))
    pla
    jmp bus_write
.endmacro
INDEX_ACCESS "ix",z_ix
INDEX_ACCESS "iy",z_iy

push_ax:
    sta z_word
    stx z_word+1
    lda z_sp
    sec
    sbc #2
    sta z_sp
    bcs :+
    dec z_sp+1
:   ldy #0
    lda z_word
    sta (z_sp),y
    iny
    lda z_word+1
    sta (z_sp),y
    rts
pop_ax:
    ldy #0
    lda (z_sp),y
    pha
    iny
    lda (z_sp),y
    tax
    lda z_sp
    clc
    adc #2
    sta z_sp
    bcc :+
    inc z_sp+1
:   pla
    rts
ex_af:
    ldx #7
    jsr exchange_byte
    dex
    jmp exchange_byte
exx:
    ldx #5
@loop:
    jsr exchange_byte
    dex
    bpl @loop
    rts
exchange_byte:
    lda z_c,x
    ldy z_alt,x
    sta z_alt,x
    tya
    sta z_c,x
    rts
ex_sp:
    stx z_dst
    jsr pop_ax
    pha
    txa
    pha
    ldx z_dst
    lda $00,x
    sta z_word
    lda $01,x
    tax
    lda z_word
    jsr push_ax
    ldx z_dst
    pla
    sta $01,x
    pla
    sta $00,x
    rts

; 16-bit ADD/ADC/SBC. X=destination ZP offset; Y=0/1/2; z_word=source.
alu16:
    stx z_dst
    sty z_kind
    lda $00,x
    sta z_old16
    lda $01,x
    sta z_old16+1
    cpy #2
    beq @sub
    cpy #0
    beq @no_carry
    lda z_f
    lsr a
    jmp @add
@no_carry:
    clc
@add:
    lda z_old16
    adc z_word
    sta z_result16
    lda z_old16+1
    adc z_word+1
    jmp @save
@sub:
    lda z_f
    eor #1
    lsr a
    lda z_old16
    sbc z_word
    sta z_result16
    lda z_old16+1
    sbc z_word+1
@save:
    sta z_result16+1
    php
    pla
    sta z_status
    lda z_result16
    sta $00,x
    lda z_result16+1
    sta $01,x
    ldy z_kind
    bne @all_flags
    and #$28
    sta z_temp
    lda z_f
    and #$c4
    ora z_temp
    sta z_f
    jmp @half_carry
@all_flags:
    and #$a8
    sta z_f
    ora z_result16
    lda z_result16+1
    ora z_result16
    bne :+
    lda z_f
    ora #$40
    sta z_f
:   lda z_status
    and #$40
    lsr a
    lsr a
    lsr a
    lsr a
    ora z_f
    sta z_f
@half_carry:
    lda z_old16+1
    eor z_word+1
    eor z_result16+1
    and #$10
    ora z_f
    sta z_f
    lda z_status
    cpy #2
    bne :+
    eor #1
:   and #1
    cpy #2
    bne :+
    ora #2
:   ora z_f
    sta z_f
    rts

; BIT preserves carry. Register and ordinary memory documented flags.
bit8:
    sta z_result
    and #$28
    ora #$10
    sta z_temp
    lda z_result
    and bit_masks,x
    bne @set
    lda z_temp
    ora #$44
    sta z_temp
    jmp @finish
@set:
    cpx #7
    bne @finish
    lda z_temp
    ora #$80
    sta z_temp
@finish:
    lda z_f
    and #1
    ora z_temp
    sta z_f
    lda z_result
    rts

rotate8:
    stx z_kind
    sta z_result
    txa
    and #7
    tax
    lda z_result
    cpx #0
    beq @rlc
    cpx #1
    beq @rrc
    cpx #2
    beq @rl
    cpx #3
    beq @rr
    cpx #4
    beq @sla
    cpx #5
    beq @sra
    cpx #6
    beq @sll
    lsr a
    jmp @flags
@rlc:
    asl a
    bcc @flags
    ora #1
    bcs @flags
@rrc:
    lsr a
    bcc @flags
    ora #$80
    bcs @flags
@rl:
    lda z_f
    lsr a
    lda z_result
    rol a
    jmp @flags
@rr:
    lda z_f
    lsr a
    lda z_result
    ror a
    jmp @flags
@sla:
    asl a
    jmp @flags
@sra:
    cmp #$80
    ror a
    jmp @flags
@sll:
    asl a
    ora #1
@flags:
    sta z_result
    lda #0
    rol a
    sta z_temp
    ldx z_kind
    cpx #8
    bcc @cb
    lda z_f
    and #$c4
    sta z_f
    lda z_result
    and #$28
    ora z_f
    jmp @save
@cb:
    ldx z_result
    lda z_parity_flags,x
@save:
    ora z_temp
    sta z_f
    lda z_result
    rts
cpl:
    lda z_a
    eor #$ff
    sta z_a
    and #$28
    sta z_temp
    lda z_f
    and #$c5
    ora #$12
    ora z_temp
    sta z_f
    rts
scf:
    lda z_f
    and #$c4
    ora #1
    sta z_f
    lda z_a
    and #$28
    ora z_f
    sta z_f
    rts
ccf:
    lda z_f
    and #1
    eor #1
    sta z_temp
    bne :+
    lda #$10
    sta z_temp
:   lda z_f
    and #$c4
    ora z_temp
    sta z_f
    lda z_a
    and #$28
    ora z_f
    sta z_f
    rts
neg:
    lda z_a
    sta z_operand
    lda #0
    sta z_a
    ldx #2
    jmp alu8
daa:
    lda z_a
    sta z_old
    lda #0
    sta z_operand
    lda z_f
    and #$10
    bne @low_adjust
    lda z_a
    and #15
    cmp #10
    bcc @high
@low_adjust:
    lda #6
    sta z_operand
@high:
    lda z_f
    and #1
    sta z_temp
    bne @high_adjust
    lda z_a
    cmp #$9a
    bcc @adjust
@high_adjust:
    lda z_operand
    ora #$60
    sta z_operand
    lda #1
    sta z_temp
@adjust:
    lda z_f
    and #2
    beq @add
    lda z_a
    sec
    sbc z_operand
    jmp @flags
@add:
    lda z_a
    clc
    adc z_operand
@flags:
    sta z_a
    tax
    eor z_old
    and #$10
    ora z_temp
    sta z_temp
    lda z_f
    and #2
    ora z_temp
    ora z_parity_flags,x
    sta z_f
    rts

block_ld:
    stx z_block
    cpx #1
    bne @loop
    lda z_b
    bne @loop
    lda z_c
    beq @loop
    lda z_h
    cmp #$f0
    bcs @loop
    cmp #$80
    bcc :+
    cmp #$c0
    bcc @loop
:
    lda z_d
    cmp #$c0
    bcc @loop
    cmp #$f0
    bcs @loop
    ; A small copy may cross ordinary pages but not a mapping boundary.
    lda z_l
    clc
    adc z_c
    lda z_h
    adc #0
    eor z_h
    and #$e0
    bne @loop
    lda z_e
    clc
    adc z_c
    lda z_d
    adc #0
    eor z_d
    and #$f8
    bne @loop
    jmp block_ld_fast
@loop:
    jsr read_hl
    sta z_byte
    jsr write_de
    lda z_block
    and #2
    bne @decrement
    inc z_l
    bne :+
    inc z_h
:   inc z_e
    bne @count
    inc z_d
    jmp @count
@decrement:
    lda z_l
    bne :+
    dec z_h
:   dec z_l
    lda z_e
    bne :+
    dec z_d
:   dec z_e
@count:
    lda z_c
    bne :+
    dec z_b
:   dec z_c
    lda z_b
    ora z_c
    beq block_ld_flags
    lda z_block
    and #1
    bne @loop
block_ld_flags:
    lda z_f
    and #$c1
    sta z_f
    lda z_c
    ora z_b
    beq :+
    lda z_f
    ora #4
    sta z_f
:   lda z_a
    clc
    adc z_byte
    sta z_temp
    and #8
    ora z_f
    sta z_f
    lda z_temp
    and #2
    asl a
    asl a
    asl a
    asl a
    ora z_f
    sta z_f
    rts

block_ld_fast:
    lda z_l
    sta z_addr
    lda z_h
    sta z_addr+1
    jsr bus_map
    lda z_host
    sta z_src
    lda z_host+1
    sta z_src+1
    lda z_e
    sta z_addr
    lda z_d
    sta z_addr+1
    jsr bus_map
    lda z_host
    sta z_dest
    lda z_host+1
    sta z_dest+1
    ldy #0
.ifdef COMPACT
    lda z_d
    cmp #$e0
    bcc @copy
@video_copy:
    lda (z_src),y
    cmp (z_dest),y
    beq :+
    sta (z_dest),y
    lda #1
    sta $0610
:   iny
    cpy z_c
    bne @video_copy
    dey
    lda (z_src),y
    jmp @copied
.endif
@copy:
    lda (z_src),y
    sta (z_dest),y
    iny
    cpy z_c
    bne @copy
@copied:
    sta z_byte
    clc
    lda z_l
    adc z_c
    sta z_l
    bcc :+
    inc z_h
:   clc
    lda z_e
    adc z_c
    sta z_e
    bcc :+
    inc z_d
:   lda #0
    sta z_c
    lda z_cur_bank
    SELECT_BANK
    jmp block_ld_flags

port_in:
    and #$1f
    cmp #4
    bcc @player
    cmp #8
    bcc @player2
    cmp #12
    bcc @system
    cmp #16
    bcs @dip
    and #1
    beq @empty
@dip:
    lda #$fe
    rts
@empty:
    lda #$ff
    rts
@player2:
    lda z_p2
    rts
@player:
    lda z_p1
    rts
@system:
    lda z_system
    rts
port_out:
    sta z_byte
    txa
    and #$1f
    cmp #$18
    bne :+
    lda z_byte
    sta z_sound
.ifdef COMPACT
    jsr audio_enqueue
.endif
    rts
:   cmp #$19
    bne :+
    lda z_byte
    sta z_video
:   rts
in_flags:
    tax
    lda z_f
    and #1
    ora z_parity_flags,x
    sta z_f
    txa
    rts

bit_masks:.byte 1,2,4,8,16,32,64,128

.export compat_reset,far_jump,dispatch_ax,dispatch_fail,push_return,return_guest,guest_halt,guest_resume,bus_map,bus_read,read_collision,bus_write,bus_read16,bus_write16,push_ax,pop_ax,ex_af,exx,exchange_byte,ex_sp,alu16,bit8,rotate8,cpl,scf,ccf,neg,daa,block_ld,block_ld_flags,block_ld_fast,port_in,port_out,in_flags
