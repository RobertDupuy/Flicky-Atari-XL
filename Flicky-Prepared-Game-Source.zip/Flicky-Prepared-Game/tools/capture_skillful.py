"""Read-only state observation and keyboard-only tool-assisted native play."""
import sys,os,time,signal,json
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from raster_probe import Session
from build import BUILD,ROOT
import movie_plan as plan

def locate(s):
    from attract_probe import observe_ram
    return observe_ram(s,plan.CARTRIDGE,plan.E)

def state(fd,base):return np.frombuffer(os.pread(fd,65536,base),dtype=np.uint8).copy()

def keyset(s,key):
    for name,bit in [('Left',128),('Right',64),('Control_R',4)]:s.key(name,not bool(key&bit))

def pause(s,fd,base):
    for _ in range(100):
        os.kill(s.emu.pid,signal.SIGSTOP);m=state(fd,base)
        if m[0x061f]&0x40 and bytes(m[0xa000:0xa040])==plan.KERNEL:return m
        os.kill(s.emu.pid,signal.SIGCONT);time.sleep(.002)
    raise RuntimeError('Could not pause with common RAM visible')

def play_actions(s,fd,base,actions):
    for key,ticks in actions:
        keyset(s,key)
        m=state(fd,base);start=int(m[0x680])+256*int(m[0x681])
        timeout=time.monotonic()+2
        # Match the host-sampled input clock; pending input remains genuine.
        while True:
            m=state(fd,base);now=int(m[0x680])+256*int(m[0x681])
            if ((now-start)&65535)>=ticks:break
            if time.monotonic()>timeout:
                s.capture().save(s.out/'stalled.png');s.monitor(['m 0680','m 07e0','m 0640'])
                raise RuntimeError(('Input clock stalled',start,now,plan.status(m),m[0x640:0x650].tolist(),m[0x680:0x690].tolist()))
            time.sleep(.001)

if __name__=='__main__':
    out=BUILD/f'native/{plan.MODE}-512-movie';out.mkdir(exist_ok=True);(out/'capture.avi').unlink(missing_ok=True);s=Session(plan.CARTRIDGE,out,plan.MODE,True)
    try:
        fd,base=locate(s);print('located RAM',hex(base),flush=True)
        m1=state(fd,base);time.sleep(.2);m2=state(fd,base)
        print('BEFORE RECORD',m1[0x680:0x684].tolist(),m2[0x680:0x684].tolist(),flush=True)
        s.capture().save(out/'title.png');s.record();time.sleep(.2);s.tap('Return');time.sleep(.5);s.tap('Control_R');time.sleep(.5)
        print('START',state(fd,base)[0x680:0x684].tolist(),int(state(fd,base)[0x7ec]),flush=True)
        targets=[6,2,7,(180,140),(130,100),1,3,5,(380,199),(264,199),2,7,(380,199),(264,199)]
        target_index=0;seen=0;started=state(fd,base);host0=int(started[0x7a2])+256*int(started[0x7a3]);last_host=host0;total_host=0;log=[];recent=[]
        for decision in range(1400):
            m=pause(s,fd,base);st=plan.status(m);host=int(m[0x7a2])+256*int(m[0x7a3]);delta=(host-last_host)&65535;last_host=host
            if delta<500:total_host+=delta
            elapsed=total_host/(49.86076 if plan.MODE=='pal' else 59.92274)
            if elapsed>=120 or st['round']>=3:break
            doors=[i for i in range(896)if m[0xc000+2*i]==0xc8]
            door=((doors[0]%32)*16+8,(doors[0]//32)*8-1) if doors else (264,199)
            if st['round']>0:
                p=plan.xy(m);recent.append((p[0]//16,p[1]//8));recent=recent[-35:]
                plan.VISITS={p:recent.count(p) for p in recent}
            if st['round']>0 or target_index>=len(targets) or st['lives']<3:
                # Continue a new stage deliberately, collecting nearby birds.
                remaining=[i for i in range(8)if not plan.goal(m,i)]
                target=min(remaining,key=lambda i:plan.cost(m,i))if remaining and st['train']<3 else door
            else:
                while target_index<len(targets)and plan.goal(m,targets[target_index]):target_index+=1
                target=targets[min(target_index,len(targets)-1)]
                if st['rescued']==255:target=(264,199)
            plan.E.ram[:]=m
            if plan.dead(m) or plan.v(m,'n_flow') or plan.v(m,'u_mode'):
                actions=[(255,6)];ok=False
            elif plan.v(m,'n_bonus'):
                birds=[i for i in range(8)if plan.v(m,'n_flags',i)&128]
                target=max(birds,key=lambda i:plan.xy(m,i)[1])if birds else (268,195)
                px,_=plan.xy(m);tx,_=plan.xy(m,target)if isinstance(target,int)else target
                delta=(tx-px+256)%512-256
                actions=[(255 if abs(delta)<12 else 191 if delta>0 else 127,4)];ok=True
            else:
                result,ok=plan.search(m,target,depth=24 if st['round'] else 20,width=28,span=6)
                actions=result[3][:1]
            if not actions:
                px,py=plan.xy(m);tx,ty=target if isinstance(target,tuple) else plan.xy(m,target)
                direction=0xbf if (tx-px+256)%512-256>0 else 0x7f
                actions=[(direction & (0xfb if ty<py-10 and st['ground'] else 0xff),6)]
            log.append({'props':sum(bool(m[plan.L['n_flags']+i]&128) and bool(m[plan.L['n_chick_state']+i]) for i in range(12,18)),'bonus_caught':plan.v(m,'b_caught'),'bonus_spawned':plan.v(m,'b_spawn'),'seconds':round(elapsed,2),'target':target,'status':st,'actions':actions,'found':ok})
            print(json.dumps(log[-1]),flush=True)
            (out/'route.json').write_text(json.dumps(log,indent=2))
            os.kill(s.emu.pid,signal.SIGCONT)
            play_actions(s,fd,base,actions)
            if decision%10==0:s.capture().save(out/f'frame-{decision:03d}.png')
        os.kill(s.emu.pid,signal.SIGCONT);keyset(s,255);time.sleep(.5);s.record();time.sleep(.8)
        print('FINAL',plan.status(state(fd,base)),flush=True)
    finally:
        os.kill(s.emu.pid,signal.SIGCONT);s.close()
