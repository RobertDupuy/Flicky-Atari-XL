local machine=manager.machine
local cpu=machine.devices[":maincpu"]
local space=cpu.spaces["program"]
local screen=machine.screens[":screen"]
local frame=0
local directory=os.getenv("FLICKY_ORACLE_DIR")
assert(directory)
for tag,port in pairs(machine.ioport.ports) do
  for name,field in pairs(port.fields) do
    print(tag,name,field.mask)
  end
end
emu.register_frame_done(function()
  frame=frame+1
  local system=machine.ioport.ports[":SYSTEM"]
  local player=machine.ioport.ports[":P1"]
  system:field(1):set_value(frame>=180 and frame<190 and 1 or 0)
  system:field(16):set_value(frame>=210 and frame<220 and 1 or 0)
  if frame>=300 then
    player:field(64):set_value(frame%240<120 and 1 or 0)
    player:field(128):set_value(frame%240>=120 and 1 or 0)
    player:field(4):set_value(frame%90<40 and 1 or 0)
  end
  if frame==360 or frame==600 or frame==900 then
    screen:snapshot(directory..string.format("/mame-%05d.png",frame))
    local f=assert(io.open(directory..string.format("/mame-%05d.bin",frame),"wb"))
    for address=0,65535 do f:write(string.char(space:read_u8(address))) end
    f:close()
    print("Captured MAME frame",frame)
  end
  if frame>=901 then machine:exit() end
end)
