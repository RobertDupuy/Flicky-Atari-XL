"""Compile a deterministic maximum-load fixture for a separate test cartridge."""
import math

def build(out):
    lines=['.ifdef BENCHMARK','.segment "FIXED"','benchmark_tick:','    lda u_mode','    bne @done','    lda #0']
    for k in ('n_flow','n_life_lost','n_exiting','n_round_complete','n_player_enemy','n_frozen'):lines += ['    sta '+k]
    lines += ['    lda n_flags+PLAYER','    and #1','    ora #$80','    sta n_flags+PLAYER','@done:','    rts','benchmark_render:','    lda #14','    NATIVE_BANK','    jmp benchmark_render_bank','.segment "BANK14"','benchmark_render_bank:','    lda r_host_frames','    lsr a','    and #31','    sta bench_phase','    ldx bench_phase']
    for actor in list(range(8))+[9,10]+list(range(12,18)):
        if actor>=13:lines+=[f'.if STRESS_PROPS>{actor-12}']
        prefix=f'bench_{actor}'
        for field in ('xlo','xhi','ylo','animation','flags'):
            lines += [f'    lda {prefix}_{field},x',f'    sta n_{field}+{actor}']
        lines+=['    lda #0',f'    sta n_pause+{actor}',f'    sta n_frame+{actor}',f'    sta n_draw_yoffset+{actor}']
        if actor<8:lines += ['    lda #1',f'    sta n_chick_state+{actor}',f'    lda #{actor}',f'    sta n_chain+{actor}']
        elif actor>=12:lines += ['    lda #$80',f'    sta n_chick_state+{actor}','    lda #90',f'    sta n_timer+{actor}']
        else:lines+=['    lda #0',f'    sta n_chick_state+{actor}']
        if actor>=13:lines+=['.endif']
    lines+=['    lda #8','    sta n_train','    rts','bench_phase=$06f0']
    for actor in list(range(8))+[9,10]+list(range(12,18)):
        if actor>=13:lines+=[f'.if STRESS_PROPS>{actor-12}']
        values=[]
        for frame in range(32):
            # Includes crowded overlaps, character-band crossings and wraps.
            x=(frame*7+actor*31)&511;y=55+round(60+52*math.sin((frame-actor*5)/13))
            anim=(frame//2+actor)% (9 if actor<8 else 18 if actor<12 else 15)
            values.append((x&255,x>>8,y,anim,0xb0|(frame&3 if actor>=9 else frame&1)))
        for col,field in enumerate(('xlo','xhi','ylo','animation','flags')):
            lines += [f'bench_{actor}_{field}:','.byte '+','.join(str(v[col])for v in values)]
        if actor>=13:lines+=['.endif']
    lines += ['.endif']
    (out/'benchmark-fixture.s').write_text('\n'.join(lines)+'\n')
