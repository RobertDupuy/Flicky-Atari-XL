; ANTIC 4 reference compositor. 32 columns, 28 rows, seven character sets.
; Presentation is horizontally reduced; mixer and sprite collision coordinates
; retain all 512 source clocks. Buffers are exchanged only after a complete draw.
.segment "LOWZP": zeropage
r_y: .res 1
r_worldy: .res 1
r_page: .res 1
r_tiles: .res 2
r_lookup: .res 2
r_glyph: .res 2
r_flags: .res 2
r_colors: .res 2
r_font: .res 2
r_screen: .res 2
r_col: .res 1
r_row: .res 1
r_bits: .res 1
r_mask: .res 1
r_priority: .res 1
r_ink: .res 1
r_count: .res 1
r_value: .res 1
r_bg_even: .res 1
r_bg_odd: .res 1
r_bg_color: .res 1
r_x: .res 1
r_out: .res 1
r_phase: .res 1
r_sprite: .res 1
r_sprptr: .res 2
r_source: .res 2
r_stride: .res 2
r_sx: .res 2
r_pen: .res 1
r_byte: .res 1
r_reverse: .res 1
r_limit: .res 1
r_owner: .res 1
r_clock: .res 1
r_collptr: .res 2
r_backfont: .res 1
r_backscreen: .res 1
r_shift: .res 1
r_index: .res 1
r_left: .res 1
r_right: .res 1
r_work: .res 1
r_bgbyte: .res 1
r_bgmask: .res 1
r_bgred: .res 1
r_fgbyte: .res 1
r_fgmask: .res 1
r_choose: .res 1
r_red: .res 1
r_mix: .res 1
r_cacheptr: .res 2
r_cachepage: .res 1
r_bitmap: .res 1
r_bgpass: .res 1
r_bufid: .res 1
r_full: .res 1
.segment "FIXED"
.export render_frame,render_init,r_backfont,r_backscreen
render_init:
    lda #8
    SELECT_BANK
    ldx #0
@tables:
    lda $9800,x
    sta $0400,x
    lda $9900,x
    sta $0500,x
    inx
    bne @tables
    lda #0
    sta $0613
    lda #$20
    sta r_backfont
    lda #$18
    sta r_backscreen
    rts

render_frame:
    ; Reset cell codes and fourth-ink selectors in the back screen.
    lda #0
    sta r_screen
    lda r_backscreen
    sta r_screen+1
    ldx #4
    ldy #0
@screen:
    tya
    and #$7f
    sta (r_screen),y
    iny
    bne @screen
    inc r_screen+1
    dex
    bne @screen
    lda z_video
    and #$10
    beq @visible
    lda #0
    sta r_font
    lda r_backfont
    sta r_font+1
    ldx #28
    ldy #0
    lda #0
@blankframe:
    sta (r_font),y
    iny
    bne @blankframe
    inc r_font+1
    dex
    bne @blankframe
    lda #1
    sta $0614
    sta $0615
    rts
@visible:
    ; Source X scroll is signed but all video indexing wraps modulo 512.
    clc
    lda $effc
    adc #28
    sta r_value
    lda $effd
    adc #0
    lsr a
    lda r_value
    ror a
    sta r_bg_odd
    adc #0
    sta r_bg_even
    ; Color samples use source clock 4*x and therefore ceil(scroll/4).
    lda r_bg_even
    lsr a
    adc #0
    sta r_bg_color
    jsr cache_prepare
    bcs @sprites
    lda #0
    sta r_bgpass
    sta r_y
@background:
    jsr render_addresses
    jsr render_layers
    jsr render_background_line
    inc r_y
    lda r_y
    cmp #224
    bne @background
    jsr cache_capture
@sprites:
    jsr render_active_lines
    lda #1
    sta r_bgpass
    lda #0
    sta r_y
@spriteline:
    ldx r_y
    lda $0700,x
    beq @next
    jsr render_addresses
    jsr render_collision_prepare
    ldx #0
    lda #0
@owners:
    sta $0d00,x
    sta $0e00,x
    inx
    bne @owners
    jsr render_sprite_line
@next:
    inc r_y
    lda r_y
    cmp #224
    bne @spriteline
    lda z_cur_bank
    SELECT_BANK
    rts
render_addresses:
    lda r_y
    and #7
    sta r_font
    lda r_y
    lsr a
    lsr a
    lsr a
    clc
    adc r_backfont
    sta r_font+1
    lda r_y
    and #$38
    asl a
    asl a
    sta r_screen
    lda r_y
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc r_backscreen
    sta r_screen+1
    rts
render_layers:
    lda #$e0
    sta r_page
    lda r_y
    clc
    adc $efbd
    sta r_worldy
    lda #$11
    sta r_flags+1
    lda #0
    sta r_colors
    jsr render_tile_line
    lda #$e8
    sta r_page
    lda r_y
    sta r_worldy
    lda #$12
    sta r_flags+1
    lda #$80
    sta r_colors
    jsr render_tile_line
    rts
render_active_lines:
    ldx #223
    lda #0
@clear:
    sta $0700,x
    dex
    bpl @clear
    ; X must cover all 224 entries, including the unsigned upper half.
    ldx #0
@all:
    sta $0700,x
    inx
    cpx #224
    bne @all
    lda #0
    sta r_sprptr
    lda #$70
    sta r_sprptr+1
    ldx #32
@actor:
    ldy #0
    lda (r_sprptr),y
    cmp #255
    beq @done
    clc
    adc #1
    sta r_value
    iny
    lda (r_sprptr),y
    cmp #223
    bcc :+
    lda #223
:   sta r_limit
    ldy r_value
    cpy #224
    bcs @advance
@span:
    cpy r_limit
    bcc :+
    beq :+
    bcs @advance
:   lda #1
    sta $0700,y
    iny
    bne @span
@advance:
    clc
    lda r_sprptr
    adc #16
    sta r_sprptr
    bcc :+
    inc r_sprptr+1
:   dex
    bne @actor
@done:
    rts

render_tile_line:
    lda #0
    sta r_flags
    lda #$13
    sta r_colors+1
    lda r_worldy
    and #7
    sta r_row
    lda r_worldy
    and #$18
    asl a
    asl a
    asl a
    sta r_tiles
    lda r_worldy
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    ora r_page
    sta r_tiles+1
    lda #0
    sta r_col
@tile:
    ldy #0
    lda (r_tiles),y
    sta r_lookup
    iny
    lda (r_tiles),y
    pha
    and #7
    ora #$80
    sta r_lookup+1
    pla
    and #$18
    ldx r_page
    cpx #$e8
    beq @fgpriority
    asl a
    asl a
    jmp @priority
@fgpriority:
    lsr a
@priority:
    sta r_priority
    lda #8
    SELECT_BANK
    ldy #0
    lda (r_lookup),y
    sta r_glyph
    clc
    lda r_lookup+1
    adc #8
    sta r_lookup+1
    lda (r_lookup),y
    sta r_glyph+1
    clc
    lda r_lookup+1
    adc #8
    sta r_lookup+1
    lda (r_lookup),y
    sta r_ink
    and #$7f
    SELECT_BANK
    ldy r_row
    lda (r_glyph),y
    sta r_bits
    tya
    clc
    adc #8
    tay
    lda (r_glyph),y
    sta r_mask
    ; Keep rows packed. Color and collision masks share the tile lookup.
    ldy r_col
    lda r_bits
    sta (r_flags),y
    tya
    clc
    adc #32
    tay
    lda r_mask
    sta (r_flags),y
    tya
    clc
    adc #32
    tay
    lda r_priority
    sta (r_flags),y
    tya
    clc
    adc #32
    tay
    lda r_ink
    sta (r_flags),y
    clc
    lda r_tiles
    adc #2
    sta r_tiles
    bcc :+
    inc r_tiles+1
:   inc r_col
    lda r_col
    cmp #32
    beq :+
    jmp @tile
:   rts

render_background_line:
    lda #0
    sta r_col
@cell:
    lda r_col
    asl a
    asl a
    sec
    sbc r_bg_color
    and #$7f
    pha
    and #3
    sta r_shift
    pla
    lsr a
    lsr a
    sta r_index
    clc
    adc #1
    and #31
    tax
    lda $1100,x
    sta r_right
    ldx r_index
    lda $1100,x
    sta r_left
    jsr render_shift
    sta r_bgbyte
    lda r_index
    clc
    adc #1
    and #31
    tax
    lda $1120,x
    tax
    lda render_expand,x
    sta r_right
    ldx r_index
    lda $1120,x
    tax
    lda render_expand,x
    sta r_left
    jsr render_shift
    sta r_bgmask
    lda r_index
    clc
    adc #1
    and #31
    tax
    lda $1160,x
    bpl :+
    lda $1100,x
    jsr render_redbits
    jmp :++
:   lda #0
:   sta r_right
    ldx r_index
    lda $1160,x
    bpl :+
    lda $1100,x
    jsr render_redbits
    jmp :++
:   lda #0
:   sta r_left
    jsr render_shift
    sta r_bgred
    ldx r_col
    lda $1200,x
    sta r_fgbyte
    lda $1220,x
    tax
    lda render_expand,x
    sta r_fgmask
    ldx r_col
    lda $1240,x
    and #4
    beq :+
    lda r_fgmask
    jmp @choose
:   lda r_bgmask
    eor #$ff
    and r_fgmask
@choose:
    sta r_choose
    lda r_bgbyte
    eor r_fgbyte
    and r_choose
    eor r_bgbyte
    sta r_out
    lda $1260,x
    bpl :+
    lda r_fgbyte
    jsr render_redbits
    jmp :++
:   lda #0
:   and r_choose
    sta r_red
    lda r_choose
    eor #$ff
    and r_bgred
    ora r_red
    sta r_red
    beq :+
    jsr render_setred
:   ldy r_col
    lda (r_screen),y
    bpl @store
    lda r_out
    jsr render_redbits
    sta r_work
    lda r_red
    eor #$ff
    and r_work
    eor #$ff
    and r_out
    sta r_out
@store:
    lda r_col
    asl a
    asl a
    asl a
    tay
    lda r_out
    sta (r_font),y
    inc r_col
    lda r_col
    cmp #32
    beq :+
    jmp @cell
:   rts
render_shift:
    ldx r_shift
    beq @done
@loop:
    asl r_right
    rol r_left
    asl r_right
    rol r_left
    dex
    bne @loop
@done:
    lda r_left
    rts
render_redbits:
    sta r_work
    asl a
    and r_work
    and #$aa
    rts
render_setred:
    ldy r_col
    lda (r_screen),y
    bmi @done
    ora #$80
    sta (r_screen),y
    ; Preserve contrast: old yellow becomes white when this cell selects red.
    lda #0
    sta r_lookup
    lda r_font+1
    sta r_lookup+1
    lda r_col
    asl a
    asl a
    asl a
    tay
    ldx #8
@row:
    lda (r_lookup),y
    sta r_work
    asl a
    and r_work
    and #$aa
    eor #$ff
    and r_work
    sta (r_lookup),y
    iny
    dex
    bne @row
@done:
    rts
; Input X = original pixel 0..255, A = source clock parity. Output PROM index.
render_getmix:
    sta r_phase
    stx r_x
    txa
    lsr a
    lsr a
    lsr a
    tax
    jsr render_ensure_foreground
    lda r_x
    and #7
    tay
    lda render_pixelbits,y
    sta r_mask
    lda $1220,x
    and r_mask
    beq :+
    lda #0
    beq :++
:   lda #2
:   ora $1240,x
    sta r_mix
    lda r_phase
    bne :+
    lda r_x
    sec
    sbc r_bg_even
    jmp :++
:   lda r_x
    sec
    sbc r_bg_odd
:   sta r_index
    lsr a
    lsr a
    lsr a
    tax
    jsr render_ensure_background
    lda r_index
    and #7
    tay
    lda render_pixelbits,y
    sta r_mask
    lda $1120,x
    and r_mask
    beq :+
    lda #0
    beq :++
:   lda #16
:   ora $1140,x
    ora r_mix
    rts

; Fetch only tile masks actually touched by sprites. A busy sprite scanline
; usually touches a handful of cells, not all 64 cells of both tile planes.
; The mask remains eight original pixels wide: display reduction is irrelevant.
render_collision_prepare:
    ldx #31
    lda #0
@invalidate:
    sta $1180,x
    sta $1280,x
    dex
    bpl @invalidate
    lda r_y
    and #7
    sta r_row
    lda r_y
    and #$18
    asl a
    asl a
    asl a
    sta r_colors
    lda r_y
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    ora #$e8
    sta r_colors+1
    lda r_y
    clc
    adc $efbd
    pha
    and #7
    sta r_worldy
    pla
    pha
    and #$18
    asl a
    asl a
    asl a
    sta r_flags
    pla
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    ora #$e0
    sta r_flags+1
    rts
render_ensure_foreground:
    lda $1280,x
    bne @done
    lda r_colors
    sta r_tiles
    lda r_colors+1
    sta r_tiles+1
    jsr render_fetch_mask
    lda r_priority
    and #$18
    lsr a
    sta $1240,x
    ldy r_row
    iny
    iny
    iny
    iny
    iny
    iny
    iny
    iny
    lda (r_glyph),y
    sta $1220,x
    lda #1
    sta $1280,x
@done:
    rts
render_ensure_background:
    lda $1180,x
    bne @done
    lda r_flags
    sta r_tiles
    lda r_flags+1
    sta r_tiles+1
    jsr render_fetch_mask
    lda r_priority
    and #$18
    asl a
    asl a
    sta $1140,x
    lda r_worldy
    ora #8
    tay
    lda (r_glyph),y
    sta $1120,x
    lda #1
    sta $1180,x
@done:
    rts
render_fetch_mask:
    txa
    asl a
    tay
    lda (r_tiles),y
    sta r_lookup
    iny
    lda (r_tiles),y
    sta r_priority
    and #7
    ora #$80
    sta r_lookup+1
    lda #8
    SELECT_BANK
    ldy #0
    lda (r_lookup),y
    sta r_glyph
    clc
    lda r_lookup+1
    adc #8
    sta r_lookup+1
    lda (r_lookup),y
    sta r_glyph+1
    clc
    lda r_lookup+1
    adc #8
    sta r_lookup+1
    lda (r_lookup),y
    and #$7f
    SELECT_BANK
    rts

render_sprite_line:
    lda #0
    sta r_sprite
    sta r_sprptr
    lda #$70
    sta r_sprptr+1
@sprite:
    ldy #0
    lda (r_sprptr),y
    cmp #255
    bne :+
    rts
:   cmp r_y
    bcc :+
    jmp @nextsprite
:   sta r_value
    iny
    lda (r_sprptr),y
    cmp r_y
    bcs :+
    jmp @nextsprite
:   lda r_y
    sec
    sbc r_value
    sta r_count
    ldy #2
    lda (r_sprptr),y
    sta r_sx
    iny
    lda (r_sprptr),y
    and #1
    sta r_sx+1
    iny
    lda (r_sprptr),y
    sta r_stride
    iny
    lda (r_sprptr),y
    sta r_stride+1
    iny
    lda (r_sprptr),y
    sta r_source
    iny
    lda (r_sprptr),y
    sta r_source+1
@stride:
    clc
    lda r_source
    adc r_stride
    sta r_source
    lda r_source+1
    adc r_stride+1
    sta r_source+1
    dec r_count
    bne @stride
    lda r_source+1
    and #$80
    sta r_reverse
    lda #0
    sta r_limit
@byte:
    lda r_source
    sta r_glyph
    lda r_source+1
    and #$1f
    ora #$80
    sta r_glyph+1
    lda r_source+1
    and #$60
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #11
    SELECT_BANK
    ldy #0
    lda (r_glyph),y
    sta r_byte
    bit r_reverse
    bmi @reverse
    lsr a
    lsr a
    lsr a
    lsr a
    cmp #15
    beq @nextsprite
    jsr render_sprite_pixel
    lda r_byte
    and #15
    cmp #15
    beq @nextsprite
    jsr render_sprite_pixel
    inc r_source
    bne @more
    inc r_source+1
    jmp @more
@reverse:
    and #15
    cmp #15
    beq @nextsprite
    jsr render_sprite_pixel
    lda r_byte
    lsr a
    lsr a
    lsr a
    lsr a
    cmp #15
    beq @nextsprite
    jsr render_sprite_pixel
    lda r_source
    bne :+
    dec r_source+1
:   dec r_source
@more:
    inc r_limit
    beq @nextsprite
    jmp @byte
@nextsprite:
    clc
    lda r_sprptr
    adc #16
    sta r_sprptr
    bcc :+
    inc r_sprptr+1
:   inc r_sprite
    lda r_sprite
    cmp #32
    beq :+
    jmp @sprite
:   rts

render_sprite_pixel:
    sta r_pen
    beq @advance
    lda r_sx+1
    cmp #2
    bcs @advance
    ; Both source clocks must participate in collision detection.
    lda #0
    sta r_clock
    jsr render_collision_clock
    inc r_clock
    jsr render_collision_clock
    ; Mixer selection for the left source clock controls this display sample.
    lda r_sx+1
    lsr a
    lda r_sx
    ror a
    tax
    lda r_sx
    and #1
    bne @odd
    lda #0
    jsr render_getmix
    jmp @mix
@odd:
    lda #1
    jsr render_getmix
@mix:
    tax
    lda $0400,x
    and #3
    bne @advance
    lda r_sprite
    asl a
    asl a
    asl a
    asl a
    ora r_pen
    sta r_lookup
    lda r_sprite
    lsr a
    lsr a
    lsr a
    lsr a
    ora #$d8
    sta r_lookup+1
    ldy #0
    lda (r_lookup),y
    tax
    lda $0500,x
    sta r_value
    jsr render_plot
@advance:
    clc
    lda r_sx
    adc #2
    sta r_sx
    bcc :+
    inc r_sx+1
:   rts

render_collision_clock:
    clc
    lda r_sx
    adc r_clock
    sta r_value
    lda r_sx+1
    adc #0
    cmp #2
    bcc :+
    rts
:   lsr a
    lda r_value
    ror a
    tax
    lda r_value
    and #1
    bne @odd
    lda $0d00,x
    sta r_owner
    lda r_sprite
    clc
    adc #1
    sta $0d00,x
    lda #0
    jsr render_getmix
    jmp @mixer
@odd:
    lda $0e00,x
    sta r_owner
    lda r_sprite
    clc
    adc #1
    sta $0e00,x
    lda #1
    jsr render_getmix
@mixer:
    tax
    lda $0400,x
    sta r_value
    and #4
    bne @sprites
    lda r_value
    and #8
    asl a
    asl a
    ora r_sprite
    tax
    lda #1
    sta $f000,x
    sta z_mixsum
@sprites:
    lda r_owner
    beq @done
    sec
    sbc #1
    cmp r_sprite
    beq @done
    sta r_owner
    lda r_sprite
    and #7
    asl a
    asl a
    asl a
    asl a
    asl a
    ora r_owner
    sta r_collptr
    lda r_sprite
    lsr a
    lsr a
    lsr a
    ora #$f8
    sta r_collptr+1
    ldy #0
    lda #1
    sta (r_collptr),y
    sta z_collsum
@done:
    rts

render_plot:
    lda r_sx+1
    lsr a
    lda r_sx
    ror a
    lsr a
    sta r_x
    and #3
    sta r_phase
    lda r_x
    lsr a
    lsr a
    sta r_col
    jsr cache_mark
    lda r_value
    cmp #4
    bne @ordinary
    jsr render_setred
    lda #3
    jmp @color
@ordinary:
    cmp #3
    bne @color
    ldy r_col
    lda (r_screen),y
    bmi :+
    lda #3
    bne @color
:   lda #1
@color:
    asl a
    asl a
    ora r_phase
    tax
    lda render_inks,x
    sta r_value
    lda r_x
    and #$7c
    asl a
    tay
    ldx r_phase
    lda (r_font),y
    and render_masks,x
    ora r_value
    sta (r_font),y
    rts
render_masks: .byte $3f,$cf,$f3,$fc
render_inks: .byte 0,0,0,0,$40,$10,4,1,$80,$20,8,2,$c0,$30,12,3

render_pixelbits: .byte $80,$40,$20,$10,8,4,2,1
render_expand:
.byte 0
.byte 3
.byte 3
.byte 3
.byte 12
.byte 15
.byte 15
.byte 15
.byte 12
.byte 15
.byte 15
.byte 15
.byte 12
.byte 15
.byte 15
.byte 15
.byte 48
.byte 51
.byte 51
.byte 51
.byte 60
.byte 63
.byte 63
.byte 63
.byte 60
.byte 63
.byte 63
.byte 63
.byte 60
.byte 63
.byte 63
.byte 63
.byte 48
.byte 51
.byte 51
.byte 51
.byte 60
.byte 63
.byte 63
.byte 63
.byte 60
.byte 63
.byte 63
.byte 63
.byte 60
.byte 63
.byte 63
.byte 63
.byte 48
.byte 51
.byte 51
.byte 51
.byte 60
.byte 63
.byte 63
.byte 63
.byte 60
.byte 63
.byte 63
.byte 63
.byte 60
.byte 63
.byte 63
.byte 63
.byte 192
.byte 195
.byte 195
.byte 195
.byte 204
.byte 207
.byte 207
.byte 207
.byte 204
.byte 207
.byte 207
.byte 207
.byte 204
.byte 207
.byte 207
.byte 207
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 192
.byte 195
.byte 195
.byte 195
.byte 204
.byte 207
.byte 207
.byte 207
.byte 204
.byte 207
.byte 207
.byte 207
.byte 204
.byte 207
.byte 207
.byte 207
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 192
.byte 195
.byte 195
.byte 195
.byte 204
.byte 207
.byte 207
.byte 207
.byte 204
.byte 207
.byte 207
.byte 207
.byte 204
.byte 207
.byte 207
.byte 207
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 240
.byte 243
.byte 243
.byte 243
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255
.byte 252
.byte 255
.byte 255
.byte 255

.export render_init,render_frame,render_tile_line,render_background_line,render_shift,render_redbits,render_setred,render_getmix,render_sprite_line,render_sprite_pixel,render_collision_clock,render_plot,render_masks,render_inks,render_pixelbits,render_expand
