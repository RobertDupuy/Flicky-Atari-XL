#!/usr/bin/env python3
"""Convert verified artwork to ANTIC 4 glyphs; retain original collision masks."""
import json
import numpy as np
from build import ROOT,BUILD
from run_reference import Reference

def color(v):
    r=(int(v)&7)*255/7;g=(int(v)>>3&7)*255/7;b=(int(v)>>6)*255/3
    if r+g+b<150:return 0
    if min(r,g,b)>120 and max(r,g,b)-min(r,g,b)<120:return 1
    if b>r*1.2 and b>g*.85:return 2
    if r>g*1.6 and r>90:return 4
    if g>r*1.5:return 0
    if r+g>2*b+90:return 3
    return 1

def main():
    r=Reference()
    for f in range(601):
        system=254 if 180<=f<190 else 239 if 210<=f<220 else 255
        p1=255
        if f>=300:
            p1&=~(0x40 if f%240<120 else 0x80)
            if f%90<40:p1&=~4
        r.frame(p1,system)
    palette=r.ram[0xdc00:0xde00]
    records=[];unique={};indices=[];inks=[]
    for code,tile in enumerate(r.tiles):
        pixels=np.array([[color(palette[(code//32)*8+int(c)]) for c in row] for row in tile])
        ink=int(np.any(pixels==4) and not np.any(pixels==3))
        if ink:
            pixels[pixels==3]=1
            pixels[pixels==4]=3
        else:
            pixels[pixels==4]=1
        glyph=[];mask=[]
        for y in range(8):
            value=0;opaque=0
            for x in range(8):opaque=(opaque<<1)|int(tile[y,x]!=0)
            for x in range(4):
                left=int(pixels[y,x*2]);right=int(pixels[y,x*2+1])
                value=(value<<2)|(left or right)
            glyph.append(value);mask.append(opaque)
        record=bytes(glyph+mask)
        if record not in unique:unique[record]=len(records);records.append(record)
        indices.append(unique[record]);inks.append(ink)
    assert len(records)<=1024, 'Glyph bank allocation needs expansion'
    tables=bytearray(8192);glyphs=b''.join(records)
    for code,idx in enumerate(indices):
        addr=0x8000+(idx*16&8191)
        tables[code]=addr&255;tables[2048+code]=addr>>8
        tables[4096+code]=9+idx//512+(inks[code]<<7)
    # PROM and color projection are ROM tables, not approximated collision rules.
    tables[6144:6400]=(ROOT/'private-roms/lookup_proms.bin').read_bytes()
    tables[6400:6656]=bytes(color(v) for v in range(256))
    (BUILD/'tile-index.bin').write_bytes(tables)
    (BUILD/'tile-glyphs.bin').write_bytes(glyphs)
    (BUILD/'assets.json').write_text(json.dumps({'unique_glyphs':len(records),'glyph_bytes':len(glyphs),'colors':['black','white','blue','yellow','red'],'collision_masks':'original 8-pixel resolution'},indent=2))
    print('Graphics:',len(records),'unique glyph/mask records,',len(glyphs),'bytes')
if __name__=='__main__':main()
