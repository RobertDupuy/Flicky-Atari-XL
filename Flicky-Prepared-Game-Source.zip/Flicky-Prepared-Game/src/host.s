; Atari presentation and input. NMI restores the bank and every CPU register.
; Audio scratch is private. Held joystick levels are sampled on every host VBI.
h_front = $0600
h_pending = $0601
h_band = $0602
h_vbis = $0603
h_player = $0604
h_fire = $0605
h_request = $0606
h_lastconsole = $0607
h_console = $0608
h_sequence = $0609
h_coin = $060a
h_startmask = $060b
h_player2 = $060c
h_fire2 = $060d
.segment "FIXED"
.export host_init,host_present,host_nmi,host_controls
host_init:
    ldx #31
    lda #0
@state:
    sta $0600,x
    dex
    bpl @state
    lda #7
    sta h_lastconsole
    lda #$ff
    sta h_player
    sta h_player2
    lda #0
    sta z_host
    lda #$18
    sta z_host+1
    ldy #0
    lda #0
@clear:
    sta (z_host),y
    iny
    bne @clear
    inc z_host+1
    ldx z_host+1
    cpx #$5c
    bne @clear
    jsr render_init
    lda #$20
    sta h_front
    sta h_band
    sta $d409
    ldx #0
@dl:
    lda host_dl0,x
    sta $1500,x
    lda host_dl1,x
    sta $1540,x
    inx
    cpx #host_dl_end-host_dl1
    bne @dl
    lda #0
    sta $d402
    sta $d401
    sta $d01b
    sta $d01d
    sta $d01a
    lda #$15
    sta $d403
    lda #$0e
    sta $d016
    lda #$9a
    sta $d017
    lda #$2c
    sta $d018
    lda #$38
    sta $d019
    lda #<host_nmi
    sta $fffa
    lda #>host_nmi
    sta $fffb
    lda #$21
    sta $d400
    jsr audio_init
    lda #$c0
    sta $d40e
    rts
host_present:
    jsr render_frame
    lda #1
    sta h_pending
@wait:
    lda h_pending
    bne @wait
    lda r_backfont
    eor #$60
    sta r_backfont
    lda r_backscreen
    eor #4
    sta r_backscreen
host_controls:
    lda h_player
    ldx h_fire
    beq :+
    and #$fb
:   sta z_p1
    lda #0
    sta h_fire
    lda h_player2
    ldx h_fire2
    beq :+
    and #$fb
:   sta z_p2
    lda #0
    sta h_fire2
    ; Upright arcade mode uses port 1 for both turns. Permit controller 2 on
    ; player 2's turn while retaining controller 1 for a shared-controller game.
    lda $c001
    and #1
    beq :+
    lda z_p1
    and z_p2
    sta z_p1
:   
    lda z_pc+1
    cmp #7
    bne @defer
    lda z_pc
    cmp #$68
    bne @defer
    lda h_request
    and #1
    beq :+
    lda #24
    sta h_sequence
    lda #$ef
    sta h_startmask
:   lda h_request
    and #2
    beq :+
    lda #40
    sta h_sequence
    lda #$df
    sta h_startmask
:   lda h_request
    and #4
    beq :+
    lda #8
    sta h_coin
:   lda #0
    sta h_request
@defer:
    lda #$ff
    ldx h_coin
    beq @sequence
    dec h_coin
    lda #$fe
@sequence:
    ldx h_sequence
    beq @input
    dec h_sequence
    cpx #33
    bcs @coin
    cpx #25
    bcs @input
    cpx #17
    bcs @coin
    cpx #9
    bcs @input
    lda h_startmask
    bne @input
@coin:
    lda #$fe
@input:
    sta z_system
    rts
host_nmi:
    pha
    lda $d40f
    bpl :+
    jmp @dli
:   txa
    pha
    tya
    pha
    inc h_vbis
    lda h_pending
    beq @noflip
    lda r_backfont
    sta h_front
    lda r_backscreen
    cmp #$18
    beq :+
    lda #$40
    bne :++
:   lda #0
:   sta $d402
    lda #0
    sta h_pending
@noflip:
    ; Reassert both DLIST bytes each VBI. ANTIC advances this register while
    ; fetching the list; a buffer exchange must not inherit its old JVB pointer.
    lda h_front
    and #$40
    sta $d402
    lda #$15
    sta $d403
    lda h_front
    sta h_band
    sta $d409
    lda #$ff
    sta h_player
    lda $d300
    and #4
    bne :+
    lda h_player
    and #$7f
    sta h_player
:   lda $d300
    and #8
    bne :+
    lda h_player
    and #$bf
    sta h_player
:   lda $d010
    bne :+
    lda h_player
    and #$fb
    sta h_player
    lda #1
    sta h_fire
:   lda #$ff
    sta h_player2
    lda $d300
    and #$40
    bne :+
    lda h_player2
    and #$7f
    sta h_player2
:   lda $d300
    and #$80
    bne :+
    lda h_player2
    and #$bf
    sta h_player2
:   lda $d011
    bne :+
    lda h_player2
    and #$fb
    sta h_player2
    lda #1
    sta h_fire2
:   lda $d01f
    sta h_console
    eor #$ff
    and h_lastconsole
    and #7
    ora h_request
    sta h_request
    lda h_console
    sta h_lastconsole
    jsr audio_vbi
    pla
    tay
    pla
    tax
    pla
    rti
@dli:
    clc
    lda h_band
    adc #4
    sta h_band
    sta $d40a
    sta $d409
    pla
    rti
.macro GAME_DL screen, self
    .byte $70,$70,$44
    .word screen
    .repeat 27,I
        .if ((I+2) .mod 4)=0 .and I<23
            .byte $84
        .else
            .byte 4
        .endif
    .endrepeat
    .byte $41
    .word self
.endmacro
host_dl0: GAME_DL $1800,$1500
host_dl1: GAME_DL $1c00,$1540
host_dl_end:
