"""Capture actual cartridge screens using diagnostic level selection.

No mockups: the emulator runs the normal round loader and ANTIC/GTIA output.
"""
import argparse,json,time
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from native_engine import Engine
from raster_probe import Session

def contact_sheet(paths,out,columns=4,thumb=(336,240)):
    w,h=thumb; sheet=Image.new('RGB',(columns*w,((len(paths)+columns-1)//columns)*(h+30)),(16,20,28))
    draw=ImageDraw.Draw(sheet)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    for i,p in enumerate(paths):
        x=(i%columns)*w;y=(i//columns)*(h+30)
        im=Image.open(p);im.thumbnail(thumb,Image.Resampling.NEAREST)
        sheet.paste(im,(x+(w-im.width)//2,y))
        draw.text((x+12,y+h+5),p.stem.replace('-',' ').upper(),font=font,fill='white')
    sheet.save(out)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['pal','ntsc'],required=True)
    ap.add_argument('--cartridge',type=Path,required=True);ap.add_argument('--labels',type=Path)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--rounds',default='1-48')
    a=ap.parse_args(); n=Engine(a.cartridge,a.labels);s=Session(a.cartridge,a.output,a.mode)
    rounds=[]
    for part in a.rounds.split(','):
        if '-' in part:
            start,end=map(int,part.split('-'));rounds+=list(range(start,end+1))
        else:rounds.append(int(part))
    paths=[]
    try:
        load=n.labels['game_round_load']
        # Intro playback can have the upper ROM window mapped. Expose the
        # shared kernel before entering the normal round-loader diagnostic.
        code=bytes([0xa9,0x60,0x8d,0x1f,6,0x8d,0,0xd5,
                    0x20,load&255,load>>8,0xa9,1,0x8d,0x8f,6,0x4c,0xf0,5])
        for r in rounds:
            s.monitor(['c 05f0 4c f0 05',f'c {n.labels["n_round"]:04x} {r-1:02x}',
                'c 05d0 '+code[:16].hex(' '),'c 05e0 '+code[16:].hex(' '),'cont 05d0'],resume=False)
            time.sleep(1.5)
            path=a.output/f'round-{r:02d}.png';s.capture().save(path);paths.append(path)
            print(f'{a.mode} round {r:02d}',flush=True)
        contact_sheet(paths,a.output/'all-rounds.png')
        (a.output/'capture.json').write_text(json.dumps(dict(mode=a.mode,diagnostic_level_selection=True,
            rounds=rounds,source='Atari800 ANTIC/GTIA cartridge output'),indent=2)+'\n')
    finally:s.close()

if __name__=='__main__':main()
