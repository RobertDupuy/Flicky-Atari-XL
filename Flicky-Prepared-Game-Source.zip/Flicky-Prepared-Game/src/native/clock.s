; Exact rational arcade/host clocks. The interrupt produces timed input records;
; the game consumes every record, including when drawing spans host frames.
c_produced=$0680
c_consumed=$0682
c_phase=$0684
c_step=$0687
c_denominator=$068a
c_overflow=$068d
c_peak=$068e
c_paused=$068f
c_inputs=$1a00
.segment "FIXED"
.export clock_init,clock_vbi,clock_take_tick,c_produced,c_consumed,c_phase,c_overflow,c_peak
clock_init:
    lda #0
    ldx #15
@clear:
    sta $0680,x
    dex
    bpl @clear
    lda $d014
    and #$0e
    beq @pal
    lda #<26933
    sta c_step
    lda #>26933
    sta c_step+1
    lda #<(9306817)
    sta c_denominator
    lda #>(9306817)
    sta c_denominator+1
    lda #^(9306817)
    sta c_denominator+2
    rts
@pal:
    lda #<145621
    sta c_step
    lda #>145621
    sta c_step+1
    lda #^145621
    sta c_step+2
    lda #<709379
    sta c_denominator
    lda #>709379
    sta c_denominator+1
    lda #^709379
    sta c_denominator+2
    rts
clock_vbi:
    jsr clock_produce
    clc
    lda c_phase
    adc c_step
    sta c_phase
    lda c_phase+1
    adc c_step+1
    sta c_phase+1
    lda c_phase+2
    adc c_step+2
    sta c_phase+2
    cmp c_denominator+2
    bcc @done
    bne @extra
    lda c_phase+1
    cmp c_denominator+1
    bcc @done
    bne @extra
    lda c_phase
    cmp c_denominator
    bcc @done
@extra:
    sec
    lda c_phase
    sbc c_denominator
    sta c_phase
    lda c_phase+1
    sbc c_denominator+1
    sta c_phase+1
    lda c_phase+2
    sbc c_denominator+2
    sta c_phase+2
    jmp clock_produce
@done:
    rts
clock_produce:
    lda c_paused
    beq :+
    rts
:   
    sec
    lda c_produced
    sbc c_consumed
    cmp c_peak
    bcc :+
    sta c_peak
:   cmp #64
    bcc @queue
    lda #1
    sta c_overflow
@queue:
    lda c_produced
    and #63
    tax
    lda r_input
    sta c_inputs,x
    inc c_produced
    bne :+
    inc c_produced+1
:   rts
clock_take_tick:
    lda c_produced
    cmp c_consumed
    bne @take
    lda c_produced+1
    cmp c_consumed+1
    bne @take
    lda #0
    rts
@take:
    lda c_consumed
    and #63
    tax
    lda c_inputs,x
    sta n_input
    inc c_consumed
    bne :+
    inc c_consumed+1
:   lda #1
    rts
