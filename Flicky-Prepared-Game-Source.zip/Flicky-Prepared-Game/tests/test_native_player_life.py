"""Native enemy death decisions and timing against the original routines."""
import json,random,subprocess,sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine
from native_oracle import Original

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    e=Engine()
    yield e
    (BUILD/'native/player-life-cycles.json').write_text(json.dumps(e.maximum,indent=2)+'\n')


def test_cat_contact_response_matches_original_bounds_and_priority(native):
    o=Original();r=random.Random(0x3ac9)
    fields=[('n_flags',8,0xc400),('n_timer',8,0xc416),('n_frame',8,0xc40d),
            ('n_cycle',8,0xc417),('n_pose',8,0xc406),('n_frozen',0,0xc029)]
    for trial in range(8192):
        o.ram[0xc000:]=0;native.call('native_reset')
        flags=0x80|(4 if r.randrange(16)==0 else 0)
        for (name,index,address),value in zip(fields,[flags,r.randrange(256),r.randrange(4),r.randrange(24),1,r.randrange(2)]):
            native.set(name,value,index);o.ram[address]=value
        for name,address,value in [('n_bonus',0xc02c,int(r.randrange(32)==0)),('n_exiting',0xc028,int(r.randrange(32)==0))]:
            native.set(name,value);o.ram[address]=value
        y=r.randrange(256);native.set('n_ylo',y,8);o.ram[0xc409]=y
        world=r.randrange(65536);native.set('n_world',world);native.set('n_world',world>>8,1)
        contacts=r.randrange(4);native.set('n_player_enemy',contacts)
        for actor in (9,10):
            base=0xc300+actor*32;x=r.randrange(240,272);wy=r.choice([r.randrange(256),(y+r.randrange(-16,17))&255])
            native.set('n_xlo',x-world,actor);native.set('n_xhi',(x-world)>>8,actor)
            o.ram[base+7:base+9]=[x&255,x>>8]
            for name,offset,value in [('n_ylo',9,wy),('n_pause',6,int(r.randrange(8)==0)),('n_chick_state',26,16*int(r.randrange(8)==0))]:
                native.set(name,value,actor);o.ram[base+offset]=value
            o.ram[0xf800+actor*32+8]=(contacts>>(actor-9))&1
        o.call(0x39b8,ix=0xc400,stop=0x43a4)
        native.call('player_enemy_response')
        for name,index,address in fields:
            assert native.get(name,index)==o.ram[address],(trial,name,contacts,y)
        expected=int(o.ram[0xf928])|int(o.ram[0xf948])<<1
        assert native.get('n_player_enemy')==expected
        if not flags&4 and native.get('n_flags',8)&4:
            assert native.get('n_animation',8)==5
            assert native.get('n_sound_event')==0x86


def test_grounded_death_frames_and_enemy_hiding_match_original(native):
    o=Original();r=random.Random(0x3537)
    for trial in range(32):
        o.ram[0xc000:]=0;native.call('native_reset')
        o.ram[0xc021]=1;o.ram[0xc400]=0x84
        o.ram[0xc401:0xc403]=[0x98,0x34];o.ram[0xc406]=1
        native.set('n_flags',0x84,8);native.set('n_cycle',0,8)
        native.set('n_animation',5,8);native.set('n_pose',1,8)
        for a in (9,10,11,24,25,26):
            flags=r.randrange(256);o.ram[0xc300+a*32]=flags;native.set('n_flags',flags,a)
        for tick in range(96):
            o.call(0x3537,ix=0xc400,stop=0x092e if tick==95 else 0x43a4)
            native.call('player_death_update')
            for name,offset in [('n_flags',0),('n_timer',22),('n_cycle',23),('n_frame',13)]:
                assert native.get(name,8)==o.ram[0xc400+offset],(trial,tick,name)
            for a in (9,10,11,24,25,26):
                assert native.get('n_flags',a)==o.ram[0xc300+a*32],(trial,tick,a)
            assert native.get('n_life_lost')==int(tick==95)


def test_life_restart_preserves_rescues_score_and_chick_world_positions(native):
    native.call('native_reset');native.call('level_load');native.call('chicks_reset')
    native.call('display_init');native.call('idle_reset')
    native.set('n_world',0x71);native.set('n_world',0xb3,1)
    native.set('n_score',0x45);native.set('n_score',0x23,1);native.set('n_score',1,2)
    native.ram[0x07ee]=1  # The injected 12,345-point score already earned its extra life.
    native.set('n_rescued',0x53);native.set('n_lives',2)
    for actor in range(8):
        native.set('n_xlo',17+actor*23,actor);native.set('n_xhi',actor&1,actor)
        native.set('n_ylo',40+actor*18,actor)
        native.set('n_flags',0x30 if 0x53&(1<<actor) else 0xb0,actor)
        native.set('n_chick_state',0,actor)
    saved={name:[native.get(name,a) for a in range(8)] for name in ('n_xlo','n_xhi','n_ylo','n_flags')}
    native.set('n_life_lost',1);native.set('n_frozen',1)
    assert native.call('game_flow_tick')==0
    assert native.get('n_lives')==1 and native.get('n_flow')==1
    for _ in range(55):assert native.call('game_flow_tick')==0
    assert native.get('n_flow_wait')==0
    native.call('game_flow_tick')
    assert native.get('n_flow')==0 and native.get('n_lives')==1
    assert native.get('n_rescued')==0x53
    assert [native.get('n_score',a) for a in range(3)]==[0x45,0x23,1]
    for name,values in saved.items():
        # Idle facing is staggered by actor; alive/rescued status is retained.
        mask=0xfe if name=='n_flags' else 0xff
        assert [native.get(name,a)&mask for a in range(8)]==[v&mask for v in values],name
    assert (native.get('n_world'),native.get('n_world',1))==(0xf8,1)
    assert native.get('n_flags',8)==0x80 and native.get('n_frozen')==0
    assert native.get('r_fault')==0


def test_round_completion_awards_time_bonus_and_loads_next_map(native):
    native.call('native_reset');native.call('level_load');native.call('chicks_reset');native.call('display_init')
    native.set('n_round_complete',1);native.set('n_rescued',255);native.set('n_flags',0,23)
    native.set('n_round_seconds',34);native.set('n_round_seconds',0,1)
    assert native.call('game_flow_tick')==0
    assert native.get('n_flow')==2
    assert [native.get('n_score',a) for a in range(3)]==[0,5,0]
    for _ in range(240):native.call('game_flow_tick')
    native.call('game_flow_tick')
    assert native.get('n_round')==1 and native.get('n_flow')==0
    assert native.get('n_rescued')==0x11 and native.get('n_lives')==3
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    assert native.ram[0xc000:0xc700].tobytes()==maps[1792:3584]
    assert native.get('n_round_seconds')==native.get('n_round_seconds',1)==0


def test_game_over_requires_release_then_press_to_start_new_game(native):
    native.call('native_reset');native.set('n_lives',1);native.set('n_life_lost',1)
    native.set('n_input',251);native.set('n_score',99)
    native.call('game_flow_tick')
    assert native.get('n_flow')==3 and native.get('n_lives')==0
    for _ in range(130):native.call('game_flow_tick')
    assert native.get('n_flow')==3
    native.set('n_input',255);native.call('game_flow_tick')
    native.set('n_input',251);native.call('game_flow_tick')
    assert native.get('n_flow')==0 and native.get('n_lives')==3
    assert native.get('n_round')==0 and native.get('n_score')==0


def test_live_game_contact_reaches_death_and_life_transition(native):
    native.call('native_reset');native.call('level_load');native.call('chicks_reset')
    native.call('display_init');native.call('idle_reset')
    native.set('n_flags',0xb0,9);native.set('n_pause',0,9);native.set('n_chick_state',0,9)
    native.set('n_animation',0,9);native.set('n_ylo',native.get('n_ylo',8),9)
    native.set('n_xlo',8,9);native.set('n_xhi',255,9)
    native.call('enemy_contacts')
    assert native.get('n_player_enemy')&1
    world=(native.get('n_world'),native.get('n_world',1))
    native.call('game_update')
    assert native.get('n_flags',8)&4 and native.get('n_frozen')==1
    for _ in range(160):
        assert (native.get('n_world'),native.get('n_world',1))==world
        if native.get('n_flow'):break
        native.call('game_update')
    assert native.get('n_flow')==1 and native.get('n_lives')==2
