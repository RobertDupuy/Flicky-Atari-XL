"""Exact twelve-row bonus birds, with prepared columns and occupancy flags."""
def build(out):
    lines=['.segment "BANK31"'];names=[];flags=[[] for _ in range(8)]
    for art in range(8):
        for phase in range(4):
            raw=(out/f'arcade-bonus-art-{art:02d}-{phase}.bin').read_bytes()
            h,w,_,span=raw[:4];assert h<=12 and w<=2
            p=int.from_bytes(raw[4:6],'little');data=bytearray()
            for col in range(2):
                a=p+col*span*2
                mask=raw[a+7:a+7+h] if col<w else bytes([255]*h)
                bits=raw[a+span+7:a+span+7+h] if col<w else bytes(h)
                data+=bytes([255]*7)+mask+bytes([255]*(19-h))
                data+=bytes(7)+bits+bytes(19-h)
            name=f'arcade-bonus-strip-{art}-{phase}.bin';(out/name).write_bytes(data)
            label=f'ab_strip_{art}_{phase}';names.append(label)
            lines += [f'{label}: .incbin "{name}"']
            for py in range(8):
                f=0
                for row in range(3):
                    for col in range(2):
                        a=col*52+7-py+row*8
                        if any(v!=255 for v in data[a:min(a+8,col*52+26)]):f|=1<<(row*2+col)
                flags[py].append(f)
    lines += ['ab_strip_lo: .lobytes '+','.join(names),'ab_strip_hi: .hibytes '+','.join(names),'ab_strip_flags:']
    for row in flags:lines+=['.byte '+','.join(map(str,row))]
    (out/'arcade-bonus-stamps-data.s').write_text('\n'.join(lines)+'\n')
