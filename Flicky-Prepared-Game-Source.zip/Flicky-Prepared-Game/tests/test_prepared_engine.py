"""Check the replacement renderer against converted pixels, not its own tables."""
import sys,json
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import BUILD

@pytest.fixture(scope='module')
def n():
    e=Engine();e.lib.at_video_timing(0);e.call('native_reset');e.call('game_round_load');e.set('u_mode',0)
    return e

def raw_pixels(kind,index,meta):
    p=BUILD/'native';d=json.loads((p/f'{kind}-assets.json').read_text())
    prefix='object-pixels' if kind=='object' else kind+'-image'
    raw=(p/f'{prefix}-{d["images"][index]:03d}.bin').read_bytes();h,w=raw[:2]
    width=(meta['width']+1)//2
    phase=meta['phase']
    return np.array([[raw[4+2*(y*w+(x+phase)//4)]>>(6-2*((x+phase)&3))&3 for x in range(width)]for y in range(h)],dtype=np.uint8)

def test_player_hardware_planes_preserve_three_colors_and_clear_old_pose(n):
    d=json.loads((BUILD/'native/player-assets.json').read_text());cases=0;maxcycles=0
    for i,m in enumerate(d['records']):
        if m['phase']:continue
        n.set('n_flags',0x80|m['facing'],8);n.set('n_animation',m['animation'],8);n.set('n_frame',m['frame'],8)
        n.set('n_ylo',60+(cases*13)%130,8);n.set('n_pose',m['animation'],8)
        n.set('n_flags',0xb0,9);n.set('n_flags',0xb1,10)
        n.set('n_animation',cases%18,9);n.set('n_animation',(cases+5)%18,10)
        n.set('n_ylo',120,9);n.set('n_ylo',140,10)
        n.set('r_front',n.get('r_back'));n.call('pmg_prepare');start=n.lib.at_cycles();n.call('pmg_present');maxcycles=max(maxcycles,n.lib.at_cycles()-start)
        pixels=raw_pixels('player',i,m)
        if pixels.shape[1]>8:pixels=pixels[:,[round(x*(pixels.shape[1]-1)/7)for x in range(8)]]
        canvas=np.zeros((256,256),dtype=np.uint8)
        for plane,color in ((0,2),(1,1)):
            xpos=int(n.ram[0xd000+plane]);bits=n.ram[0xdc00+plane*256:0xdd00+plane*256]
            for y,v in enumerate(bits):
                for x in range(8):
                    if int(v)&(128>>x):canvas[y,xpos+x]=color
        for y,v in enumerate(n.ram[0xdb00:0xdc00]):
            for missile in range(4):
                xpos=int(n.ram[0xd004+missile])
                for x in range(2):
                    if int(v)&((2>>x)<<(2*missile)):canvas[y,xpos+x]=3
        radius=n.get('native_player_radius',m['animation'])
        left=(256-radius)//4+64;top=n.get('pm_y')
        expected=np.zeros_like(canvas);expected[top:top+pixels.shape[0],left:left+pixels.shape[1]]=pixels
        assert np.array_equal(canvas,expected),(m,np.argwhere(canvas!=expected)[:10])
        start=n.lib.at_cycles();n.call('pmg_present');assert n.lib.at_cycles()-start<500
        cases+=1
    assert cases==48

def test_every_prop_rotation_and_alignment_has_prepared_pixels(n):
    d=json.loads((BUILD/'native/object-assets.json').read_text())
    for i,m in enumerate(d['records']):
        kind=m['animation']//6;flip=(m['animation']//3)&1;frame=m['animation']%3
        pixels=raw_pixels('object',i,m);h,w=pixels.shape;oh=min(h,10);ow=min(w,5)
        resized=pixels[[round(y*(h-1)/max(1,oh-1))for y in range(oh)]][:,[round(x*(w-1)/max(1,ow-1))for x in range(ow)]]
        for py in (0,2,4,6):
            back=(i+py)&1;n.set('r_back',back);n.call('fast_sprites_begin')
            n.set('n_flags',0x80|m['facing']|flip*2,12);n.set('n_animation',kind,12);n.set('n_frame',frame,12)
            left=16*9+m['phase']*4;radius=n.get('native_object_radius_draw',kind)
            pos=left+radius;n.set('n_xlo',pos,12);n.set('n_xhi',pos>>8,12)
            top=88+py;n.set('n_ylo',top+h//2-1,12)
            n.call('prepared_object',x=12)
            expected=np.zeros((16,8),dtype=np.uint8);expected[py:py+oh,m['phase']:m['phase']+ow]=resized
            actual=np.zeros_like(expected)
            for cy in range(2):
                band=((top//8)+cy)//4
                for cx in range(2):
                    code=int(n.ram[0x6000+back*4096+(top//8+cy)*96+9+cx])&127
                    glyph=0x2000+back*0x2000+band*1024+code*8
                    for y,v in enumerate(n.ram[glyph:glyph+8]):
                        for x in range(4):actual[cy*8+y,cx*4+x]=int(v)>>(6-x*2)&3
            assert np.array_equal(actual,expected),(i,py,m)
            assert n.get('r_fault')==0
            n.set('r_dirty_counts',int(n.ram[0x8d])&127,back)

def test_full_scene_front_buffer_isolation_and_bounded_render(n):
    n.call('game_round_load');n.set('u_mode',0)
    cycles=[]
    for frame in range(240):
        back=frame&1;n.set('r_back',back)
        front=n.ram[0x2000+(back^1)*8192:0x3c00+(back^1)*8192].copy()
        pmfront=0x0b00 if back else 0xdb00
        hardware_front=n.ram[pmfront:pmfront+1280].copy()
        for a in range(8):
            x=(frame*7+a*37)&511
            for k,v in [('n_flags',0xb0|(frame&1)),('n_chick_state',1),('n_xlo',x),('n_xhi',x>>8),('n_ylo',45+(a*23+frame)%140),('n_animation',(frame+a)%9)]:n.set(k,v,a)
        for a in (9,10):
            for k,v in [('n_flags',0xb0|(frame&3)),('n_animation',frame%18),('n_ylo',55+(frame+a*19)%120)]:n.set(k,v,a)
        for a in (range(12,18) if n.labels['PAL_MULTI_PROP'] else (12,13)):
            for k,v in [('n_chick_state',128),('n_flags',0xb0|(frame&3)),('n_animation',(frame+a)%15),('n_frame',frame%3),('n_xlo',frame*7+a*19),('n_ylo',70+(frame+a*17)%120)]:n.set(k,v,a)
        start=n.lib.at_cycles();n.call('native_render_submit');cycles.append(n.lib.at_cycles()-start)
        assert (n.ram[0x2000+(back^1)*8192:0x3c00+(back^1)*8192]==front).all()
        assert n.get('r_fault')==0
        assert np.array_equal(hardware_front,n.ram[pmfront:pmfront+1280])
        assert sum(n.get('r_dirty_counts',b)for b in (0,1))<128
    assert max(cycles)<(42000 if n.labels['PAL_MULTI_PROP'] else 28000)
    (BUILD/'native/prepared-render-verification.json').write_text(json.dumps({'frames':len(cycles),'median_bare_cycles':int(np.median(cycles)),'maximum_bare_cycles':max(cycles),'actors':17 if n.labels['PAL_MULTI_PROP'] else 13,'front_buffer_isolation':True},indent=2)+'\n')


def test_all_cat_poses_fit_hardware_and_keep_visible_details(n):
    d=json.loads((BUILD/'native/cat-assets.json').read_text());n.set('n_flags',0,8);n.set('n_flags',0,10)
    for i,m in enumerate(d['records']):
        if m['phase']:continue
        n.set('r_back',m['facing']);n.set('r_front',m['facing']);n.set('n_world',0);n.set('n_world',0,1)
        for k,v in [('n_flags',0x80|m['facing']),('n_animation',m['animation']),('n_xlo',160),('n_xhi',0),('n_ylo',100)]:n.set(k,v,9)
        n.call('pmg_prepare');n.call('pmg_present')
        pix=raw_pixels('cat',i,m);h,w=pix.shape
        active=(pix==1)|(pix==3);occupied=np.nonzero(active)[1]
        start=int(min(occupied,default=0))
        if w>8:columns=[round(x*(w-1)/7)for x in range(8)];start=(w-8)//2
        else:columns=list(range(start,start+8))
        expected=np.zeros(256,dtype=np.uint8);top=n.get('pm_y',2)
        expected[top:top+h]=[sum(128>>b for b,x in enumerate(columns)if x<w and active[y,x]) for y in range(h)]
        base=0x0e00 if m['facing']==0 else 0xde00
        assert np.array_equal(expected,n.ram[base:base+256]),m
        assert n.ram[0xd002]==((160-n.get('native_cat_radius',m['animation']))//4+64+start)
