; Fixed glyph destinations. All phases, scaling and color selection are baked.
; Four characters per bird, two-scanline vertical steps. Masked cell writes
; preserve uncovered scenery and previously drawn birds beneath each pose.
s_data=$da
s_bank=$dc
s_right=$dd
s_right_bank=$df
s_code=$e0
s_font_index=$e1
s_cell=$e2
s_occupied=$e3
s_phase=$e4
s_index=$e5
s_left_mask=$e6
s_right_mask=$e8
s_writer_bank=$ea
s_screen_column=$eb
.segment "FIXED"
.export fast_draw_chicks
fast_draw_chicks:
    lda #0
    sta n_actor_cursor
@actor:
    ldx n_actor_cursor
    lda n_flags,x
    bpl @next
    lda i_active
    and pickup_bits,x
    bne @next
    jsr fast_draw_chick
@next:
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #8
    bcc @actor
    rts
fast_draw_chick:
    stx p_actor
    lda n_ylo,x
    clc
    adc n_draw_yoffset,x
    sec
    sbc #4
    and #$fe
    sta p_y
    cmp #216
    bcc :+
    rts
:   ldy n_animation,x
    sec
    lda n_xlo,x
    sbc native_chick_radius,y
    sta p_left
    lda n_xhi,x
    sbc #0
    and #1
    sta p_left+1
    lda p_left
    lsr a
    lsr a
    and #3
    sta s_index
    tya
    .repeat 4
        asl a
    .endrepeat
    ora s_index
    sta s_index
    lda n_frame,x
    and #1
    asl a
    asl a
    asl a
    ora s_index
    sta s_index
    lda n_flags,x
    and #1
    asl a
    asl a
    ora s_index
    tax
    lda p_y
    and #6
    beq @phase0
    cmp #2
    beq @phase1
    cmp #4
    beq @phase2
    jmp fast_chick_load_3
@phase2:
    jmp fast_chick_load_2
@phase1:
    jmp fast_chick_load_1
@phase0:
    jmp fast_chick_load_0
stamp_draw:
    lda s_bank
    NATIVE_BANK
    lda p_y
    and #6
    eor #6
    sta s_phase
    lda s_data
    sta n_src
    lda s_data+1
    sta n_src+1
    ldy #0
    clc
    lda (n_src),y
    adc s_phase
    sta s_data
    iny
    lda (n_src),y
    adc #0
    sta s_data+1
    iny
    lda (n_src),y
    sta s_bank
    iny
    clc
    lda (n_src),y
    adc s_phase
    sta s_right
    iny
    lda (n_src),y
    adc #0
    sta s_right+1
    iny
    lda (n_src),y
    sta s_right_bank
    lda p_y
    and #6
    lsr a
    clc
    adc #6
    tay
    lda (n_src),y
    sta s_occupied
    clc
    lda s_data
    adc #22
    sta s_left_mask
    lda s_data+1
    adc #0
    sta s_left_mask+1
    clc
    lda s_right
    adc #22
    sta s_right_mask
    lda s_right+1
    adc #0
    sta s_right_mask+1
stamp_draw_ready:
    lda p_y
    lsr a
    lsr a
    lsr a
    sta r_row
    lda p_left+1
    lsr a
    lda p_left
    ror a
    lsr a
    lsr a
    lsr a
    sta p_index
    lda #0
    sta s_cell
    lda r_back
    beq :+
    lda #28
:   clc
    adc r_row
    sta s_font_index
    ldx p_actor
    lda stamp_actor_offset,x
    sta r_font
    lda stamp_actor_code,x
    sta s_code
    lda stamp_actor_page,x
    sta p_fontbase
@row:
    ldx s_font_index
    lda stamp_font_hi,x
    clc
    adc p_fontbase
    sta r_font+1
    jsr stamp_row_write
    lda s_cell
    bne @done
    inc s_cell
    lda r_font
    ora #16
    sta r_font
    clc
    lda s_data
    adc #8
    sta s_data
    bcc :+
    inc s_data+1
:   clc
    lda s_right
    adc #8
    sta s_right
    bcc :+
    inc s_right+1
:   clc
    lda s_left_mask
    adc #8
    sta s_left_mask
    bcc :+
    inc s_left_mask+1
:   clc
    lda s_right_mask
    adc #8
    sta s_right_mask
    bcc :+
    inc s_right_mask+1
:
    inc r_row
    inc s_font_index
    jmp @row
@done:
    rts
stamp_row_write:
    ldy r_row
    lda stamp_row_lo,y
    sta @call+1
    lda stamp_row_hi,y
    sta @call+2
    lda r_back
    beq :+
    lda #7
    bne @bank
:   lda #9
@bank:
    NATIVE_BANK
    sta s_writer_bank
    ldx p_index
@call:
    jsr $8000
    rts

