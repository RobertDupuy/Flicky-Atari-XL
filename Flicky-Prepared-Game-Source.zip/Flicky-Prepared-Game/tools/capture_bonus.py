"""Record a separately selected NTSC bonus round using genuine keyboard input.

The emulator monitor selects round 3 before recording. No state is edited
during the recorded game, including the catch count, score, and results.
"""
import json
import os
import signal
import time
from capture_skillful import locate, state, pause, play_actions, keyset
from raster_probe import Session
from build import BUILD
import movie_plan as plan


def main():
    out = BUILD / 'native/ntsc-512-bonus-movie'
    out.mkdir(exist_ok=True)
    (out / 'capture.avi').unlink(missing_ok=True)
    session = Session(plan.CARTRIDGE, out, plan.MODE, True)
    recording = False
    log = []
    try:
        session.tap('Control_R')
        time.sleep(.4)
        fd, base = locate(session)
        load = plan.L['game_round_load']
        idle = plan.L['native_idle']
        session.monitor([
            f'c {plan.L["n_round"]:04x} 02',
            f'c 05f0 20 {load & 255:02x} {load >> 8:02x} 4c {idle & 255:02x} {idle >> 8:02x}',
            'cont 05f0',
        ], resume=False)
        session.record()
        recording = True
        time.sleep(.1)
        session.tap('Return')
        time.sleep(.15)
        start = time.monotonic()
        for decision in range(500):
            memory = pause(session, fd, base)
            if plan.v(memory, 'n_round') >= 3:
                os.kill(session.emu.pid, signal.SIGCONT)
                break
            birds = [i for i in range(8) if plan.v(memory, 'n_flags', i) & 128]
            player_x, _ = plan.xy(memory)
            target = max(birds, key=lambda i: plan.xy(memory, i)[1]) if birds else None
            target_x = plan.xy(memory, target)[0] if target is not None else player_x
            delta = (target_x - player_x + 256) % 512 - 256
            key = 255 if abs(delta) < 12 else 191 if delta > 0 else 127
            if plan.v(memory, 'u_mode') or plan.v(memory, 'n_flow'):
                key = 255
            log.append({
                'decision': decision, 'round': plan.v(memory, 'n_round'),
                'screen': plan.v(memory, 'u_mode'), 'spawned': plan.v(memory, 'b_spawn'),
                'caught': plan.v(memory, 'b_caught'), 'player_x': player_x,
                'target_x': target_x, 'key': key,
            })
            os.kill(session.emu.pid, signal.SIGCONT)
            play_actions(session, fd, base, [(key, 4)])
            if decision % 30 == 0:
                session.capture().save(out / f'frame-{decision:03d}.png')
                print(json.dumps(log[-1]), flush=True)
            if time.monotonic() - start > 45:
                raise RuntimeError('Bonus capture exceeded its expected duration')
        keyset(session, 255)
        time.sleep(.2)
        session.record()
        recording = False
        (out / 'route.json').write_text(json.dumps(log, indent=2) + '\n')
        report = {'variant': plan.MODE, 'round_selected_before_recording': 3,
                  'state_edited_during_recording': False,
                  'maximum_caught': max(row['caught'] for row in log),
                  'maximum_spawned': max(row['spawned'] for row in log),
                  'results_shown': any(row['screen'] == 3 for row in log)}
        (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report), flush=True)
        assert report['maximum_spawned'] == 20 and report['results_shown']
    finally:
        if session.emu.poll() is None:
            os.kill(session.emu.pid, signal.SIGCONT)
            if recording:
                keyset(session, 255)
                session.record()
        session.close()


if __name__ == '__main__':
    main()
