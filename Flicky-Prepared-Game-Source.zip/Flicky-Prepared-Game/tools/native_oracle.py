"""Original subroutines for native-engine differential tests and data extraction."""
import ctypes as C
import subprocess
import numpy as np
from build import ROOT, BUILD

class Original:
    def __init__(self):
        library=BUILD/'native-oracle.so'
        source=ROOT/'tools/native_oracle.c'
        if not library.exists() or source.stat().st_mtime>library.stat().st_mtime:
            subprocess.run(['gcc','-std=c11','-O2','-fPIC','-shared',str(source),'-o',str(library)],check=True)
        self.lib=C.CDLL(str(library))
        self.lib.no_init.argtypes=[C.c_char_p,C.c_char_p]
        self.lib.no_init((ROOT/'private-roms/maincpu-data.bin').read_bytes(),
                         (ROOT/'private-roms/maincpu-opcodes.bin').read_bytes())
        self.lib.no_memory.restype=C.POINTER(C.c_uint8)
        self.lib.no_result.restype=C.POINTER(C.c_uint16)
        self.lib.no_call.argtypes=[C.c_uint16,C.POINTER(C.c_uint16),C.c_uint8,C.c_uint32]
        self.ram=np.ctypeslib.as_array(self.lib.no_memory(),shape=(65536,))

    def call(self,entry,af=0,bc=0,de=0,hl=0,ix=0,iy=0,player=255,limit=20_000_000,stop=0xbffe):
        self.lib.no_stop(stop)
        regs=(C.c_uint16*6)(af,bc,de,hl,ix,iy)
        ticks=self.lib.no_call(entry,regs,player,limit)
        self.last_ticks=self.lib.no_ticks()
        self.last_fetches=self.lib.no_fetches()
        if ticks<0:
            raise RuntimeError(f'Original routine {entry:04x} did not return')
        return list(self.lib.no_result()[:8])
