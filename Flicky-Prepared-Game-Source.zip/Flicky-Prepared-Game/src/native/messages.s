; Static room lettering and bonus/result screens are prepared in cartridge ROM.
; The gameplay frame loop never draws text. Load-time copies preserve collision
; maps and exclude the cells occupied by precomposed stationary chicks.
u_wait=$07ef
u_time_bonus=$07f2
.segment "FIXED"
.export message_background,message_bonus_intro,message_result,u_wait,u_time_bonus
message_background:
    lda #16
    NATIVE_BANK
    jmp message_prepare
message_copy:
    NATIVE_BANK
@block:
    jsr level_byte
    sta n_dst
    jsr level_byte
    sta n_dst+1
    beq @done
    jsr level_byte
    sta n_remaining
@byte:
    jsr level_byte
    ldy #0
    sta (n_dst),y
    inc n_dst
    bne :+
    inc n_dst+1
:   dec n_remaining
    bne @byte
    beq @block
@done:
    rts
message_bonus_intro:
    lda n_bonus
    beq :+
    jmp bonus_message_intro
:
    rts
message_result:
    lda n_bonus
    beq :+
    jmp bonus_message_result
:
    lda #26
    NATIVE_BANK
    jmp result_show
.segment "BANK16"
message_prepare:
    lda n_round
@mod:
    cmp #48
    bcc @select
    sec
    sbc #48
    bcs @mod
@select:
    tax
    lda message_lo,x
    sta n_src
    lda message_hi,x
    sta n_src+1
    lda message_banks,x
    jmp message_copy
