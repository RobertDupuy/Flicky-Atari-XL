/* Host-only original-routine oracle. Never linked into the native cartridge.
 * The independent floooh CPU reads verified, separately decoded ROM views.
 * Calls have no interrupts: this tests algorithm results, not raster timing.
 */
#define CHIPS_IMPL
#include "../vendor/z80.h"
#include <stdint.h>
#include <string.h>
static uint8_t data[32768], opcodes[32768], memory[65536], input_level;
static uint16_t result[8];
static uint16_t stop_address=0xbffe;
static uint32_t last_ticks,last_fetches;

void no_init(const uint8_t *rom_data, const uint8_t *rom_opcodes) {
    memcpy(data, rom_data, sizeof data);
    memcpy(opcodes, rom_opcodes, sizeof opcodes);
    memset(memory, 0, sizeof memory);
}
uint8_t *no_memory(void) { return memory; }
uint16_t *no_result(void) { return result; }
void no_stop(uint16_t address) { stop_address=address; }
uint32_t no_ticks(void) { return last_ticks; }
uint32_t no_fetches(void) { return last_fetches; }

int no_call(uint16_t entry, const uint16_t *registers, uint8_t player,
            uint32_t limit) {
    z80_t cpu;
    z80_init(&cpu);
    cpu.af=registers[0]; cpu.bc=registers[1]; cpu.de=registers[2];
    cpu.hl=registers[3]; cpu.ix=registers[4]; cpu.iy=registers[5];
    cpu.sp=0xcff0; memory[0xcff0]=0xfe; memory[0xcff1]=0xbf;
    input_level=player;
    uint64_t pins=z80_prefetch(&cpu,entry);
    uint32_t ticks;
    int previous_fetch=0;
    last_fetches=0;
    for(ticks=0;ticks<limit;ticks++) {
        pins=z80_tick(&cpu,pins);
        int fetch=(pins&(Z80_M1|Z80_MREQ|Z80_RD))==(Z80_M1|Z80_MREQ|Z80_RD);
        if(fetch&&!previous_fetch)last_fetches++;
        previous_fetch=fetch;
        if(pins&Z80_MREQ) {
            uint16_t address=Z80_GET_ADDR(pins);
            if(pins&Z80_RD) {
                if((pins&Z80_M1) && (address==0xbffe || address==stop_address)) break;
                uint8_t value=address<32768 ?
                    ((pins&Z80_M1)?opcodes[address]:data[address]) : memory[address];
                Z80_SET_DATA(pins,value);
            } else if((pins&Z80_WR) && address>=0xc000) {
                memory[address]=Z80_GET_DATA(pins);
            }
        } else if((pins&(Z80_IORQ|Z80_RD))==(Z80_IORQ|Z80_RD)) {
            Z80_SET_DATA(pins,input_level);
        }
    }
    result[0]=cpu.af; result[1]=cpu.bc; result[2]=cpu.de; result[3]=cpu.hl;
    result[4]=cpu.ix; result[5]=cpu.iy; result[6]=cpu.sp; result[7]=cpu.pc;
    last_ticks=ticks;
    return ticks<limit ? (int)ticks : -1;
}
