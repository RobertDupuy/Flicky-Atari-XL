"""Injected round-initialization differential with IRQs/collisions disabled.
This isolates instruction semantics; it is not an end-to-end playthrough."""
import ctypes as C,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from run_reference import Reference
from run_native import Native

def test_48_round_initializations():
    r=Reference();n=Native(True);n.run();r.lib.fm_collisions(0)
    r.lib.fm_registers.restype=C.POINTER(C.c_uint16)
    for f in range(400):r.frame(255,254 if 180<=f<190 else 239 if 210<=f<220 else 255)
    r.lib.fm_until_halt(255,255)
    initial=r.ram.copy()
    for stage in range(48):
        r.ram[:]=initial;r.ram[0xc018]=stage
        regs=list(r.lib.fm_registers()[:12])
        for i,key in enumerate(['f','c','e','l','ix','iy','sp','pc']):
            a=n.labels['z_'+key];n.memory[a]=regs[i]&255;n.memory[a+1]=regs[i]>>8
        for i,offset in [(8,6),(9,0),(10,2),(11,4)]:
            a=n.labels['z_alt']+offset;n.memory[a]=regs[i]&255;n.memory[a+1]=regs[i]>>8
        n.memory[0xc000:0xd000]=r.ram[0xc000:0xd000]
        n.memory[0x7000:0x7800]=r.ram[0xd000:0xd800]
        n.memory[0xd800:0xf000]=r.ram[0xd800:0xf000]
        a=n.labels['z_pc'];n.memory[a:a+2]=[0xbd,1]
        n.memory[n.labels['z_iff']]=0
        r.lib.fm_test_redirect(0x01bd)
        pc=r.lib.fm_until_halt(255,255);assert pc>0
        n.lib.at_prefetch(n.labels['guest_resume'])
        n.run(1_000_000_000)
        np.testing.assert_array_equal(n.memory[0xc000:0xcf80],r.ram[0xc000:0xcf80],err_msg=f'round {stage+1}')
        np.testing.assert_array_equal(n.memory[0x7000:0x7800],r.ram[0xd000:0xd800],err_msg=f'round sprites {stage+1}')
        np.testing.assert_array_equal(n.memory[0xd800:0xf000],r.ram[0xd800:0xf000],err_msg=f'round map {stage+1}')
