#!/usr/bin/env python3
"""Pack delta streams into measured spare cartridge regions, with bank jumps."""
import json
from build import BUILD

def main(regions=None,destination=None):
    tracks=json.loads((BUILD/'audio/manifest.json').read_text())
    if regions is None:
        map_end=(4*len(json.loads((BUILD/'hot-banks.json').read_text()))+15)&~15
        regions=[(6,0x0c00,0x2000),(4,0x1800,0x2000),(5,0x1800,0x2000),
                 (7,map_end,0x2000),(8,0x1a00,0x2000),(10,0x0a00,0x1000)]
    lines=[];ri=-1;used=0;limit=0;bank=0;starts={};loops={};jumps=0
    def region():
        nonlocal ri,used,limit,bank
        ri+=1
        if ri==len(regions):raise ValueError('Audio exceeds reserved 128 KB cartridge regions')
        bank,used,limit=regions[ri]
        lines.append(f'.segment "BANK{bank}"')
        if bank in [4,5,6,7]:
            lines.append(f'.assert (*-hot_bank_start{bank}) <= ${used:04x}, error, "Native code reaches audio reserve"')
            lines.append(f'.res ${used:04x}-(*-hot_bank_start{bank}),$ff')
        else:lines.append(f'.res ${used:04x},$ff')
    region()
    for track in sorted(tracks,key=lambda t:-t['bytes']):
        command=track['command'];data=(BUILD/f'audio/{command:02x}.bin').read_bytes();pos=0;started=False
        while data[pos]:
            mask=data[pos+1];length=2+mask.bit_count()
            if used+length+5>limit:
                nextbank=regions[ri+1][0] if ri+1<len(regions) else -1
                target=f'audio_continue_{jumps}';jumps+=1
                lines += [f'.byte 0,1,{nextbank}',f'.word {target}']
                region();lines.append(target+':')
            if not started:
                starts[command]=(bank,0x8000+used);lines.append(f'audio_start_{command:02x}:');started=True
            if pos==track['loop_offset']:
                loops[command]=bank;lines.append(f'audio_loop_{command:02x}:')
            lines.append('.byte '+','.join(str(v) for v in data[pos:pos+length]))
            pos+=length;used+=length
        if track['loop_offset'] is not None:
            lines += [f'.byte 0,1,{loops[command]}',f'.word audio_loop_{command:02x}'];used+=5
        else:lines.append('.byte 0,0');used+=2
    ordered=sorted(tracks,key=lambda t:t['command'])
    lines += ['.segment "FIXED"','audio_banks:']+[f'.byte {starts[t["command"]][0]}' for t in ordered]
    lines += ['audio_lo:']+[f'.byte <audio_start_{t["command"]:02x}' for t in ordered]
    lines += ['audio_hi:']+[f'.byte >audio_start_{t["command"]:02x}' for t in ordered]
    lines += ['audio_flags:']+[f'.byte {int(t["replace"] or t["loop_frame"] is not None)}' for t in ordered]
    (destination or BUILD/'audio-data.s').write_text('\n'.join(lines)+'\n')
    print('Audio cartridge regions used:',ri+1,'bank transitions:',jumps)
if __name__=='__main__':main()
