"""Bake stationary chick animations against their exact level background.

These are character animations, not game logic: native state still selects the
pose, direction and bob. Moving, scattered, clipped and overlapping chicks
continue through the ordinary actor renderer.
"""
import json
from pathlib import Path
from scenery_visibility import black_wall


def build_idle_characters(output: Path, build: Path, rom: bytes, maps):
    assets=json.loads((output/'chick-assets.json').read_text())
    images={i:(output/f'chick-image-{i:03}.bin').read_bytes() for i in set(assets['images'])}
    index=(build/'scenery-index.bin').read_bytes();glyph_data=(build/'scenery-glyphs.bin').read_bytes()
    glyphs=[];glyph_ids={};styles=[];style_ids={};profiles=[]
    def intern(data):
        if data not in glyph_ids:
            glyph_ids[data]=len(glyphs);glyphs.append(data)
        return glyph_ids[data]
    def white(value):
        return sum((1 if (value>>s)&3==3 else (value>>s)&3)<<s for s in (6,4,2,0))
    for profile in range(56):
        stage=profile if profile<48 else profile-48
        round_number=stage+48 if profile<48 else stage
        layout=rom[0x2fca+stage]
        positions=rom[0xdf3+16*layout:0xdf3+16*(layout+1)]
        background=[]
        for cell in range(896):
            tile=int.from_bytes(maps[stage][cell*2:cell*2+2],'little')&2047
            address=index[tile]+256*index[2048+tile]
            packed=index[4096+tile]
            offset=address-0x8000+((packed&127)-9)*8192
            pixels=bytes(8) if black_wall(stage,tile) else glyph_data[offset:offset+8]
            background.append((pixels,packed&128))
        actor_profiles=[]
        for actor in range(8):
            rawx,center=positions[actor*2:actor*2+2]
            x=2*rawx+(rawx>>7)
            column=((x-10)&511)//16;row=(center-4)//8
            variant=int(actor>8-min((round_number&252)//2,4))
            assert 0<=row<=25,(stage,actor,center)
            style=bytearray()
            for pose in (5,6):
                for facing in range(2):
                    for bob in range(-3,4):
                        base=pose*16+variant*8+facing*4
                        metadata=assets['records'][base]
                        left=(x-2*(metadata['stride']-1))&511
                        phase=(left//4)&3
                        image=images[assets['images'][base+phase]]
                        height,width,ink=image[:3]
                        top=(center-height//2+1)&~3
                        for cell in range(4):
                            rr=row+cell//2;cc=(column+cell%2)&31
                            background_pixels,old_ink=background[rr*32+cc]
                            masks=[255]*8;pixels=[0]*8
                            source_column=(cc-left//16)&31
                            for line in range(8):
                                source_row=rr*8+line-top
                                if 0<=source_row<height and source_column<width:
                                    offset=3+2*(source_row*width+source_column)
                                    masks[line],pixels[line]=image[offset:offset+2]
                            result_ink=old_ink
                            result=bytearray(background_pixels)
                            if ink!=old_ink and any(v&(v>>1)&85 for v in pixels):
                                result=bytearray(white(v) for v in result);result_ink=ink
                            for line in range(8):result[line]=(result[line]&masks[line])|pixels[line]
                            identifier=intern(bytes(result))
                            style.extend(((identifier*8)&255,0xa0|((identifier>>5)&31),(1+(identifier>>10))|result_ink))
            style=bytes(style);assert len(style)==336
            if style not in style_ids:style_ids[style]=len(styles);styles.append(style)
            actor_profiles.append((style_ids[style],row,column,variant))
        # The background layer may not hide another chick's independently
        # animated pixels. Exclude overlapping spawn rectangles conservatively.
        for actor,record in enumerate(actor_profiles):
            _,row,column,_=record
            cells={(row+y,(column+x)&31) for y in range(2) for x in range(2)}
            for other,other_record in enumerate(actor_profiles):
                if actor==other:continue
                _,rr,cc,_=other_record
                if cells&{(rr+y,(cc+x)&31) for y in range(2) for x in range(2)}:
                    actor_profiles[actor]=(255,row,column,record[3]);break
        profiles.append(actor_profiles)
    assert len(glyphs)<5120,len(glyphs)
    assert len(styles)<255,len(styles)
    lines=[]
    for chunk in range((len(glyphs)+1023)//1024):
        name=f'idle-glyphs-{chunk:02}.bin';data=b''.join(glyphs[chunk*1024:(chunk+1)*1024])
        (output/name).write_bytes(data)
        lines += [f'.segment "UPPER{1+chunk}"',f'.incbin "{name}"']
    regions=[(bank,8192) for bank in range(6,12)]
    region=0;used=0;style_banks=[]
    for identifier,data in enumerate(styles):
        if used+len(data)>regions[region][1]:region+=1;used=0
        assert region<len(regions),(len(glyphs),len(styles))
        bank=regions[region][0];style_banks.append(bank);used+=len(data)
        name=f'idle-style-{identifier:03}.bin';(output/name).write_bytes(data)
        lines += [f'.segment "UPPER{bank}"',f'native_idle_style_{identifier}:',f'.incbin "{name}"']
    lines += ['.segment "BANK6"','native_idle_profiles:']
    for actors in profiles:
        for field in range(4):lines.append('.byte '+','.join(str(a[field]) for a in actors))
    lines += ['native_idle_style_lo:', '.lobytes '+','.join(f'native_idle_style_{i}' for i in range(len(styles))),
              'native_idle_style_hi:', '.hibytes '+','.join(f'native_idle_style_{i}' for i in range(len(styles))),
              'native_idle_style_bank:', '.byte '+','.join(map(str,style_banks))]
    (output/'idle-characters.s').write_text('\n'.join(lines)+'\n')
    (output/'idle-characters.json').write_text(json.dumps({
        'profiles':56,'styles':len(styles),'glyphs':len(glyphs),'glyph_bytes':len(glyphs)*8,
        'style_bytes':len(styles)*336,'excluded_overlapping_spawns':sum(a[0]==255 for p in profiles for a in p),
        'format':'28 animation states per style; four native glyph addresses per state; eight precomposed rows per glyph',
    },indent=2)+'\n')
