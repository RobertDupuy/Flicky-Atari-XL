#!/usr/bin/env python3
"""Reproduce the binary study without downloading or searching for information."""
from pathlib import Path
import hashlib,json,subprocess,zlib
ROOT=Path(__file__).resolve().parents[1]
REGIONS=[
 ('interrupt_and_tick',0x219,0x2a8,'IRQ input, sound, movement and VDP work; a one-byte frame handshake at C0BE.'),
 ('stage_wrap',0x34e,0x36f,'C0A4 is incremented and reset from 41 to 1: the forty-layout selector.'),
 ('main_play_dispatch',0x425,0x45c,'Main-loop scrolling, player, objects, enemies and chicks are separate calls.'),
 ('scroll_phases',0x5c0,0x664,'C0CA holds the phase modulo eight; C0CB holds the column modulo 32.'),
 ('player_character_animation',0x7fc,0x871,'Select prepared player pattern/color data and upload three VDP pattern regions.'),
 ('chick_collection_and_states',0x10b5,0x115e,'Eight chicks, four-byte sprite records, three-byte states. Pickup tests sampled character classes 4 through 9.'),
 ('object_dispatch_and_throw',0x1539,0x161c,'Six objects, four-byte state records, explicit pickup/carried/thrown/retiring states and a bounded throw timer.'),
 ('character_point_probe',0x1c1b,0x1c4c,'IX position plus BC offsets, divided by eight, addresses a name-table character. This is not sprite pixel ownership.'),
 ('map_and_shifted_tile_lookup',0x1c9d,0x1d32,'Twenty rows of sixteen packed bytes: two cells per byte. Fine phase selects one of eight nine-entry tile-code tables.'),
 ('level_setup_and_population',0x2034,0x2189,'Round setup, two enemy records, packed map traversal, and spawn markers.'),
]
def main():
 out=ROOT/'build/sg-study';out.mkdir(exist_ok=True)
 rom=ROOT/'private-roms/flicky-sg1000.sg';data=rom.read_bytes()
 assert len(data)==32768 and zlib.crc32(data)==0xbd24d27b
 exe=ROOT/'build/sg-disassemble'
 subprocess.run(['gcc','-O2',str(ROOT/'tools/sg_disassemble.c'),'-o',str(exe)],check=True)
 for name,start,end,note in REGIONS:
  result=subprocess.check_output([str(exe),str(rom),f'{start:x}',f'{end:x}'],text=True)
  (out/(name+'.asm')).write_text('; '+note+'\n; Addresses refer to the unmodified SG-1000 v0 binary.\n'+result)
 pointers=[int.from_bytes(data[0x4803+i*2:0x4805+i*2],'little') for i in range(40)]
 (out/'manifest.json').write_text(json.dumps({'rom_bytes':len(data),'crc32':f'{zlib.crc32(data):08x}',
  'md5':hashlib.md5(data).hexdigest(),'sha256':hashlib.sha256(data).hexdigest(),
  'layout_pointers':[f'{x:04x}' for x in pointers],
  'method':'Static disassembly and explicit data-table inspection; no claim of full dynamic reverse engineering.',
  'regions':[{'name':n,'start':f'{s:04x}','end_exclusive':f'{e:04x}','finding':t} for n,s,e,t in REGIONS]},indent=2)+'\n')
 print(out)
if __name__=='__main__':main()
