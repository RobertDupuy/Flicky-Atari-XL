"""Convert original DATA into native cartridge assets, with no executable ROM.

The host-only independent oracle expands level layouts. The cartridge receives
bounded LZ streams, not original code or a CPU representation.
"""
from collections import defaultdict
import json
from pathlib import Path
from build import ROOT, BUILD
from native_oracle import Original
from assets import color
from character_atlas import CharacterAtlas
from idle_contacts import build_idle_contacts
from idle_characters import build_idle_characters

OUT=BUILD/'native'

from prepared_codec import compress,expand

def main():
    OUT.mkdir(exist_ok=True)
    oracle=Original();maps=[];streams=[]
    for stage in range(48):
        oracle.ram[:]=0
        oracle.ram[0xc000]=0x80
        oracle.ram[0xc018]=stage
        oracle.ram[0xc02c]=int(stage%4==2)
        oracle.ram[0xc01a:0xc01c]=[0xf8,1]
        oracle.call(0x2785)
        oracle.call(0x2431)
        data=oracle.ram[0xe000:0xe700].tobytes()
        stream=compress(data)
        assert expand(stream)==data
        maps.append(data);streams.append(stream)
    (OUT/'maps-reference.bin').write_bytes(b''.join(maps))
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    lines=[];bank=0;used=0;banks=[]
    for i,stream in enumerate(streams):
        if used+len(stream)>8192:bank+=1;used=0
        assert bank<4, 'Native map allocation exceeded'
        banks.append(bank)
        name=f'level-{i+1:02d}.lz'
        (OUT/name).write_bytes(stream)
        lines += [f'.segment "BANK{bank}"',f'native_level_{i}:',f'.incbin "{name}"']
        used+=len(stream)
    lines += ['.segment "FIXED"','native_level_banks:', '.byte '+','.join(map(str,banks)),
              'native_level_lo:', '.lobytes '+','.join(f'native_level_{i}' for i in range(48)),
              'native_level_hi:', '.hibytes '+','.join(f'native_level_{i}' for i in range(48))]
    for label,data in [('native_round_layout',rom[0x2fca:0x2ffa]),
                       ('native_player_start_y',rom[0x13d2:0x13f6])]:
        lines.append(label+':')
        for p in range(0,len(data),16):lines.append('.byte '+','.join(f'${v:02x}' for v in data[p:p+16]))
    lines.append('.segment "BANK4"')
    for label,data in [('native_chick_positions',rom[0x0df3:0x0df3+36*16]),
                       ('native_chick_sine',bytes(v>>6 for v in rom[0x454d:0x45cd])),
                       ('native_score_points',rom[0x1a7d:0x1a9b])]:
        if label=='native_score_points':
            # The source stores tens of points and prints an implicit zero.
            # The new HUD and combat/bonus systems use actual BCD points.
            data=b''.join(int(f'{int(f"{data[i+1]:02x}{data[i]:02x}")*10:04d}',16).to_bytes(2,'little')
                          for i in range(0,len(data),2))
        lines.append(label+':')
        for p in range(0,len(data),16):lines.append('.byte '+','.join(f'${v:02x}' for v in data[p:p+16]))
    (OUT/'data.s').write_text('\n'.join(lines)+'\n')
    images=CharacterAtlas(OUT)
    player_assets(rom,images)
    chick_assets(rom,images)
    cat_assets(rom,images)
    from object_assets import object_art,pack_native_records
    object_art(None,compact_writer=pack_native_records)
    assert len(images.patterns) < 0x4000, 'Generic glyph IDs overlap compact floor-object IDs'
    images.finish()
    build_idle_contacts(OUT,BUILD,rom,maps)
    build_idle_characters(OUT,BUILD,rom,maps)
    result={'map_count':48,'map_bytes_each':1792,'compressed_map_bytes':sum(map(len,streams)),
            'map_banks':max(banks)+1,'executable_original_rom_bytes':0}
    (OUT/'assets.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result)

def player_assets(rom,allocator):
    sprites=(ROOT/'private-roms/sprites.bin').read_bytes()
    palette=(BUILD/'reference/ram-00600.bin').read_bytes()[0xd880:0xd890]
    descriptors=[0x3434,0x344c,0x3477,0x3482,0x348d,0x3498]
    records=[];masks=[];image_index=[];mask_index=[];metadata=[]
    for animation,pointer in enumerate(descriptors):
        height,stride=rom[pointer:pointer+2]
        frame_count=rom[pointer+6]
        for frame in range(4):
            f=frame%frame_count
            source=int.from_bytes(rom[pointer+7+f*2:pointer+9+f*2],'little')
            for facing in range(2):
                rows=[]
                for row in range(height):
                    values=[]
                    start=source+row*stride
                    if facing:start+=stride-2
                    for byte in range(stride):
                        v=sprites[(start+(-byte if facing else byte))&32767]
                        pair=(v&15,v>>4) if facing else (v>>4,v&15)
                        for pixel in pair:
                            if pixel==15:break
                            values.append(pixel)
                        if 15 in pair:break
                    rows.append(values)
                width=max(map(len,rows))
                assert width<=24
                solid=b''.join(int(''.join('1' if p else '0' for p in row).ljust(24,'0'),2).to_bytes(3,'big') for row in rows)
                if solid not in masks:masks.append(solid)
                mask_id=masks.index(solid)
                colors=[[color(palette[p]) if p else 0 for p in row] for row in rows]
                ink=128 if any(4 in row for row in colors) and not any(3 in row for row in colors) else 0
                for phase in range(4):
                    columns=(phase+(width+1)//2+3)//4
                    record=bytearray([height,columns,ink])
                    for row,projected in zip(rows,colors):
                        packed=[0]*columns;opaque=[0]*columns
                        for pixel in range((len(row)+1)//2):
                            pair=projected[pixel*2:pixel*2+2]
                            value=next((v for v in pair if v),0)
                            if value==4:value=3 if ink else 1
                            elif value==3 and ink:value=1
                            position=pixel+phase;shift=6-2*(position&3)
                            packed[position//4]|=value<<shift
                            if any(row[pixel*2:pixel*2+2]):opaque[position//4]|=3<<shift
                        for mask,bits in zip(opaque,packed):record.extend((mask^255,bits))
                    record[2]=128  # actors use the dedicated gold ink
                    record=bytes(record)
                    if record not in records:records.append(record)
                    image_index.append(records.index(record));mask_index.append(mask_id)
                    metadata.append({'animation':animation,'frame':frame,'facing':facing,'phase':phase,
                                     'height':height,'source':source,'stride':stride,'width':width})
    lines=[];size=0;image_banks=[];mask_banks=[]
    for i,record in enumerate(records):
        (OUT/f'player-image-{i:03d}.bin').write_bytes(record)
        data=allocator.convert(record);bank=allocator.allocate(len(data));image_banks.append(bank)
        name=f'player-characters-{i:03d}.bin';(OUT/name).write_bytes(data)
        lines += [f'.segment "BANK{bank}"',f'native_player_image_{i}:',f'.incbin "{name}"'];size+=len(data)
    bank=8;used=0;lines.append('.segment "BANK8"')
    for i,mask in enumerate(masks):
        for phase in range(8):
            shifted=b''.join(((int.from_bytes(mask[p:p+3],'big')<<8)>>phase).to_bytes(4,'big')
                             for p in range(0,len(mask),3))
            if used+len(shifted)>8192:bank+=1;used=0;lines.append(f'.segment "BANK{bank}"')
            mask_banks.append(bank);used+=len(shifted)
            name=f'player-maskshift-{i:03d}-{phase}.bin';(OUT/name).write_bytes(shifted)
            lines += [f'native_player_mask_{i}_{phase}:',f'.incbin "{name}"'];size+=len(shifted)
    assert bank<=9, size
    lines += ['.segment "BANK5"','native_player_image_lo:',
              '.lobytes '+','.join(f'native_player_image_{i}' for i in image_index),
              'native_player_image_hi:', '.hibytes '+','.join(f'native_player_image_{i}' for i in image_index),
              'native_player_image_bank:', '.byte '+','.join(str(image_banks[i]) for i in image_index)]
    for parity in range(2):
        for field in ('lo','hi','bank'):
            lines.append(f'native_player_mask_{field}{parity}:')
            if field=='bank':
                lines.append('.byte '+','.join(str(mask_banks[i*8+2*(index%4)+parity]) for index,i in enumerate(mask_index)))
            else:
                directive='.lobytes ' if field=='lo' else '.hibytes '
                lines.append(directive+','.join(f'native_player_mask_{i}_{2*(index%4)+parity}' for index,i in enumerate(mask_index)))
    lines += ['.segment "FIXED"',
              'native_player_height:', '.byte '+','.join(str(rom[p]) for p in descriptors),
              'native_player_radius:', '.byte '+','.join(str(2*(rom[p+1]-1)) for p in descriptors),
              'native_third_to_white=$f600', '.segment \"BANK15\"', 'native_third_to_white_rom:']
    convert=[sum((1 if (value>>shift)&3==3 else (value>>shift)&3)<<shift for shift in (6,4,2,0)) for value in range(256)]
    for p in range(0,256,16):lines.append('.byte '+','.join(map(str,convert[p:p+16])))
    for byte in range(4):
        lines.append(f'native_prefix{byte}=$f700+{byte}*33')
        lines.append(f'native_prefix_rom{byte}:')
        lines.append('.byte '+','.join(str((((1<<count)-1)<<(32-count)>>(24-byte*8))&255) for count in range(33)))
    (OUT/'player-data.s').write_text('\n'.join(lines)+'\n')
    (OUT/'player-assets.json').write_text(json.dumps({'rom_bytes':size,'images':image_index,'masks':mask_index,'records':metadata},indent=2)+'\n')

def chick_assets(rom,allocator):
    palette=(BUILD/'reference/ram-00600.bin').read_bytes()[0xd800:0xd810]
    descriptors=[0x337d,0x3388,0x3393,0x339e,0x33a9,0x33b4,0x33bf,0x33ca,0x33d5]
    small_actor_assets(rom,allocator,'chick',descriptors,palette,2,(2,3))


def cat_assets(rom,allocator):
    descriptors=[0x67b2,0x67bb,0x67c4,0x67cd,0x67d6,0x67df,0x67e8,0x67f1,0x67fa,
                 0x6803,0x680c,0x6815,0x681e,0x6827,0x6830,0x6839,0x6842,0x684b]
    # The three spinning poses also occur upside down during the hit animation.
    descriptors += [descriptors[i] for i in (5,7,8)]
    small_actor_assets(rom,allocator,'cat',descriptors,rom[0x6866:0x6875]+b'\0',1,(28,29,31),range(18,21))
    doors=[]
    for layout in range(36):
        for door in range(2):
            p=0x20c5+layout*4+door*2
            address=int.from_bytes(rom[p:p+2],'little')
            column=(address+2)&63
            x=column*8+(column>>5)
            y=((address&248)>>3)|(((address>>8)&7)<<5)
            doors.append((x&255,x>>8,y))
    lines=['.segment "BANK3"']
    for field,name in enumerate(('xlo','xhi','y')):
        lines += [f'native_cat_door_{name}:','.byte '+','.join(str(d[field]) for d in doors)]
    lines += ['native_cat_spawn_delays:', '.byte '+','.join(map(str,rom[0x2806:0x280e]))]
    (OUT/'cat-spawn-data.s').write_text('\n'.join(lines)+'\n')



def small_actor_assets(rom,allocator,kind,descriptors,palette,variants,mask_regions,flipped=(),compact_writer=None):
    """Small actor images and full-resolution bit masks, converted offline."""
    sprites=(ROOT/'private-roms/sprites.bin').read_bytes()
    records=[];masks=[];image_index=[];mask_index=[];metadata=[]
    for animation,pointer in enumerate(descriptors):
        height,stride=rom[pointer:pointer+2]
        animation_palette=palette[animation] if isinstance(palette,list) else palette
        for variant in range(variants):
            source=int.from_bytes(rom[pointer+7+variant*2:pointer+9+variant*2],'little')
            for facing in range(2):
                rows=[]
                for row in range(height):
                    values=[];start=source+row*stride+(stride-2 if facing else 0)
                    for byte in range(stride):
                        v=sprites[(start+(-byte if facing else byte))&32767]
                        pair=(v&15,v>>4) if facing else (v>>4,v&15)
                        for pixel in pair:
                            if pixel==15:break
                            values.append(pixel)
                        if 15 in pair:break
                    rows.append(values)
                if animation in flipped:rows.reverse()
                width=max(map(len,rows));assert width<=24
                solid=b''.join(int(''.join('1' if p else '0' for p in row).ljust(24,'0'),2).to_bytes(3,'big') for row in rows)
                if solid not in masks:masks.append(solid)
                mask_id=masks.index(solid)
                colors=[[color(animation_palette[p]) if p else 0 for p in row] for row in rows]
                ink=128 if any(4 in row for row in colors) and not any(3 in row for row in colors) else 0
                for phase in range(4):
                    columns=(phase+(width+1)//2+3)//4
                    record=bytearray([height,columns,ink])
                    for row,projected in zip(rows,colors):
                        packed=[0]*columns;opaque=[0]*columns
                        for pixel in range((len(row)+1)//2):
                            pair=projected[pixel*2:pixel*2+2]
                            value=next((v for v in pair if v),0)
                            if value==4:value=3 if ink else 1
                            elif value==3 and ink:value=1
                            position=pixel+phase;shift=6-2*(position&3)
                            packed[position//4]|=value<<shift
                            if any(row[pixel*2:pixel*2+2]):opaque[position//4]|=3<<shift
                        for mask,bits in zip(opaque,packed):record.extend((mask^255,bits))
                    if kind in ('chick','object'):record[2]=128
                    record=bytes(record)
                    if record not in records:records.append(record)
                    image_index.append(records.index(record));mask_index.append(mask_id)
                    metadata.append({'animation':animation,'frame':variant,'facing':facing,'phase':phase,
                                     'height':height,'source':source,'stride':stride,'width':width})
    if compact_writer is not None:
        return compact_writer(OUT,records,masks,image_index,mask_index,metadata)
    lines=[];image_banks=[];mask_banks=[];size=0
    for i,record in enumerate(records):
        (OUT/f'{kind}-image-{i:03d}.bin').write_bytes(record)
        data=allocator.convert(record);bank=allocator.allocate(len(data));image_banks.append(bank);size+=len(data)
        name=f'{kind}-characters-{i:03d}.bin';(OUT/name).write_bytes(data)
        lines += [f'.segment "BANK{bank}"',f'native_{kind}_image_{i}:',f'.incbin "{name}"']
    image_size=size
    region=0;bank=mask_regions[0];used=0
    for i,mask in enumerate(masks):
        for phase in range(8):
            shifted=b''.join(((int.from_bytes(mask[p:p+3],'big')<<8)>>phase).to_bytes(4,'big')
                             for p in range(0,len(mask),3))
            if used+len(shifted)>8192:
                region+=1;bank=mask_regions[region];used=0
            mask_banks.append(bank);used+=len(shifted);size+=len(shifted)
            name=f'{kind}-maskshift-{i:03d}-{phase}.bin';(OUT/name).write_bytes(shifted)
            lines += [f'.segment "BANK{bank}"',f'native_{kind}_mask_{i}_{phase}:',f'.incbin "{name}"']
    lines += ['.segment "BANK5"',f'native_{kind}_image_lo:',
              '.lobytes '+','.join(f'native_{kind}_image_{i}' for i in image_index),
              f'native_{kind}_image_hi:', '.hibytes '+','.join(f'native_{kind}_image_{i}' for i in image_index),
              f'native_{kind}_image_bank:', '.byte '+','.join(str(image_banks[i]) for i in image_index)]
    for parity in range(2):
        for field in ('lo','hi','bank'):
            lines.append(f'native_{kind}_mask_{field}{parity}:')
            if field=='bank':
                lines.append('.byte '+','.join(str(mask_banks[i*8+2*(index%4)+parity]) for index,i in enumerate(mask_index)))
            else:
                directive='.lobytes ' if field=='lo' else '.hibytes '
                lines.append(directive+','.join(f'native_{kind}_mask_{i}_{2*(index%4)+parity}' for index,i in enumerate(mask_index)))
    lines += ['.segment "FIXED"',
              f'native_{kind}_height:', '.byte '+','.join(str(rom[p]) for p in descriptors),
              f'native_{kind}_radius:', '.byte '+','.join(str(2*(rom[p+1]-1)) for p in descriptors)]
    (OUT/f'{kind}-data.s').write_text('\n'.join(lines)+'\n')
    (OUT/f'{kind}-assets.json').write_text(json.dumps({'rom_bytes':size,'image_bytes':image_size,
        'images':image_index,'masks':mask_index,'records':metadata},indent=2)+'\n')

if __name__=='__main__':main()
