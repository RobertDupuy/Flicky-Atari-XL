"""Real-time diagnostic preview; select the bonus BEFORE recording.

During the capture only ordinary keys and read-only RAM observation are used.
No pause, speed change, teleportation, injected score, or edits during play.
"""
import json,os,time
from pathlib import Path
from build import BUILD
from native_engine import Engine
from raster_probe import Session
import movie_plan as plan
from capture_skillful import locate,state,keyset

def main():
    mode=os.getenv('FLICKY_MOVIE_VARIANT','pal')
    car=BUILD/'native/flicky-native-dev.car'
    n=Engine();plan.CARTRIDGE=car;plan.E=n
    out=BUILD/f'arcade-bonus/{mode}-realtime';out.mkdir(exist_ok=True)
    video_name=f'capture-{time.time_ns()}.avi'
    s=Session(car,out,mode,True,video_name);recording=False;log=[]
    def v(m,k,i=0):return int(m[n.labels[k]+i])
    def pos(m,i):return v(m,'n_xlo',i)+256*v(m,'n_xhi',i)
    def signed(a):return a-256 if a>=128 else a
    try:
        s.tap('Control_R');time.sleep(.2);fd,base=locate(s)
        load=n.labels['game_round_load'];idle=n.labels['native_idle']
        s.monitor(['c 0700 02',f'c 05f0 20 {load&255:02x} {load>>8:02x} 4c {idle&255:02x} {idle>>8:02x}','cont 05f0'],resume=False)
        s.record();time.sleep(.2);s.tap('Return');recording=True
        start=time.monotonic();next_control=0;done_at=None
        while time.monotonic()-start<24:
            m=state(fd,base);elapsed=time.monotonic()-start
            if v(m,'n_round')!=2:break
            if elapsed>=next_control:
                next_control=elapsed+.12
                px=pos(m,8);speed=-signed(v(m,'n_vx',31))/16
                candidates=[]
                for i in list(range(8))+list(range(11,23)):
                    if v(m,'n_flags',i)&4 or not v(m,'n_chick_state',i):continue
                    y=v(m,'n_ylo',i);vy=signed(v(m,'n_vy',i))/16
                    if vy<=0 or y>177:continue
                    ticks=max(0,(163-y)/max(.2,vy/2))
                    tx=(pos(m,i)+signed(v(m,'n_vx',i))/32*ticks)%512
                    candidates.append((ticks,tx,i))
                if candidates:
                    _,tx,target=min(candidates)
                    offset=16 if tx>=px else -16
                    delta=(tx-offset-px+256)%512-256
                    stopping=speed*abs(speed)/.125/2
                    key=255 if abs(delta)<8 else 191 if delta>stopping else 127
                else:key=255;target=None
                if v(m,'n_flow') or v(m,'u_wait'):key=255
                keyset(s,key)
                row=dict(seconds=elapsed,caught=v(m,'b_caught'),done=v(m,'b_done'),key=key,
                    target=target,player_x=px,rendered=v(m,'r_presented')+256*v(m,'r_presented',1),
                    consumed=v(m,'c_consumed')+256*v(m,'c_consumed',1),
                    host=int(m[0x7a2])+256*int(m[0x7a3]),fault=v(m,'r_fault'),
                    clock_overflow=v(m,'c_overflow'),clock_peak=v(m,'c_peak'))
                log.append(row)
                if len(log)%30==0:s.capture().save(out/f'frame-{len(log):03d}.png');print(row,flush=True)
            if v(m,'n_round_complete') and done_at is None:done_at=elapsed;s.capture().save(out/'result.png')
            if done_at is not None and elapsed-done_at>3:break
            time.sleep(.008)
        keyset(s,255);s.capture().save(out/'end.png');s.record();recording=False
        report=dict(mode=mode,round_selected_before_capture=3,state_edits_during_capture=0,
                    pauses_during_capture=0,caught=max(x['caught'] for x in log),
                    completed=done_at is not None,renderer_faults=max(x['fault'] for x in log),
                    duration=time.monotonic()-start,video=video_name,
                    clock_overflow=max(x['clock_overflow'] for x in log),
                    maximum_logic_backlog=max(x['clock_peak'] for x in log))
        (out/'input-log.json').write_text(json.dumps(log,indent=2)+'\n')
        (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
    finally:
        if recording:s.record()
        s.close()

if __name__=='__main__':main()
