/* Flicky reference machine. Z80 cores are independent floooh/chips code.
 * Video and bus behavior follows MAME System 1 (see THIRD_PARTY.md).
 * Host research/test utility, not code linked into the Atari cartridge.
 */
#define CHIPS_IMPL
#include "../vendor/z80.h"
#define CHIPS_UTIL_IMPL
#include "../vendor/z80dasm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static z80_t maincpu,soundcpu;
static uint64_t mpins,spins,master_time,next_line;
static uint8_t ram[65536],opcodes[32768],srom[32768],sram[2048];
static uint8_t tiles[2048][8][8],sprites[32768],prom[256],picture[224][512];
static uint8_t mix[64],coll[1024],mixsum,collsum;
static uint8_t p1,system_input,video_mode,sound_latch,mainirq,soundirq,soundnmi;
static uint32_t profile[65536],sprofile[65536],op_counts[256];
static uint32_t frames,scanline,main_tstates,main_m1,sound_remainder;
static uint16_t snregs[16];
static uint8_t sn_latch[2];
static FILE *trace;
static int collision_enabled=1;
static int boundary_mode=0;

static int read_blob(const char *dir,const char *name,uint8_t *dst,size_t length) {
    char path[2048];snprintf(path,sizeof(path),"%s/%s",dir,name);
    FILE *f=fopen(path,"rb");if(!f)return 0;
    size_t n=fread(dst,1,length,f);fclose(f);return n==length;
}

int fm_init(const char *dir) {
    uint8_t raw[49152];
    memset(ram,0,sizeof ram);memset(srom,0xff,sizeof srom);memset(sram,0,sizeof sram);
    memset(profile,0,sizeof profile);memset(sprofile,0,sizeof sprofile);memset(op_counts,0,sizeof op_counts);
    memset(mix,0,sizeof mix);memset(coll,0,sizeof coll);memset(picture,0,sizeof picture);
    if(!read_blob(dir,"maincpu-data.bin",ram,32768) || !read_blob(dir,"maincpu-opcodes.bin",opcodes,32768) ||
       !read_blob(dir,"soundcpu.bin",srom,8192) || !read_blob(dir,"tiles.bin",raw,49152) ||
       !read_blob(dir,"sprites.bin",sprites,32768) || !read_blob(dir,"lookup_proms.bin",prom,256)) return 0;
    memset(ram+0x8000,0xff,0x4000);
    for(int c=0;c<2048;c++)for(int y=0;y<8;y++)for(int x=0;x<8;x++) {
        int v=0;
        for(int plane=0;plane<3;plane++)v|=((raw[plane*16384+c*8+y]>>(7-x))&1)<<(2-plane);
        tiles[c][y][x]=v;
    }
    mpins=z80_init(&maincpu);spins=z80_init(&soundcpu);
    master_time=0;next_line=1280;scanline=0;frames=0;main_tstates=0;main_m1=0;sound_remainder=0;
    mixsum=collsum=mainirq=soundirq=soundnmi=video_mode=sound_latch=0;
    p1=system_input=0xff;
    memset(snregs,0,sizeof snregs);for(int i=1;i<16;i+=2)snregs[i]=15;
    sn_latch[0]=sn_latch[1]=0;
    boundary_mode=0;
    return 1;
}

static uint16_t tile_pixel(int page,int x,int y) {
    x&=255;y&=255;
    int a=0xe000+page*2048+((y>>3)*32+(x>>3))*2;
    int td=ram[a]|ram[a+1]<<8;
    int code=(td&0x7ff)|((td>>4)&0x800);
    // Flicky's 48 KB tile ROM contains 2048 tiles; code line 11 is unconnected.
    return (((td>>5)&255)*8)|tiles[code&2047][y&7][x&7];
}

static void render_line(int y) {
    if(y>=224)return;
    if(video_mode&0x10){memset(picture[y],0,512);return;}
    uint16_t sprline[512]={0};
    for(int n=0;n<32;n++) {
        const uint8_t *s=ram+0xd000+n*16;
        if(s[0]==255)break;
        int top=s[0]+1,bottom=s[1]+1;
        if(y<top || y>=bottom)continue;
        uint16_t stride=s[4]|s[5]<<8;
        uint16_t addr=(s[6]|s[7]<<8)+(uint16_t)(stride*(y-top+1));
        int x=(s[2]|s[3]<<8)&511;
        int delta=(addr&0x8000)?-1:1;
        for(int limit=0;limit<256;limit++,addr+=delta) {
            uint8_t b=sprites[addr&32767];
            int c[2]={(addr&0x8000)?b&15:b>>4,(addr&0x8000)?b>>4:b&15};
            int done=0;
            for(int k=0;k<2;k++,x+=2) {
                if(c[k]==15){done=1;break;}
                if(!c[k])continue;
                for(int j=0;j<2;j++)if(x+j<512) {
                    int prev=sprline[x+j];
                    if(collision_enabled && (prev&15)){coll[((prev>>4)&31)+32*n]=1;collsum=1;}
                    sprline[x+j]=n*16+c[k];
                }
            }
            if(done)break;
        }
    }
    int xs=(int16_t)((ram[0xeffc]|ram[0xeffd]<<8)+28);
    int ys=ram[0xefbd];
    for(int x=0;x<512;x++) {
        int sp=sprline[x],fg=tile_pixel(1,x/2,y),bg=tile_pixel(0,(x-xs)/2,y+ys);
        int index=(!(sp&15))|(!(fg&7)<<1)|((fg>>9&3)<<2)|(!(bg&7)<<4)|((bg>>9&3)<<5);
        int v=prom[index];
        if(collision_enabled && !(v&4)){mix[((v&8)<<2)|((sp>>4)&31)]=1;mixsum=1;}
        int pal=(v&3)==0?sp&511:(v&3)==1?0x200|(fg&511):0x400|(bg&511);
        picture[y][x]=ram[0xd800+pal];
    }
}

static uint8_t read_main(uint16_t a,int m1) {
    if(a<0x8000)return m1?opcodes[a]:ram[a];
    if(a<0xf000)return ram[a];
    if(a<0xf400)return mix[a&63]|0x7e|(mixsum<<7);
    if(a>=0xf800 && a<0xfc00)return coll[a&1023]|0x7e|(collsum<<7);
    return 0xff;
}
static void write_main(uint16_t a,uint8_t v) {
    if(a>=0xc000 && a<0xf000)ram[a]=v;
    else if(a>=0xf000 && a<0xf400)mix[a&63]=0;
    else if(a>=0xf400 && a<0xf800)mixsum=0;
    else if(a>=0xf800 && a<0xfc00)coll[a&1023]=0;
    else if(a>=0xfc00)collsum=0;
}
static uint8_t input(uint16_t address) {
    int a=address&31;
    if(a<4)return p1;
    if(a<8)return 255;
    if(a<12)return system_input;
    if(a<16)return (a&1)?0xfe:0xff;
    if(a<20)return 0xfe;
    if(a==0x18)return sound_latch;
    if(a==0x19)return video_mode;
    return 255;
}
static void output(uint16_t address,uint8_t v) {
    int a=address&31;
    if(a==0x18){sound_latch=v;soundnmi=1;}
    if(a==0x19)video_mode=v;
}
static void sound_write(int chip,uint8_t v) {
    int r;
    if(v&128) {
        r=sn_latch[chip]=(v>>4)&7;
        snregs[chip*8+r]=(snregs[chip*8+r]&0x3f0)|(v&15);
    } else {
        r=sn_latch[chip];
        if(r&1)snregs[chip*8+r]=v&15;
        else if(r==6)snregs[chip*8+r]=v&7;
        else snregs[chip*8+r]=(snregs[chip*8+r]&15)|((v&63)<<4);
    }
}
static void tick_sound(void) {
    if(soundirq)spins|=Z80_INT;else spins&=~Z80_INT;
    if(soundnmi)spins|=Z80_NMI;else spins&=~Z80_NMI;
    spins=z80_tick(&soundcpu,spins);
    if((spins&(Z80_IORQ|Z80_M1))==(Z80_IORQ|Z80_M1)){soundirq=0;Z80_SET_DATA(spins,255);}
    if(spins&Z80_MREQ) {
        uint16_t a=Z80_GET_ADDR(spins);
        if(spins&Z80_RD) {
            uint8_t v=a<0x8000?srom[a]:a<0xa000?sram[a&2047]:a>=0xe000?sound_latch:255;
            if(a>=0xe000)soundnmi=0;
            Z80_SET_DATA(spins,v);
            if((spins&Z80_M1)&&!soundcpu.prefix_active)sprofile[a]++;
        } else if(spins&Z80_WR) {
            uint8_t v=Z80_GET_DATA(spins);
            if(a>=0x8000&&a<0xa000)sram[a&2047]=v;
            else if(a>=0xa000&&a<0xc000)sound_write(0,v);
            else if(a>=0xc000&&a<0xe000)sound_write(1,v);
        }
    }
}

void fm_sound_reset(void) {
    memset(sram,0,sizeof sram);spins=z80_init(&soundcpu);
    soundirq=soundnmi=sound_latch=0;sn_latch[0]=sn_latch[1]=0;
    memset(snregs,0,sizeof snregs);for(int i=1;i<16;i+=2)snregs[i]=15;
}
void fm_sound_command(uint8_t command){sound_latch=command;soundnmi=1;}
void fm_sound_frame(void) {
    for(int line=0;line<260;line++) {
        if((line&63)==32)soundirq=1;
        for(int t=0;t<256;t++)tick_sound();
    }
}
uint8_t *fm_sound_ram(void){return sram;}

static void tick_main(void) {
        if(mainirq)mpins|=Z80_INT;else mpins&=~Z80_INT;
        mpins=z80_tick(&maincpu,mpins);
        unsigned elapsed=5;main_tstates++;
        if((mpins&(Z80_IORQ|Z80_M1))==(Z80_IORQ|Z80_M1)){mainirq=0;Z80_SET_DATA(mpins,255);}
        if(mpins&Z80_MREQ) {
            uint16_t a=Z80_GET_ADDR(mpins);
            if(mpins&Z80_RD) {
                int m1=!!(mpins&Z80_M1);
                uint8_t v=read_main(a,m1);Z80_SET_DATA(mpins,v);
                if(m1){elapsed+=2;main_m1++;if(!maincpu.prefix_active){
                    profile[a]++;op_counts[v]++;
                    if(trace)fprintf(trace,"%u %04X %02X %04X %04X %04X %04X %04X %04X %04X\n",frames,a,v,maincpu.af,maincpu.bc,maincpu.de,maincpu.hl,maincpu.ix,maincpu.iy,maincpu.sp);
                }}
            } else if(mpins&Z80_WR)write_main(a,Z80_GET_DATA(mpins));
        } else if(mpins&Z80_IORQ) {
            if(mpins&Z80_RD){uint8_t v=input(Z80_GET_ADDR(mpins));Z80_SET_DATA(mpins,v);}
            else if(mpins&Z80_WR)output(Z80_GET_ADDR(mpins),Z80_GET_DATA(mpins));
        }
        master_time+=elapsed;sound_remainder+=elapsed;
        while(sound_remainder>=5){sound_remainder-=5;tick_sound();}
        while(master_time>=next_line) {
            render_line(scanline);
            scanline++;
            if(scanline==224 && !boundary_mode)mainirq=1;
            if((scanline&63)==32)soundirq=1;
            if(scanline==260){scanline=0;frames++;}
            next_line+=1280;
        }
}
int fm_frame(uint8_t player,uint8_t system) {
    p1=player;system_input=system;
    uint32_t target=frames+1;
    while(frames<target)tick_main();
    return maincpu.pc;
}
int fm_until_halt(uint8_t player,uint8_t system) {
    p1=player;system_input=system;
    int was_halted=!!(mpins&Z80_HALT);
    for(int n=0;n<100000000;n++) {
        tick_main();int halted=!!(mpins&Z80_HALT);
        if(halted && !was_halted)return maincpu.pc;
        was_halted=halted;
    }
    return -1;
}
void fm_collisions(int enabled){collision_enabled=enabled;}
/* Test-only entry point: restart a verified ROM routine from a captured state. */
void fm_seek(uint16_t pc){mpins=z80_prefetch(&maincpu,pc);mainirq=0;}
void fm_boundary_mode(int enabled){boundary_mode=enabled;mainirq=0;}
void fm_boundary_irq(void){mainirq=1;}
uint16_t *fm_registers(void){
    static uint16_t out[12];
    out[0]=maincpu.af;out[1]=maincpu.bc;out[2]=maincpu.de;out[3]=maincpu.hl;
    out[4]=maincpu.ix;out[5]=maincpu.iy;out[6]=maincpu.sp;out[7]=maincpu.pc;
    out[8]=maincpu.af2;out[9]=maincpu.bc2;out[10]=maincpu.de2;out[11]=maincpu.hl2;
    return out;
}
void fm_render_snapshot(int mode){
    video_mode=mode;memset(mix,0,sizeof mix);memset(coll,0,sizeof coll);
    mixsum=collsum=0;collision_enabled=1;
    for(int y=0;y<224;y++)render_line(y);
}
uint8_t *fm_mix(void){return mix;}
uint8_t *fm_coll(void){return coll;}
uint8_t *fm_ram(void){return ram;}
uint8_t *fm_picture(void){return &picture[0][0];}
uint16_t *fm_sound(void){return snregs;}
uint32_t *fm_profile(void){return profile;}
uint32_t *fm_sound_profile(void){return sprofile;}
uint8_t *fm_tile_pixels(void){return &tiles[0][0][0];}
int fm_mode(void){return video_mode;}
void fm_trace(const char *path){if(trace)fclose(trace);trace=path?fopen(path,"w"):NULL;}
void fm_dump(const char *path){FILE *f=fopen(path,"wb");if(f){fwrite(ram,1,65536,f);fclose(f);}}

typedef struct{uint16_t pc;int n,outn;uint8_t view[16];char *out;} Dis;
static uint8_t dis_in(void *p){Dis *d=p;return d->view[d->n++&15];}
static void dis_out(char c,void *p){Dis*d=p;d->out[d->outn++]=c;}
int fm_disassemble(uint16_t pc,char *out,int sound){
    Dis d={.pc=pc,.out=out};
    for(int i=0;i<16;i++)d.view[i]=sound?srom[(pc+i)&32767]:ram[(pc+i)&65535];
    if(!sound && pc<32768){
        int i=0;d.view[i]=opcodes[pc];
        while((d.view[i]==0xdd||d.view[i]==0xfd)&&i<10){i++;d.view[i]=opcodes[(pc+i)&32767];}
        if(d.view[i]==0xed || (d.view[i]==0xcb&&i==0)){i++;d.view[i]=opcodes[(pc+i)&32767];}
    }
    int end=z80dasm_op(pc,dis_in,dis_out,&d);out[d.outn]=0;return end;
}

/* Historical isolated-round test API, retained for checkpoint continuity. */
void fm_test_redirect(uint16_t pc){boundary_mode=1;mainirq=0;maincpu.iff1=maincpu.iff2=0;mpins=z80_prefetch(&maincpu,pc);}
