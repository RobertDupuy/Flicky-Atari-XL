"""Prepare static lettering and transition screens; no text rasterizer in play."""
import json,re
from fast_ui_assets import FONT,CHARS,text
from build import BUILD

MESSAGES=('GATHER UP PIOPIO','DEFEAT NYANNYAN','TAKE PIOPIO HOME')

def table(path,label):
    source=path.read_text().split(label+':',1)[1]
    values=[]
    for line in source.splitlines():
        line=line.strip()
        if not line:continue
        if not line.startswith('.byte '):break
        values.extend(int(v[1:],16) if v.startswith('$') else int(v) for v in line[6:].split(','))
    return values

def glyph(c):
    return bytes([0]+[sum(int(v)<<(6-2*i) for i,v in enumerate(row)) for row in FONT[c].split()]+[0,0])

def build(out):
    maps=(out/'maps-reference.bin').read_bytes()
    index=(BUILD/'tile-index.bin').read_bytes();pixels=(BUILD/'tile-glyphs.bin').read_bytes()
    layouts=table(out/'data.s','native_round_layout')
    chicks=table(out/'data.s','native_chick_positions')
    props=table(out/'object-data.s','native_object_positions')
    heights=table(out/'object-data.s','native_object_height')
    draw_heights=table(out/'prepared-art.s','native_object_height_draw')
    radii=table(out/'prepared-art.s','native_object_radius_draw')
    banks=[];labels=[];lines=[];bank=17;used=0;reports=[]
    for stage in range(48):
        m=maps[stage*1792:(stage+1)*1792]
        tiles=[int.from_bytes(m[i:i+2],'little') for i in range(0,len(m),2)]
        patterns=[]
        for tile in tiles:
            tile&=2047;addr=index[tile]+256*index[2048+tile]
            offset=addr-0x8000+((index[4096+tile]&127)-9)*8192
            patterns.append(pixels[offset:offset+8])
        counts=[len(set(t&2047 for t in tiles[b*128:(b+1)*128])) for b in range(7)]
        avoid=set()
        if stage%4!=2:
            for actor in range(8):
                xx,yy=chicks[layouts[stage]*16+actor*2:layouts[stage]*16+actor*2+2]
                col=((2*xx+(xx>>7)-10)&511)//16;row=(yy-4)//8
                avoid.update((row+y,(col+x)&31) for y in range(2) for x in range(2))
            for actor in range(6):
                xx,yy=props[layouts[stage]*12+actor*2:layouts[stage]*12+actor*2+2]
                xx*=2;floor=yy//8
                while floor<27 and not tiles[floor*32+((xx//16)&31)]&0x1000:floor+=1
                kind=stage%15;height=draw_heights[kind]
                top=floor*8-heights[kind]//2-height//2
                left=(xx-radii[kind])//16;right=(xx+radii[kind])//16
                avoid.update((r,c&31) for r in range(top//8,(top+height-1)//8+1) for c in range(left,right+1))
        message='BONUS ROUND' if stage%4==2 else MESSAGES[(stage-(stage+1)//4)%3]
        candidates=[]
        for row in range(2,25):
            for col in range(33-len(message)):
                cells=[(row,col+i) for i,c in enumerate(message) if c!=' ']
                if any(tiles[r*32+c]&0x1000 or (r,c) in avoid for r,c in cells):continue
                # Avoid decorative art when open sky is available. Also prefer
                # the top of the room and spare glyph capacity in that band.
                cost=sum(sum(v.bit_count() for v in patterns[r*32+c]) for r,c in cells)*4+row*8+abs(col-(32-len(message))/2)
                if counts[row//4]+len(set(message)-{' '})>48:continue
                candidates.append((cost,row,col))
        if not candidates:raise RuntimeError(('No safe message position',stage+1))
        _,row,col=min(candidates);band=row//4;base=counts[band]
        chars=sorted(set(message)-{' '});codes={c:base+i for i,c in enumerate(chars)}
        blocks=[]
        def put(address,data):
            data=bytes(data);assert 0<len(data)<256
            blocks.append(address.to_bytes(2,'little')+bytes([len(data)])+data)
        for c,code in codes.items():
            for back in (0,1):put(0x2000+back*8192+band*1024+code*8,glyph(c))
        for i,c in enumerate(message):
            if c==' ':continue
            code=codes[c]
            put(0x1600+row*32+col+i,[code])
            for back in (0,1):
                for wrap in range(3):put(0x6000+back*4096+row*96+col+i+wrap*32,[code])
        for back in (0,1):put(0x6a0+band+back*7,[base+len(chars)])
        payload=b''.join(blocks)+bytes(2)
        if used+len(payload)>8192:bank+=1;used=0
        assert bank<24
        name=f'message-background-{stage:02d}.bin';(out/name).write_bytes(payload)
        label=f'message_background_{stage}';banks.append(bank);labels.append(label);used+=len(payload)
        lines += [f'.segment "BANK{bank}"',label+':',f'.incbin "{name}"']
        reports.append(dict(round=stage+1,message=message,row=row,column=col,characters=len(chars),base_code=base,bytes=len(payload)))
    lines += ['.segment "BANK16"','message_banks:','.byte '+','.join(map(str,banks)),
              'message_lo:','.lobytes '+','.join(labels),'message_hi:','.hibytes '+','.join(labels)]
    title=(out/'ui-title.bin').read_bytes()
    def screen(heading,sub,body):
        data=bytearray(1024)
        def line(y,s):
            assert len(s)<=32
            start=y*32+(32-len(s))//2;data[start:start+len(s)]=text(s)
        line(3,'FLICKY');line(6,heading);line(9,sub)
        # Reuse the converted original Flicky artwork from the title font.
        data[13*32:20*32]=title[13*32:20*32]
        for y,s in body:line(y,s)
        return data
    screens=[
        screen('BONUS ROUND','GATHER UP PIOPIO',[(21,'CATCH ALL 20 WITH THE NET'),(23,'100 POINTS FOR EACH CATCH'),(25,'PERFECT BONUS 2000 POINTS')]),
        screen('ROUND CLEAR!','TAKE PIOPIO HOME',[(21,'TIME BONUS'),(23,'00000 POINTS')]),
        screen('BONUS ROUND COMPLETE','CAUGHT 00/20',[(21,'CATCH POINTS 0000'),(24,'TRY FOR A PERFECT CATCH!')]),
        screen('PERFECT BONUS','CAUGHT 20/20',[(21,'CATCH POINTS 2000'),(23,'PERFECT BONUS 2000'),(25,'TOTAL 4000 POINTS')]),
    ]
    for i,data in enumerate(screens):
        name=f'message-screen-{i}.bin';(out/name).write_bytes(data)
        lines += ['.segment "BANK24"',f'message_screen_{i}:',f'.incbin "{name}"']
    lines += ['.segment "BANK24"','message_screen_lo:','.lobytes '+','.join(f'message_screen_{i}' for i in range(4)),
              'message_screen_hi:','.hibytes '+','.join(f'message_screen_{i}' for i in range(4))]
    (out/'message-data.s').write_text('\n'.join(lines)+'\n')
    (out/'static-messages.json').write_text(json.dumps({'backgrounds':reports,'presentation_screens':4,'per_frame_text_drawing':False,'data_banks':sorted(set(banks))},indent=2)+'\n')
