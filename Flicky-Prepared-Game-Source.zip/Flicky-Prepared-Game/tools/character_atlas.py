"""Prepare vertically aligned ANTIC character animations entirely offline."""
import json
from pathlib import Path


class CharacterAtlas:
    frame_banks = (16, 17, 26, 27, 6, 7, 18, 19, 20, 21, 22, 23, 24, 25)
    pattern_banks = (18, 19, 20, 21, 22, 23, 24, 25, 29, 30, 28)

    def __init__(self, output: Path):
        self.output = output
        self.patterns = [bytes([255] * 8 + [0] * 8)]
        self.pattern_ids = {self.patterns[0]: 0}
        self.region = 0
        self.used = 0
        self.frame_bytes = 0

    def allocate(self, size):
        if self.used + size > 8192:
            self.region += 1
            self.used = 0
        assert self.region < len(self.frame_banks), 'Character animation banks are full'
        self.used += size
        self.frame_bytes += size
        return self.frame_banks[self.region]

    def convert(self, record):
        height, width, ink = record[:3]
        data = bytearray([height, width, ink, height + 14, 0, 0] + [0] * 16)
        for phase in range(8):
            data[6 + phase * 2:8 + phase * 2] = len(data).to_bytes(2, 'little')
            rows = (height + phase + 7) // 8
            data.append(rows)
            for row in range(rows):
                for column in range(width):
                    masks, pixels = [], []
                    for line in range(row * 8 - phase, row * 8 - phase + 8):
                        if 0 <= line < height:
                            offset = 3 + 2 * (line * width + column)
                            masks.append(record[offset])
                            pixels.append(record[offset + 1])
                        else:
                            masks.append(255)
                            pixels.append(0)
                    pattern = bytes(masks + pixels)
                    identifier = self.pattern_ids.get(pattern)
                    if identifier is None:
                        # All-ones low IDs are reserved by stationary character cells.
                        if len(self.patterns) & 8191 == 8191:
                            self.patterns.append(b'')
                        identifier = len(self.patterns)
                        assert identifier < 32767, 'Character cache identity exhausted'
                        self.pattern_ids[pattern] = identifier
                        self.patterns.append(pattern)
                    data.extend(identifier.to_bytes(2, 'little'))
        data[4:6] = len(data).to_bytes(2, 'little')
        for column in range(width):
            data.extend([255] * 7)
            data.extend(record[3 + 2 * (line * width + column)] for line in range(height))
            data.extend([255] * 7)
            data.extend([0] * 7)
            data.extend(record[4 + 2 * (line * width + column)] for line in range(height))
            data.extend([0] * 7)
        return bytes(data)

    def finish(self):
        (self.output / 'character-data.s').write_text('; Character IDs are cache keys; padded columns supply aligned pixels.\n')
        (self.output / 'character-atlas.json').write_text(json.dumps({
            'format': 'eight precomputed character-ID maps and padded mask/pixel columns',
            'patterns': len(self.patterns), 'pattern_bytes': 0,
            'animation_bytes': self.frame_bytes, 'pattern_banks': [],
            'animation_banks': list(self.frame_banks[:self.region + 1]),
        }, indent=2) + '\n')
