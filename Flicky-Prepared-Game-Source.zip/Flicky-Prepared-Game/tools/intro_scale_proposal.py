"""Arcade-scale replacement review frame, drawn directly on the Atari grid."""
import json, shutil, time
from collections import Counter
import numpy as np
from PIL import Image, ImageDraw
import intro_art_proposal as hw
from build import BUILD, ROOT
from round_clear_art import LETTERS

OUT=BUILD/'intro-scale-proposal'

def palettes(row):
    y=row*8
    if y<48:return (0x9c,0x0e,0,0x5c if y<24 else 0x5a if y<32 else 0x58,0xee)
    if y<136:return (0x9c,0x0e,0,0x4c if y<96 else 0x4a,0xee)
    if y<184:return (0x9c,0xba,0xb2,0x6c,0xec)
    return (0xba,0x0e,0,0x8a,0xee)

BIKE=[
    '...b.b......',
    '..bbbbb.....',
    '..bbwww.....',
    '..bbwkw.....',
    '..bbwkwyy...',
    '...bwwyyy...',
    '...bbbbb....',
    '..bbbww.....',
    '.bbbbww.....',
    '..bbbww..kk.',
    '...bbwwbbk..',
    '....yrrr..k.',
    '....yrrrw.k.',
    '...krrr...k.',
    '..kkwkwkk.k.',
    '.kk..kw..kk.',
    '.kwk.kww.kwk',
    '.kwk.....kwk',
    '.kkk.....kkk',
    '..k.......k.',
]

PLANE=[
    '........y...y....',
    '........yy.yy....',
    '........yyyyy....',
    '........ywywy....',
    '........ykyky....',
    '..pp....ywywy....',
    '.pwwp...yyyyy....',
    '.pwwp...owkwo....',
    '.pppp...ywwwy....',
    '.ppppp..yyyyy....',
    'pppwwwppppppp..k.',
    'pppwwwppwwwwpp.k.',
    '.ppwwpppwwwwwpkkk',
    '.ppwwppppwwwpp.k.',
    '..pwwpppppwppp.k.',
    '..pppppppwwppp...',
    '...ppppppwppp....',
    '....ppppwppp.....',
    '.....ppwwpp......',
    '......pwwp.......',
    '.......kk........',
]

def picture():
    # Retain the released forest/mountain scenery and its original scale.
    prepared=np.load(BUILD/'native/attract-pixels.npz')
    i=int(np.argmin(abs(prepared['times']-1040)))
    pix=np.zeros((224,160),dtype=np.uint8)
    pix[144:184]=prepared['pixels'][i,144:184]
    im=Image.fromarray(pix);d=ImageDraw.Draw(im)
    # Cloud footprints follow the arcade framing.
    for x,y in ((44,24),(120,35)):
        d.polygon([(x,y+9),(x+3,y+4),(x+7,y+4),(x+10,y),
                   (x+14,y+3),(x+18,y+2),(x+21,y+6),(x+25,y+7),
                   (x+25,y+13),(x+21,y+15),(x+16,y+16),(x+10,y+18),
                   (x+4,y+16),(x,y+12)],fill=hw.WHITE)
    # The balloon/chick row stays central, leaving the large open arcade sky.
    for x,y in ((25,80),(75,80),(125,80)):
        d.ellipse((x,y,x+13,y+29),fill=hw.MAIN)
        d.arc((x+1,y+1,x+11,y+25),150,260,fill=hw.WHITE,width=1)
        d.line((x+3,y+5,x+6,y+2,x+9,y+2),fill=hw.WHITE)
        d.polygon([(x+5,y+29),(x+8,y+29),(x+7,y+32)],fill=hw.MAIN)
        d.line((x+7,y+33,x+7,y+38),fill=hw.WHITE)
        chick=['.yy..','yyyy.','ywky.','yyy..','.yyyy','..yy.','..y..','..yyy']
        colors={'y':hw.GOLD,'w':hw.WHITE,'k':hw.BLACK}
        for yy,row in enumerate(chick):
            for xx,c in enumerate(row):
                if c!='.':d.point((x+5+xx,y+39+yy),fill=colors[c])
    # Native-pixel sprite redrawing: no resampling from the rejected artwork.
    colors={'b':hw.MAIN,'w':hw.WHITE,'k':hw.BLACK,'y':hw.GOLD,
            'r':9,'p':hw.MAIN,'o':hw.ORANGE}
    for x,y,rows in ((35,190,BIKE),(96,15,PLANE)):
        width=len(rows[0]);assert all(len(row)==width for row in rows)
        for yy,row in enumerate(rows):
            for xx,c in enumerate(row):
                if c!='.':d.point((x+xx,y+yy),fill=colors[c])
    # Fine ground strokes preserve the horizon and do not compete with actors.
    for x,y in ((8,188),(61,185),(76,194),(110,187),(144,201),(15,203),(63,204),(91,208)):
        d.line((x,y,x+2,y),fill=hw.WHITE)
    text='FIRE TO PLAY';x=(160-(len(text)*6-1))//2
    for c in text:
        for yy,row in enumerate(LETTERS[c]):
            for xx,b in enumerate(row):
                if b=='1':d.point((x+xx,216+yy),fill=hw.WHITE)
        x+=6
    return np.asarray(im).copy()

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    hw.OUT=OUT;hw.row_palette=palettes;hw.EXTRA[9]=0x38
    pix=picture();fonts,screen,pmg,mux,expected,counts=hw.compile_art(pix,fixed_cat=False)
    hw.write_cartridge(fonts,screen,pmg,mux)
    np.savez_compressed(OUT/'native-art.npz',pixels=pix,pmg=pmg,mux=mux,expected=expected)
    from raster_probe import Session
    s=Session(OUT/'proposal.car',OUT/'pal','pal')
    try:
        time.sleep(.5);s.capture().save(OUT/'proposal-pal.png')
        time.sleep(.1);s.capture().save(OUT/'proposal-pal-second.png')
    finally:s.close()
    a=np.asarray(Image.open(OUT/'proposal-pal.png'))[32:480,16:656]
    sample=a[::2,::4]
    palette={int(c):Counter(map(tuple,sample[expected==c])).most_common(1)[0][0] for c in np.unique(expected)}
    target=np.empty((*expected.shape,3),dtype=np.uint8)
    for c,rgb in palette.items():target[expected==c]=rgb
    target=np.repeat(np.repeat(target,2,axis=0),4,axis=1)
    mismatches=int(np.any(a!=target,axis=2).sum())
    assert mismatches==0,('emulator pixel mismatches',mismatches)
    assert (OUT/'proposal-pal.png').read_bytes()==(OUT/'proposal-pal-second.png').read_bytes()
    report=dict(status='Static art proposal at arcade relative scale',
       arcade_original_pixels=dict(motorcycle=[19,20],airplane=[27,21],screen=[256,224]),
       atari_pixels=dict(motorcycle=[12,20],airplane=[17,21],screen=[160,224]),
       full_emulator_pixel_mismatches=mismatches,stable_capture=True,font_patterns=counts,
       emulator='Atari800 stock 64 KB XL, PAL',rom_bytes=16384)
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    shutil.copyfile(OUT/'proposal-pal.png',ROOT/'release/Flicky-Intro-Art-Proposal-PAL.png')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
