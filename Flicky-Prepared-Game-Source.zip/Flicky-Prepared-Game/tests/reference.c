/* Independent Z80 oracle: floooh/chips, zlib license retained in vendor/z80.h. */
#define CHIPS_IMPL
#include "../vendor/z80.h"
#include <string.h>
typedef struct {
    uint8_t a,f,b,c,d,e,h,l,r;
    uint16_t sp,pc;
    uint32_t ticks;
} Result;
int reference_run(const uint8_t *program, unsigned length, uint8_t *memory,
                  const Result *initial, Result *out, unsigned limit) {
    z80_t cpu;
    z80_init(&cpu);
    cpu.a=initial->a; cpu.f=initial->f; cpu.b=initial->b; cpu.c=initial->c;
    cpu.d=initial->d; cpu.e=initial->e; cpu.h=initial->h; cpu.l=initial->l;
    cpu.r=initial->r; cpu.sp=initial->sp;
    memcpy(memory,program,length);
    uint64_t pins=z80_prefetch(&cpu,0);
    unsigned t;
    for(t=0;t<limit;t++) {
        pins=z80_tick(&cpu,pins);
        if(pins & Z80_MREQ) {
            unsigned addr=Z80_GET_ADDR(pins);
            if(pins & Z80_RD) { Z80_SET_DATA(pins,memory[addr]); }
            else if(pins & Z80_WR) memory[addr]=Z80_GET_DATA(pins);
        }
        if((pins & (Z80_IORQ|Z80_RD))==(Z80_IORQ|Z80_RD)) { Z80_SET_DATA(pins,0xFF); }
        if(pins & Z80_HALT) break;
    }
    *out=(Result){cpu.a,cpu.f,cpu.b,cpu.c,cpu.d,cpu.e,cpu.h,cpu.l,cpu.r,cpu.sp,cpu.pc,t+1};
    return t<limit;
}
