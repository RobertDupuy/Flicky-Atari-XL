; Handwritten native motion. Original physics units are retained exactly.
; Reference algorithms: $7322, $72dc, $733f/$7369, $73ba, $1dc2..$1e9c.
.segment "FIXED"
.export motion_delta,motion_integrate,motion_accelerate,motion_gravity
.export motion_vertical_stop,world_motion,round_select,native_reset
.export n_fraction,n_flags,n_xlo,n_xhi,n_ylo,n_yhi,n_vx,n_fx,n_vy,n_fy
.export n_target,n_acceleration,n_round,n_layout,n_bonus,n_theme
.export n_grounded,n_ceiling,n_input,n_world,n_scroll_delta,n_pose

; A = signed velocity in sixteenths; n_fraction = 0..15.
; Return signed whole-pixel displacement in A and new fraction in n_fraction.
motion_delta:
    clc
    adc n_fraction
    sta n_sum
    and #15
    sta n_fraction
    lda n_sum
    bvs @unsigned
    bpl @unsigned
    lsr a
    lsr a
    lsr a
    lsr a
    ora #$f0
    rts
@unsigned:
    lsr a
    lsr a
    lsr a
    lsr a
    rts

; X = actor. Fractional positions are separate from integer coordinates.
motion_integrate:
    lda n_fx,x
    sta n_fraction
    lda n_vx,x
    jsr motion_delta
    sta n_step
    ; The source X helper uses the sum's sign even on signed overflow.
    ; Y below tests the returned displacement; retain this edge distinction.
    lda n_sum
    cmp #$80
    ldy #0
    bcc :+
    dey
:   lda n_step
    clc
    adc n_xlo,x
    sta n_xlo,x
    tya
    adc n_xhi,x
    sta n_xhi,x
    lda n_fraction
    sta n_fx,x
    lda n_vy,x
    beq @done
    pha
    lda n_fy,x
    sta n_fraction
    pla
    jsr motion_delta
    cmp #$80
    ldy #0
    bcc :+
    dey
:   clc
    adc n_ylo,x
    sta n_ylo,x
    tya
    adc n_yhi,x
    sta n_yhi,x
    lda n_fraction
    sta n_fy,x
@done:
    rts

; X = actor. Preserve the original signed-byte limit/crossing behavior.
motion_accelerate:
    lda n_acceleration,x
    bmi @negative_step
    lda n_vx,x
    bmi @positive_from_negative
@positive_compare:
    clc
    adc n_acceleration,x
    sta n_candidate
@compare_positive:
    lda n_target,x
    sec
    sbc n_candidate
    bmi @limit
    jmp @candidate
@positive_from_negative:
    lda n_target,x
    bmi @positive_negative_goal
    lda n_vx,x
    clc
    adc n_acceleration,x
    sta n_candidate
    bmi @candidate
    jmp @compare_positive
@positive_negative_goal:
    lda n_vx,x
    clc
    adc n_acceleration,x
    sta n_candidate
    bmi @compare_positive
    bpl @limit
@negative_step:
    lda n_vx,x
    bpl @negative_from_positive
@negative_compare:
    clc
    adc n_acceleration,x
    sta n_candidate
@compare_negative:
    lda n_candidate
    sec
    sbc n_target,x
    bpl @candidate
    bmi @limit
@negative_from_positive:
    lda n_target,x
    bpl @negative_positive_goal
    lda n_vx,x
    clc
    adc n_acceleration,x
    sta n_candidate
    bpl @candidate
    bmi @compare_negative
@negative_positive_goal:
    lda n_vx,x
    clc
    adc n_acceleration,x
    sta n_candidate
    bpl @compare_negative
@limit:
    lda n_target,x
    sta n_vx,x
    lda n_flags,x
    ora #8
    sta n_flags,x
    sec
    rts
@candidate:
    lda n_candidate
    sta n_vx,x
    clc
    rts

motion_gravity:
    lda n_vy,x
    clc
    adc #1
    bmi @store
    cmp #$31
    bcc @store
    sec
    sbc #1
@store:
    sta n_vy,x
    rts

motion_vertical_stop:
    lda n_flags+PLAYER
    and #$f7
    sta n_flags+PLAYER
    lda n_ceiling
    beq @floor
    lda n_vy+PLAYER
    bpl @done
    bmi @stop
@floor:
    lda n_vy+PLAYER
    bmi @done
@stop:
    lda #0
    sta n_vy+PLAYER
@done:
    rts

; Active-low source direction bits: $80 left, $40 right.
; World coordinates eliminate the original per-frame translation of 26 actors.
world_motion:
    lda #4
    NATIVE_BANK
    jmp world_motion_bank
.segment "BANK4"
world_motion_bank:
    lda n_exiting
    beq :+
    rts
:   
    ldx #CAMERA
    lda n_input
    and #$80
    bne @right
    lda n_target+CAMERA
    beq @left_target
    bpl @accelerate
@left_target:
    lda #$30
    sta n_target+CAMERA
    lda #3
    bne @new_acceleration
@right:
    lda n_input
    and #$40
    bne @released
    lda n_target+CAMERA
    bmi @accelerate
    lda #$d0
    sta n_target+CAMERA
    lda #$fd
    bne @new_acceleration
@released:
    lda n_grounded
    beq @integrate
    lda n_vx+CAMERA
    beq @no_move
    pha
    lda #0
    sta n_target+CAMERA
    pla
    bmi @brake_negative
    lda #$ff
    bne @new_acceleration
@brake_negative:
    lda #1
@new_acceleration:
    sta n_acceleration+CAMERA
    lda n_flags+CAMERA
    and #$f7
    sta n_flags+CAMERA
@accelerate:
    lda n_flags+CAMERA
    and #8
    bne @integrate
    jsr motion_accelerate
@integrate:
    lda n_fx+CAMERA
    sta n_fraction
    lda n_vx+CAMERA
    jsr motion_delta
    sta n_scroll_delta
    cmp #$80
    ldy #0
    bcc :+
    dey
:   sty n_scroll_delta+1
    clc
    adc n_world
    sta n_world
    tya
    adc n_world+1
    sta n_world+1
    lda n_fraction
    sta n_fx+CAMERA
    rts
@no_move:
    ; Caller clears delta before each update, including stationary early exits.
    rts

.segment "FIXED"
round_select:
    lda n_round
@wrap:
    cmp #48
    bcc @lookup
    sec
    sbc #48
    bcs @wrap
@lookup:
    tax
    lda native_round_layout,x
    sta n_layout
    lda n_round
    clc
    adc #1
    pha
    and #3
    cmp #3
    lda #0
    rol a
    sta n_bonus
    pla
    and #$fc
    lsr a
    lsr a
@theme:
    cmp #6
    bcc @theme_ready
    sec
    sbc #6
    bcs @theme
@theme_ready:
    clc
    adc #1
    sta n_theme
    rts

native_reset:
    ldx #0
    lda #0
@clear:
    sta $0700,x
    sta $0800,x
    sta $0900,x
    inx
    bne @clear
    lda #3
    sta n_lives
    lda #$ff
    sta n_input
    sta n_last_input
    lda #$80
    sta n_flags+PLAYER
    lda #1
    sta n_grounded
    sta n_world+1
    sta n_xhi+PLAYER
    lda #$f8
    sta n_world
    lda #$30
    sta n_target+CAMERA
    lda #2
    sta n_acceleration+CAMERA
    jsr round_select
    ldx n_layout
    lda native_player_start_y,x
    sta n_ylo+PLAYER
    rts
