"""Host-side specifications for later native integration, not the cartridge bus.

These preserve timing and collision-latch behavior before optimization.
Clock rates come from MAME System 1 and Atari800's src/atari.h.
"""
from fractions import Fraction

ARCADE_FPS=Fraction(10_000_000,640*260)
HOST_FPS={'ntsc':Fraction(3_579_545,262*228),'pal':Fraction(3_546_895,312*228)}
MASTER_TICKS_PER_FRAME=332800

class FrameScheduler:
    """Rational phase accumulator; never rounds the arcade clock to 60 Hz."""
    def __init__(self, standard):
        ratio=ARCADE_FPS/HOST_FPS[standard]
        self.increment,self.denominator=ratio.numerator,ratio.denominator
        self.phase=0
    def next_frame(self):
        self.phase+=self.increment
        ticks,self.phase=divmod(self.phase,self.denominator)
        return ticks

def master_ticks(nominal_z80_tstates,m1_fetches,wait_tstates=0):
    """5 master clocks/T-state plus 2 extra clocks on each M1 fetch.

    Caller must supply video WAIT time; instruction counters alone do not
    constitute a complete cycle-accurate System 1 implementation.
    """
    return 5*(nominal_z80_tstates+wait_tstates)+2*m1_fetches

class CollisionLatch:
    def __init__(self,size):
        if size not in (64,1024): raise ValueError('Mixer=64; sprite/sprite=1024')
        self.bits=bytearray(size)
        self.summary=0
    def hit(self,index):
        self.bits[index&(len(self.bits)-1)]=1
        self.summary=1
    def read(self,address):
        return self.bits[address&(len(self.bits)-1)]|0x7e|(self.summary<<7)
    def clear_entry(self,address):
        self.bits[address&(len(self.bits)-1)]=0
    def clear_summary(self):
        self.summary=0

def character_pixel(byte,pixel,char_code):
    """ANTIC 4 register index: 0=BK,1=PF0,2=PF1,3=PF2,4=PF3."""
    code=(byte>>(6-2*pixel))&3
    return 4 if code==3 and char_code&0x80 else code
