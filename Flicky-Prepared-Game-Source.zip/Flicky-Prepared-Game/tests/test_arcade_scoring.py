"""Current 6502 scoring against actual MAME outputs, including BCD carries.

The golden values are reproducible with tools/arcade_scoring_mame.lua and
tools/check_arcade_scoring.py plus the user's original ROM; tests need no ROM.
"""
import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import ROOT

def put_score(n,value):
    digits=f'{value:06d}'
    for i in range(3):n.set('n_score',int(digits[4-i*2:6-i*2],16),i)

def get_score(n):
    return int(''.join(f'{n.get("n_score",i):02x}' for i in (2,1,0)))

def test_scoring_time_bonus_lives_and_sound_match_255_mame_cases():
    fixture=json.loads((ROOT/'tests/fixtures/arcade-scoring-mame.json').read_text())
    assert len(fixture['cases'])==255 and fixture['provenance']['independent_z80_crosscheck']
    n=Engine();n.lib.at_video_timing(0)
    for c in fixture['cases']:
        n.call('native_reset');n.call('chicks_reset')
        put_score(n,c['input_score'])
        n.set('n_lives',c['input_lives']);n.set('u_extra',c['input_milestone'])
        n.set('n_sound_event',0)
        if c['kind']=='event':
            # chicks_reset selected the bank containing this shared routine.
            n.call('chick_score',a=c['event'])
        else:
            n.set('n_round_seconds',c['seconds']);n.set('n_round_seconds',c['seconds']>>8,1)
            n.call('game_time_bonus')
        n.ram[0xe700:0xe708]=255
        n.call('ui_refresh')
        actual=dict(score=get_score(n),lives=n.get('n_lives'),milestone=n.get('u_extra'),life_sound=n.get('n_sound_event'))
        assert actual=={k:c[k] for k in actual},(c,actual)
        n.set('n_sound_event',0)
        for _ in range(3):n.call('ui_refresh')
        assert n.get('n_lives')==c['lives'] and n.get('n_sound_event')==0,c

def test_milestones_survive_round_change_and_reset_for_new_game():
    n=Engine();n.lib.at_video_timing(0);n.call('native_reset')
    for value,index in ((30000,1),(80000,2),(160000,3),(170000,3),(200000,3)):
        put_score(n,value);n.call('ui_refresh')
        assert n.get('n_lives')==3+index and n.get('u_extra')==index
        n.set('n_round',1);n.call('game_round_load')
        assert n.get('n_lives')==3+index and n.get('u_extra')==index
    n.call('native_reset')
    assert get_score(n)==0 and n.get('n_lives')==3 and n.get('u_extra')==0
