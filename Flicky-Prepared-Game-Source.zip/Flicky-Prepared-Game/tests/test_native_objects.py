"""Compact native object artwork, state and projectile behavior."""
import json,random,subprocess,sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine
from native_oracle import Original
from test_native_idle_characters import pixels

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    e=Engine()
    yield e
    (BUILD/'native/object-cycles.json').write_text(json.dumps(e.maximum,indent=2)+'\n')


@pytest.mark.parametrize('object_state', [0, 0x40])
def test_all_object_rotations_and_character_alignments(native, object_state):
    native.call('native_reset');native.call('level_load');native.call('display_init')
    data=json.loads((BUILD/'native/object-assets.json').read_text())
    images={i:(BUILD/f'native/object-pixels-{i:03}.bin').read_bytes() for i in set(data['images'])}
    background=pixels(native,0)
    for trial in range(5760):
        index=trial//8;phasey=trial&7;pose=index//8;facing=(index>>2)&1;phase=index&3
        kind=pose//6;frame=pose%3;flip=pose%6>=3;buffer=trial&1;actor=12+trial%6
        row=data['records'][index];radius=2*(row['stride']-1)
        world=(256-radius-4*phase)&511;position=(256-world)&65535
        native.set('r_back',buffer);native.call('sprites_begin')
        native.set('n_world',world);native.set('n_world',world>>8,1)
        native.set('n_flags',0xb0|facing|2*flip,actor);native.set('n_animation',kind,actor)
        native.set('n_frame',frame,actor);native.set('n_chick_state',object_state,actor)
        native.set('n_xlo',position,actor);native.set('n_xhi',position>>8,actor)
        center=80+row['height']//2-1+phasey;native.set('n_ylo',center,actor)
        image=images[data['images'][index]];height,width,ink=image[:3];cursor=3
        expected=background.copy();top=center-height//2+1;column=phase//4
        # world was chosen so the object's world-relative left is exactly 4*phase.
        for y in range(height):
            for c in range(width):
                keep,value=image[cursor:cursor+2];cursor+=2;dest=(column+c)*4;line=top+y
                if value&(value>>1)&0x55:
                    cell=expected[line//8*8:line//8*8+8,dest:dest+4]
                    cell[cell==(3 if ink else 4)]=1
                for x in range(4):
                    shift=6-2*x
                    if not (keep>>shift)&3:
                        v=(value>>shift)&3;expected[line,dest+x]=4 if v==3 and ink else v
        native.call('sprite_draw_object',x=actor)
        assert native.get('r_fault')==0,trial
        np.testing.assert_array_equal(pixels(native,buffer),expected,err_msg=f'object rotation {trial}')
