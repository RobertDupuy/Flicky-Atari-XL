#!/usr/bin/env python3
"""Package sources and validation artifacts; never include imported game ROMs."""
from pathlib import Path
import argparse, zipfile
from build import ROOT

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    allowed_build={'.bin','.car','.rom','.lbl','.map','.png','.log','.json','.z80','.s'}
    with zipfile.ZipFile(a.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for file in sorted(ROOT.rglob('*')):
            if not file.is_file(): continue
            relative=file.relative_to(ROOT)
            if set(relative.parts)&{'private-roms','__pycache__','.pytest_cache','.git'}: continue
            if relative.parts[0]=='build' and file.suffix not in allowed_build: continue
            if file.name=='xvfb.log': continue
            if file.suffix=='.zip': continue
            z.write(file,'flicky-xl/'+str(relative))
    print(a.output)

if __name__=='__main__': main()
