#!/usr/bin/env python3
"""Repeatable headless CPU counts. Excludes ANTIC DMA and interrupt overlap."""
import ctypes as C,json
import numpy as np
from run_native import Native,BUILD

def main():
    n=Native(True)
    boot=n.run();logic=[n.resume() for _ in range(60)]
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    def call(name,a=0):
        count=n.lib.at_call(n.labels[name],a,0,0)
        assert count>0
        return count
    s=np.fromfile(BUILD/'reference/ram-00600.bin',dtype=np.uint8)
    n.memory[0xc000:0xd000]=s[0xc000:0xd000]
    n.memory[0x7000:0x7800]=s[0xd000:0xd800]
    n.memory[0xd800:0xf000]=s[0xd800:0xf000]
    n.memory[n.labels['z_video']]=0
    call('render_init')
    render=[call('render_frame') for _ in range(3)]
    call('audio_init');call('audio_enqueue',0x83)
    audio=[call('audio_vbi') for _ in range(1400)]
    result={'kind':'headless NMOS6502 counts, excludes ANTIC DMA/NMI overlap',
        'boot_to_first_halt':boot,'logic_60_attract_mean':sum(logic)/len(logic),
        'logic_60_attract_max':max(logic),'render_snapshot600_first_cached_cached':render,
        'audio_vbi_1400_music83_max':max(audio),'cartridge_payload':131072}
    (BUILD/'performance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
