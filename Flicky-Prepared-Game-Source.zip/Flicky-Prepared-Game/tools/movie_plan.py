import sys,time,json,heapq,os
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_engine import Engine
from build import ROOT,BUILD
MODE=os.environ.get('FLICKY_MOVIE_VARIANT','ntsc')
CARTRIDGE=ROOT/f'release/Flicky-Atari-XL-{MODE.upper()}-512K.car'
E=Engine(CARTRIDGE,BUILD/f'variants/{MODE}/native.lbl');L=E.labels
KERNEL=CARTRIDGE.read_bytes()[16+8192:16+8192+64]
VISITS={}
E.call('native_reset');E.set('u_mode',0);E.call('game_round_load');E.lib.at_video_timing(0)
def v(m,k,i=0):return int(m[L[k]+i])
def xy(m,i=8):
 if i==8 and not v(m,'n_bonus'):return ((256-v(m,'n_world')-256*v(m,'n_world',1))&511,v(m,'n_ylo',8))
 return (v(m,'n_xlo',i)+256*v(m,'n_xhi',i),v(m,'n_ylo',i))
def goal(m,i):
 if isinstance(i,tuple):
  px,py=xy(m);tx,ty=i
  return abs((px-tx+256)%512-256)<10 and abs(py-ty)<10
 return bool(v(m,'n_rescued')&(1<<i) or v(m,'n_chick_state',i)&1)
def dead(m):return v(m,'n_lives')==0 or bool(v(m,'n_flags',8)&4)
def status(m):return dict(p=xy(m),train=v(m,'n_train'),rescued=v(m,'n_rescued'),lives=v(m,'n_lives'),round=v(m,'n_round'),flags=v(m,'n_flags',8),ground=v(m,'n_grounded'))
ACTIONS=(0xff,0xbf,0x7f,0xfb,0xbb,0x7b)
def tick(key,n=8):
 E.set('n_input',key);E.set('r_input',key)
 E.ram[0xd300]=0xff^((0 if key&0x80 else 4)|(0 if key&0x40 else 8));E.ram[0xd010]=int(bool(key&4))
 for _ in range(n):
  E.set('n_input',key);E.call('game_update')
  if dead(E.ram):break
 return E.ram.copy()
def cost(m,target):
 px,py=xy(m);tx,ty=target if isinstance(target,tuple) else xy(m,target)
 dx=abs((px-tx+256)%512-256);dy=abs(py-ty)
 have=sum(goal(m,i)for i in range(8))
 return dx*.5+dy*2-have*1000+VISITS.get((px//16,py//8),0)*12

def search(base,target,depth=16,width=22,span=8):
 beam=[(cost(base,target),0,base,[])];serial=0;best=beam[0]
 for d in range(depth):
  candidates=[];seen=set()
  for _,_,m,path in beam:
   for key in ACTIONS:
    E.ram[:]=m;E.lib.at_set_cart_control(int(m[0x61f]))
    # The planning copy runs logic only. Skip the raster-time rescue pause;
    # the live emulator still executes that pause and all graphics normally.
    E.ram[L['rescue_wait']]=0x60
    nxt=tick(key,span)
    if dead(nxt) or v(nxt,'n_lives')<v(base,'n_lives'):continue
    serial+=1;newpath=path+[(key,span)]
    c=cost(nxt,target);node=(c,serial,nxt,newpath)
    if goal(nxt,target):return node,True
    # Preserve fractional motion and basic input latch while merging close states.
    px,py=xy(nxt)
    sig=(px//4,py//2,v(nxt,'n_vx',31)//4,v(nxt,'n_vy',8)//4,v(nxt,'n_grounded'),key,sum(1<<i for i in range(8)if goal(nxt,i)))
    if sig in seen:continue
    seen.add(sig);candidates.append(node)
  if not candidates:break
  beam=heapq.nsmallest(width,candidates)
  if beam[0][0]<best[0]:best=beam[0]
 return (best if best[3] else beam[0]),False

