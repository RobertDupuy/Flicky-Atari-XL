; A floor object is painted once per display buffer. Its glyphs stay pinned
; until pickup, when its saved background is restored on that buffer.
f_floor_ptr=$d4
f_floor_mode=$d6
f_floor_offset=$d7
f_floor_meta=$d8
.segment "FIXED"
.export floor_cache_reset,floor_cached_object
floor_cache_reset:
    lda #0
    sta f_floor_mode
    ldx #0
@clear:
    sta $e400,x
    sta $e500,x
    sta $e600,x
    inx
    bne @clear
    rts

floor_cached_object:
    txa
    sec
    sbc #12
    ldy r_back
    beq :+
    clc
    adc #6
:   pha
    and #3
    lsr a
    ror a
    ror a
    sta f_floor_ptr
    pla
    lsr a
    lsr a
    clc
    adc #$e4
    sta f_floor_ptr+1
    ldy #0
    lda (f_floor_ptr),y
    sta f_floor_offset
    lda n_flags,x
    bpl @remove
    lda n_chick_state,x
    bne @remove
    lda f_floor_offset
    bne @done
    lda #1
    sta f_floor_mode
    sta f_floor_offset
    jsr sprite_draw_object
    ldy #0
    lda f_floor_offset
    sta (f_floor_ptr),y
    lda #0
    sta f_floor_mode
@done:
    rts
@remove:
    lda f_floor_offset
    beq @done
    lda #1
    sta f_floor_mode
@cell:
    ldy f_floor_mode
    cpy f_floor_offset
    bcs @removed
    lda (f_floor_ptr),y
    sta r_screen
    iny
    lda (f_floor_ptr),y
    sta r_screen+1
    iny
    lda (f_floor_ptr),y
    pha
    iny
    iny
    lda (f_floor_ptr),y
    sta f_floor_meta
    iny
    lda (f_floor_ptr),y
    sta f_floor_meta+1
    iny
    sty f_floor_mode
    pla
    jsr sprite_write_cell
    lda f_floor_meta+1
    beq @cell
    lda #0
    ldy #2
@unpin:
    sta (f_floor_meta),y
    dey
    bpl @unpin
    jmp @cell
@removed:
    lda #0
    sta f_floor_mode
    tay
    sta (f_floor_ptr),y
    rts

.segment "HIGHRAM"
fast_floor_pin:
    lda p_code
    cmp #64
    bcs :+
    tay
    lda #0
    sta (p_negative_mask),y
    lda #0
    sta f_floor_meta
    sta f_floor_meta+1
    beq @record
:   
    cmp #112
    bcc :+
    inc r_fault
    rts
:   sec
    sbc #64
    asl a
    asl a
    clc
    adc p_meta
    sta f_floor_meta
    lda p_meta+1
    adc #0
    sta f_floor_meta+1
    ldy #2
    lda #255
@pin:
    sta (f_floor_meta),y
    dey
    bpl @pin
@record:
    ldy f_floor_offset
    lda r_screen
    sta (f_floor_ptr),y
    iny
    lda r_screen+1
    sta (f_floor_ptr),y
    iny
    lda p_bg
    sta (f_floor_ptr),y
    iny
    lda p_code
    sta (f_floor_ptr),y
    iny
    lda f_floor_meta
    sta (f_floor_ptr),y
    iny
    lda f_floor_meta+1
    sta (f_floor_ptr),y
    iny
    sty f_floor_offset
    rts

.segment "FIXED"
prime_floor_objects:
    lda #0
    sta r_back
@buffer:
    lda #12
    sta n_actor_cursor
@object:
    ldx n_actor_cursor
    jsr floor_cached_object
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #18
    bcc @object
    inc r_back
    lda r_back
    cmp #2
    bcc @buffer
    lda #1
    sta r_back
    rts
