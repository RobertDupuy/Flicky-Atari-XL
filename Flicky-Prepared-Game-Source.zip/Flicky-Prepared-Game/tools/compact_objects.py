"""Keep only cold floor poses; every moving pose uses the prepared strip path."""
import json

def build(out):
    d=json.loads((out/'object-assets.json').read_text())
    # Preserve converted layout/dimension tables: rebuilding never needs ROMs.
    old=(out/'object-data.s').read_text()
    tail=old[old.index('.segment "BANK3"'):]
    chosen=[i for i,m in enumerate(d['records']) if m['animation']%6==0 and m['facing']==0]
    lookup={(d['records'][i]['animation']//6,d['records'][i]['phase']):i for i in chosen}
    lines=['.segment "UPPER14"'];pointers={};size=0
    for i in chosen:
        img=d['images'][i];mask=d['masks'][i]
        for kind,ident in [('pixels',img),('mask',mask)]:
            key=kind,ident
            if key in pointers:continue
            name=f'object-{kind}-{ident:03d}.bin';data=(out/name).read_bytes()
            label=f'floor_{kind}_{ident}';pointers[key]=label
            lines += [label+':',f'.incbin "{name}"'];size+=len(data)
    assert size<=8192
    lines+=['.segment "UPPER13"','native_object_records:']
    for m in d['records']:
        i=lookup[m['animation']//6,m['phase']];img=d['images'][i];mask=d['masks'][i]
        lines += [f'.byte {(out/f"object-pixels-{img:03d}.bin").stat().st_size}',
                  f'.word {pointers["pixels",img]}','.byte 14',f'.word {pointers["mask",mask]}','.byte 14']
    (out/'floor-object-data.s').write_text('\n'.join(lines)+'\n'+tail)
    (out/'floor-objects.json').write_text(json.dumps({'poses':len(chosen),'pixel_and_mask_bytes':size,'directory_bytes':len(d['records'])*7},indent=2)+'\n')
