"""Arcade ROM golden traces, full-size prepared art and bonus lifecycle."""
import sys,json
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import BUILD
from check_arcade_bonus import SLOTS,FIELDS

def start(n,stage=2):
    n.lib.at_video_timing(0);n.call('native_reset');n.set('n_round',stage)
    n.call('game_round_load');n.set('u_wait',0)

def test_every_arcade_flight_matches_original_instruction_trace():
    n=Engine();gold=np.load(BUILD/'native/arcade-bonus-golden.npz')
    addresses=np.array([n.labels[name]+np.array(SLOTS) for name in FIELDS.values()]).T
    for key in gold:
        start(n,int(key[1:])-1)
        for tick,frame in enumerate(gold[key]):
            expected=frame.reshape(20,17).copy();actual=n.ram[addresses].copy()
            expected[:,0]&=0x8f;actual[:,0]&=0x8f
            np.testing.assert_array_equal(actual,expected[:,:16],err_msg=f'{key}, tick {tick}')
            np.testing.assert_array_equal(n.ram[n.labels['n_animation']+np.array(SLOTS)],expected[:,16])
            for actor in SLOTS:n.call('bonus_bird_step',x=actor)

def pixels(n,back=0):
    out=np.empty((224,128),dtype=np.uint8)
    for row in range(28):
        for col in range(32):
            code=int(n.ram[0x6000+back*4096+row*96+col])
            ptr=0x2000+back*8192+(row//4)*1024+(code&127)*8
            for y,b in enumerate(n.ram[ptr:ptr+8]):
                for x in range(4):out[row*8+y,col*4+x]=(int(b)>>(6-2*x))&3
    return out

def test_bonus_stamps_keep_every_source_pixel_and_uncovered_background():
    n=Engine();start(n)
    for art in range(8):
        for phase in range(4):
            raw=(BUILD/f'native/arcade-bonus-art-{art:02d}-{phase}.bin').read_bytes()
            h,w,_,span=raw[:4];p=int.from_bytes(raw[4:6],'little')
            for py in range(8):
                for background in (0,0x66):
                    n.set('r_back',0);n.ram[0x660:0x662]=0;n.call('fast_sprites_begin')
                    for b in range(7):
                        n.ram[0x2000+b*1024:0x2008+b*1024]=background
                        n.ram[0xec00+b*256]=128 if background==0 else 0
                    for r in range(28):n.ram[0x6000+r*96:0x6060+r*96]=128
                    before=pixels(n);expected=before.copy()
                    top=88+py;left=144+phase*4
                    n.ram[0x72:0x75]=[left&255,left>>8,top];n.ram[0x7fb]=art
                    n.call('bonus_stamp')
                    for y in range(h):
                        for c in range(w):
                            mask=raw[p+c*span*2+7+y];bits=raw[p+c*span*2+span+7+y]
                            for x in range(4):
                                shift=6-2*x;px=36+c*4+x
                                expected[top+y,px]=(expected[top+y,px]&((mask>>shift)&3))|((bits>>shift)&3)
                    np.testing.assert_array_equal(pixels(n),expected,err_msg=f'art {art}, phase {phase}/{py}, bg {background}')

def test_bonus_player_hardware_bitmap_is_uploaded_with_software_cats():
    n=Engine();start(n)
    for back in (0,1):
        n.set('r_back',back);n.call('native_render_submit')
        base=0xc00 if back==0 else 0xdc00
        assert any(n.ram[base:base+256])
        assert any(n.ram[base+256:base+512])
        assert n.get('pm_x') and n.get('pm_x',1)
        assert not n.get('pm_x',2) and not n.get('pm_x',3)

def test_original_sprite_ownership_edge_clipping_and_collision_latches():
    n=Engine();start(n)
    gold=np.load(BUILD/'native/arcade-bonus-collision-golden.npz')
    for data,expected in zip(gold['inputs'],gold['expected']):
        n.set('b_net',int(data[0]));n.ram[0x1be0:0x1be3]=data[1:4]
        n.ram[0x1ca0:0x1cb4]=data[4:24];n.set('b_caught',0);n.set('b_done',0)
        birds=data[24:].reshape(20,7)
        for slot,(lo,hi,y,art,vel,flags,visible) in zip(SLOTS,birds):
            n.set('n_flags',int(flags),slot);n.set('n_vy',int(vel),slot)
            for base,value in [(0x1c00,lo),(0x1c20,hi),(0x1c40,y),(0x1c60,art),(0x1c80,visible)]:n.ram[base+slot]=value
        n.call('bonus_catch')
        actual=next((i for i,slot in enumerate(SLOTS) if not birds[i,5]&4 and n.get('n_flags',slot)&4),255)
        assert actual==expected[0]
        np.testing.assert_array_equal(n.ram[0x1ca0:0x1cb4],expected[1:])

def test_net_remains_attached_to_the_moving_player():
    n=Engine();start(n)
    for key in [191]*100+[127]*100+[255]*100:
        n.set('n_input',key);n.call('bonus_update')
        player=n.get('n_xlo',8)+256*n.get('n_xhi',8)
        net=int(n.ram[0x1be0])+256*int(n.ram[0x1be1])
        assert net==(player+(-16 if n.get('n_flags',8)&1 else 16))&65535

@pytest.mark.parametrize('caught',range(21))
def test_arcade_points_and_original_result_layout(caught):
    n=Engine();start(n);n.set('b_caught',caught);n.set('b_done',20)
    for a in SLOTS:n.set('n_flags',0x84,a)
    n.call('bonus_update')
    score=int(''.join(f'{n.get("n_score",i):02x}' for i in (2,1,0)))
    assert score==caught*250+(10000 if caught==20 else 0)
    assert n.get('n_round_complete')==1 and n.get('n_lives')==3
    n.call('message_result');assert n.get('u_mode')==0
    overlay=(BUILD/'native/arcade-bonus-overlays.bin').read_bytes()[caught*896:(caught+1)*896]
    font=(BUILD/'native/arcade-bonus-font.bin').read_bytes()
    for r in (5,9,12,14):
        for c,ch in enumerate(overlay[r*32:(r+1)*32]):
            if not ch:continue
            for back in (0,1):
                code=int(n.ram[0x6000+back*4096+r*96+c]);p=0x2000+back*8192+(r//4)*1024+(code&127)*8
                expected=font[ch*8:ch*8+8]
                if ch==47:expected=bytes(x*3 for x in expected)
                assert bytes(n.ram[p:p+8])==expected,(caught,r,c)

def test_all_bonus_patterns_render_without_damage_or_glyph_overflow():
    n=Engine();report=[]
    for stage in range(2,48,4):
        start(n,stage);maximum=0
        for tick in range(910):
            n.call('bonus_update')
            if tick%2:continue
            back=(tick//2)&1;n.set('r_back',back)
            front=n.ram[0x2000+(back^1)*8192:0x3c00+(back^1)*8192].copy()
            before=n.lib.at_cycles();n.call('native_render_submit');maximum=max(maximum,n.lib.at_cycles()-before)
            assert n.get('r_fault')==0,(stage,tick)
            np.testing.assert_array_equal(front,n.ram[0x2000+(back^1)*8192:0x3c00+(back^1)*8192])
        assert n.get('b_done')==20
        report.append(dict(round=stage+1,maximum_render_cycles=maximum))
    (BUILD/'native/arcade-bonus-render.json').write_text(json.dumps(report,indent=2)+'\n')
