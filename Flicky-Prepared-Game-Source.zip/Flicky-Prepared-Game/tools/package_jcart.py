#!/usr/bin/env python3
"""Package both-mapper source using an explicit, ROM-free prepared-input manifest."""
import json, zipfile
from pathlib import Path
from build import ROOT

def main():
    files={ROOT/name for name in json.loads((ROOT/'prepared-source-files.json').read_text())}
    for folder in ('src','tools','tests','vendor'):
        files.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts
                     and p.suffix in ('.py','.c','.h','.s','.inc','.cfg','.lua'))
    files.update(ROOT.glob('*.md'))
    files.update(ROOT/name for name in ('LICENSE','requirements-dev.txt','.gitignore','prepared-source-files.json'))
    files.add(ROOT/'config/flicky-roms.json')
    files.update((ROOT/'tests/fixtures').glob('*.json'))
    files.update(p for p in (ROOT/'evidence').rglob('*') if p.is_file() and p.suffix in ('.json','.xml','.png'))
    out=ROOT/'release/Flicky-Prepared-Game-Source.zip';out.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(files):
            assert p.is_file(),p
            assert not any(part in ('rom','private-roms','mame-roms')for part in p.relative_to(ROOT).parts),p
            z.write(p,Path('Flicky-Prepared-Game')/p.relative_to(ROOT))
    print(out)
if __name__=='__main__':main()
