"""Fixed, masked column copies. Empty ink and all-gold cells have short paths."""
def build(out):
    lines=['.segment "HIGHRAM"']
    for side,bits,mask,bank in [('left','s_data','s_left_mask','s_bank'),('right','s_right','s_right_mask','s_right_bank')]:
        lines += [f'stamp_composite_{side}:','    sta p_fontold+1','    stx s_screen_column',f'    lda {bank}',
            '    CART_UPPER_VALUE','    sta $061f','    CART_WRITE','    lda p_fontold+1','    bpl :+','    jmp @blank',
            ':   lda $f300,y','    sta p_fontold','    lda s_occupied','    and #8','    beq @masked','    ldy #0']
        for row in range(8):
            lines += ['    lda (p_fontold),y',f'    ora ({bits}),y','    sta (r_font),y']
            if row<7:lines += ['    iny']
        lines += ['    jmp @done','@masked:','    ldy #0']
        for row in range(8):
            lines += ['    lda (p_fontold),y',f'    and ({mask}),y',f'    ora ({bits}),y','    sta (r_font),y']
            if row<7:lines += ['    iny']
        lines += ['    jmp @done','@blank:','    ldy #0']
        for row in range(8):
            lines += [f'    lda ({bits}),y','    sta (r_font),y']
            if row<7:lines += ['    iny']
        lines += ['@done:','    lda s_writer_bank','    sta $061f','    CART_WRITE','    ldx s_screen_column','    rts']
    (out/'stamp-blits.s').write_text('\n'.join(lines)+'\n')
