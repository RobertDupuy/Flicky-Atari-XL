; Twenty falling chicks, 100 each, plus 2000 for a perfect catch.
b_spawn=$07f4
b_caught=$07f5
b_clock=$07f6
b_actor=$07f7
b_active=$07f8
.segment "FIXED"
.export bonus_reset,bonus_update,b_spawn,b_caught
bonus_reset:
    lda #6
    NATIVE_BANK
    jmp bonus_reset_bank
bonus_update:
    lda #6
    NATIVE_BANK
    jmp bonus_update_bank
sprite_draw_net:
    lda n_bonus
    bne :+
    rts
:   lda #1
    sta p_visible
    sec
    lda n_xlo+PLAYER
    sbc #32
    sta p_left
    lda n_xhi+PLAYER
    sbc #0
    and #1
    sta p_left+1
    lda n_ylo+PLAYER
    sec
    sbc #18
    sta p_y
    lda p_left
    lsr a
    lsr a
    and #3
    tax
    lda #6
    sta p_imagebank
    NATIVE_BANK
    lda bonus_net_lo,x
    sta p_image
    lda bonus_net_hi,x
    sta p_image+1
    jmp fast_draw_prepared
.segment "BANK6"
bonus_reset_bank:
    lda #0
    sta b_spawn
    sta b_caught
    sta b_clock
    lda n_bonus
    beq @done
    ldx #7
    lda #0
@birds:
    sta n_flags,x
    dex
    bpl @birds
    sta n_world
    sta n_world+1
    sta n_rescued
    lda #195
    sta n_ylo+PLAYER
@done:
    rts
bonus_update_bank:
    inc n_game_ticks
    lda #0
    sta n_animation+PLAYER
    lda n_input
    and #$40
    bne @left
    clc
    lda n_xlo+PLAYER
    adc #6
    sta n_xlo+PLAYER
    lda n_xhi+PLAYER
    adc #0
    and #1
    sta n_xhi+PLAYER
    lda #$80
    sta n_flags+PLAYER
    lda #1
    sta n_animation+PLAYER
@left:
    lda n_input
    and #$80
    bne @frame
    sec
    lda n_xlo+PLAYER
    sbc #6
    sta n_xlo+PLAYER
    lda n_xhi+PLAYER
    sbc #0
    and #1
    sta n_xhi+PLAYER
    lda #$81
    sta n_flags+PLAYER
    lda #1
    sta n_animation+PLAYER
@frame:
    lda n_game_ticks
    lsr a
    lsr a
    lsr a
    and #1
    sta n_frame+PLAYER
    inc b_clock
    lda b_clock
    cmp #36
    bcc @falling
    lda #0
    sta b_clock
    ldy b_spawn
    cpy #20
    bcs @falling
    ldx #7
@free:
    lda n_flags,x
    bpl @spawn
    dex
    bpl @free
    bmi @falling
@spawn:
    lda bonus_xlo,y
    sta n_xlo,x
    lda bonus_xhi,y
    sta n_xhi,x
    lda #24
    sta n_ylo,x
    sta n_vy,x
    lda #0
    sta n_yhi,x
    sta n_vx,x
    sta n_fx,x
    sta n_fy,x
    sta n_draw_yoffset,x
    sta n_frame,x
    lda #2
    sta n_chick_state,x
    lda #$b0
    sta n_flags,x
    lda #4
    sta n_animation,x
    inc b_spawn
@falling:
    lda #0
    sta b_active
    sta b_actor
@bird:
    ldx b_actor
    lda n_flags,x
    bpl @next
    inc b_active
    jsr motion_integrate
    lda n_game_ticks
    lsr a
    lsr a
    and #1
    clc
    adc #3
    sta n_animation,x
    lda n_ylo,x
    cmp #178
    bcc @next
    cmp #209
    bcs @miss
    sec
    lda n_xlo,x
    sbc n_xlo+PLAYER
    sta f_dx
    lda n_xhi,x
    sbc n_xhi+PLAYER
    sta f_dx+1
    clc
    lda f_dx
    adc #34
    sta f_dx
    lda f_dx+1
    adc #0
    and #1
    bne @next
    lda f_dx
    cmp #69
    bcs @next
    inc b_caught
    sed
    clc
    lda n_score+1
    adc #1
    sta n_score+1
    lda n_score+2
    adc #0
    sta n_score+2
    cld
    lda #$85
    sta n_sound_event
@miss:
    lda #0
    sta n_flags,x
@next:
    inc b_actor
    lda b_actor
    cmp #8
    bcc @bird
    lda b_spawn
    cmp #20
    bne @done
    lda b_active
    bne @done
    lda b_caught
    cmp #20
    bne @complete
    sed
    clc
    lda n_score+1
    adc #$20
    sta n_score+1
    lda n_score+2
    adc #0
    sta n_score+2
    cld
@complete:
    lda #1
    sta n_round_complete
@done:
    rts
bonus_xlo: .lobytes 220,172,124,76,124,172,220,268,316,364,412,364,316,268,220,172,124,172,220,268
bonus_xhi: .hibytes 220,172,124,76,124,172,220,268,316,364,412,364,316,268,220,172,124,172,220,268
