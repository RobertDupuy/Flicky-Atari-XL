"""Native algorithms are checked against original ROM routines, not retyped models."""
import json
import ctypes as C
import random
import subprocess
import sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine
from native_oracle import Original
from run_reference import Reference
from hardware_model import FrameScheduler

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    n=Engine()
    yield n
    (BUILD/'native/algorithm-cycles.json').write_text(json.dumps(n.maximum,indent=2)+'\n')

def test_native_fractional_motion_all_velocities(native):
    original=Original()
    for velocity in range(256):
        for fraction in range(16):
            result=original.call(0x7322,af=velocity<<8,de=fraction)
            native.set('n_fraction',fraction)
            step=native.call('motion_delta',velocity)
            assert (step,native.get('n_fraction'))==(result[0]>>8,result[2]&255)

def test_native_actor_position_wraps(native):
    original=Original();randomizer=random.Random(6502)
    for _ in range(1500):
        row=bytes(randomizer.randrange(256) for _ in range(32))
        original.ram[0xc400:0xc420]=list(row)
        for name,offset in [('n_xlo',7),('n_xhi',8),('n_ylo',9),('n_yhi',10),
                            ('n_vx',18),('n_fx',19),('n_vy',20),('n_fy',21)]:
            value=row[offset]&15 if offset in (19,21) else row[offset]
            original.ram[0xc400+offset]=value;native.set(name,value,8)
        original.call(0x72dc,ix=0xc400)
        native.call('motion_integrate',x=8)
        for name,offset in [('n_xlo',7),('n_xhi',8),('n_ylo',9),('n_yhi',10),('n_fx',19),('n_fy',21)]:
            assert native.get(name,8)==original.ram[0xc400+offset],name

def test_native_acceleration_crossings_and_limits(native):
    original=Original();randomizer=random.Random(7369)
    cases=[(v,goal,step) for v in range(256) for goal in (0,48,208) for step in (1,3,253,255)]
    cases += [tuple(randomizer.randrange(256) for _ in range(3)) for _ in range(4096)]
    for velocity,goal,step in cases:
        original.ram[0xc400]=0x80
        original.ram[0xc40b]=goal;original.ram[0xc40c]=step;original.ram[0xc412]=velocity
        original.call(0x733f,ix=0xc400)
        for name,value in [('n_flags',0x80),('n_target',goal),('n_acceleration',step),('n_vx',velocity)]:
            native.set(name,value,8)
        native.call('motion_accelerate',x=8)
        assert (native.get('n_vx',8),native.get('n_flags',8))==tuple(original.ram[[0xc412,0xc400]]),(velocity,goal,step)

def test_native_gravity_and_vertical_stops(native):
    original=Original()
    for velocity in range(256):
        original.ram[0xc414]=velocity
        original.call(0x73ba,ix=0xc400)
        native.set('n_vy',velocity,8);native.call('motion_gravity',x=8)
        assert native.get('n_vy',8)==original.ram[0xc414]
        for ceiling in (0,1):
            original.ram[0xc400]=0x88;original.ram[0xc414]=velocity;original.ram[0xc020]=ceiling
            original.call(0x3b01,ix=0xc400)
            native.set('n_flags',0x88,8);native.set('n_vy',velocity,8);native.set('n_ceiling',ceiling)
            native.call('motion_vertical_stop')
            assert native.get('n_vy',8)==original.ram[0xc414]
            assert native.get('n_flags',8)==original.ram[0xc400]

def test_native_world_motion_sequences(native):
    original=Original();native.call('native_reset')
    original.ram[0xc01a:0xc01c]=[0xf8,1]
    original.ram[0xc6eb]=0x30;original.ram[0xc6ec]=2
    randomizer=random.Random(1984)
    for tick in range(3000):
        player=[255,127,191,63][(tick//71)%4]
        grounded=int(tick%173<120)
        original.ram[0xc021]=grounded
        original.ram[0xc016:0xc018]=0
        original.call(0x1dc2,ix=0xc6e0,player=player)
        native.set('n_grounded',grounded);native.set('n_input',player)
        native.call('native_tick')
        for name,address in [('n_vx',0xc6f2),('n_fx',0xc6f3),('n_target',0xc6eb),
                             ('n_acceleration',0xc6ec),('n_flags',0xc6e0)]:
            assert native.get(name,31)==original.ram[address],(tick,name)
        source_world=int(original.ram[0xc01a])|(int(original.ram[0xc01b])<<8)
        native_world=native.get('n_world')|(native.get('n_world',1)<<8)
        assert native_world==source_world,tick

def test_native_rounds_and_map_decompression(native):
    original=Original()
    for stage in range(256):
        original.ram[0xc018]=stage
        original.call(0x2785)
        native.set('n_round',stage);native.call('round_select')
        assert native.get('n_layout')==original.ram[0xc014]
        assert native.get('n_bonus')==int(((stage+1)&3)==3)
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    for stage in list(range(48))+[48,71,95,98,255]:
        native.set('n_round',stage)
        native.ram[0xbfff]=0xa5;native.ram[0xc700]=0x5a
        native.call('level_load')
        expected=maps[(stage%48)*1792:(stage%48+1)*1792]
        assert native.ram[0xc000:0xc700].tobytes()==expected
        assert native.ram[0xc700]==0x5a

def test_native_player_terrain_response(native):
    original=Original();randomizer=random.Random(0x36a9)
    fields=[('n_grounded',0,0xc021),('n_ceiling',0,0xc020),('n_blocked',0,0xc022),
            ('n_pose',8,0xc406),('n_ylo',8,0xc409),('n_vy',8,0xc414),('n_flags',8,0xc400),
            ('n_vx',31,0xc6f2),('n_target',31,0xc6eb),('n_flags',31,0xc6e0),('n_world',0,0xc01a)]
    for trial in range(4096):
        values=[randomizer.randrange(2),randomizer.randrange(2),0,randomizer.randrange(4),
                randomizer.randrange(13,204),randomizer.randrange(256),0x80,
                randomizer.randrange(256),randomizer.randrange(256),0x80,randomizer.randrange(256)]
        for (name,index,address),value in zip(fields,values):
            original.ram[address]=value;native.set(name,value,index)
        mask=trial&255;native.set('n_contacts',mask)
        original.call(0x36a9,de=mask,ix=0xc400,stop=0x3816)
        native.call('player_contacts')
        for name,index,address in fields:
            assert native.get(name,index)==original.ram[address],(trial,mask,name,values)

def test_native_player_jump_and_control_sequences(native):
    original=Original();randomizer=random.Random(0x3816)
    fields=[('n_grounded',0,0xc021),('n_ceiling',0,0xc020),('n_blocked',0,0xc022),
            ('n_action',0,0xc023),('n_exiting',0,0xc028),('n_ylo',8,0xc409),('n_yhi',8,0xc40a),
            ('n_vy',8,0xc414),('n_fy',8,0xc415),('n_flags',8,0xc400),('n_pose',8,0xc406),
            ('n_timer',8,0xc416),('n_frame',8,0xc40d),('n_action_latch',8,0xc41a),
            ('n_vx',31,0xc6f2),('n_acceleration',31,0xc6ec)]
    for trial in range(4096):
        values=[randomizer.randrange(2),randomizer.randrange(2),randomizer.choice([0,1,128]),0,0,
                randomizer.randrange(13,204),0,randomizer.randrange(256),randomizer.randrange(16),0x80,0,
                randomizer.randrange(3),randomizer.randrange(2),randomizer.choice([0,1,0x80,0x81]),
                randomizer.randrange(256),randomizer.choice([1,3,253,255])]
        for (name,index,address),value in zip(fields,values):
            original.ram[address]=value;native.set(name,value,index)
        # Horizontal player velocity is zero in the scrolling normal rounds.
        original.ram[0xc412]=0;original.ram[0xc413]=0
        native.set('n_vx',0,8);native.set('n_fx',0,8)
        player=randomizer.choice([255,251,249]);native.set('n_input',player)
        original.call(0x3816,ix=0xc400,player=player,stop=0x3988)
        native.call('player_controls')
        for name,index,address in fields:
            assert native.get(name,index)==original.ram[address],(trial,name,values,player)

def test_native_player_terrain_sampling(native):
    original=Original();randomizer=random.Random(0x3fb7)
    for trial in range(1024):
        data=bytes(randomizer.randrange(256) for _ in range(2048))
        original.ram[0xe000:0xe800]=list(data);native.ram[0xc000:0xc800]=list(data)
        world=randomizer.randrange(512);y=randomizer.randrange(13,204);pose=randomizer.randrange(4)
        original.ram[0xc01a:0xc01c]=[world&255,world>>8]
        native.set('n_world',world&255);native.set('n_world',world>>8,1)
        original.ram[0xc406]=pose;native.set('n_pose',pose,8)
        original.ram[0xc409]=y;native.set('n_ylo',y,8)
        regs=original.call(0x35ec,ix=0xc400,stop=0x36a9)
        native.call('player_sample_terrain')
        assert native.get('n_contacts')==regs[2]&255,(trial,world,y,pose)

def test_native_background_glyphs_and_wrapped_rows(native):
    tables=(BUILD/'tile-index.bin').read_bytes()
    glyphs=(BUILD/'tile-glyphs.bin').read_bytes()
    maps=np.frombuffer((BUILD/'native/maps-reference.bin').read_bytes(),dtype='<u2').reshape(48,28,32)
    for stage in range(48):
        native.set('n_round',stage);native.call('level_load');native.call('display_build')
        assert native.get('r_fault')==0
        for row in range(28):
            band=row//4
            for col in range(32):
                code=int(maps[stage,row,col])&2047
                offset=((tables[code]|tables[2048+code]<<8)-0x8000)+((tables[4096+code]&127)-9)*8192
                cell=native.get('r_background',row*32+col)
                assert cell&0x80==tables[4096+code]&0x80
                # The compromise engine samples tile flags directly. The
                # retired per-pixel collision buffer now holds UI/cache RAM.
                for fontbase,screenbase in [(0x2000,0x6000),(0x4000,0x7000)]:
                    pointer=fontbase+band*1024+(cell&127)*8
                    assert native.ram[pointer:pointer+8].tobytes()==glyphs[offset:offset+8]
                    for repeat in range(3):assert native.ram[screenbase+row*96+col+repeat*32]==cell

def test_native_player_contact_matches_original_pixel_mixer(native):
    original=Reference();randomizer=random.Random(0xf028)
    original.lib.fm_mix.restype=C.POINTER(C.c_uint8)
    blank=int(np.flatnonzero(~original.tiles.any(axis=(1,2)))[0])
    metadata=json.loads((BUILD/'native/player-assets.json').read_text())['records']
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    for stage in [0,1,7,11,19,20,23,43]:
        native.set('n_round',stage);native.call('level_load');native.call('display_build')
        original.ram[0xc000:]=0
        original.ram[0xe000:0xe700]=list(maps[stage*1792:(stage+1)*1792])
        original.ram[0xe800:0xf000:2]=blank&255
        original.ram[0xe801:0xf000:2]=blank>>8
        for trial in range(128):
            world=randomizer.randrange(512);center=randomizer.randrange(13,204)
            animation=randomizer.randrange(6);frame=randomizer.randrange(2 if animation<5 else 4)
            facing=randomizer.randrange(2)
            native.set('n_world',world&255);native.set('n_world',world>>8,1)
            native.set('n_xlo',0,8);native.set('n_xhi',1,8)
            native.set('n_ylo',center,8);native.set('n_animation',animation,8)
            native.set('n_pose',[0,0,2,3,1,1][animation],8)
            native.set('n_frame',frame,8);native.set('n_flags',0x80|facing,8)
            native.call('player_terrain_contact')
            record=metadata[animation*32+frame*8+facing*4]
            height,stride=record['height'],record['stride']
            top=center-height//2+int(animation==3)
            address=record['source']
            if facing:address=(address+stride-2)|0x8000
            address=(address-stride)&65535
            x=(256-2*(stride-1))&511
            original.ram[0xd080:0xd088]=[top,top+height,x&255,x>>8,stride,0,address&255,address>>8]
            scroll=(world-28)&65535
            original.ram[0xeffc:0xeffe]=[scroll&255,scroll>>8]
            original.lib.fm_render_snapshot(0)
            expected=int(original.lib.fm_mix()[40])
            assert native.get('n_terrain_contact')==expected,(stage,trial,world,center,animation,frame,facing)

def test_native_sprite_composition_and_buffer_restoration(native):
    native.call('native_reset');native.call('level_load');native.call('display_init')
    baseline=native.ram[0x1600:0x1980].copy()
    metadata=json.loads((BUILD/'native/player-assets.json').read_text())
    randomizer=random.Random(0x6502)
    def pixels(buffer):
        result=np.zeros((224,128),dtype=np.uint8)
        for row in range(28):
            codes=native.ram[0x6000+buffer*4096+row*96:0x6000+buffer*4096+row*96+32]
            for col,code in enumerate(codes):
                pointer=0x2000+buffer*8192+(row//4)*1024+(int(code)&127)*8
                for y,value in enumerate(native.ram[pointer:pointer+8]):
                    for x in range(4):
                        v=(int(value)>>(6-x*2))&3
                        result[row*8+y,col*4+x]=4 if v==3 and code&128 else v
        return result
    background=pixels(0)
    for trial in range(100):
        buffer=trial&1;native.set('r_back',buffer)
        native.call('sprites_begin')
        assert np.array_equal(pixels(buffer),background)
        animation=randomizer.randrange(6);frame=randomizer.randrange(2 if animation<5 else 4)
        facing=randomizer.randrange(2);world=randomizer.randrange(512);center=randomizer.randrange(13,204)
        native.set('n_world',world&255);native.set('n_world',world>>8,1)
        native.set('n_animation',animation,8);native.set('n_frame',frame,8)
        native.set('n_pose',[0,0,2,3,1,1][animation],8)
        native.set('n_flags',0x80|facing,8);native.set('n_ylo',center,8)
        entry=metadata['records'][animation*32+frame*8+facing*4]
        left=(256-world-2*(entry['stride']-1))&511
        index=animation*32+frame*8+facing*4+((left>>2)&3)
        image=(BUILD/'native'/f'player-image-{metadata["images"][index]:03}.bin').read_bytes()
        height,width,ink=image[:3];cursor=3
        expected=background.copy();top=center-height//2+1+int(animation==3);column=left//16
        for y in range(height):
            for c in range(width):
                keep,value=image[cursor:cursor+2];cursor+=2
                dest=((column+c)&31)*4;line=top+y
                if value&(value>>1)&0x55:
                    cell=expected[line//8*8:line//8*8+8,dest:dest+4]
                    cell[cell==(3 if ink else 4)]=1
                for x in range(4):
                    shift=6-2*x
                    if not (keep>>shift)&3:
                        v=(value>>shift)&3
                        expected[line,dest+x]=4 if v==3 and ink else v
        native.call('sprite_draw_player')
        assert native.get('r_fault')==0
        np.testing.assert_array_equal(pixels(buffer),expected,err_msg=f'pose {trial}')
        np.testing.assert_array_equal(native.ram[0x1600:0x1980],baseline)

def test_native_player_full_movement_sequence(native):
    original=Original();video=Reference()
    video.lib.fm_mix.restype=C.POINTER(C.c_uint8)
    blank=int(np.flatnonzero(~video.tiles.any(axis=(1,2)))[0])
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    fields=[('n_grounded',0,0xc021),('n_ceiling',0,0xc020),('n_blocked',0,0xc022),
            ('n_action',0,0xc023),('n_collision_wait',0,0xc024),('n_ylo',8,0xc409),('n_yhi',8,0xc40a),
            ('n_vy',8,0xc414),('n_fy',8,0xc415),('n_flags',8,0xc400),('n_pose',8,0xc406),
            ('n_timer',8,0xc416),('n_frame',8,0xc40d),('n_action_latch',8,0xc41a),
            ('n_vx',31,0xc6f2),('n_fx',31,0xc6f3),('n_target',31,0xc6eb),
            ('n_acceleration',31,0xc6ec),('n_flags',31,0xc6e0),('n_world',0,0xc01a),('n_world',1,0xc01b)]
    def contact():
        pointer=int(original.ram[0xc401])|(int(original.ram[0xc402])<<8)
        height,stride=rom[pointer:pointer+2]
        frame=int(original.ram[0xc40d]);facing=int(original.ram[0xc400])&1
        address=int.from_bytes(rom[pointer+7+frame*2:pointer+9+frame*2],'little')
        if facing:address=(address+stride-2)|0x8000
        address=(address-stride)&65535
        center=int(original.ram[0xc409])+int(original.ram[0xc406]==3)
        top=center-height//2;x=(256-2*(stride-1))&511
        video.ram[0xd080:0xd088]=[top,top+height,x&255,x>>8,stride,0,address&255,address>>8]
        world=int(original.ram[0xc01a])|(int(original.ram[0xc01b])<<8)
        scroll=(world-28)&65535;video.ram[0xeffc:0xeffe]=[scroll&255,scroll>>8]
        video.lib.fm_render_snapshot(0)
        return int(video.lib.fm_mix()[40])
    for stage in [0,7,19]:
        native.call('native_reset');native.set('n_round',stage)
        native.call('level_load');native.call('display_init')
        native.set('n_ylo',int(rom[0x13d2+native.get('n_layout')]),8)
        native.call('player_terrain_contact')
        original.ram[:]=0;video.ram[0xc000:]=0
        original.ram[0xc000]=0x80;original.ram[0xc408]=1;original.ram[0xc405]=8
        original.ram[0xc401:0xc403]=[0x34,0x34]
        original.ram[0xe000:0xe700]=list(maps[stage*1792:(stage+1)*1792])
        video.ram[0xe000:0xe700]=original.ram[0xe000:0xe700]
        video.ram[0xe800:0xf000:2]=blank&255;video.ram[0xe801:0xf000:2]=blank>>8
        for name,index,address in fields:original.ram[address]=native.get(name,index)
        for tick in range(600):
            player=191 if tick%360<180 else 127
            if tick%53<7:player&=~4
            original.ram[0xf028]=contact()
            assert native.get('n_terrain_contact')==original.ram[0xf028],(stage,tick,'pixel contact')
            original.call(0x3537,ix=0xc400,player=player,stop=0x3988)
            original.call(0x1dc2,ix=0xc6e0,player=player)
            # This oracle runs player/terrain/world routines only. Its enemy
            # collision matrix is empty; keep that same input for this test.
            native.set('n_player_enemy',0)
            native.set('n_input',player);native.call('game_update')
            for name,index,address in fields:
                assert native.get(name,index)==original.ram[address],(stage,tick,name)

@pytest.mark.parametrize('standard,pal_register',[('ntsc',15),('pal',1)])
def test_native_exact_clock_and_delayed_input_queue(native,standard,pal_register):
    native.ram[0xd014]=pal_register;native.call('clock_init')
    reference=FrameScheduler(standard);expected=[];ticks=0
    for frame in range(100000):
        player=(frame*37)&255;native.set('r_input',player)
        expected.extend([player]*reference.next_frame())
        native.call('clock_vbi')
        # Deliberately let 1..11 video frames pass before consuming game ticks.
        if frame%11==10 or frame==99999:
            actual=[]
            while native.call('clock_take_tick'):
                actual.append(native.get('n_input'));ticks+=1
            assert actual==expected,(standard,frame)
            expected.clear()
    assert native.get('c_overflow')==0
    phase=native.ram[native.labels['c_phase']:native.labels['c_phase']+3].tobytes()
    assert int.from_bytes(phase,'little')==reference.phase
    assert ticks==100000*reference.increment//reference.denominator
