.segment "FIXED"
.export prepared_terrain_load,prepared_player_sample,prepared_rect_query
prepared_terrain_load:
    lda #255
    sta $1d90
    sta $1d91
    lda n_round
@wrap:
    cmp #48
    bcc :+
    sbc #48
    bcs @wrap
:   asl a
    sta z:p_actor
    lda #0
    sta z:p_slot
@plane:
    ldx z:p_actor
    lda terrain_bank,x
    NATIVE_BANK
    lda terrain_lo,x
    sta n_src
    lda terrain_hi,x
    sta n_src+1
    lda #0
    sta n_dst
    lda z:p_slot
    beq :+
    lda #$4c
:   clc
    adc #$10
    sta n_dst+1
@token:
    jsr level_byte
    beq @next
    bmi @reference
    sta n_count
@literal:
    jsr level_byte
    jsr level_emit
    dec n_count
    bne @literal
    beq @token
@reference:
    and #127
    clc
    adc #3
    sta n_count
    jsr level_byte
    sta n_offset
    jsr level_byte
    sta n_offset+1
    sec
    lda n_dst
    sbc n_offset
    sta n_ptr
    lda n_dst+1
    sbc n_offset+1
    sta n_ptr+1
@copy:
    ldy #0
    lda (n_ptr),y
    jsr level_emit
    inc n_ptr
    bne :+
    inc n_ptr+1
:   dec n_count
    bne @copy
    beq @token
@next:
    inc z:p_actor
    inc z:p_slot
    lda z:p_slot
    cmp #2
    bcc @plane
    rts

prepared_player_sample:
    lda #4
    NATIVE_BANK
    jmp prepared_player_sample_bank

; Exact replacement for the old rectangle scan, using a prepared 16-bit mask.
prepared_rect_query:
    lda z:p_y
    cmp #224
    bcc :+
    lda #0
    rts
:   and #7
    clc
    adc z:p_height
    clc
    adc #7
    lsr a
    lsr a
    lsr a
    sec
    sbc #1
    asl a
    asl a
    sta n_count
    lda z:p_left
    lsr a
    and #7
    clc
    adc z:p_sprite_width
    clc
    adc #8
    lsr a
    lsr a
    lsr a
    sec
    sbc #1
    ora n_count
    tax
    lda z:p_y
    and #$38
    asl a
    asl a
    sta n_ptr
    lda z:p_y
    .repeat 6
        lsr a
    .endrepeat
    clc
    adc #$10
    sta n_ptr+1
    lda z:p_left+1
    lsr a
    lda z:p_left
    ror a
    lsr a
    lsr a
    lsr a
    tay
    lda (n_ptr),y
    and rect_mask_lo,x
    sta n_count
    lda n_ptr+1
    clc
    adc #$4c
    sta n_ptr+1
    lda (n_ptr),y
    and rect_mask_hi,x
    ora n_count
    cmp #1
    lda #0
    rol a
    rts

.segment "BANK4"
prepared_player_sample_bank:
    lda n_ylo+PLAYER
    ldx n_pose+PLAYER
    beq @height
    cpx #3
    beq @height
    sec
    sbc #8
@height:
    sta n_tile_y
    ldy n_world
    lda n_world+1
    and #1
    bne @odd
    lda contact_column0,y
    jmp @column
@odd:
    lda contact_column1,y
@column:
    sta n_column
    cmp $1d91
    bne @refresh
    lda n_tile_y
    and #$f8
    cmp $1d90
    bne @refresh
    lda $1d92
    sta n_contacts
    jmp @door
@refresh:
    lda n_column
    sta $1d91
    lda n_tile_y
    and #$f8
    sta $1d90
    and #$38
    asl a
    asl a
    sta n_ptr
    lda n_tile_y
    .repeat 6
        lsr a
    .endrepeat
    clc
    adc #$10
    sta n_ptr+1
    ldy n_column
    lda (n_ptr),y
    tax
    lda contact_low,x
    sta n_contacts
    lda n_ptr+1
    clc
    adc #$4c
    sta n_ptr+1
    lda (n_ptr),y
    tax
    lda contact_high,x
    ora n_contacts
    sta n_contacts
    sta $1d92
@door:
    lda n_train
    beq @done
    lda n_grounded
    beq @done
    lda n_exiting
    bne @done
    ; The existing rescue handler inspects the middle tile one row below.
    lda n_tile_y
    .repeat 5
        lsr a
    .endrepeat
    clc
    adc #$c0
    sta n_ptr+1
    lda n_tile_y
    and #$18
    asl a
    asl a
    asl a
    clc
    adc #128
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   lda n_column
    clc
    adc #1
    and #31
    asl a
    ora #1
    sta n_column
    jmp train_check_door_bank
@done:
    rts
