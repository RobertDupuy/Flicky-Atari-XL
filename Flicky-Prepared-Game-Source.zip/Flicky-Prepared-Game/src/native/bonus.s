; Arcade bonus: native implementation of ROM $4060..$4247.
; Twenty independent birds, original flight tables and unscaled catch masks.
b_spawn=$07f4
b_caught=$07f5
b_clock=$07f6
b_actor=$07f7
b_active=$07f8
b_pattern=$07f9
b_done=$07fa
b_art=$07fb
b_net=$07fc
b_dx=$07fd
b_dy=$07fe
b_mask=$07ff
b_net_x=$1be0
b_net_y=$1be2
b_seesaw=$1be3
b_score=$1be4
b_background=$1be5
b_prev_xlo=$1c00
b_prev_xhi=$1c20
b_prev_y=$1c40
b_prev_art=$1c60
b_prev_visible=$1c80
b_collision=$1ca0
b_remaining=$1b00
b_candidates=$1b40
b_candidate_x=$1b60
b_candidate_y=$1b80
b_hit=$1be7
b_row=$1be8
b_column=$1be9
b_offset=$1bea
b_temp=$1beb
b_rows=$1bec
b_net_left=$1bed
.segment "FIXED"
.export bonus_reset,bonus_update,bonus_render,bonus_bird_step,bonus_catch
.export b_spawn,b_caught,b_done,b_clock,b_pattern,b_seesaw,b_net,b_net_x,b_net_y
bonus_reset:
    lda #28
    NATIVE_BANK
    jmp bonus_reset_bank
bonus_update:
    lda #28
    NATIVE_BANK
    jmp bonus_update_bank
bonus_bird_step:
    lda #28
    NATIVE_BANK
    jmp bonus_bird_bank
bonus_render:
    lda #28
    NATIVE_BANK
    jmp bonus_render_bank
bonus_catch:
    lda #28
    NATIVE_BANK
    jmp bonus_catch_bank
bonus_blit:
    jsr fast_draw_prepared
    lda #28
    NATIVE_BANK
    rts
bonus_mask_read:
    lda #29
    NATIVE_BANK
    lda (n_src),y
    sta b_mask
    lda #28
    NATIVE_BANK
    rts
; Enter with the prepared source pointer/bank and copy one back buffer only.
bonus_apparatus_copy:
    NATIVE_BANK
    jsr bonus_apparatus_copy_bank
    lda #28
    NATIVE_BANK
    rts
.segment "BANK30"
bonus_apparatus_copy_bank:
    lda #0
    sta n_dst
    lda r_back
    asl a
    asl a
    asl a
    asl a
    asl a
    clc
    adc #$34
    sta n_dst+1
    lda #2
    sta b_active
@font:
    jsr level_byte
    sta n_count
    jsr level_byte
    ldy #0
@byte:
    lda (n_src),y
    sta (n_dst),y
    iny
    cpy n_count
    bcc @byte
    tya
    clc
    adc n_src
    sta n_src
    bcc :+
    inc n_src+1
:   clc
    lda n_dst+1
    adc #4
    sta n_dst+1
    dec b_active
    bne @font
    lda r_back
    beq :+
    jmp bonus_background_back1
:   jmp bonus_background_back0
.repeat 2,B
.if B=0
bonus_background_back0:
.else
bonus_background_back1:
.endif
    .repeat 8,R
        ldy #0
    :   lda (n_src),y
        sta $6780+B*$1000+R*96,y
        sta $67a0+B*$1000+R*96,y
        sta $67c0+B*$1000+R*96,y
        iny
        cpy #32
        bcc :-
        clc
        lda n_src
        adc #32
        sta n_src
        bcc :+
        inc n_src+1
    :
    .endrepeat
    rts
.endrepeat
.segment "BANK28"
bonus_slots: .byte 0,1,2,3,4,5,6,7,11,12,13,14,15,16,17,18,19,20,21,22
bonus_reset_bank:
    lda #0
    sta b_caught
    sta b_done
    sta b_spawn
    sta b_clock
    sta b_seesaw
    lda #255
    sta b_background
    sta b_background+1
    lda n_bonus
    bne :+
    rts
:   lda #0
    ldx #31
@clear:
    sta n_flags,x
    sta n_draw_yoffset,x
    sta b_collision,x
    sta b_prev_visible,x
    dex
    bpl @clear
    sta n_world
    sta n_world+1
    sta n_rescued
    sta n_xlo+PLAYER
    sta n_vx+CAMERA
    sta n_fx+CAMERA
    sta n_flags+CAMERA
    sta n_animation+PLAYER
    sta n_frame+PLAYER
    lda #$80
    sta n_flags+PLAYER
    lda #1
    sta n_xhi+PLAYER
    sta n_grounded
    lda #159
    sta n_ylo+PLAYER
    lda n_round
    clc
    adc #1
    and #$3c
    lsr a
    lsr a
@fold:
    cmp #12
    bcc :+
    sbc #11
    bcs @fold
:   tax
    lda ab_pattern_offset,x
    sta b_pattern
    lda n_round
    clc
    adc #1
    cmp #16
    bcc :+
    lda #0
:   and #12
    lsr a
    lsr a
    tax
    lda bonus_initial_lo,x
    sta n_src
    lda bonus_initial_hi,x
    sta n_src+1
    lda #0
    sta b_actor
@init:
    ldy b_actor
    ldx bonus_slots,y
    lda #0
    sta n_yhi,x
    sta n_fx,x
    sta n_fy,x
    sta n_acceleration,x
    sta n_frame,x
    sta n_timer,x
    sta n_pause,x
    sta n_cycle,x
    sta n_bob,x
    sta n_chick_state,x
    sta n_action_latch,x
    lda #5
    sta n_animation,x
    lda #$80
    sta n_flags,x
    lda #201
    sta n_ylo,x
    ldy #0
    lda (n_src),y
    sta n_xlo,x
    iny
    lda (n_src),y
    sta n_xhi,x
    iny
    lda (n_src),y
    sta n_vx,x
    bmi @negative
    clc
    adc #1
    bne @target
@negative:
    sec
    sbc #1
    pha
    lda #1
    sta n_action_latch,x
    lda #$81
    sta n_flags,x
    pla
@target:
    sta n_target,x
    iny
    lda (n_src),y
    sta n_vy,x
    clc
    lda n_src
    adc #4
    sta n_src
    bcc :+
    inc n_src+1
:   inc b_actor
    lda b_actor
    cmp #20
    bcs :+
    jmp @init
:   sta b_spawn
    ; Setup runs each actor once before the original introduction delay.
    lda #0
    sta b_actor
@prime:
    ldy b_actor
    ldx bonus_slots,y
    jsr bonus_bird_bank
    inc b_actor
    lda b_actor
    cmp #20
    bcc @prime
    inc b_clock
    lda #8
    sta b_seesaw
    jsr bonus_save_picture
    rts
bonus_initial_lo: .lobytes ab_initial,ab_initial+80,ab_initial+160,ab_initial+240
bonus_initial_hi: .hibytes ab_initial,ab_initial+80,ab_initial+160,ab_initial+240

bonus_update_bank:
    lda u_wait
    beq :+
    dec u_wait
    rts
:
    inc n_game_ticks
    inc b_clock
    lda b_clock
    and #7
    bne @board_ready
    lda b_clock
    lsr a
    lsr a
    lsr a
    and #7
    sta b_seesaw
@board_ready:
    lda #0
    sta b_actor
@bird:
    ldy b_actor
    ldx bonus_slots,y
    jsr bonus_bird_bank
    inc b_actor
    lda b_actor
    cmp #20
    bcc @bird
    jsr bonus_catch_bank
    jsr bonus_player_motion
    jsr bonus_save_picture
    lda b_done
    cmp #20
    bcc @done
    lda n_round_complete
    bne @done
    ; Catch points are awarded on completion, as in the arcade.
    lda b_caught
    sta b_active
@points:
    lda b_active
    beq @perfect
    sed
    clc
    lda n_score
    adc #$50
    sta n_score
    lda n_score+1
    adc #2
    sta n_score+1
    lda n_score+2
    adc #0
    sta n_score+2
    cld
    dec b_active
    bne @points
@perfect:
    lda b_caught
    cmp #20
    bne @complete
    sed
    clc
    lda n_score+2
    adc #1
    sta n_score+2
    cld
@complete:
    lda #1
    sta n_round_complete
@done:
    rts

bonus_bird_bank:
    lda n_flags,x
    and #4
    beq :+
    rts
:   inc n_cycle,x
    lda n_cycle,x
    and #3
    bne :+
    inc n_bob,x
    lda n_bob,x
    and #3
    sta n_bob,x
:   lda n_chick_state,x
    bne @flying
    lda n_vx,x
    bmi @walk_left
    inc n_xlo,x
    bne @walk_check
    inc n_xhi,x
    jmp @walk_check
@walk_left:
    lda n_xlo,x
    bne :+
    dec n_xhi,x
:   dec n_xlo,x
@walk_check:
    lda n_xhi,x
    cmp #2
    bcc :+
    rts
:   lda n_vx,x
    bmi @left_launch
    lda n_xlo,x
    cmp #128
    bcc @walk_art
    bcs @launch
@left_launch:
    lda n_xlo,x
    cmp #160
    bcs @walk_art
@launch:
    lda #1
    sta n_chick_state,x
@walk_art:
    lda n_bob,x
    and #1
    clc
    adc #3
    sta n_animation,x
    rts
@flying:
    lda n_pause,x
    asl a
    clc
    adc n_pause,x
    adc b_pattern
    tay
    lda n_timer,x
    clc
    adc #1
    cmp #255
    beq @motion
    sta n_timer,x
    cmp ab_pattern,y
    bne @motion
    inc n_pause,x
    iny
    lda ab_pattern,y
    sta n_acceleration,x
    iny
    lda ab_pattern,y
    sta n_target,x
    lda n_action_latch,x
    beq @clear_limit
    lda n_acceleration,x
    eor #255
    clc
    adc #1
    sta n_acceleration,x
    lda n_target,x
    eor #255
    clc
    adc #1
    sta n_target,x
@clear_limit:
    lda n_flags,x
    and #$f7
    sta n_flags,x
@motion:
    lda n_vy,x
    bmi @integrate
    lda n_cycle,x
    and #1
    bne @air_art
@integrate:
    jsr motion_gravity
    jsr motion_accelerate
    jsr motion_integrate
    lda n_flags,x
    and #8
    beq :+
    lda #0
    sta n_acceleration,x
:   lda n_ylo,x
    cmp #240
    bcc @air_art
    lda n_flags,x
    ora #4
    sta n_flags,x
    inc b_done
    rts
@air_art:
    lda n_vy,x
    bpl :+
    jmp @walk_art
:
    lda n_cycle,x
    and #31
    bne :+
    lda n_flags,x
    eor #1
    sta n_flags,x
:   lda n_bob,x
    and #1
    clc
    adc #5
    sta n_animation,x
    rts

bonus_player_motion:
    ldx #CAMERA
    lda n_input
    and #$80
    bne @right
    lda n_target+CAMERA
    beq @left_goal
    bpl @accelerate
@left_goal:
    lda #$30
    sta n_target+CAMERA
    lda #3
    bne @new
@right:
    lda n_input
    and #$40
    bne @release
    lda n_target+CAMERA
    bmi @accelerate
    lda #$d0
    sta n_target+CAMERA
    lda #$fd
    bne @new
@release:
    lda n_vx+CAMERA
    beq @animate
    pha
    lda #0
    sta n_target+CAMERA
    pla
    bmi :+
    lda #255
    bne @new
:   lda #1
@new:
    sta n_acceleration+CAMERA
    lda n_flags+CAMERA
    and #$f7
    sta n_flags+CAMERA
@accelerate:
    lda n_flags+CAMERA
    and #8
    bne @integrate
    jsr motion_accelerate
@integrate:
    lda n_fx+CAMERA
    sta n_fraction
    lda n_vx+CAMERA
    jsr motion_delta
    sta n_step
    lda #0
    ldy n_step
    bpl :+
    lda #255
:   sta n_sum
    sec
    lda n_xlo+PLAYER
    sbc n_step
    sta n_xlo+PLAYER
    lda n_xhi+PLAYER
    sbc n_sum
    and #1
    sta n_xhi+PLAYER
    lda n_fraction
    sta n_fx+CAMERA
@animate:
    lda #0
    sta n_animation+PLAYER
    lda n_vx+CAMERA
    beq @frame
    lda #1
    sta n_animation+PLAYER
    lda n_vx+CAMERA
    bmi @right_face
    lda #$81
    bne @face
@right_face:
    lda #$80
@face:
    sta n_flags+PLAYER
@frame:
    lda n_timer+PLAYER
    beq :+
    dec n_timer+PLAYER
    rts
:   lda #2
    sta n_timer+PLAYER
    lda n_frame+PLAYER
    eor #1
    sta n_frame+PLAYER
    rts

bonus_save_picture:
    lda #0
    sta b_actor
@bird:
    ldy b_actor
    ldx bonus_slots,y
    lda n_xlo,x
    sta b_prev_xlo,x
    lda n_xhi,x
    sta b_prev_xhi,x
    lda n_ylo,x
    sta b_prev_y,x
    lda n_animation,x
    sec
    sbc #3
    asl a
    sta b_art
    lda n_flags,x
    and #4
    eor #4
    sta b_prev_visible,x
    lda n_flags,x
    and #1
    ora b_art
    sta b_prev_art,x
    inc b_actor
    lda b_actor
    cmp #20
    bcc @bird
    lda n_flags+PLAYER
    and #1
    eor #1
    sta b_net
    lda n_vx+CAMERA
    beq :+
    lda b_net
    ora #2
    sta b_net
:   lda n_flags+PLAYER
    and #1
    bne @left
    clc
    lda n_xlo+PLAYER
    adc #16
    sta b_net_x
    lda n_xhi+PLAYER
    adc #0
    jmp @net_high
@left:
    sec
    lda n_xlo+PLAYER
    sbc #16
    sta b_net_x
    lda n_xhi+PLAYER
    sbc #0
@net_high:
    sta b_net_x+1
    lda n_ylo+PLAYER
    clc
    adc #7
    sta b_net_y
    rts

bonus_catch_bank:
    ; Hardware latches which visible bird owns each net pixel. Higher-numbered
    ; birds hide earlier ones, even when they are ascending and uncatchable.
    sec
    lda b_net_x
    sbc #16
    sta b_net_left
    lda b_net_x+1
    sbc #0
    and #1
    sta b_net_left+1
    clc
    lda b_net_left
    adc #16
    sta n_dst
    lda b_net_left+1
    adc #0
    sta n_dst+1
    lda #0
    sta b_actor
    sta b_active
@bird:
    ldy b_actor
    lda #0
    sta b_candidates,y
    ldx bonus_slots,y
    lda b_prev_visible,x
    bne :+
    jmp @next
:   lda b_prev_xhi,x
    cmp #2
    bcc :+
    jmp @next
:
    ldy b_prev_art,x
    sec
    lda b_prev_xlo,x
    sbc ab_radius,y
    sta b_dx
    lda b_prev_xhi,x
    sbc #0
    and #1
    sta b_dy
    clc
    lda b_dx
    adc ab_radius,y
    sta b_dx
    lda b_dy
    adc #0
    sta b_dy
    sec
    lda b_dx
    sbc n_dst
    sta b_dx
    lda b_dy
    sbc n_dst+1
    sta b_dy
    clc
    lda b_dx
    adc #32
    sta b_dx
    lda b_dy
    adc #0
    bne @next
    lda b_dx
    cmp #64
    bcs @next
    sec
    lda b_prev_y,x
    sbc b_net_y
    clc
    adc #16
    cmp #32
    bcs @next
    asl a
    asl a
    asl a
    sta b_dy
    lda b_dx
    lsr a
    lsr a
    lsr a
    ora b_dy
    tay
    lda b_net
    asl a
    asl a
    asl a
    ora b_prev_art,x
    ora #$80
    sta n_src+1
    lda #0
    sta n_src
    jsr bonus_mask_read
    lda b_dx
    and #7
    tax
    lda bonus_bits,x
    and b_mask
    beq @next
    ldy b_actor
    lda #1
    sta b_candidates,y
    inc b_active
    lda b_dx
    sta b_candidate_x,y
    lda b_dy
    lsr a
    lsr a
    lsr a
    sta b_candidate_y,y
@next:
    inc b_actor
    lda b_actor
    cmp #20
    bcs :+
    jmp @bird
:   lda b_active
    beq bonus_consume_collision
    jsr bonus_resolve_ownership
bonus_consume_collision:
    ldy #0
@consume:
    lda b_collision,y
    beq @advance
    lda #0
    sta b_collision,y
    ldx bonus_slots,y
    lda n_flags,x
    and #4
    bne @done
    lda n_vy,x
    beq @done
    bmi @done
    lda n_flags,x
    ora #4
    sta n_flags,x
    inc b_caught
    inc b_done
    lda #$8b
    sta n_sound_event
    jmp bonus_tally
@advance:
    iny
    cpy #20
    bcc @consume
@done:
    rts
bonus_bits: .byte 1,2,4,8,16,32,64,128

bonus_resolve_ownership:
    lda b_net
    .repeat 6
        asl a
    .endrepeat
    tax
    ldy #0
@net:
    lda ab_net_silhouettes,x
    sta b_remaining,y
    inx
    iny
    cpy #64
    bcc @net
    ; The original sprite shifter clips at the right screen edge; its left
    ; address wraps before shifting, rather than wrapping every output pixel.
    lda b_net_left+1
    beq @birds
    lda b_net_left
    cmp #225
    bcc @birds
    ldx #0
@clip_column:
    txa
    asl a
    asl a
    asl a
    clc
    adc b_net_left
    bcs @empty
    cmp #249
    bcc @clip_next
    eor #255
    tay
    lda bonus_clip_bits,y
    bne @clip_mask
@empty:
    lda #0
@clip_mask:
    sta b_temp
    txa
    tay
@clip_row:
    lda b_remaining,y
    and b_temp
    sta b_remaining,y
    tya
    clc
    adc #4
    tay
    cpy #64
    bcc @clip_row
@clip_next:
    inx
    cpx #4
    bcc @clip_column
@birds:
    lda #19
    sta b_actor
@actor:
    ldy b_actor
    lda b_candidates,y
    bne :+
    jmp @next_actor
:   ldx bonus_slots,y
    ldy b_prev_art,x
    sty b_art
    ldx b_actor
    lda b_candidate_x,x
    sec
    sbc #16
    sec
    sbc ab_radius,y
    sta b_column
    and #7
    sta b_temp
    tya
    asl a
    asl a
    asl a
    ora b_temp
    tay
    lda ab_silhouette_lo,y
    sta n_src
    lda ab_silhouette_hi,y
    sta n_src+1
    lda b_column
    cmp #128
    ror a
    cmp #128
    ror a
    cmp #128
    ror a
    sta b_column
    ldy b_art
    lda ab_height,y
    lsr a
    sta b_temp
    lda b_candidate_y,x
    sec
    sbc #7
    sec
    sbc b_temp
    sta b_row
    lda #12
    sta b_rows
    lda #0
    sta b_hit
@row:
    lda b_row
    cmp #16
    bcs @next_row
    asl a
    asl a
    sta b_offset
    ldx b_column
    ldy #0
@byte:
    cpx #4
    bcs @next_byte
    txa
    clc
    adc b_offset
    tax
    lda (n_src),y
    and b_remaining,x
    beq @no_hit
    lda #1
    sta b_hit
    lda (n_src),y
    eor #255
    and b_remaining,x
    sta b_remaining,x
@no_hit:
    txa
    sec
    sbc b_offset
    tax
@next_byte:
    inx
    iny
    cpy #4
    bcc @byte
@next_row:
    clc
    lda n_src
    adc #4
    sta n_src
    bcc :+
    inc n_src+1
:   inc b_row
    dec b_rows
    bne @row
    lda b_hit
    beq @next_actor
    ldy b_actor
    sta b_collision,y
@next_actor:
    dec b_actor
    bmi @done
    jmp @actor
@done:
    rts
bonus_clip_bits: .byte 1,3,7,15,31,63,127

bonus_tally:
    ldx b_caught
    lda #ab_tally_code
    sta $16a6,x
    sta $61e6,x
    sta $6206,x
    sta $6226,x
    sta $71e6,x
    sta $7206,x
    sta $7226,x
    txa
    clc
    adc #$e6
    sta b_dx
    ldx #0
@saved:
    lda $3c00,x
    cmp b_dx
    bne @next
    lda $3d00,x
    and #$ef
    cmp #$61
    bne @next
    lda #ab_tally_code
    sta $3e00,x
@next:
    inx
    bne @saved
    rts

.segment "FIXED"
bonus_message_intro:
    lda #27
    NATIVE_BANK
    jmp bonus_message_intro_bank
bonus_message_result:
    lda #27
    NATIVE_BANK
    jmp bonus_message_result_bank
.segment "BANK27"
bonus_message_intro_bank:
    lda #<ab_message_font
    sta n_src
    lda #>ab_message_font
    sta n_src+1
    lda #27
    jsr message_copy
    lda #0
    ldx #63
@background_flags:
    sta $f100,x
    sta $f180,x
    sta $f200,x
    sta $f280,x
    dex
    bpl @background_flags
    lda #128
    sta $f100
    sta $f180
    sta $f200
    sta $f280
    lda #31
    sta u_wait
    rts
bonus_message_result_bank:
    ldx b_caught
    lda ab_message_lo,x
    sta n_src
    lda ab_message_hi,x
    sta n_src+1
    lda #27
    jmp message_copy
.segment "BANK28"

bonus_render_bank:
    ldx r_back
    lda b_background,x
    cmp b_seesaw
    beq @background_ready
    lda b_seesaw
    sta b_background,x
    tax
    lda ab_apparatus_lo,x
    sta n_src
    lda ab_apparatus_hi,x
    sta n_src+1
    lda ab_apparatus_bank,x
    jsr bonus_apparatus_copy
@background_ready:
    lda #0
    sta b_actor
@bird:
    ldy b_actor
    ldx bonus_slots,y
    lda n_flags,x
    and #4
    bne @next
    lda n_xhi,x
    cmp #2
    bcs @next
    lda n_ylo,x
    cmp #218
    bcs @next
    lda n_animation,x
    sec
    sbc #3
    asl a
    sta b_art
    lda n_flags,x
    and #1
    ora b_art
    sta b_art
    lda n_xlo,x
    sta p_left
    lda n_xhi,x
    sta p_left+1
    lda n_ylo,x
    sta p_y
    jsr bonus_draw_art
@next:
    inc b_actor
    lda b_actor
    cmp #20
    bcc @bird
    lda b_net
    clc
    adc #20
    sta b_art
    lda b_net_x
    sta p_left
    lda b_net_x+1
    sta p_left+1
    lda b_net_y
    sta p_y
    jmp bonus_draw_art
bonus_draw_art:
    ldx b_art
    lda ab_height,x
    lsr a
    sta n_step
    lda p_y
    sec
    sbc n_step
    clc
    adc #1
    sta p_y
    sec
    lda p_left
    sbc ab_radius,x
    sta p_left
    lda p_left+1
    sbc #0
    and #1
    sta p_left+1
    lda b_art
    cmp #8
    bcs :+
    jmp bonus_stamp
:
    txa
    asl a
    asl a
    sta n_step
    lda p_left
    lsr a
    lsr a
    and #3
    ora n_step
    tax
    lda ab_art_lo,x
    sta p_image
    lda ab_art_hi,x
    sta p_image+1
    lda ab_art_bank,x
    sta p_imagebank
    lda #1
    sta p_visible
    jmp bonus_blit
