"""Address-decoded Type 110 bus behavior and interrupt-safe selector execution."""
import os, sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import BUILD
from native_engine import Engine
pytestmark=pytest.mark.skipif(os.environ.get('FLICKY_MAPPER')!='jcart',reason='Type 110 build only')

def test_jcart_header_boot_vectors_and_all_64_address_selected_banks():
    n=Engine();car=(BUILD/'native/flicky-native-dev.car').read_bytes();rom=car[16:]
    assert len(rom)==524288 and n.cart_type==110
    assert int.from_bytes(car[8:12],'big')==sum(rom)&0xffffffff
    assert int.from_bytes(rom[0x1ffa:0x1ffc],'little')==n.labels['sic_boot']+0x2000
    assert int.from_bytes(rom[0x1ffe:0x2000],'little')==n.labels['cart_init']+0x2000
    n.labels['bus_probe']=0x0500
    for bank in range(64):
        for data in (0,255):
            # A6 is ignored. Reads of D5xx must neither select a bank nor
            # expose a SIC-style control register. A000..BFFF is the only ROM.
            code=bytes([0xa9,data,0x8d,bank|0x40,0xd5,0xad,0x13,0xa0,0x8d,0xe0,5,
                        0xad,0,0xd5,0x8d,0xe1,5,0x60])
            n.ram[0x500:0x500+len(code)]=list(code);n.call('bus_probe')
            assert n.ram[0x5e0]==rom[bank*8192+0x13]
            assert n.ram[0x5e1]==255 and n.lib.at_bank()==bank
    # Disable reveals writable underlying RAM; re-enable preserves that RAM.
    code=bytes.fromhex('a9 00 8d 80 d5 a9 a5 8d 13 a0 ad 13 a0 8d e0 05 8d 00 d5 60')
    n.ram[0x500:0x500+len(code)]=list(code);n.call('bus_probe')
    assert n.ram[0x5e0]==n.ram[0xa013]==0xa5 and n.lib.at_bank()==0

def test_hot_bank_switch_survives_audio_nmi_at_every_instruction_cycle():
    n=Engine();n.call('audio_enqueue',0x82)
    n.labels['idle_pad']=0x0500;n.ram[0x500:0x565]=[0xea]*100+[0x60]
    for bank in range(32):
        for delay in range(1,81):
            n.lib.at_force_nmi(delay)
            n.call('jcart_hot_bank',bank)
            n.call('idle_pad')
            assert n.lib.at_bank()==n.ram[0x061f]==bank*2+1,(bank,delay)
