#!/usr/bin/env python3
"""Capture the original sound sequencer and arrange its voices for POKEY.

No guessed melodies: source commands execute on the independent Z80/SN model.
The four-voice projection and SN-to-POKEY volume/pitch conversion are explicit.
"""
import ctypes as C,json,math
from pathlib import Path
import numpy as np
from run_reference import Reference
from build import ROOT,BUILD

def pokey(sn):
    tones=[]
    for chip in range(2):
        for channel in range(3):
            period=int(sn[chip*8+channel*2]) or 1024
            attenuation=int(sn[chip*8+channel*2+1])
            volume=0 if attenuation==15 else round(15*10**(-attenuation/10))
            frequency=(2_000_000 if chip==0 else 4_000_000)/(32*period)
            divisor=max(0,round(1_789_790/(56*frequency)-1))
            while divisor>255:
                frequency*=2
                divisor=max(0,round(1_789_790/(56*frequency)-1))
            if not volume:divisor=0
            tones.append((divisor,0xa0|volume,volume))
    # Keep chip one's three music parts stable; use the fourth voice for the
    # loudest extra tone or noise. Effects can overlay only non-silent voices.
    voices=tones[:3]+[max(tones[3:],key=lambda t:t[2])]
    for chip in range(2):
        attenuation=int(sn[chip*8+7]);volume=0 if attenuation==15 else round(15*10**(-attenuation/10))
        noise=int(sn[chip*8+6])
        if volume>voices[3][2]:
            period=(16,32,64,int(sn[chip*8+4]) or 1024)[noise&3]
            frequency=(2_000_000 if chip==0 else 4_000_000)/(32*period)
            divisor=max(0,min(255,round(1_789_790/(56*frequency)-1)))
            voices[3]=(divisor,(0x80 if noise&4 else 0xa0)|volume,volume)
    return bytes(v for d,c,_ in voices for v in [d,c])

def encode(frames,loop):
    # [duration, change-mask, changed register values]. Duration 0 is the end.
    # Include an absolute first state, and force an absolute loop destination.
    out=bytearray();previous=bytes(8);i=0;loop_offset=None
    while i<len(frames):
        if i==loop:loop_offset=len(out)
        end=i+1
        while end<len(frames) and frames[end]==frames[i] and end-i<255 and end!=loop:end+=1
        mask=255 if i==0 or i==loop else sum(1<<j for j in range(8) if frames[i][j]!=previous[j])
        out.extend([end-i,mask]);out.extend(frames[i][j] for j in range(8) if mask>>j&1)
        previous=frames[i];i=end
    out.append(0)
    return bytes(out),loop_offset

def main():
    r=Reference();r.lib.fm_sound_ram.restype=C.POINTER(C.c_uint8)
    ram=np.ctypeslib.as_array(r.lib.fm_sound_ram(),shape=(2048,))
    rom=(ROOT/'private-roms/soundcpu.bin').read_bytes()
    out=BUILD/'audio';out.mkdir(exist_ok=True)
    manifest=[]
    for command in rom[0x4e2:0x4f5]:
        r.lib.fm_sound_reset()
        for _ in range(4):r.lib.fm_sound_frame()
        r.lib.fm_sound_command(command)
        frames=[];raw=[];seen={};loop=None;quiet=0
        for f in range(2400):
            r.lib.fm_sound_frame()
            frame=pokey(r.sound);state=ram[0x20:0x230].tobytes()+r.sound.tobytes()
            active=any(ram[0x30+i*32]&128 for i in range(16))
            if f>4 and active and state in seen:
                loop=seen[state];break
            seen[state]=f
            frames.append(frame);raw.append(r.sound.copy())
            quiet=quiet+1 if not active and all((v&15)==0 for v in frame[1::2]) else 0
            if quiet>=8:break
        if len(frames)==2400:raise RuntimeError(f'Command {command:02X} did not terminate or repeat')
        encoded,offset=encode(frames,loop)
        (out/f'{command:02x}.bin').write_bytes(encoded)
        np.save(out/f'{command:02x}-sn.npy',np.array(raw))
        np.save(out/f'{command:02x}-pokey.npy',np.array([list(v) for v in frames],dtype=np.uint8))
        handler=int.from_bytes(rom[0x4f5+(command-0x81)*2:0x4f7+(command-0x81)*2],'little')
        # Reset-track handlers explicitly clear/mute the source's active parts.
        replace=any(pattern in rom[handler:handler+20] for pattern in [bytes([0xcd,0x8b,0x04]),bytes([0xcd,0x94,0x06])])
        row={'command':command,'frames':len(frames),'loop_frame':loop,'loop_offset':offset,'bytes':len(encoded),'replace':replace,'handler':handler}
        manifest.append(row);print(row,flush=True)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print('Encoded sound bytes',sum(r['bytes'] for r in manifest))
if __name__=='__main__':main()
