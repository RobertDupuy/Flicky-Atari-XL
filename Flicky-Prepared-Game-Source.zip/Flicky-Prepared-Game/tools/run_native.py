#!/usr/bin/env python3
import argparse,ctypes as C,subprocess,json
import numpy as np
from build import ROOT,BUILD

class Native:
    def __init__(self,compact=False):
        subprocess.run(['gcc','-std=c11','-O2','-shared','-fPIC',str(ROOT/'tests/atari_cpu.c'),'-o',str(BUILD/'atari_cpu.so')],check=True)
        self.lib=C.CDLL(str(BUILD/'atari_cpu.so'))
        self.lib.at_init.argtypes=[C.c_char_p,C.c_uint16]
        self.lib.at_run.argtypes=[C.c_uint16,C.c_uint]
        self.lib.at_run.restype=C.c_int64
        self.lib.at_memory.restype=C.POINTER(C.c_uint8)
        self.lib.at_profile.restype=C.POINTER(C.c_uint32)
        self.lib.at_guest_cycles.restype=C.POINTER(C.c_uint64)
        self.labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (BUILD/('compact.lbl' if compact else 'game.lbl')).read_text().splitlines() if line.startswith('al ')}
        assert self.lib.at_init(str(BUILD/('flicky-compact.car' if compact else 'flicky-reference.car')).encode(),self.labels['start'])
        self.memory=np.ctypeslib.as_array(self.lib.at_memory(),shape=(65536,))
        self.profile=np.ctypeslib.as_array(self.lib.at_profile(),shape=(128,8192))
        self.guest_cycles=np.ctypeslib.as_array(self.lib.at_guest_cycles(),shape=(32768,))
        banks=json.loads((BUILD/('hot-banks.json' if compact else 'aot-banks.json')).read_text())
        for k,addr in self.labels.items():
            if k.startswith('g_'):
                pc=int(k[2:],16)
                self.lib.at_label(banks[f'{pc:04X}'],addr,pc)
    def run(self,limit=100_000_000):
        cycles=self.lib.at_run(self.labels['host_frame'],limit)
        if cycles<0 or self.memory[self.labels['z_fault']]:
            pc=int.from_bytes(self.memory[self.labels['z_pc']:self.labels['z_pc']+2].tobytes(),'little')
            raise RuntimeError(f'Native stopped: cycles={cycles}, guest={pc:04X}, cpu={self.lib.at_pc():04X}, bank={self.lib.at_bank()}, fault={self.memory[self.labels["z_fault"]]}')
        return cycles
    def resume(self,p1=255,system=255,limit=100_000_000):
        self.memory[self.labels['z_p1']]=p1
        self.memory[self.labels['z_system']]=system
        self.lib.at_prefetch(self.labels['guest_resume'])
        return self.run(limit)

def main():
    p=argparse.ArgumentParser();p.add_argument('--frames',type=int,default=600);p.add_argument('--trace',action='store_true');a=p.parse_args()
    out=BUILD/'native';out.mkdir(exist_ok=True)
    n=Native()
    if a.trace:n.lib.at_trace(str(out/'cpu-trace.txt').encode())
    print('boot',n.run(),flush=True)
    counts=[]
    for f in range(a.frames):
        system=254 if 180<=f<190 else 239 if 210<=f<220 else 255
        cycles=n.resume(255,system);counts.append(cycles)
        if f%60==0 or f==a.frames-1:
            print(f,'cycles',cycles,'mode',int(n.memory[0xc000]),'round',int(n.memory[0xc018]),flush=True)
            (out/f'ram-{f:05d}.bin').write_bytes(n.memory.tobytes())
    n.lib.at_trace(None)
    (out/'cycles.json').write_text(json.dumps(counts))
    np.save(out/'profile.npy',n.profile)
    print('steady worst/average',max(counts[300:]) if len(counts)>300 else max(counts),sum(counts)/len(counts))

if __name__=='__main__':main()
