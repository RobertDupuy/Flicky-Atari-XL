#!/usr/bin/env python3
"""Build and retain both 512 KB cartridge variants from the shared source."""
import argparse, json, hashlib, os, shutil, subprocess, sys
from build import ROOT, BUILD

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mapper',choices=('sic','jcart'),default=os.environ.get('FLICKY_MAPPER','sic'))
    a=p.parse_args();jcart=a.mapper=='jcart'
    release=ROOT/'release';release.mkdir(exist_ok=True)
    env=os.environ.copy();env.pop('FLICKY_BENCHMARK',None)
    results=[]
    for mode in ('ntsc','pal'):
        subprocess.run([sys.executable,str(ROOT/'tools/build_native.py'),'--prepared','--variant',mode,'--mapper',a.mapper],env=env,check=True)
        out=BUILD/('variants-jcart' if jcart else 'variants')/mode;out.mkdir(parents=True,exist_ok=True)
        for name in ('native.lbl','manifest.json'):shutil.copy2(BUILD/'native'/name,out/name)
        dest=release/(f'Flicky-Atari-XL-{mode.upper()}-'+('JatariCart-' if jcart else '')+'512K.car')
        # Copy bytes only: the variants have separate persistent file IDs.
        shutil.copyfile(BUILD/'native/flicky-native-dev.car',dest)
        data=dest.read_bytes()
        assert len(data)==524304 and data[:4]==b'CART' and int.from_bytes(data[4:8],'big')==(110 if jcart else 56)
        assert int.from_bytes(data[8:12],'big')==sum(data[16:])&0xffffffff
        results.append({'filename':dest.name,'sha256':hashlib.sha256(data).hexdigest(),
            'rom_bytes':524288,'mapper':'J(atari)Cart 512 KB' if jcart else 'SIC! 512 KB','cart_type':110 if jcart else 56,'mode':mode,
            'moving_prop_limit':6 if mode=='pal' else 1,'stress_fixture':False})
    # Preserve the published default filename as the NTSC build.
    if not jcart:shutil.copyfile(release/'Flicky-Atari-XL-NTSC-512K.car',release/'Flicky-Prepared-Game.car')
    (release/('variants-jcart.json' if jcart else 'variants.json')).write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
