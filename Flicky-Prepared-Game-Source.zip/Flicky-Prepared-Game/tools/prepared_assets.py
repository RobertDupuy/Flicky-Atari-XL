"""Compile hardware-sprite planes and fixed actor metadata from converted art."""
import json
from pathlib import Path

def build(out:Path):
    lines=['; Generated offline. No pixel conversion runs on the Atari.','.segment "FIXED"']
    for kind in ('player','chick','cat'):
        old=(out/f'{kind}-data.s').read_text()
        tail=old[old.index(f'native_{kind}_height:'):]
        lines += ['.segment "FIXED"',tail]
    lines += ['.segment "FIXED"']
    obj=(out/'object-data.s').read_text()
    for name in ('height_draw','radius_draw'):
        label=f'native_object_{name.replace('_draw','')}:'
        lines += [f'native_object_{name}:',obj[obj.index(label):].splitlines()[1]]
    lines += ['.segment "BANK8"']
    records={};pointers={};adjust={};clipped=[]
    for kind in ('player','cat'):
        d=json.loads((out/f'{kind}-assets.json').read_text());ptr=[];offsets=[]
        for idx,meta in enumerate(d['records']):
            if meta['phase']:continue
            raw=(out/f'{kind}-image-{d["images"][idx]:03d}.bin').read_bytes()
            h,w=raw[:2]
            pix=[[raw[4+2*(y*w+x//4)]>>(6-2*(x&3))&3 for x in range((meta['width']+1)//2)] for y in range(h)]
            if kind=='player' and len(pix[0])>8:
                pix=[[r[round(x*(len(r)-1)/7)] for x in range(8)] for r in pix]
            planes=(lambda v:v==2,lambda v:v==1) if kind=='player' else (lambda v:v in (1,3),)
            label=f'pm_{kind}_{len(ptr)}';ptr.append(label)
            data=[];ofs=[]
            for active in planes:
                occupied=[x for row in pix for x,v in enumerate(row) if active(v)]
                start=min(occupied,default=0)
                if occupied and max(occupied)-start>=8:clipped.append((kind,meta['animation'],meta['facing']))
                # Initial hardware fit. Wider cat frames are center-preserving
                # reductions compiled here; no runtime scaling occurs.
                if kind=='cat' and len(pix[0])>8:
                    columns=[round(x*(len(pix[0])-1)/7) for x in range(8)];start=(len(pix[0])-8)//2
                else:columns=list(range(start,start+8))
                ofs.append(start)
                plane=bytes(sum((128>>i) for i,x in enumerate(columns) if x<len(row) and active(row[x])) for row in pix)
                data+=list(plane)+[0]*(24-h)
            if kind=='player':
                remaining={x for r in pix for x,v in enumerate(r) if v==3};gold=[]
                while remaining:
                    start=min(remaining);gold.append(start);remaining-={start,start+1}
                assert len(gold)<=4
                gold += [0]*(4-len(gold));ofs+=gold
                data += [sum((2>>(x-start))<<(2*m) for m,start in enumerate(gold) for x in range(start,start+2) if x<len(r) and r[x]==3 and (m==0 or start not in gold[:m])) for r in pix]+[0]*(24-h)
            lines += [label+':','.byte '+','.join(map(str,data))]
            offsets.append(ofs)
        pointers[kind]=ptr;adjust[kind]=offsets
    for kind,ptr in pointers.items():
        lines += [f'pm_{kind}_lo:','.lobytes '+','.join(ptr),f'pm_{kind}_hi:','.hibytes '+','.join(ptr)]
        for plane in range(6 if kind=='player' else 1):
            lines += [f'pm_{kind}_offset{plane}:','.byte '+','.join(str(o[plane]) for o in adjust[kind])]
    lines += ['.segment "FIXED"','pm_cat_flip:', '.byte '+','.join(str({5:18,7:19,8:20}.get(i,i)) for i in range(21))]
    (out/'prepared-art.s').write_text('\n'.join(lines)+'\n')
    (out/'prepared-art.json').write_text(json.dumps({'player_frames':len(pointers['player']),'cat_frames':len(pointers['cat']), 'wide_poses_fit_offline':clipped},indent=2)+'\n')

    y=[round(-3.5*t+.05*t*t)for t in range(0,73,2)]
    death=[round(-2*t+.06*t*t)for t in range(0,49,2)]
    motion=['.segment "BANK3"']
    for label,values in [('pc_jump_dy',[(y[t+1]-y[t])&255 for t in range(36)]),('pc_jump_pose',[16 if t<18 else 17 for t in range(36)]),('pc_jump_next',[min(t+1,35)for t in range(36)]),('pc_death_dy',[(death[t+1]-death[t])&255 for t in range(24)]),('pc_death_pose',[[5,7,8,7][(t//2)&3]for t in range(24)]),('pc_speed',[4 if r<24 else 6 for r in range(256)])]:
        motion += [label+':','.byte '+','.join(map(str,values))]
    (out/'prepared-motion.s').write_text('\n'.join(motion)+'\n')
