; Arithmetic helpers carried forward from stage 1, independently tested.
alu8:
    stx z_kind
    lda z_a
    sta z_old
    cpx #4
    bcs @logical
    cpx #2
    bcs @subtract
    cpx #0
    beq @add_no_carry
    lda z_f
    lsr a
    lda z_a
    jmp @add
@add_no_carry:
    clc
@add:
    adc z_operand
    jmp arithmetic_result
@subtract:
    cpx #2
    beq @sub_no_carry
    lda z_f
    eor #1
    lsr a
    lda z_a
    jmp @sub
@sub_no_carry:
    sec
@sub:
    sbc z_operand
    jmp arithmetic_result
@logical:
    cpx #7
    bne @not_cp
    sec
    sbc z_operand
    jmp arithmetic_result
@not_cp:
    cpx #4
    bne @not_and
    and z_operand
    tax
    lda z_parity_flags,x
    ora #$10
    jmp logical_result
@not_and:
    cpx #5
    bne @or
    eor z_operand
    jmp @logical_flags
@or:
    ora z_operand
@logical_flags:
    tax
    lda z_parity_flags,x
logical_result:
    sta z_f
    stx z_a
    rts
arithmetic_result:
    sta z_result
    php
    pla
    sta z_status
    ldx z_result
    lda z_sz_flags,x
    sta z_f
    lda z_old
    eor z_operand
    eor z_result
    and #$10
    ora z_f
    sta z_f
    lda z_status
    and #$40
    lsr a
    lsr a
    lsr a
    lsr a
    ora z_f
    sta z_f
    ldx z_kind
    cpx #2
    bcc @add_carry
    lda z_status
    eor #1
    and #1
    ora #2
    jmp @carry
@add_carry:
    lda z_status
    and #1
@carry:
    ora z_f
    sta z_f
    cpx #7
    beq @cp_flags
    lda z_result
    sta z_a
    rts
@cp_flags:
    lda z_f
    and #$d7
    sta z_f
    lda z_operand
    and #$28
    ora z_f
    sta z_f
    rts

; INC/DEC affect the specified operand, preserve virtual A and carry.
inc8:
    sta z_old
    clc
    adc #1
    tax
    lda z_sz_flags,x
    sta z_temp
    lda z_old
    and #$0f
    cmp #$0f
    bne @no_half
    lda z_temp
    ora #$10
    sta z_temp
@no_half:
    lda z_old
    cmp #$7f
    bne incdec_finish
    lda z_temp
    ora #4
    sta z_temp
    jmp incdec_finish
dec8:
    sta z_old
    sec
    sbc #1
    tax
    lda z_sz_flags,x
    ora #2
    sta z_temp
    lda z_old
    and #$0f
    bne @no_half
    lda z_temp
    ora #$10
    sta z_temp
@no_half:
    lda z_old
    cmp #$80
    bne incdec_finish
    lda z_temp
    ora #4
    sta z_temp
incdec_finish:
    lda z_f
    and #1
    ora z_temp
    sta z_f
    txa
    rts


.align 256
z_sz_flags:
.repeat 256, I
    .byte (I & $a8) | ((I = 0) * $40)
.endrepeat
z_parity_flags:
.repeat 256, I
    .byte (I & $a8) | ((I = 0) * $40) | (((((I >> 0) ^ (I >> 1) ^ (I >> 2) ^ (I >> 3) ^ (I >> 4) ^ (I >> 5) ^ (I >> 6) ^ (I >> 7)) & 1) ^ 1) * 4)
.endrepeat

.export alu8,logical_result,arithmetic_result,inc8,dec8,incdec_finish,z_sz_flags,z_parity_flags
