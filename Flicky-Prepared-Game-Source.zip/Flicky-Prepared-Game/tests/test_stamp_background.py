"""Pixel oracle: every chick pose must preserve scenery through transparency."""
import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import BUILD

def pixels(packed):
    return np.array([[v>>s&3 for s in (6,4,2,0)]for v in packed],dtype=np.uint8)

def read_stamp(n,back,row,col):
    result=np.zeros((16,8),dtype=np.uint8)
    for cy in range(2):
        for cx in range(2):
            a=0x6000+back*4096+(row+cy)*96+(col+cx)%32
            code=int(n.ram[a]);g=0x2000+back*8192+((row+cy)//4)*1024+(code&127)*8
            result[cy*8:cy*8+8,cx*4:cx*4+4]=pixels(n.ram[g:g+8])
            assert n.ram[a]==n.ram[a+32]==n.ram[a+64]
    return result

def test_every_chick_alignment_preserves_background_and_restores_cells():
    n=Engine();n.lib.at_video_timing(0);n.call('game_round_load');n.set('i_active',0)
    d=json.loads((BUILD/'native/chick-assets.json').read_text())
    pattern=bytes((0x1b,0xe4,0x55,0xaa,0xff,0x00,0xc3,0x3c))
    for i,m in enumerate(d['records']):
        raw=(BUILD/f'native/chick-image-{d["images"][i]:03d}.bin').read_bytes();h,w=raw[:2]
        ink=np.zeros((10,8),dtype=np.uint8)
        for y in range(10):
            sy=round(y*(h-1)/9)
            for cx in range(min(2,w)):ink[y,cx*4:cx*4+4]=pixels([raw[4+2*(sy*w+cx)]])[0]
        for phase in (0,2,4,6):
            back=(i+phase//2)&1;row=11;col=31 if i&1 else 9;top=row*8+phase
            bgcode=62|(128 if i&2 else 0)
            n.set('r_back',back);n.set('r_dirty_counts',0,back)
            for band in range(7):
                g=0x2000+back*8192+band*1024+62*8;n.ram[g:g+8]=list(pattern);n.ram[0xec00+band*256+62]=0x21+band*4;n.ram[0xec00+band*256+128+62]=0x41+band*4
            base=0x6000+back*4096;n.ram[base:base+28*96]=bgcode
            n.call('fast_sprites_begin')
            radius=n.get('native_chick_radius',m['animation'])
            pos=col*16+m['phase']*4+radius
            for key,value in [('n_flags',128|m['facing']),('n_animation',m['animation']),('n_frame',m['frame']),
                              ('n_xlo',pos),('n_xhi',pos>>8),('n_ylo',top+4),('n_draw_yoffset',0)]:n.set(key,value,0)
            n.call('fast_draw_chick',x=0)
            bg=np.tile(pixels(pattern),(2,2))
            expected=bg.copy();sprite=np.zeros((16,8),dtype=np.uint8);sprite[phase:phase+10]=ink
            expected[sprite!=0]=sprite[sprite!=0]
            assert np.array_equal(read_stamp(n,back,row,col),expected),(i,phase)
            # A second chick shares the cell without erasing uncovered pixels.
            j=next(j for j,v in enumerate(d['records'])if v['animation']==m['animation'] and v['frame']==m['frame'] and v['facing']==1-m['facing'] and v['phase']==m['phase'])
            raw2=(BUILD/f'native/chick-image-{d["images"][j]:03d}.bin').read_bytes();h2,w2=raw2[:2]
            sprite2=np.zeros((16,8),dtype=np.uint8)
            for y in range(10):
                sy=round(y*(h2-1)/9)
                for cx in range(min(2,w2)):sprite2[phase+y,cx*4:cx*4+4]=pixels([raw2[4+2*(sy*w2+cx)]])[0]
            for key in ('n_flags','n_animation','n_frame','n_xlo','n_xhi','n_ylo','n_draw_yoffset'):n.set(key,n.get(key,0),1)
            n.set('n_flags',128|1-m['facing'],1);n.call('fast_draw_chick',x=1)
            expected[sprite2!=0]=sprite2[sprite2!=0]
            assert np.array_equal(read_stamp(n,back,row,col),expected),(i,phase,'overlap')
            # Restoration is independently checked even for font-band and wrap crossings.
            n.set('r_dirty_counts',int(n.ram[0x8d])&127,back);n.call('fast_sprites_begin')
            assert np.all(n.ram[base:base+28*96]==bgcode),(i,phase,'restore')
