"""Prepared collision geometry and bounded NPC behaviour on the real 6502 code."""
import sys, random
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine

@pytest.fixture(scope='module')
def n():
    e=Engine();e.lib.at_video_timing(0)
    return e

def test_all_prepared_neighbourhoods_and_collision_queries_match_old_scans(n):
    rng=random.Random(1789)
    for level in range(48):
        n.set('n_round',level);n.call('level_load');n.call('prepared_terrain_load')
        tiles=n.ram[0xc000:0xc700].reshape(28,32,2)[:,:,1]&16
        for row in range(28):
            for col in range(32):
                expected=sum(int(bool(tiles[row+dy,(col+dx)&31]))<<(dy*4+dx)
                    for dy in range(4)for dx in range(4)if row+dy<28)
                i=row*32+col
                assert int(n.ram[0x1000+i])+256*int(n.ram[0x5c00+i])==expected,(level,row,col)
        n.set('n_train',0)
        for world in range(512):
            n.set('n_world',world);n.set('n_world',world>>8,1)
            y=13+(world*37)%191
            n.set('n_ylo',y,8)
            for pose in range(4):
                n.set('n_pose',pose,8)
                n.call('player_sample_terrain');old=n.get('n_contacts')
                n.call('prepared_player_sample')
                assert n.get('n_contacts')==old,(level,world,y,pose)
        for trial in range(512):
            left=rng.randrange(512);y=rng.randrange(256);width=rng.randrange(1,19);height=rng.randrange(1,25)
            # These are the shared geometry inputs to both native routines.
            n.ram[0x72:0x76]=[left&255,left>>8,y,height];n.ram[0xc5]=width
            old=n.call('sprite_terrain_bounds')
            new=n.call('prepared_rect_query')
            assert new==old,(level,left,y,width,height,old,new)

def test_prepared_cats_walk_jump_land_and_finish_hit_animation(n):
    n.call('native_reset');n.call('game_round_load');n.set('n_frozen',0)
    # A controlled empty room with a solid floor at row 24.
    n.ram[0xc000:0xc700]=0
    n.ram[0xc000+24*64+1:0xc000+25*64:2]=16
    a=9
    for k,v in [('n_flags',0xb0),('n_xlo',100),('n_xhi',0),('n_ylo',182),('n_pause',0),('n_chick_state',0)]:n.set(k,v,a)
    n.ram[0x1d80:0x1d86]=[255,255,255,255,0,0]
    n.set('n_ylo',182,8);n.set('n_game_ticks',0)
    n.ram[0x061f]=0x63;n.ram[0xd500]=0x63
    # Select the bank through the existing wrapper, then call the bank routine.
    n.call('enemies_update')
    x0=n.get('n_xlo',a);n.call('prepared_cat_tick',x=a)
    assert n.get('n_xlo',a)==(x0+4)&255
    n.call('pc_jump',x=a)
    lowest=255
    for tick in range(90):
        n.set('n_game_ticks',1)
        n.call('prepared_cat_tick',x=a);lowest=min(lowest,n.get('n_ylo',a))
        if not n.get('n_chick_state',a)&4:break
    assert lowest<150 and n.get('n_ylo',a)==182
    assert not n.get('n_chick_state',a)&4
    n.set('n_chick_state',0x80,a)
    for tick in range(24):n.call('prepared_cat_tick',x=a)
    assert n.get('n_flags',a)==0


def test_prepared_prop_motion_matches_original_integrator(n):
    n.call('native_reset');n.call('game_round_load');n.call('objects_update')
    a=12
    for vx in (96,160):
        for vy in list(range(224,256))+list(range(49)):
            for fraction in range(16):
                initial={'n_xlo':253,'n_xhi':1,'n_ylo':100,'n_yhi':0,'n_vx':vx,'n_vy':vy,'n_fx':0,'n_fy':fraction}
                for k,v in initial.items():n.set(k,v,a)
                n.call('motion_gravity',x=a);n.call('motion_integrate',x=a)
                expected={k:n.get(k,a)for k in ('n_xlo','n_xhi','n_ylo','n_vy','n_fy')}
                for k,v in initial.items():n.set(k,v,a)
                n.call('object_prepared_motion',x=a)
                for k,v in expected.items():
                    mask=1 if k=='n_xhi' else 255
                    assert n.get(k,a)&mask==v&mask,(vx,vy,fraction,k)


def test_prepared_samples_preserve_rescue_door_triggers(n):
    for level in range(48):
        n.set('n_round',level);n.call('level_load');n.call('prepared_terrain_load')
        for row in range(1,27):
            for col in range(32):
                if n.ram[0xc000+row*64+col*2]&240!=192:continue
                world=(240-((col-1)&31)*16)&511
                n.set('n_world',world);n.set('n_world',world>>8,1)
                n.set('n_ylo',(row-1)*8,8);n.set('n_pose',0,8)
                n.set('n_train',1);n.set('n_grounded',1)
                outputs=[]
                for routine in ('player_sample_terrain','prepared_player_sample'):
                    n.set('n_exiting',0);n.set('n_delivered',0)
                    for a in range(8):n.set('n_chick_state',int(a==0),a);n.set('n_flags',0xb0,a)
                    n.call(routine)
                    outputs.append((n.get('n_contacts'),n.get('n_exiting'),n.get('n_flags',0)))
                assert outputs[0]==outputs[1] and outputs[1][1]==1,(level,row,col,outputs)


def test_full_flock_contact_shortcut_matches_general_path(n):
    rng=random.Random(5158)
    n.lib.at_video_timing(0);n.call('native_reset');n.call('game_round_load')
    for trial in range(256):
        world=rng.randrange(512);n.set('n_world',world);n.set('n_world',world>>8,1)
        n.set('n_ylo',rng.randrange(40,190),8);n.set('n_grounded',trial&1)
        n.set('n_flags',0x80|(4 if trial%7==0 else 0),8)
        for a in list(range(8))+[9,10]:
            x=rng.randrange(512)
            n.set('n_flags',0xb0,a);n.set('n_xlo',x,a);n.set('n_xhi',x>>8,a)
            n.set('n_ylo',rng.randrange(40,190),a);n.set('n_pause',0,a)
            n.set('n_chick_state',1 if a<8 else 0,a)
        results=[]
        for count in (7,8):
            n.set('n_train',count)
            for a in range(8):n.set('n_enemy_contact',0,a)
            n.call('quick_contacts')
            results.append(([n.get('n_chick_contact',a)for a in range(8)],
                [n.get('n_enemy_contact',a)for a in range(8)],n.get('n_pickup'),n.get('n_player_enemy')))
        assert results[0]==results[1],(trial,results)
