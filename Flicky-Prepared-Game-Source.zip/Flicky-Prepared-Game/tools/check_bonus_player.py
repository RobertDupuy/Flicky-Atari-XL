"""Bonus jump oracle: original instructions plus original sprite/floor collisions.

Research-only. Uses the separately owned arcade ROMs and a staged MAME RAM
snapshot. The resulting compact state fixture can be tested without ROMs.
"""
import ctypes as C
import json
import numpy as np
from build import ROOT, BUILD
from native_engine import Engine
from native_oracle import Original
from run_reference import Reference

FIELDS = [
    ('n_xlo',8,0xc407),('n_xhi',8,0xc408),('n_ylo',8,0xc409),
    ('n_vy',8,0xc414),('n_fy',8,0xc415),('n_grounded',0,0xc021),
    ('n_pose',8,0xc406),('n_timer',8,0xc416),('n_frame',8,0xc40d),
    ('n_action_latch',8,0xc41a),('n_flags',8,0xc400),
    ('n_vx',31,0xc6f2),('n_fx',31,0xc6f3),('n_target',31,0xc6eb),
    ('n_acceleration',31,0xc6ec),('n_flags',31,0xc6e0),
]

def main():
    snapshot=(BUILD/'background-jump/mame-before-jump.bin').read_bytes()
    o=Original();r=Reference();n=Engine()
    r.lib.fm_mix.restype=C.POINTER(C.c_uint8)
    runs=[
        [255]*20+[251]*8+[255]*130+[251]*200+[255]*25+[251]*8+[255]*100,
        [191]*5+[251]*8+[255]*100+[127]*5+[251]*8+[255]*100,
        [127]*5+[251]*8+[255]*100+[191]*5+[251]*8+[255]*100,
    ]
    inputs=[];expected=[];initial=[];report=[]
    for run,keys in enumerate(runs):
        o.ram[:]=np.frombuffer(snapshot,np.uint8);r.ram[:]=o.ram
        n.lib.at_video_timing(0);n.call('native_reset');n.set('n_round',2)
        n.call('game_round_load');n.set('u_wait',0)
        for name,index,address in FIELDS:o.ram[address]=n.get(name,index)
        o.ram[0xc020]=o.ram[0xc022]=o.ram[0xc023]=o.ram[0xc024]=0
        o.ram[0xc412:0xc414]=0
        o.ram[0xc401:0xc403]=[0x34,0x34]
        o.call(0x43a4,ix=0xc400)
        initial.append([n.get(name,index) for name,index,_ in FIELDS])
        start=len(inputs);jumps=0;old_ground=1
        for tick,key in enumerate(keys):
            # Original hardware collision against the real bonus platform.
            r.ram[0xd000:0xd400]=0;r.ram[0xd1f0]=255
            r.ram[0xd080:0xd088]=o.ram[0xc149:0xc151]
            r.lib.fm_render_snapshot(0)
            o.ram[0xf028]=r.lib.fm_mix()[40]
            o.call(0x3537,ix=0xc400,player=key)
            o.call(0x1dc2,ix=0xc6e0,player=key)
            want=[int(o.ram[address]) for _,_,address in FIELDS]
            n.set('n_input',key);n.call('bonus_player_step')
            got=[n.get(name,index) for name,index,_ in FIELDS]
            assert got==want,(run,tick,key,want,[(FIELDS[i][0],a,b) for i,(a,b) in enumerate(zip(got,want)) if a!=b])
            if old_ground and not want[5]:jumps+=1
            old_ground=want[5]
            inputs.append(key);expected.append(want)
        report.append(dict(run=run,ticks=len(keys),jumps=jumps,start=start))
    out=BUILD/'native'
    np.savez_compressed(out/'arcade-bonus-player-golden.npz',inputs=np.array(inputs,np.uint8),
        expected=np.array(expected,np.uint8),initial=np.array(initial,np.uint8),
        starts=np.array([v['start'] for v in report],np.int32))
    result=dict(source_player_routine='3537',source_motion_routine='1DC2',
        original_sprite_and_floor_collision=True,source_rom_set='flicky',
        states=len(inputs),fields=len(FIELDS),mismatches=0,runs=report)
    (out/'arcade-bonus-player.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
