"""Cinematic decoding and the previously missing original delivery actors."""
import sys,json
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import BUILD
from attract_stream import raster
from attract_palette import PMG_ORIGIN,raster_row_size,gradient_row
from fast_ui_assets import FONT
from test_arcade_bonus import pixels

def intro_pixels(n,back):
    screen=n.ram[0x6000+4096*back:0x6460+4096*back].reshape(28,40)
    font=n.ram[0x2000+8192*back:0x3c00+8192*back].reshape(7,128,8)
    out=np.empty((224,160),np.uint8)
    for row in range(28):
        codes=screen[row];glyph=font[row//4,codes&127]
        dots=((glyph[:,:,None]>>np.array([6,4,2,0]))&3)
        dots=np.where((dots==3)&((codes[:,None,None]&128)!=0),4,dots)
        out[row*8:row*8+8]=dots.transpose(1,0,2).reshape(8,160)
    return out

def test_complete_intro_decodes_without_tearing_and_survives_interrupts():
    n=Engine();art=np.load(BUILD/'native/attract-pixels.npz')
    mode=json.loads((BUILD/'native/manifest.json').read_text())['variant']
    cycles=[]
    for f in range(len(art['pixels'])):
        back=f&1
        if f>=2:
            front=back^1;before=n.ram[0x2000+front*8192:0x3c00+front*8192].copy()
            n.call('attract_publish')
            # A real VBI or a DLI may interrupt the banked stream fetch.
            if f%2:n.lib.at_force_nmi((f*97)%3000+1)
            else:
                row=1+(f//2)%27
                address=0xc000+front*2048+sum(raster_row_size(r)for r in range(1,row))
                n.ram[0x51:0x53]=[address&255,address>>8]
                # The headless CPU has no ANTIC. Supply the scanline register
                # that real-time video verification independently exercises.
                if gradient_row(row):n.ram[0xd40b]=(PMG_ORIGIN+row*8+2)//2
                n.lib.at_force_dli((f*137)%3000+1)
            n.call('attract_work');cycles.append(n.maximum['attract_work'])
            n.maximum['attract_work']=0
            np.testing.assert_array_equal(n.ram[0x2000+front*8192:0x3c00+front*8192],before)
        np.testing.assert_array_equal(intro_pixels(n,back),art['pixels'][f],err_msg=f'frame {f}')
        pm=0x0c00 if back==0 else 0xdc00
        np.testing.assert_array_equal(n.ram[pm:pm+1024].reshape(4,256),art['pmg'][f])
        expected=raster(art['mux'][f],back,mode,art['pmg'][f])
        dl=0xc000+back*2048
        assert bytes(n.ram[dl:dl+1792])==bytes(expected[:1792]),f
    n.call('attract_publish');n.call('attract_work');assert n.get('it_finished')==1
    (BUILD/'native/attract-decoder-check.json').write_text(json.dumps(dict(frames=len(art['pixels']),
        pixels_checked=True,player_bitmaps_checked=True,raster_programs_checked=True,
        interrupts_injected=True,front_buffer_unchanged=True,maximum_decode_cycles=max(cycles)),indent=2)+'\n')
    n.set('n_input',255);n.call('game_update');n.set('n_input',251);n.call('game_update')
    assert n.get('u_mode')==n.get('result_active')==0 and n.get('r_fault')==0


def test_all_delivery_awards_draw_exact_native_digits_and_expire():
    n=Engine();n.lib.at_video_timing(0);n.call('native_reset');n.call('game_round_load')
    awards=(100,200,300,400,500,1000,2000,5000);indices=(5,6,7,8,9,11,12,14)
    # Both display buffers, all pixel phases, independent of original-ROM data.
    for value,index in zip(awards,indices):
        for back in (0,1):
            for phase in range(4):
                n.set('r_back',back);n.call('fast_sprites_begin')
                n.ram[0x660:0x662]=0
                for band in range(7):n.ram[0x2000+back*8192+band*1024:0x2008+back*8192+band*1024]=0
                for row in range(28):n.ram[0x6000+back*4096+row*96:0x6060+back*4096+row*96]=0
                for a in range(20,24):n.set('n_flags',0,a)
                radius=(len(str(value))*4+1)*2;left=144+phase*4
                n.set('n_flags',0xb0,23);n.set('n_popup_value',index,23)
                n.set('n_xlo',(left+radius)&255,23);n.set('n_xhi',(left+radius)>>8,23);n.set('n_ylo',91,23)
                n.call('delivery_draw')
                expected=np.zeros((224,128),np.uint8)
                for i,ch in enumerate(str(value)):
                    for y,line in enumerate(FONT[ch].split()):
                        for x,b in enumerate(line):expected[89+y,37+phase+i*4+x]=int(b)
                np.testing.assert_array_equal(pixels(n,back),expected,err_msg=f'{value}/{back}/{phase}')
                assert n.get('r_fault')==0
    n.set('n_pause',254,23);n.set('n_target',32,23)
    for _ in range(33):n.call('popup_update');assert n.get('n_flags',23)&128
    n.call('popup_update');assert n.get('n_flags',23)==0
