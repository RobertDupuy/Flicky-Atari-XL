"""End-to-end acceptance checks for the bounded native engine."""
import sys, subprocess, json, statistics, zlib
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import ROOT,BUILD

@pytest.fixture(scope='module')
def game():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True)
    return Engine()

def word(n,name,value,index=0):
    n.set(name,value,index);n.set(name,value>>8,index+1)

def stage(n,index=0):
    n.lib.at_video_timing(0)
    n.call('native_reset');n.set('n_round',index);n.call('game_round_load')

@pytest.mark.skipif(not (ROOT/"private-roms/flicky-sg1000.sg").exists(),reason="Original SG-1000 ROM is not distributed with the prepared source.")
def test_sg_binary_identity_and_disassembled_fixed_bounds():
    rom=(ROOT/'private-roms/flicky-sg1000.sg').read_bytes()
    assert len(rom)==32768 and zlib.crc32(rom)==0xbd24d27b
    assert rom[0x359:0x360]==bytes.fromhex('7e fe 29 20 11 36 01')
    assert rom[0x1539:0x1543]==bytes.fromhex('dd 21 95 c1 fd 21 3e c1 06 06')
    assert rom[0x10ca:0x10d4]==bytes.fromhex('dd 21 75 c1 fd 21 e1 c0 06 08')

def test_title_start_hud_and_persistent_best(game):
    n=game;n.set('u_mode',1);n.set('n_input',255);n.call('game_update')
    n.set('n_input',251);n.call('game_update')
    assert n.get('u_mode')==0 and n.get('n_lives')==3
    for i,v in enumerate((0x45,0x23,0x01)):n.set('n_score',v,i)
    n.call('ui_refresh')
    assert n.ram[0x1f06:0x1f0c].tolist()==[27,28,29,30,31,32]
    assert n.ram[0x1f30:0x1f32].tolist()==[27,28]
    stage(n);n.call('ui_refresh')
    assert n.ram[0x1f13:0x1f19].tolist()==[27,28,29,30,31,32]

def test_all_48_rounds_render_with_bounded_glyph_pools(game):
    n=game;cycles=[]
    for level in range(48):
        stage(n,level)
        for frame in range(4):
            n.set('r_back',frame&1);n.call('game_update')
            before=n.lib.at_cycles();n.call('native_render_submit')
            if frame>=2:cycles.append(n.lib.at_cycles()-before)
            assert n.get('r_fault')==0,(level,frame)
        assert n.get('n_bonus')==(level%4==2)
        if not n.get('n_bonus'):
            assert all(16<=n.get('n_ylo',i)<216 for i in range(12,18))
            for i in range(12):
                count=int(n.ram[0xe400+i*64])
                assert count<=61,(level,i,count)
                if not n.get('n_chick_state',12+i%6):assert count>0,(level,i)
    (BUILD/'native/round-acceptance.json').write_text(json.dumps({
        'rounds':48,'display_buffers':2,'renderer_faults':0,
        'steady_render_median_bare_cycles':int(statistics.median(cycles)),
        'steady_render_max_bare_cycles':max(cycles)},indent=2)+'\n')

def test_pickup_throw_cat_hit_and_floor_removal(game):
    n=game;stage(n)
    for buffer in (0,1):n.set('r_back',buffer);n.call('native_render_submit')
    actor=12;x=n.get('n_xlo',actor)+256*n.get('n_xhi',actor)
    word(n,'n_world',(256-x)&65535);n.set('n_ylo',n.get('n_ylo',actor),8)
    n.call('objects_update')
    assert n.get('n_carry')==actor and n.get('n_chick_state',actor)==0x40
    for buffer in (0,1):
        n.set('r_back',buffer);n.call('native_render_submit')
        assert n.ram[0xe400+buffer*384]==0
        assert n.get('r_fault')==0
    n.set('n_action_latch',0,8);n.call('objects_update')
    assert n.get('n_carry')==255 and n.get('n_chick_state',actor)==0x80
    n.set('n_flags',0xb0,9);n.set('n_chick_state',0,9);n.set('n_pause',0,9)
    for name in ('n_xlo','n_xhi','n_ylo'):n.set(name,n.get(name,actor),9)
    n.call('objects_update')
    assert n.get('n_chick_state',9)&0x80
    assert n.get('n_score',1)==1
    n.call('cat_update',x=9)
    assert n.get('n_chick_state',9)&0x10
    for _ in range(95):n.call('objects_update')
    assert n.get('n_flags',actor)==0

def test_bonus_twenty_catches_perfect_award_and_next_stage(game):
    # Scoring/transition fixture; real movement and pixel catches have their
    # own original-ROM golden and collision tests in test_arcade_bonus.py.
    n=game;stage(n,2);n.set('u_wait',0)
    n.set('b_caught',20);n.set('b_done',20)
    for a in list(range(8))+list(range(11,23)):n.set('n_flags',0x84,a)
    n.call('game_update')
    assert n.get('n_round_complete')==1
    assert [n.get('n_score',i) for i in range(3)]==[0,0x50,1]
    for _ in range(242):n.call('game_update')
    assert n.get('n_round')==3 and n.get('n_bonus')==0

def test_death_gameover_and_restart(game):
    n=game;stage(n);n.set('n_lives',1);n.set('n_life_lost',1)
    n.call('game_update');assert n.get('n_flow')==3
    for _ in range(130):n.call('game_update')
    n.set('n_input',255);n.call('game_update')
    n.set('n_input',251);n.call('game_update')
    assert n.get('n_lives')==3 and n.get('n_round')==0 and n.get('n_flow')==0

def test_wrapped_pickup_and_cat_contact_survives_half_rate_flock(game):
    n=game;stage(n)
    for a in range(8):n.set('n_flags',0,a)
    for a in (9,10):n.set('n_flags',0,a)
    word(n,'n_world',255);n.set('n_ylo',100,8)
    n.set('n_flags',0xb0,0);n.set('n_chick_state',0,0)
    n.set('n_xlo',255,0);n.set('n_xhi',1,0);n.set('n_ylo',100,0)
    n.call('quick_contacts');assert n.get('n_pickup')&1
    word(n,'n_world',0);n.set('n_train',2)
    for a in (0,1):
        n.set('n_flags',0xb0,a);n.set('n_chick_state',1,a);n.set('n_chain',a,a)
        n.set('n_xlo',100,a);n.set('n_xhi',0,a);n.set('n_ylo',100,a)
    for k,v in [('n_flags',0xb0),('n_chick_state',0),('n_pause',0),('n_xlo',100),('n_xhi',0),('n_ylo',100)]:n.set(k,v,9)
    n.call('quick_contacts');assert n.get('n_enemy_contact',0)==1
    n.set('n_flags',0,9);n.call('quick_contacts')
    assert n.get('n_enemy_contact',0)==1
    n.call('chicks_update')
    assert n.get('n_train')==0
    assert all(n.get('n_chick_state',a)&3==2 for a in (0,1))

def test_complete_train_delivery_scores_every_chick_and_advances(game):
    n=game;stage(n);n.lib.at_video_timing(262)
    word(n,'n_world',0);n.set('n_ylo',199,8);n.set('n_grounded',1)
    active=[1,2,3,5,6,7]
    n.set('n_train',len(active));n.ram[0x1b00:0x1b28]=199
    n.ram[0x1b40:0x1ba8]=0
    for rank,a in enumerate(active):
        n.set('n_flags',0xb0,a);n.set('n_chick_state',1,a);n.set('n_chain',rank,a)
        n.set('n_ylo',199,a);n.set('n_xlo',0,a);n.set('n_xhi',1,a)
        n.set('n_trail_xlo',0,rank);n.set('n_trail_xhi',1,rank)
    n.call('player_sample_terrain');assert n.get('n_exiting')==1
    for _ in range(600):
        n.set('n_input',255);n.call('game_update')
        if n.get('n_round')==1:break
    assert n.get('n_round')==1 and n.get('r_fault')==0
    assert [n.get('n_score',i) for i in range(3)]==[0,0x25,2]
    n.lib.at_video_timing(0)

def test_eight_moving_chicks_two_cats_and_buffer_isolation(game):
    import math
    n=game;stage(n,4);measurements=[]
    for frame in range(160):
        back=frame&1;n.set('r_back',back)
        front=n.ram[0x2000+(back^1)*8192:0x3c00+(back^1)*8192].copy()
        for a in range(8):
            x=(270-a*16+frame*3)&511
            n.set('n_flags',0xb0,a);n.set('n_chick_state',1,a)
            n.set('n_animation',frame%3,a);n.set('n_xlo',x,a);n.set('n_xhi',x>>8,a)
            n.set('n_ylo',100+int(18*math.sin((frame-a*5)/13)),a)
        for a in (9,10):
            x=(frame*2+a*42)&511
            n.set('n_flags',0xb0,a);n.set('n_animation',frame%9,a)
            n.set('n_xlo',x,a);n.set('n_xhi',x>>8,a);n.set('n_ylo',105,a)
        before=n.lib.at_cycles();n.call('native_render_submit');measurements.append(n.lib.at_cycles()-before)
        assert n.get('r_fault')==0,frame
        assert (n.ram[0x2000+(back^1)*8192:0x3c00+(back^1)*8192]==front).all()
    (BUILD/'native/crowded-render.json').write_text(json.dumps({
        'frames':160,'median_bare_cycles':int(statistics.median(measurements)),
        'maximum_bare_cycles':max(measurements),'renderer_faults':0,
        'front_buffer_unchanged':True},indent=2)+'\n')


def test_extra_life_is_awarded_once_and_survives_restart(game):
    n=game;stage(n)
    n.set('n_score',0x90);n.set('n_score',0x99,1);n.set('n_score',2,2)
    n.call('ui_refresh');assert n.get('n_lives')==3
    n.set('n_score',0);n.set('n_score',0,1);n.set('n_score',3,2)
    n.call('ui_refresh');assert n.get('n_lives')==4
    for _ in range(3):n.call('ui_refresh')
    assert n.get('n_lives')==4
    n.call('game_life_restart');assert n.get('n_lives')==4


def test_picking_up_a_new_prop_obeys_build_policy(game):
    n=game;stage(n)
    n.set('n_chick_state',0x80,12);n.set('n_timer',90,12);n.set('n_vx',96,12)
    x=n.get('n_xlo',13)+256*n.get('n_xhi',13)
    word(n,'n_world',(256-x)&65535);n.set('n_ylo',n.get('n_ylo',13),8)
    n.call('objects_update')
    assert n.get('n_carry')==13
    active=[a for a in range(12,18)if n.get('n_flags',a)&128 and n.get('n_chick_state',a)]
    if n.labels['PAL_MULTI_PROP']:
        assert n.get('n_flags',12)&128
        assert n.get('n_chick_state',12)==0x80
        assert active==[12,13]
    else:
        assert n.get('n_flags',12)==0
        assert active==[13]
    n.set('n_action_latch',0,8);n.call('objects_update')
    assert n.get('n_chick_state',13)==0x80 and n.get('n_carry')==255


def test_pal_six_independent_props_survive_pickup_and_expire_individually(game):
    n=game
    if not n.labels['PAL_MULTI_PROP']:
        pytest.skip('PAL multi-prop policy')
    stage(n)
    for a in range(12,17):
        n.set('n_flags',0x80,a);n.set('n_chick_state',0x80,a)
        n.set('n_timer',60+a,a);n.set('n_vx',96,a)
    x=n.get('n_xlo',17)+256*n.get('n_xhi',17)
    word(n,'n_world',(256-x)&65535);n.set('n_ylo',n.get('n_ylo',17),8)
    n.call('objects_update')
    assert n.get('n_carry')==17
    assert all(n.get('n_flags',a)&128 and n.get('n_chick_state',a)==0x80 for a in range(12,17))
    n.set('n_action_latch',0,8);n.call('objects_update')
    assert n.get('n_carry')==255
    assert all(n.get('n_flags',a)&128 and n.get('n_chick_state',a)==0x80 for a in range(12,18))
    n.set('n_timer',1,12)
    for a in range(12,18):n.set('n_ylo',100,a)
    n.call('objects_update')
    assert n.get('n_flags',12)==0
    assert all(n.get('n_flags',a)&128 for a in range(13,18))
