"""Native cinematic palettes shared by conversion, raster compiler and QA."""

PMG_ORIGIN=16
SKY=0x88
GRASS=0xb8
FOLIAGE=0xb8
FOREST_SHADOW=0xb2
MOUNTAIN=0x8a
BALLOON=0x4a
BIRD=0x8a
GOLD=0xee
PLANE=0x58
MOTORCYCLE=0x36
CAT_SHADE=0x1a
GRADIENT_BASE=0x1600
GRADIENT_STRIDE=14

def sky_color(y):
    """Two neighboring GTIA blues, blended across one narrow scanline ramp.

    The first three and last two lines in each character row share a shade.
    This leaves time for ANTIC's first-line DMA and the next DLI. There is
    no temporal flicker, palette postprocessing, or emulator adjustment.
    """
    if y<24:return 0x86
    if y<56:start,low=24,0x86
    else:return 0x88
    masks=((0,0,0,0,0,1,0,0),(0,0,0,1,0,0,1,1),
           (1,1,1,0,0,0,1,1),(1,1,1,1,0,1,1,1))
    return low+2*masks[(y-start)//8][y%8]

def gradient_row(row):
    return row in (3,4,5,6)

def ntsc_color(color):
    hue=color&0xf0;light=color&15
    return {0x00:0x00,0x10:0x30,0x30:0x40,0x40:0x50,0x50:0x60,
            0x60:0x70,0x70:0x80,0x80:0x90,0x90:0xa0,0xb0:0xd0,0xe0:0x20}.get(hue,hue)|light

def row_palette(row,mode='pal'):
    y=row*8
    if y<144:
        colors=(SKY,0x0e,0,BALLOON,GOLD)
    elif y<184:
        colors=(SKY,FOLIAGE,FOREST_SHADOW,MOUNTAIN,GOLD)
    else:colors=(GRASS,0x0e,0,BIRD,GOLD)
    return tuple(ntsc_color(c)for c in colors) if mode=='ntsc' else colors

def display_palette(y,mode='pal'):
    colors=list(row_palette(y//8))
    if y<144:colors[0]=sky_color(y)
    return tuple(ntsc_color(c)for c in colors) if mode=='ntsc' else tuple(colors)

def raster_row_size(row):return 96 if row in (18,23) else 64
