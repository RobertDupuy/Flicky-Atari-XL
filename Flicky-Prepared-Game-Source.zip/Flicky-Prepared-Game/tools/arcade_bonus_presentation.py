"""Native 5x7 bonus lettering, prepared once; never squeeze arcade text pixels.

Letters may span hardware characters, so every stroke and one-pixel space is
retained at ANTIC 4 resolution. The bird renderer still composes over the text.
"""
import json
from round_clear_art import LETTERS

TALLY = bytes([0x0c,0x34,0x3f,0xfc,0x3c,0x30,0x44,0])

def lettering(text, ink=1):
    pixels=[[0]*128 for _ in range(8)]
    left=(128-(len(text)*6-1))//2
    assert left>=0,text
    for i,c in enumerate(text):
        for y,row in enumerate(LETTERS[c]):
            for x,bit in enumerate(row):pixels[y][left+i*6+x]=int(bit)*ink
    return pixels

def result_lines(caught):
    return {9:f'{caught:02d} X 250 = {caught*250:04d} PTS',
            12:'PERFECT BONUS' if caught==20 else '',
            14:'10000 EXTRA POINTS' if caught==20 else ''}

def build(out):
    maps=(out/'maps-reference.bin').read_bytes()[2*1792:3*1792]
    tiles=[int.from_bytes(maps[i:i+2],'little')&2047 for i in range(0,len(maps),2)]
    base=[len(set(tiles[b*128:(b+1)*128])) for b in range(7)]
    patterns={b:[] for b in range(4)};lookup={b:{} for b in range(4)}
    def code(b,g):
        # Band zero's original glyph 0 is a HUD ornament, not blank. Reserve
        # our own empty tile rather than exposing it between the new letters.
        if not any(g) and b:return 0
        if g not in lookup[b]:
            lookup[b][g]=base[b]+len(patterns[b]);patterns[b].append(g)
        return lookup[b][g]
    def row_codes(row,text):
        ink=3 if row in (12,14) else 1
        p=lettering(text,ink);data=[]
        for col in range(32):
            g=bytes(sum(p[y][col*4+x]<<(6-2*x) for x in range(4)) for y in range(8))
            c=code(row//4,g);data.append(c|(128 if c and ink==3 else 0))
        return bytes(data)
    heading=row_codes(3,'BONUS ROUND')
    tally_code=code(1,TALLY)|128
    screens=[{row:row_codes(row,text) for row,text in result_lines(n).items()} for n in range(21)]
    assert all(base[b]+len(p)<64 for b,p in patterns.items()),[(b,len(p))for b,p in patterns.items()]
    def block(a,data):
        assert 0<len(data)<256
        return a.to_bytes(2,'little')+bytes([len(data)])+bytes(data)
    def patch_row(row,data,whole=False):
        occupied=[i for i,v in enumerate(data) if v]
        if not occupied and not whole:return b''
        lo,hi=(0,32) if whole else (min(occupied),max(occupied)+1)
        p=block(0x1600+row*32+lo,data[lo:hi])
        for back in (0,1):
            for wrap in range(3):p+=block(0x6000+back*4096+row*96+wrap*32+lo,data[lo:hi])
        return p
    init=bytearray()
    for b,gs in patterns.items():
        for i,g in enumerate(gs):
            for back in (0,1):init+=block(0x2000+back*8192+b*1024+(base[b]+i)*8,g)
    # Replace the complete old arcade headline, including its old blank cells.
    init+=patch_row(3,heading,whole=True)+bytes(2)
    (out/'arcade-bonus-message-font.bin').write_bytes(init)
    lines=['.segment "BANK27"','ab_message_font: .incbin "arcade-bonus-message-font.bin"']
    total=len(init);banks=[];sizes=[]
    for count,screen in enumerate(screens):
        patch=bytearray();tally=bytearray(32);tally[7:7+count]=bytes([tally_code])*count
        patch+=patch_row(5,tally)
        for row,data in screen.items():patch+=patch_row(row,data)
        patch+=bytes(2);total+=len(patch);sizes.append(len(patch))
        bank=24 if count<10 else 26;banks.append(bank)
        name=f'arcade-bonus-result-{count:02d}.bin';(out/name).write_bytes(patch)
        lines += [f'.segment "BANK{bank}"',f'ab_message_{count}: .incbin "{name}"']
    lines += ['.segment "BANK27"',
              'ab_message_lo: .lobytes '+','.join(f'ab_message_{i}' for i in range(21)),
              'ab_message_hi: .hibytes '+','.join(f'ab_message_{i}' for i in range(21)),
              'ab_message_bank: .byte '+','.join(map(str,banks)),f'ab_tally_code={tally_code}']
    (out/'arcade-bonus-message-data.s').write_text('\n'.join(lines)+'\n')
    (out/'arcade-bonus-lettering.json').write_text(json.dumps(dict(
        source='Hand-drawn native 5x7 letter patterns; no arcade font conversion',
        pixels_per_letter=[5,7],space_between_letters=1,
        glyph_counts={str(b):base[b]+len(p) for b,p in patterns.items()},
        header_row=3,tally_row=5,result_rows=[9,12,14],
        patch_bytes=total,per_frame_text_rasterization=False),indent=2)+'\n')
    print('Native bonus text patches:',total,'bytes')
