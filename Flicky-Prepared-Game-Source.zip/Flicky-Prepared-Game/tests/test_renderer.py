import ctypes as C,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from run_native import Native,BUILD
from run_reference import Reference
from render_native import decode

def test_collision_latches_and_cached_buffers():
    n=Native(True);r=Reference()
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    def call(name):
        count=n.lib.at_call(n.labels[name],0,0,0)
        assert count>0
        return count
    for frame in [360,600,900]:
        snapshot=np.fromfile(BUILD/f'reference/ram-{frame:05d}.bin',dtype=np.uint8)
        n.memory[0xc000:0xd000]=snapshot[0xc000:0xd000]
        n.memory[0x7000:0x7800]=snapshot[0xd000:0xd800]
        n.memory[0xd800:0xf000]=snapshot[0xd800:0xf000]
        n.memory[0xf000:0xf040]=0;n.memory[0xf800:0xfc00]=0
        r.ram[:]=snapshot;r.lib.fm_render_snapshot(0)
        call('render_init');first_cycles=call('render_frame');first=decode(n.memory)
        for name,base,size in [('mix',0xf000,64),('coll',0xf800,1024)]:
            fn=getattr(r.lib,'fm_'+name);fn.restype=C.POINTER(C.c_uint8)
            expected=np.ctypeslib.as_array(fn(),shape=(size,))
            np.testing.assert_array_equal(n.memory[base:base+size],expected)
        cached_cycles=call('render_frame')
        np.testing.assert_array_equal(decode(n.memory),first)
        assert cached_cycles<first_cycles
        n.memory[n.labels['r_backfont']]=0x40;n.memory[n.labels['r_backscreen']]=0x1c
        call('render_frame')
        np.testing.assert_array_equal(decode(n.memory,0x4000,0x1c00),first)
        # Moving actors must not leave old glyphs in either back buffer.
        n.memory[0x7002:0x7200:16]^=8
        call('render_frame');cached=decode(n.memory,0x4000,0x1c00)
        n.memory[0x610]=1;call('render_frame')
        np.testing.assert_array_equal(decode(n.memory,0x4000,0x1c00),cached)
