"""Prepare the arcade bonus DATA, art and pixel-exact catch masks.

Run explicitly with the user's verified private ROM set. Normal release builds
use the converted files; no original executable instructions enter the cart.
"""
import json
from pathlib import Path
from build import ROOT, BUILD
from character_atlas import CharacterAtlas
from assets import color

OUT=BUILD/'native'
BIRD_DESCRIPTORS=(0x339e,0x33a9,0x33b4,0x33bf)

def decode(rom,sprites,descriptor,frame,facing):
    h,stride=rom[descriptor:descriptor+2]
    p=descriptor+7+frame*2
    src=int.from_bytes(rom[p:p+2],'little')
    rows=[]
    for y in range(h):
        row=[]
        a=src+y*stride+(stride-2 if facing else 0)
        for x in range(stride):
            b=sprites[(a+(-x if facing else x))&32767]
            pair=(b&15,b>>4) if facing else (b>>4,b&15)
            for v in pair:
                if v==15:break
                row.append(v)
            if 15 in pair:break
        rows.append(row)
    return rows,2*(stride-1)

def main():
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    sprites=(ROOT/'private-roms/sprites.bin').read_bytes()
    ram=(BUILD/'arcade-bonus/original-600.bin').read_bytes()
    atlas=CharacterAtlas(OUT)
    lines=['; Converted arcade bonus data. No original executable code.']
    poses=[]
    for d in BIRD_DESCRIPTORS:
        for face in range(2):poses.append((d,0,face,'bird',ram[0xd890:0xd8a0]))
    for frame in range(3):
        for face in range(2):poses.append((0x334c,frame,face,'seesaw',ram[0xd800:0xd810]))
    for d in (0x67c4,0x67bb,0x6854):
        for face in range(2):poses.append((d,0,face,'cat',ram[0xd820:0xd830]))
    for d in (0x336b,0x3374):
        for face in range(2):poses.append((d,0,face,'net',ram[0xd9e0:0xd9f0]))
    banks=(21,22,23,25,26,27);bi=used=0
    names=[];image_banks=[];heights=[];radii=[];masks=[];report=[]
    for i,(d,fr,face,kind,pal) in enumerate(poses):
        pix,radius=decode(rom,sprites,d,fr,face)
        h=len(pix);width=max(map(len,pix));heights.append(h);radii.append(radius)
        masks.append({(2*x+j-radius,y-h//2+1) for y,row in enumerate(pix)
                      for x,v in enumerate(row) if v for j in range(2)})
        for phase in range(4):
            w=(phase+(width+1)//2+3)//4
            raw=bytearray([h,w,128 if kind=='bird' else 0])
            for row in pix:
                mask=[0]*w;bits=[0]*w
                for x in range((len(row)+1)//2):
                    pair=row[2*x:2*x+2]
                    projected=[color(pal[p]) if p else 0 for p in pair]
                    v=next((v for v in projected if v),0)
                    if kind=='bird':v=3 if v in (3,4) else v
                    elif kind=='net':v=3 if v in (3,4) else v
                    else:v=3 if v in (3,4) else v
                    pos=x+phase;shift=6-2*(pos&3)
                    if any(pair):mask[pos//4]|=3<<shift
                    bits[pos//4]|=v<<shift
                for a,b in zip(mask,bits):raw.extend((a^255,b))
            data=atlas.convert(raw)
            if used+len(data)>8192:bi+=1;used=0
            assert bi<len(banks)
            name=f'arcade-bonus-art-{i:02d}-{phase}.bin';(OUT/name).write_bytes(data)
            label=f'ab_art_{i}_{phase}';names.append(label);image_banks.append(banks[bi]);used+=len(data)
            lines += [f'.segment "BANK{banks[bi]}"',label+':',f'.incbin "{name}"']
        report.append(dict(id=i,descriptor=f'{d:04x}',frame=fr,facing=face,kind=kind,height=h,radius=radius))
    lines += ['.segment "BANK28"','ab_art_lo:','.lobytes '+','.join(names),
              'ab_art_hi:','.hibytes '+','.join(names),'ab_art_bank:',
              '.byte '+','.join(map(str,image_banks)), 'ab_height:',
              '.byte '+','.join(map(str,heights)),'ab_radius:', '.byte '+','.join(map(str,radii))]
    for name,data in [('ab_initial',rom[0x145e:0x159e]),('ab_pattern',rom[0x15b6:0x1607])]:
        lines += [name+':']
        for p in range(0,len(data),16):lines += ['.byte '+','.join(map(str,data[p:p+16]))]
    offsets=[int.from_bytes(rom[p:p+2],'little')-0x15b6 for p in range(0x159e,0x15b6,2)]
    lines += ['ab_pattern_offset:', '.byte '+','.join(map(str,offsets))]
    # Hardware sprite collision works at the ORIGINAL doubled horizontal
    # resolution, independently of the Atari display's reduced glyphs.
    catch=bytearray()
    for net in range(20,24):
        for bird in range(8):
            table=bytearray(256)
            for dy in range(-16,16):
                for dx in range(-32,32):
                    if any((x+dx,y+dy) in masks[net] for x,y in masks[bird]):
                        off=(dy+16)*8+(dx+32)//8
                        table[off]|=1<<((dx+32)&7)
            catch.extend(table)
    assert len(catch)==8192
    (OUT/'arcade-bonus-catch.bin').write_bytes(catch)
    lines+=['.segment "BANK29"','ab_catch_masks: .incbin "arcade-bonus-catch.bin"']
    # Full-resolution silhouettes for the rare overlapping-net case. The
    # renderer's reduced color pixels must not decide collision ownership.
    aligned=bytearray()
    for art in range(8):
        for phase in range(8):
            for y in range(12):
                bits=sum(1<<(x+radii[art]+phase) for x,yy in masks[art]
                         if yy==y-heights[art]//2+1)
                aligned.extend(bits.to_bytes(4,'little'))
    nets=bytearray()
    for art in range(20,24):
        for y in range(-8,8):
            bits=sum(1<<(x+16) for x,yy in masks[art] if yy==y)
            nets.extend(bits.to_bytes(4,'little'))
    (OUT/'arcade-bonus-silhouettes.bin').write_bytes(aligned)
    (OUT/'arcade-bonus-net-silhouettes.bin').write_bytes(nets)
    lines+=['.segment "BANK28"',
            'ab_silhouettes: .incbin "arcade-bonus-silhouettes.bin"',
            'ab_net_silhouettes: .incbin "arcade-bonus-net-silhouettes.bin"',
            'ab_silhouette_lo:', '.lobytes '+','.join(f'ab_silhouettes+{i*48}' for i in range(64)),
            'ab_silhouette_hi:', '.hibytes '+','.join(f'ab_silhouettes+{i*48}' for i in range(64))]
    (OUT/'arcade-bonus-data.s').write_text('\n'.join(lines)+'\n')
    # Exact foreground glyphs and result layouts, executed from the ROM.
    from native_oracle import Original
    original=Original();overlays=[]
    for caught in range(21):
        original.ram[:]=0
        original.ram[0xc000]=128
        original.ram[0xc03b]=20
        original.ram[0xc03c]=int(f'{caught:02d}',16)
        original.ram[0xc03d]=caught
        original.call(0x0573,stop=0x068e)
        for i in range(caught):
            original.ram[0xe94e+i*2:0xe950+i*2]=[0x2f,8]
        overlays.append(original.ram[0xe800:0xef00:2].tobytes())
    (OUT/'arcade-bonus-overlays.bin').write_bytes(b''.join(overlays))
    tile=(ROOT/'private-roms/tiles.bin').read_bytes();font=bytearray()
    for char in range(128):
        code=char if char==47 else char+256
        for y in range(8):
            bits=tile[code*8+y]|tile[16384+code*8+y]|tile[32768+code*8+y]
            font.append(sum(bool(bits&(0xc0>>(2*x)))<<(6-2*x) for x in range(4)))
    (OUT/'arcade-bonus-font.bin').write_bytes(font)
    (OUT/'arcade-bonus-assets.json').write_text(json.dumps(dict(poses=report,art_banks=list(banks[:bi+1]),
        pattern_offsets=offsets,catch_masks_bytes=len(catch),original_executable_bytes=0),indent=2)+'\n')
    print('Prepared',len(poses),'arcade poses; catch masks',len(catch),'bytes; art banks',banks[:bi+1])

if __name__=='__main__':main()
