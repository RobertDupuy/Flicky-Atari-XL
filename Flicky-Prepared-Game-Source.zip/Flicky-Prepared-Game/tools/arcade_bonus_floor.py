"""One-time floor color preparation from the supplied arcade graphics.

Normal builds consume the converted 2 KB floor role map and cat color arrays,
not private ROM inputs. Original tile joints and cat silhouettes are retained.
"""
import json
from build import ROOT,BUILD

def main():
    out=BUILD/'native';raw=(ROOT/'private-roms/tiles.bin').read_bytes()
    m=(out/'maps-reference.bin').read_bytes()[3584:5376];floor=bytearray()
    for y in range(208,224):
        for x in range(128):
            a=((y//8)*32+x//4)*2;c=int.from_bytes(m[a:a+2],'little')&2047
            pair=[sum(((raw[p*16384+c*8+y%8]>>(7-xx))&1)<<(2-p)for p in range(3))for xx in (x%4*2,x%4*2+1)]
            # Source 4/5 are bright mortar; 2/3 are the brick faces.
            roles={0:0,1:0,2:2,3:2,4:3,5:3,6:0,7:2}
            values=[roles[v]for v in pair]
            floor.append(3 if 3 in values else values[0] or values[1])
    (out/'arcade-bonus-floor.bin').write_bytes(floor)
    from arcade_bonus_assets import decode
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    sprites=(ROOT/'private-roms/sprites.bin').read_bytes()
    cats=[]
    for descriptor in (0x67c4,0x67bb,0x6854):
        for facing in range(2):
            source,radius=decode(rom,sprites,descriptor,0,facing);pixels=[]
            for row in source:
                line=[]
                for x in range(0,len(row),2):
                    pair=[v for v in row[x:x+2] if v]
                    # White eye pixels take priority; light fur stays orange
                    # rather than being classified as white by RGB distance.
                    color=255 if not pair else 1 if 1 in pair else 4 if any(v in (2,3,4,5,6,7,8,12,13) for v in pair) else 2
                    line.append(color)
                pixels.append(line)
            cats.append(pixels)
    (out/'arcade-bonus-cat-colors.json').write_text(json.dumps(cats,separators=(',',':'))+'\n')

if __name__=='__main__':main()
