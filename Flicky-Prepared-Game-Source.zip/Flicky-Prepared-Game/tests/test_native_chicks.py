"""Chick behavior is compared to the independent original CPU on the host."""
import json
import ctypes as C
import random
import subprocess
import sys
from pathlib import Path
import pytest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import ROOT,BUILD
from native_engine import Engine
from native_oracle import Original
from run_reference import Reference

DESCRIPTORS=[0x337d,0x3388,0x3393,0x339e,0x33a9,0x33b4,0x33bf,0x33ca,0x33d5]
FIELDS=[('n_flags',0),('n_pause',6),('n_ylo',9),('n_yhi',10),('n_target',11),
        ('n_acceleration',12),('n_frame',13),('n_bob',16),('n_vx',18),('n_fx',19),
        ('n_vy',20),('n_fy',21),('n_timer',22),('n_cycle',23),('n_chick_state',26),('n_chain',28)]

@pytest.fixture(scope='module')
def native():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True,capture_output=True)
    engine=Engine()
    yield engine
    (BUILD/'native/chick-cycles.json').write_text(json.dumps(engine.maximum,indent=2)+'\n')

def set_word(native,name,value):
    native.set(name,value);native.set(name,value>>8,1)

def test_native_chick_initial_positions_and_variants(native):
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    original=Original()
    for stage in range(48):
        native.call('native_reset');native.set('n_round',stage);native.call('round_select')
        native.call('chicks_reset')
        layout=native.get('n_layout')
        original.ram[:]=0
        original.ram[0xc000]=0x80
        original.ram[0xc008]=stage if stage<2 else 2
        original.ram[0xc014]=layout
        for actor in range(8):
            address=0xc300+actor*32
            original.ram[address+5]=actor
            original.ram[address+1:address+3]=[0xb4,0x33]
        original.call(0x0d29)
        assert native.get('n_rescued')==original.ram[0xc013]
        for actor in range(8):
            address=0xc300+actor*32
            for field,offset in [('n_flags',0),('n_ylo',9),('n_target',11),('n_acceleration',12)]:
                assert native.get(field,actor)==original.ram[address+offset],(stage,actor,field)
            assert native.get('n_xlo',actor)==original.ram[address+7]
            assert native.get('n_xhi',actor)==original.ram[address+8]
            # Run the source variant selection itself; initialization of later
            # actors and bonus objects is outside this component test.
            original.ram[0xc018]=stage
            original.call(0x03ba,ix=address,stop=0x03d4)
            assert native.get('n_frame',actor)==original.ram[address+13]

def test_native_trail_history_order_and_wrap(native):
    original=Original();randomizer=random.Random(0x1ebe)
    native.call('native_reset');native.call('chicks_reset')
    original.ram[:]=0
    original.ram[0xc025]=0x67;original.ram[0xc026]=0xcf;original.ram[0xc408]=1
    for tick in range(5000):
        train=randomizer.randrange(9);height=randomizer.randrange(224);delta=randomizer.randrange(-3,4)&65535
        original.ram[0xc015]=train;original.ram[0xc409]=height
        original.ram[0xc016:0xc018]=[delta&255,delta>>8]
        native.set('n_train',train);native.set('n_ylo',height,8);set_word(native,'n_scroll_delta',delta)
        original.call(0x1ebe);native.call('train_record')
        assert native.get('n_history_yindex')==original.ram[0xc025]-0x40
        assert native.get('n_history_xindex')==(original.ram[0xc026]-0x81)//2
        for slot in range(40):
            assert native.get('n_history_y',slot)==original.ram[0xc240+slot]
            assert native.get('n_history_xlo',slot)==original.ram[0xc280+2*slot]
            assert native.get('n_history_xhi',slot)==original.ram[0xc281+2*slot]
        for actor in range(train):
            assert native.get('n_trail_xlo',actor)==original.ram[0xc2e0+actor*2]
            assert native.get('n_trail_xhi',actor)==original.ram[0xc2e1+actor*2]

def test_native_chick_terrain_sampling(native):
    original=Original();randomizer=random.Random(0x3fe7)
    for trial in range(2048):
        tiles=bytes(randomizer.randrange(256) for _ in range(1792))
        original.ram[0xe000:0xe700]=list(tiles);native.ram[0xc000:0xc700]=list(tiles)
        actor=trial&7;address=0xc300+actor*32
        world=randomizer.randrange(65536);screen=randomizer.randrange(65536);height=randomizer.randrange(8,208)
        original.ram[0xc01a:0xc01c]=[world&255,world>>8]
        original.ram[address+7:address+10]=[screen&255,screen>>8,height]
        set_word(native,'n_world',world)
        position=(screen-world)&65535
        native.set('n_xlo',position,actor);native.set('n_xhi',position>>8,actor);native.set('n_ylo',height,actor)
        result=original.call(0x3e51,ix=address,stop=0x3e7d)
        mask=native.call('chick_sample_terrain',x=actor)
        assert mask==(result[2]>>8),(trial,world,screen,height)

def test_native_chick_follow_pickup_and_scatter(native):
    original=Original();randomizer=random.Random(0x3b71)
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    rom=(ROOT/'private-roms/maincpu-data.bin').read_bytes()
    for trial in range(4096):
        native.call('native_reset');native.call('chicks_reset')
        original.ram[:]=0;original.ram[0xc000]=0x80
        layout=trial%48;tiles=maps[layout*1792:(layout+1)*1792]
        original.ram[0xe000:0xe700]=list(tiles);native.ram[0xc000:0xc700]=list(tiles)
        actor=trial&7;address=0xc300+actor*32
        world=randomizer.randrange(65536);set_word(native,'n_world',world)
        original.ram[0xc01a:0xc01c]=[world&255,world>>8]
        train=8;native.set('n_train',train);original.ram[0xc015]=train
        for index in range(8):
            row=0xc300+index*32
            values=[0xb0|randomizer.randrange(2),randomizer.randrange(3),randomizer.randrange(16,204),0,
                    randomizer.choice([20+index*2,236-index*2]),randomizer.choice([1,255]),randomizer.randrange(2),
                    randomizer.randrange(256),randomizer.randrange(256),randomizer.randrange(16),
                    randomizer.randrange(256),randomizer.randrange(16),randomizer.randrange(256),
                    # Stationary idle bobbing was deliberately replaced by
                    # prepared poses; compare the retained moving states.
                    randomizer.randrange(4),randomizer.choice([1,2,6,14]),index]
            for (field,offset),value in zip(FIELDS,values):
                native.set(field,value,index);original.ram[row+offset]=value
            original.ram[row+5]=index
            original.ram[row+1:row+3]=[0xb4,0x33];native.set('n_animation',5,index)
            screen=randomizer.randrange(512);position=(screen-world)&65535
            native.set('n_xlo',position,index);native.set('n_xhi',position>>8,index)
            original.ram[row+7:row+9]=[screen&255,screen>>8]
            trail=randomizer.randrange(136,377)
            original.ram[0xc2e0+index*2:0xc2e2+index*2]=[trail&255,trail>>8]
            native.set('n_trail_xlo',trail,index);native.set('n_trail_xhi',trail>>8,index)
        history=bytes(randomizer.randrange(16,204) for _ in range(40))
        original.ram[0xc240:0xc268]=list(history)
        native.ram[0x1b00:0x1b28]=list(history)
        cursor=randomizer.randrange(40)
        native.set('n_history_yindex',cursor);original.ram[0xc025]=cursor+0x40
        death=randomizer.randrange(8)==0
        native.set('n_flags',0x80|4*death,8);original.ram[0xc400]=0x80|4*death
        terrain=randomizer.randrange(2);native.set('n_chick_contact',terrain,actor);original.ram[0xf020+actor]=terrain
        enemy=int(randomizer.randrange(8)==0);native.set('n_enemy_contact',enemy,actor);original.ram[0xf920+actor]=enemy
        pickup=int(randomizer.randrange(8)==0);native.set('n_pickup',pickup<<actor);original.ram[0xf900+actor]=pickup
        original.call(0x3b71,ix=address)
        native.call('chick_update',x=actor)
        for index in range(8):
            for field,offset in FIELDS:
                assert native.get(field,index)==original.ram[0xc300+index*32+offset],(trial,actor,index,field)
        screen=(native.get('n_xlo',actor)+(native.get('n_xhi',actor)<<8)+world)&65535
        assert screen==int(original.ram[address+7])+(int(original.ram[address+8])<<8),(trial,'x')
        assert native.get('n_train')==original.ram[0xc015],(trial,'train')
        pointer=int(original.ram[address+1])+(int(original.ram[address+2])<<8)
        assert DESCRIPTORS[native.get('n_animation',actor)]==pointer,(trial,'animation')
        top=(native.get('n_ylo',actor)+native.get('n_draw_yoffset',actor)-rom[pointer]//2)&255
        assert top==original.ram[0xc220],(trial,'draw offset')
        # Original score is big-endian BCD in tens of points; native is
        # little-endian BCD in actual points. Compare their numeric values.
        native_score=int(''.join(f'{native.get("n_score",i):02x}' for i in (2,1,0)))
        original_score=int(''.join(f'{int(v):02x}' for v in original.ram[0xc0cf:0xc0d2]))*10
        assert native_score==original_score,(trial,'score')

def configure_video_sprite(video,actor,record,screen,center,facing):
    height,stride=record['height'],record['stride']
    top=(center-height//2)&255
    source=record['source']
    if facing:source=(source+stride-2)|0x8000
    source=(source-stride)&65535
    left=(screen-2*(stride-1))&511
    video.ram[0xd000+actor*16:0xd008+actor*16]=[top,(top+height)&255,left&255,left>>8,stride,0,source&255,source>>8]

def test_native_chick_pixel_terrain_and_screen_edge_clipping(native):
    video=Reference();video.lib.fm_mix.restype=C.POINTER(C.c_uint8)
    metadata=json.loads((BUILD/'native/chick-assets.json').read_text())['records']
    maps=(BUILD/'native/maps-reference.bin').read_bytes();randomizer=random.Random(0xf020)
    blank=int(np.flatnonzero(~video.tiles.any(axis=(1,2)))[0])
    for stage in [0,7,19,23]:
        native.call('native_reset');native.set('n_round',stage)
        native.call('level_load');native.call('display_init')
        video.ram[0xc000:]=0
        video.ram[0xe000:0xe700]=list(maps[stage*1792:(stage+1)*1792])
        video.ram[0xe800:0xf000:2]=blank&255;video.ram[0xe801:0xf000:2]=blank>>8
        for trial in range(512):
            world=randomizer.randrange(65536);screen=randomizer.randrange(512)
            if trial%2==0:screen=randomizer.choice([0,1,7,8,9,10,11,12,13,14,15,500,510,511])
            animation=randomizer.randrange(9);variant=randomizer.randrange(2);facing=randomizer.randrange(2)
            center=randomizer.randrange(16,215);offset=randomizer.randrange(-3,4)
            set_word(native,'n_world',world);position=(screen-world)&65535
            native.set('n_xlo',position);native.set('n_xhi',position>>8)
            native.set('n_ylo',center);native.set('n_draw_yoffset',offset)
            native.set('n_animation',animation);native.set('n_frame',variant);native.set('n_flags',0xb0|facing)
            native.set('n_chick_contact',0)
            native.call('chick_terrain_contact',x=0)
            record=metadata[animation*16+variant*8+facing*4]
            configure_video_sprite(video,0,record,screen,center+offset,facing)
            scroll=(world-28)&65535;video.ram[0xeffc:0xeffe]=[scroll&255,scroll>>8]
            video.lib.fm_render_snapshot(0)
            assert native.get('n_chick_contact')==video.lib.fm_mix()[32],(stage,trial,world,screen,center,animation,variant,facing)

def test_native_chick_pickup_pixel_priority_and_odd_positions(native):
    video=Reference();video.lib.fm_coll.restype=C.POINTER(C.c_uint8)
    player=json.loads((BUILD/'native/player-assets.json').read_text())['records']
    chicks=json.loads((BUILD/'native/chick-assets.json').read_text())['records']
    randomizer=random.Random(0xf900)
    native.call('native_reset')
    for trial in range(2048):
        video.ram[0xc000:]=0
        world=randomizer.randrange(65536);set_word(native,'n_world',world)
        animation=randomizer.randrange(6);frame=randomizer.randrange(2 if animation<5 else 4);facing=randomizer.randrange(2)
        center=randomizer.randrange(32,192)
        native.set('n_ylo',center,8);native.set('n_animation',animation,8);native.set('n_frame',frame,8)
        native.set('n_pose',[0,0,2,3,1,1][animation],8);native.set('n_flags',0x80|facing,8)
        configure_video_sprite(video,8,player[animation*32+frame*8+facing*4],256,center+int(animation==3),facing)
        for actor in range(8):
            animation=randomizer.randrange(9);variant=randomizer.randrange(2);facing=randomizer.randrange(2)
            screen=randomizer.randrange(208,305);height=center+randomizer.randrange(-24,25);offset=randomizer.randrange(-3,4)
            position=(screen-world)&65535
            native.set('n_xlo',position,actor);native.set('n_xhi',position>>8,actor)
            native.set('n_ylo',height,actor);native.set('n_draw_yoffset',offset,actor)
            native.set('n_animation',animation,actor);native.set('n_frame',variant,actor);native.set('n_flags',0xb0|facing,actor)
            configure_video_sprite(video,actor,chicks[animation*16+variant*8+facing*4],screen,height+offset,facing)
        video.lib.fm_render_snapshot(0)
        native.set('n_pickup',0);native.call('pickup_contacts')
        expected=sum(int(video.lib.fm_coll()[256+actor])<<actor for actor in range(8))
        assert native.get('n_pickup')==expected,(trial,native.get('n_pickup'),expected)

def test_native_rescue_door_starts_only_with_grounded_followers(native):
    original=Original();randomizer=random.Random(0x3627)
    for trial in range(512):
        native.call('native_reset');native.call('chicks_reset')
        original.ram[:]=0
        tiles=bytes(randomizer.randrange(256) for _ in range(1792))
        original.ram[0xe000:0xe700]=list(tiles);native.ram[0xc000:0xc700]=list(tiles)
        world=randomizer.randrange(512);height=randomizer.randrange(16,200)
        train=randomizer.randrange(9);grounded=randomizer.randrange(2);exiting=randomizer.randrange(2)
        set_word(native,'n_world',world);original.ram[0xc01a:0xc01c]=[world&255,world>>8]
        for name,address,value in [('n_train',0xc015,train),('n_grounded',0xc021,grounded),('n_exiting',0xc028,exiting)]:
            native.set(name,value);original.ram[address]=value
        native.set('n_ylo',height,8);original.ram[0xc409]=height
        for actor in range(8):
            state=randomizer.randrange(4);flags=randomizer.choice([0x30,0xb0,0xb1])
            native.set('n_chick_state',state,actor);native.set('n_flags',flags,actor)
            original.ram[0xc31a+actor*32]=state;original.ram[0xc300+actor*32]=flags
        original.call(0x35ec,ix=0xc400,stop=0x36a9)
        native.call('player_sample_terrain')
        assert native.get('n_exiting')==original.ram[0xc028],trial
        for actor in range(8):assert native.get('n_flags',actor)==original.ram[0xc300+actor*32],(trial,actor)

def test_native_prepared_characters_overlap_recolor_clip_and_expire(native):
    native.call('native_reset');native.call('level_load');native.call('display_init')
    assets={kind:json.loads((BUILD/f'native/{kind}-assets.json').read_text()) for kind in ('player','chick','cat')}
    images={kind:[(BUILD/f'native/{kind}-image-{i:03}.bin').read_bytes()
                  for i in range(max(data['images'])+1)] for kind,data in assets.items()}
    def pixels(buffer):
        screen=native.ram[0x6000+4096*buffer:0x6000+4096*buffer+2688].reshape(28,96)[:,:32]
        pointers=0x2000+buffer*8192+(np.arange(28)//4)[:,None]*1024+(screen.astype(np.int32)&127)*8
        glyphs=native.ram[pointers[:,:,None]+np.arange(8)]
        values=(glyphs[:,:,:,None]>>np.array([6,4,2,0]))&3
        values=np.where((values==3)&((screen[:,:,None,None]&128)!=0),4,values)
        return values.transpose(0,2,1,3).reshape(224,128).astype(np.uint8)
    background=pixels(0)
    randomizer=random.Random(0x1a80)
    for frame in range(270):
        buffer=frame&1;native.set('r_back',buffer);native.call('sprites_begin')
        np.testing.assert_array_equal(pixels(buffer),background,err_msg=f'restore {frame}')
        world=(frame//8*3+504)&65535;set_word(native,'n_world',world)
        expected=background.copy()
        for actor in range(11):
            kind='player' if actor==8 else 'cat' if actor>=9 else 'chick';data=assets[kind]
            animation=(frame//16)%6 if actor==8 else (frame//12+actor)%(21 if actor>=9 else 9)
            variant=0 if actor>=9 else (frame//20)&1;facing=(frame//32+actor)&1
            if actor==8:screen=256;center=184;offset=int(animation==3)
            elif frame%90>=60:screen=242+actor*4;center=180+(actor%3)*5;offset=0
            else:screen=[0,4,12,511,64,120,340,420,256,280,310][actor];center=40+(actor%8)*20;offset=(frame//8)%5-2
            if actor>=9:offset=0
            native.set('n_flags',0xb0|facing|(2 if animation>=18 else 0),actor)
            native.set('n_animation',([5,7,8][animation-18] if animation>=18 else animation),actor)
            native.set('n_frame',variant,actor);native.set('n_ylo',center,actor)
            native.set('n_draw_yoffset',offset,actor)
            if actor==8:native.set('n_pose',[0,0,2,3,1,1][animation],8)
            else:
                position=(screen-world)&65535
                native.set('n_xlo',position,actor);native.set('n_xhi',position>>8,actor)
            if actor!=8 and frame%47 in (16,17,18,19) and actor%3==0:
                native.set('n_flags',0,actor)
                continue
            base=animation*(32 if actor==8 else 8 if actor>=9 else 16)+variant*8+facing*4
            record=data['records'][base]
            screen_left=(screen-2*(record['stride']-1))&511
            left=(screen_left-world)&511;phase=(left>>2)&3
            image=images[kind][data['images'][base+phase]]
            height,width,ink=image[:3];cursor=3;top=center+offset-height//2+1
            clip_count=24 if actor==8 else min(24,(512-screen_left+1)//2)
            clip_pixels=phase+(clip_count+1)//2
            for y in range(height):
                for col in range(width):
                    keep,value=image[cursor:cursor+2];cursor+=2
                    allowed=max(0,min(4,clip_pixels-col*4))
                    clip=((255<<(8-2*allowed))&255) if allowed else 0
                    keep|=clip^255;value&=clip
                    line=top+y;dest=(((left>>4)+col)&31)*4
                    if not 0<=line<224:continue
                    if value&(value>>1)&0x55:
                        cell=expected[line//8*8:line//8*8+8,dest:dest+4]
                        cell[cell==(3 if ink else 4)]=1
                    for x in range(4):
                        shift=6-2*x
                        if not (keep>>shift)&3:
                            v=(value>>shift)&3;expected[line,dest+x]=4 if v==3 and ink else v
            native.call({'player':'sprite_draw_player','chick':'sprite_draw_chick','cat':'sprite_draw_cat'}[kind],x=actor)
        assert native.get('r_fault')==0,frame
        np.testing.assert_array_equal(pixels(buffer),expected,err_msg=f'frame {frame}')
    assert native.get('r_cache_hits')+256*native.get('r_cache_hits',1)>200

@pytest.mark.parametrize('lines,pal_register',[(262,15),(312,1)])
def test_native_delivery_state_and_raster_timed_pause(native,lines,pal_register):
    original=Original()
    for length in range(1,9):
        native.lib.at_video_timing(0)
        native.call('native_reset');native.call('level_load');native.call('chicks_reset')
        native.ram[0xd014]=pal_register;native.call('display_init')
        native.lib.at_video_timing(lines)
        original.ram[:]=0;original.ram[0xc000]=0x80
        native.ram[0x0800:0x0808]=0
        native.set('n_train',length);original.ram[0xc015]=length
        native.set('n_rescued',(~((1<<length)-1))&255);original.ram[0xc013]=native.get('n_rescued')
        native.set('n_exiting',1);original.ram[0xc028]=1
        native.set('n_ylo',159,8);original.ram[0xc409]=159
        original.ram[0xc025]=0x67;native.set('n_history_yindex',39)
        native.ram[0x1b00:0x1b28]=159;original.ram[0xc240:0xc268]=159
        for actor in range(length):
            native.set('n_trail_xlo',0,actor);native.set('n_trail_xhi',1,actor)
            original.ram[0xc2e0+2*actor:0xc2e2+2*actor]=[0,1]
            native.set('n_flags',0xb4,actor);native.set('n_chick_state',1,actor);native.set('n_chain',actor,actor)
            native.set('n_ylo',159,actor);native.set('n_xlo',8,actor);native.set('n_xhi',255,actor)
            address=0xc300+actor*32
            original.ram[address]=0xb4;original.ram[address+5]=actor;original.ram[address+26]=1;original.ram[address+28]=actor
            original.ram[address+9]=159;original.ram[address+1:address+3]=[0xb4,0x33]
        for actor in range(length):
            original.call(0x3b71,ix=0xc300+actor*32)
            before=native.lib.at_cycles()
            native.call('chick_update',x=actor)
            elapsed=native.lib.at_cycles()-before
            # Raster counter and VBI run here; ANTIC DMA is deliberately absent.
            assert 97000<elapsed<105000,(lines,length,actor,elapsed)
            for name,address in [('n_train',0xc015),('n_rescued',0xc013),('n_delivered',0xc02b),('n_exiting',0xc028)]:
                assert native.get(name)==original.ram[address],(lines,length,actor,name)
            assert native.get('n_flags',actor)==original.ram[0xc300+32*actor]
            # Native scoring awards actual points immediately; the old source
            # defers its tens-of-points score until a later popup update.
            got=int(''.join(f'{native.get("n_score",i):02x}'for i in (2,1,0)))
            assert got==sum((100,200,300,400,500,1000,2000,5000)[:actor+1])
            assert native.get('c_overflow')==0
    native.lib.at_video_timing(0)


def test_precomputed_idle_clearance_and_moved_actor_fallback(native):
    # Validate the offline proof using the independent 6502 pixel path, including
    # negative world coordinates and the original hardware's clipping seam.
    checked = 0
    for stage in range(48):
        native.call('native_reset'); native.set('n_round', stage)
        native.call('level_load'); native.call('chicks_reset'); native.call('display_init')
        safe = native.get('n_idle_clear')
        for actor in range(8):
            if not safe & (1 << actor):
                continue
            for world in (0, 1, 511, 65535):
                set_word(native, 'n_world', world)
                for pose in (5, 6):
                    for variant in (0, 1):
                        for facing in (0, 1):
                            native.set('n_animation', pose, actor)
                            native.set('n_frame', variant, actor)
                            native.set('n_flags', 0xb0 | facing, actor)
                            for offset in (-3, 0, 3):
                                native.set('n_draw_yoffset', offset, actor)
                                native.set('n_chick_contact', 0, actor)
                                native.call('chick_terrain_contact', x=actor)
                                assert native.get('n_chick_contact', actor) == 0, (stage, actor, world, pose, variant, facing, offset)
                                checked += 1
    assert checked == 36480
    # Changing the position must invalidate the spawn-only shortcut.
    native.call('native_reset'); native.call('level_load'); native.call('chicks_reset'); native.call('display_init')
    rng = random.Random(0x1d1e)
    for sample in range(128):
        native.ram[0x0800:0x0808] = 0
        actor = sample & 7
        native.set('n_flags', 0xb0, actor)
        native.set('n_animation', 5, actor)
        native.set('n_ylo', rng.randrange(16, 208), actor)
        native.set('n_xlo', rng.randrange(256), actor)
        native.set('n_chick_contact', 0, actor)
        native.call('chick_terrain_contact', x=actor)
        expected = native.get('n_chick_contact', actor)
        native.set('n_chick_contact', 0, actor)
        native.call('chick_contacts')
        assert native.get('n_chick_contact', actor) == expected

