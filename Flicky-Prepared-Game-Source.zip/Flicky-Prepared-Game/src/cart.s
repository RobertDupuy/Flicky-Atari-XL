.setcpu "6502"
.include "runtime.s"
.segment "CODE"
.export start, idle, frame, host_position, last_frame, bank_ok
frame = $3000
host_position = $3001
last_frame = $3002
bank_ok = $3003

start:
    sei
    cld
    ldx #$ff
    txs
    lda #0
    sta $d40e
    sta $d400
    sta $d20e
    sta $d01d
    sta $d01b
    sta frame
    sta last_frame
    lda #16
    sta host_position
    ; Disable OS ROM and BASIC, retain normal 64 KB RAM configuration.
    lda #$fe
    sta $d301
    lda #<nmi
    sta $fffa
    lda #>nmi
    sta $fffb
    ldx #0
@copy:
    lda charset,x
    sta $2000,x
    lda charset+$100,x
    sta $2100,x
    lda charset+$200,x
    sta $2200,x
    lda charset+$300,x
    sta $2300,x
    lda initial_screen,x
    sta $2400,x
    lda initial_screen+$100,x
    sta $2500,x
    lda initial_screen+$200,x
    sta $2600,x
    lda initial_screen+$300,x
    sta $2700,x
    inx
    bne @copy
    lda #1
    sta bank_ok
    ldx #0
@bank_test:
    stx $d500
    cpx $8000
    beq @bank_next
    lda #0
    sta bank_ok
@bank_next:
    inx
    cpx #15
    bne @bank_test
    ; Bank 15 mirrors the fixed bank. Check its first opcode.
    stx $d500
    lda $8000
    cmp $a000
    beq @banks_done
    lda #0
    sta bank_ok
@banks_done:
    lda #0
    sta $d500
    lda #<display_list
    sta $d402
    lda #>display_list
    sta $d403
    lda #$20
    sta $d409
    lda #2
    sta $d401
    lda #$82
    sta $d01a
    lda #$0e
    sta $d016
    lda #$9a
    sta $d017
    lda #$28
    sta $d018
    lda #$48
    sta $d019
    lda #$22
    sta $d400
    lda #$40
    sta $d40e
idle:
    lda frame
    cmp last_frame
    beq idle
    sta last_frame
    ; Read held joystick levels. No edge-only movement bug.
    lda $d300
    and #4
    bne @right
    lda host_position
    beq @right
    dec host_position
@right:
    lda $d300
    and #8
    bne @run
    lda host_position
    cmp #31
    beq @run
    inc host_position
@run:
    jsr z_reset
    lda host_position
    sta z_input
    jsr guest_entry
    lda z_fault
    bne failed
    lda bank_ok
    beq failed
    lda $4000
    cmp #48
    bne failed
    lda z_cycles
    cmp #<607
    bne failed
    lda z_cycles+1
    cmp #>607
    bne failed
    lda z_m1
    cmp #74
    bne failed
    ; "PASS" uses custom 3x5 glyphs, still ANTIC 4.
    lda #'P'-32
    sta $2400+40*8+27
    lda #'A'-32
    sta $2400+40*8+28
    lda #'S'-32
    sta $2400+40*8+29
    sta $2400+40*8+30
    ldx #31
    lda #0
@erase:
    sta $2400+40*19+4,x
    dex
    bpl @erase
    ldx z_output
    lda #126+128
    sta $2400+40*19+4,x
    jmp idle
failed:
    lda #'F'-32
    sta $2400+40*8+27
    lda #'A'-32
    sta $2400+40*8+28
    lda #'I'-32
    sta $2400+40*8+29
    lda #'L'-32
    sta $2400+40*8+30
    lda #$38
    sta $d01a
    jmp failed
nmi:
    pha
    inc frame
    sta $d40f
    pla
    rti
cart_init:
    rts
.include "guest.s"

.segment "RODATA"
display_list:
    .byte $70,$70,$70,$44
    .word $2400
    .repeat 23
        .byte $04
    .endrepeat
    .byte $41
    .word display_list
.align 256
charset: .incbin "charset.bin"
initial_screen: .incbin "screen.bin"
.segment "VECTORS"
    .word start
    .byte 0,$04
    .word cart_init
