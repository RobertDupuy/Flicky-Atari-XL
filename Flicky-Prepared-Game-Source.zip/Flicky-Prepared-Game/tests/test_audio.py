"""Execute every packed sound stream on the actual NMOS 6502 player."""
import ctypes as C
import json
import sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from run_native import Native,BUILD
from native_engine import Engine

@pytest.mark.parametrize('native_engine',[False,True])
def test_all_audio_commands_and_loops(native_engine):
    n=Engine() if native_engine else Native(True)
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    def call(name,a=0):
        count=n.lib.at_call(n.labels[name],a,0,0)
        assert count>0
        return count
    for track in json.loads((BUILD/'audio/manifest.json').read_text()):
        n.memory[0xd014]=15
        call('audio_init')
        call('audio_start',track['command'])
        frames=np.load(BUILD/f'audio/{track["command"]:02x}-pokey.npy')
        slot=0x220 if track['replace'] or track['loop_frame'] is not None else 0x240
        for frame in range(len(frames)+400):
            call('audio_tick')
            if frame<len(frames):expected=frames[frame]
            elif track['loop_frame'] is not None:
                start=track['loop_frame']
                expected=frames[start+(frame-len(frames))%(len(frames)-start)]
            else:
                assert n.memory[slot]==0
                continue
            np.testing.assert_array_equal(n.memory[slot+8:slot+16],expected,
                                          err_msg=f'command {track["command"]:02x}, tick {frame}')
    call('audio_start',0)
    assert not np.any(n.memory[0xd201:0xd208:2])

@pytest.mark.parametrize('native_engine',[False,True])
def test_audio_vbi_preserves_main_state_and_bank(native_engine):
    n=Engine() if native_engine else Native(True)
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    def call(name,a=0):
        cycles=n.lib.at_call(n.labels[name],a,0,0)
        assert cycles>0,(name,n.lib.at_pc())
        return cycles
    n.memory[0xd014]=15
    call('audio_init')
    call('audio_enqueue',0x83)
    n.memory[0x20:0x100]=np.arange(224,dtype=np.uint8)
    before=n.memory[0x20:0x100].copy()
    n.memory[0x61f]=0x65 if native_engine else 5
    for _ in range(1600):
        call('audio_vbi')
        assert n.lib.at_bank()==5
    np.testing.assert_array_equal(n.memory[0x20:0x100],before)
    assert n.memory[0x622]==0
