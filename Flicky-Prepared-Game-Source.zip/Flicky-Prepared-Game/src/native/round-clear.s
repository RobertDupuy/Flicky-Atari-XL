; Dedicated static portrait. No gameplay fonts, sprites or update work survive
; on this screen; game_round_load rebuilds them before restoring the game NMI.
result_active=$07f0
result_row=$07f1
.export result_active,result_show,result_nmi,result_dl
.import __RESULT_LOAD__
.segment "BANK26"
result_show:
    lda #0
    sta $d40e
    sta $d400
    lda #1
    sta c_paused
    sta result_active
    lda #3
    sta u_mode
    ; Code executes from ordinary RAM even when audio maps upper cartridge ROM.
    lda #16
    sta l_bank
    lda #>__RESULT_LOAD__
    sta n_src+1
    lda #$40
    sta n_dst+1
    ldx #8
    jsr result_copy_pages
    lda #17
    sta l_bank
    lda #$a0
    sta n_src+1
    lda #$20
    sta n_dst+1
    ldx #28
    jsr result_copy_pages
    lda #18
    sta l_bank
    lda #$a0
    sta n_src+1
    lda #$60
    sta n_dst+1
    ldx #5
    jsr result_copy_pages
    lda #$a5
    sta n_src+1
    lda #$0b
    sta n_dst+1
    ldx #5
    jsr result_copy_pages
    lda u_time_bonus
    and #15
    ora #'0'
    sta $6000+26*40+16
    lda u_time_bonus
    .repeat 4
        lsr a
    .endrepeat
    ora #'0'
    sta $6000+26*40+15
    ; Fixed player/missile colors supply the navy edge, blush and orange beak.
    ldx #3
@players:
    lda result_player_x,x
    sta $d000,x
    lda result_missile_x,x
    sta $d004,x
    lda result_player_size,x
    sta $d008,x
    dex
    bpl @players
    lda #0
    sta $d00c
    sta $d01a
    sta $d404
.if PAL_MULTI_PROP
    lda #$84
.else
    lda #$94
.endif
    sta $d012
    lda #$4a
    sta $d013
    lda #$4c
    sta $d015
    lda $d014
    and #$0e
    beq @pal
    lda #$2e
    ldx #$38
    bne @warm
@pal:
    lda #$ee
    ldx #$18
@warm:
    sta $d019
    stx $d014
    lda #$0e
    sta $d016
    ; White and light-blue playfield details cover the overlays; blue/gold
    ; playfield pixels are behind them. Each mask stays within the silhouette.
    lda #8
    sta $d01b
    sta $d407
    lda #3
    sta $d01d
    lda #<result_nmi
    sta $fffa
    lda #>result_nmi
    sta $fffb
    jsr result_frame
    lda c_produced
    sta c_consumed
    lda c_produced+1
    sta c_consumed+1
    lda #0
    sta c_paused
    sta r_pending
    lda #$3e
    sta $d400
    lda #$c0
    sta $d40e
    rts

result_copy_pages:
    stx n_remaining
    lda #0
    sta n_src
    sta n_dst
    lda #128
    sta n_token
@half:
    jsr sic_read_block
    lda n_src
    eor #128
    sta n_src
    sta n_dst
    bne @half
    inc n_src+1
    inc n_dst+1
    dec n_remaining
    bne @half
    rts

.segment "RESULT"
result_begin:
result_nmi:
    sta $1b
    bit $d40f
    bmi result_dli
    lda $061f
    sta $1c
    lda $d500
    sta $1a
    ora #$40
    sta $061f
    sta $d500
    lda $1b
    pha
    txa
    pha
    tya
    pha
    cld
    inc r_vbis
    inc r_host_frames
    bne :+
    inc r_host_frames+1
:   jsr result_frame
    ; Input, exact logical clock and uninterrupted audio use the normal tail.
    jmp display_read_input
result_dli:
    jmp result_dli_1
result_frame:
    lda #<result_dl
    sta $d402
    lda #>result_dl
    sta $d403
    lda #$20
    sta $d409
    lda #$0e
    sta $d017
    lda #0
    sta $d018
    lda #<result_dli_1
    sta result_dli+1
    lda #>result_dli_1
    sta result_dli+2
    rts
result_dl:
    .byte $70,$70
    .repeat 28,I
        .if I<4 .or I>=24
            .byte $42 | ((I<27)*$80)
        .else
            .byte $c4
        .endif
        .word $6000+I*40
    .endrepeat
    .byte $41
    .word result_dl
.include "round-clear-data.s"
.segment "RESULT"
    .res $800-(*-result_begin),0
