"""Pre-resolve both column addresses, masks, banks and empty-cell flags."""
import json
from pathlib import Path

def build(out:Path,strips):
    d=json.loads((out/'chick-assets.json').read_text());records=[]
    for image in d['images']:
        raw=(out/f'chick-image-{image:03d}.bin').read_bytes();h,w=raw[:2]
        rows=[round(y*(h-1)/9)for y in range(10)]
        label,_=strips.put([raw[4+2*(row*w+cx)]if cx<w else 0 for row in rows for cx in range(2)],False)
        records.append(strips.poses[label])
    lines=[]
    fields=[('lo','s_data',0,False),('hi','s_data+1',0,True),('bank','s_bank',0,None),
            ('masklo','s_left_mask',22,False),('maskhi','s_left_mask+1',22,True),
            ('rightlo','s_right',0,False),('righthi','s_right+1',0,True),('rightbank','s_right_bank',0,None),
            ('rightmasklo','s_right_mask',22,False),('rightmaskhi','s_right_mask+1',22,True),('flags','s_occupied',0,None)]
    for phase in range(4):
        bank=4 if phase<2 else 5;lines += [f'.segment "BANK{bank}"']
        for name,dest,offset,high in fields:
            vals=[]
            for refs,flags in records:
                col,cbank=refs[int(name.startswith('right'))]
                vals.append(str(flags[phase])if name=='flags' else str(cbank)if high is None else
                            ('>'if high else '<')+f'({col}+{6-phase*2+offset})')
            lines += [f'fc_{name}_{phase}:','.byte '+','.join(vals)]
        lines += ['.segment "FIXED"',f'fast_chick_load_{phase}:',f'    lda #{bank}','    NATIVE_BANK']
        for name,dest,_,_ in fields:lines += [f'    lda fc_{name}_{phase},x',f'    sta {dest}']
        lines += ['    jmp stamp_draw_ready']
    lines += ['.segment "FIXED"','stamp_font_hi:']
    for back in range(2):lines+=['.byte '+','.join(str(0x22+back*0x20+(r//4)*4)for r in range(28))]
    lines += ['stamp_actor_offset:','.byte '+','.join(str((a if a<8 else max(0,a-12))*32)for a in range(18)),
              'stamp_actor_code:','.byte '+','.join(str(0xc0+a*4 if a<8 else 0xe0+max(0,a-12)*4)for a in range(18)),
              'stamp_actor_page:','.byte '+','.join(str(int(a>=12))for a in range(18))]
    (out/'fast-chick-data.s').write_text('\n'.join(lines)+'\n')
