"""Prepared idle character animations must equal the tested full compositor."""
import json
import sys
import subprocess
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from native_engine import Engine
from build import ROOT,BUILD


def pixels(native, buffer):
    screen=native.ram[0x6000+4096*buffer:0x6000+4096*buffer+2688].reshape(28,96)[:,:32]
    pointers=0x2000+buffer*8192+(np.arange(28)//4)[:,None]*1024+(screen.astype(np.int32)&127)*8
    glyphs=native.ram[pointers[:,:,None]+np.arange(8)]
    values=(glyphs[:,:,:,None]>>np.array([6,4,2,0]))&3
    values=np.where((values==3)&((screen[:,:,None,None]&128)!=0),4,values)
    return values.transpose(0,2,1,3).reshape(224,128).astype(np.uint8)


def test_idle_character_background_matches_full_renderer():
    subprocess.run([sys.executable,str(ROOT/'tools/build_native.py')],check=True)
    n=Engine();measurements=[];active=0
    for stage in range(56):
        n.call('native_reset');n.set('n_round',stage)
        n.call('level_load');n.call('chicks_reset');n.call('display_init');n.call('idle_reset')
        positions=[(n.get('n_xlo',a)+256*n.get('n_xhi',a),n.get('n_ylo',a),n.get('n_frame',a),n.get('n_flags',a)) for a in range(8)]
        baseline=n.ram[0x1600:0x1980].reshape(28,32).copy()
        for frame in range(260 if stage in (0,55) else 160):
            buffer=frame&1;n.set('r_back',buffer)
            world=(504+frame*7)&65535
            if frame>=128:world=(65535-(frame-128)*3)&65535
            n.set('n_world',world);n.set('n_world',world>>8,1)
            for actor,(x,y,variant,flags) in enumerate(positions):
                n.set('n_xlo',x,actor);n.set('n_xhi',x>>8,actor)
                n.set('n_ylo',y,actor);n.set('n_frame',variant,actor)
                n.set('n_flags',(flags&254)|((frame//8+actor)&1),actor)
                n.set('n_animation',5+((frame//4+actor)&1),actor)
                n.set('n_draw_yoffset',((frame//2+actor)%7)-3,actor)
                n.set('n_chick_state',0,actor)
                if 30<=frame%64<42 and actor==2:
                    n.set('n_chick_state',2,actor);n.set('n_xlo',x+12,actor)
                    n.set('n_animation',1,actor)
                if frame%39 in (20,21,22) and actor==5:n.set('n_flags',0,actor)
            if 100<=frame<120:
                xx,yy,_,_=positions[7]
                n.set('n_xlo',xx,0);n.set('n_xhi',xx>>8,0);n.set('n_ylo',yy,0)
                n.set('n_flags',0xb0,0);n.set('n_chick_state',1,0)
                n.set('n_animation',1,0);n.set('n_frame',0,0)
            # Cross a bird's character cells with a foreground player.
            x,y,_,_=positions[(frame//16)%8]
            screen=(x+world+(frame%16)-8)&511
            n.set('n_xlo',screen,8);n.set('n_xhi',screen>>8,8);n.set('n_ylo',y,8)
            n.set('n_animation',0,8);n.set('n_pose',0,8);n.set('n_frame',frame&1,8)
            n.set('n_flags',0x80|((frame//8)&1),8)
            before=n.lib.at_cycles()
            n.call('sprites_begin');n.call('idle_update');n.call('sprite_draw_chicks');n.call('sprite_draw_player')
            elapsed=n.lib.at_cycles()-before
            measurements.append(elapsed);active+=int(n.get('i_active')).bit_count()
            assert n.get('r_fault')==0,(stage,frame,'fast')
            actual=pixels(n,buffer);saved=n.ram.copy()
            # Reconstruct this buffer with the independently pixel-tested full
            # compositor, then preserve the fast path's history for the next use.
            screenbase=0x6000+buffer*4096
            n.ram[screenbase:screenbase+2688]=np.tile(baseline,(1,3)).reshape(-1)
            n.ram[0x6a80+buffer*4096:0x6fc0+buffer*4096]=0
            n.ram[0x660+buffer*2:0x662+buffer*2]=0
            n.set('i_active',0);n.call('sprites_begin');n.call('sprite_draw_chicks');n.call('sprite_draw_player')
            assert n.get('r_fault')==0,(stage,frame,'full')
            expected=pixels(n,buffer)
            np.testing.assert_array_equal(actual,expected,err_msg=f'stage {stage} frame {frame}')
            n.ram[:]=saved
    assert active>50000,active
    (BUILD/'native/idle-character-cycles.json').write_text(json.dumps({
        'frames':len(measurements),'fast_actor_draws':active,
        'median_cycles':int(np.median(measurements)), 'maximum_cycles':max(measurements),
        'scope':'camera seams, idle animation, disappear/reappear, movement fallback, chick priority and foreground overlap; no DMA',
    },indent=2)+'\n')

@pytest.mark.parametrize('lines,pal_register',[(262,15),(312,1)])
def test_pending_display_allows_logic_and_preserves_front_buffer(lines,pal_register):
    n=Engine()
    for name in ('native_reset','level_load','chicks_reset'):n.call(name)
    n.ram[0xd014]=pal_register;n.call('display_init');n.call('idle_reset')
    for iteration in range(4):
        front=n.get('r_front');back=front^1
        n.set('r_back',back)
        front_font=n.ram[0x2000+8192*front:0x3c00+8192*front].copy()
        front_screen=n.ram[0x6000+4096*front:0x6a80+4096*front].copy()
        n.call('native_render_submit')
        assert n.get('r_pending')==1
        n.set('r_input',191);n.call('clock_vbi')
        assert n.call('clock_take_tick')==1
        n.call('game_update')
        assert n.get('r_pending')==1
        np.testing.assert_array_equal(n.ram[0x2000+8192*front:0x3c00+8192*front],front_font)
        np.testing.assert_array_equal(n.ram[0x6000+4096*front:0x6a80+4096*front],front_screen)
        n.lib.at_video_timing(lines)
        before=n.lib.at_cycles();n.call('native_acquire_back')
        assert n.lib.at_cycles()-before<lines*114+1000
        assert n.get('r_pending')==0
        assert n.get('r_front')==back
        assert n.get('r_back')==front
        n.lib.at_video_timing(0)
