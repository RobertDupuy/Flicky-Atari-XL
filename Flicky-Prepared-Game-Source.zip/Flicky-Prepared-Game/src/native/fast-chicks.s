; Fixed glyph destinations. All phases, scaling and color selection are baked.
; Four characters per bird, two-scanline vertical steps. The only overlap
; policy is character priority: later birds own a shared character cell.
s_data=$da
s_cell=$dc
s_index=$de
s_code=$df
s_font_index=$e0
s_bank=$e1
.segment "FIXED"
.export fast_draw_chicks
fast_draw_chicks:
    lda #0
    sta n_actor_cursor
@actor:
    ldx n_actor_cursor
    lda n_flags,x
    bpl @next
    lda i_active
    and pickup_bits,x
    bne @next
    jsr fast_draw_chick
@next:
    inc n_actor_cursor
    lda n_actor_cursor
    cmp #8
    bcc @actor
    rts
fast_draw_chick:
    stx p_actor
    lda n_ylo,x
    clc
    adc n_draw_yoffset,x
    sec
    sbc #4
    and #$fe
    sta p_y
    cmp #216
    bcc :+
    rts
:   ldy n_animation,x
    sec
    lda n_xlo,x
    sbc native_chick_radius,y
    sta p_left
    lda n_xhi,x
    sbc #0
    and #1
    sta p_left+1
    lda p_left
    lsr a
    lsr a
    and #3
    sta s_index
    tya
    .repeat 4
        asl a
    .endrepeat
    ora s_index
    sta s_index
    lda n_frame,x
    and #1
    asl a
    asl a
    asl a
    ora s_index
    sta s_index
    lda n_flags,x
    and #1
    asl a
    asl a
    ora s_index
    tax
    lda #5
    NATIVE_BANK
    lda p_y
    and #6
    beq @phase0
    cmp #2
    beq @phase1
    cmp #4
    beq @phase2
    lda fast_chick_lo3,x
    sta s_data
    lda fast_chick_hi3,x
    sta s_data+1
    lda fast_chick_bank3,x
    jmp @data
@phase2:
    lda fast_chick_lo2,x
    sta s_data
    lda fast_chick_hi2,x
    sta s_data+1
    lda fast_chick_bank2,x
    jmp @data
@phase1:
    lda fast_chick_lo1,x
    sta s_data
    lda fast_chick_hi1,x
    sta s_data+1
    lda fast_chick_bank1,x
    jmp @data
@phase0:
    lda fast_chick_lo0,x
    sta s_data
    lda fast_chick_hi0,x
    sta s_data+1
    lda fast_chick_bank0,x
@data:
    sta s_bank
    NATIVE_BANK
stamp_draw:
    lda p_y
    lsr a
    lsr a
    lsr a
    sta r_row
    lda p_left+1
    lsr a
    lda p_left
    ror a
    lsr a
    lsr a
    lsr a
    sta p_index
    lda #0
    sta s_cell
    lda r_back
    beq :+
    lda #28
:   clc
    adc r_row
    sta s_font_index
    ldx p_actor
    lda stamp_actor_offset,x
    sta r_font
    lda stamp_actor_code,x
    sta s_code
    lda stamp_actor_page,x
    sta p_fontbase
@row:
    ldx s_font_index
    lda stamp_font_hi,x
    clc
    adc p_fontbase
    sta r_font+1
    ; Two adjacent glyphs are a single prepared sixteen-byte copy.
    ldy #0
    .repeat 16,I
        lda (s_data),y
        sta (r_font),y
        .if I<15
            iny
        .endif
    .endrepeat
    jsr stamp_row_write
    lda s_cell
    bne @done
    inc s_cell
    lda r_font
    ora #16
    sta r_font
    lda s_data
    ora #16
    sta s_data
    lda s_bank
    NATIVE_BANK
    inc r_row
    inc s_font_index
    jmp @row
@done:
    rts
stamp_row_write:
    ldy r_row
    lda stamp_row_lo,y
    sta @call+1
    lda stamp_row_hi,y
    sta @call+2
    lda r_back
    beq :+
    lda #31
    bne @bank
:   lda #9
@bank:
    NATIVE_BANK
    ldx p_index
@call:
    jsr $8000
    rts
