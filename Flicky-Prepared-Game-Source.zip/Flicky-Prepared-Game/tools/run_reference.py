#!/usr/bin/env python3
from pathlib import Path
import argparse,ctypes as C,json,subprocess
import numpy as np
from PIL import Image
from build import ROOT,BUILD

class Reference:
    def __init__(self):
        subprocess.run(['gcc','-std=c11','-O2','-fPIC','-shared',str(ROOT/'tools/system1_ref.c'),'-o',str(BUILD/'system1_ref.so')],check=True)
        self.lib=C.CDLL(str(BUILD/'system1_ref.so'))
        self.lib.fm_init.argtypes=[C.c_char_p]
        assert self.lib.fm_init(str(ROOT/'private-roms').encode())
        for name,typ in [('ram',C.c_uint8),('picture',C.c_uint8),('profile',C.c_uint32),('sound_profile',C.c_uint32),('sound',C.c_uint16),('tile_pixels',C.c_uint8)]:
            getattr(self.lib,'fm_'+name).restype=C.POINTER(typ)
        self.ram=np.ctypeslib.as_array(self.lib.fm_ram(),shape=(65536,))
        self.picture=np.ctypeslib.as_array(self.lib.fm_picture(),shape=(224,512))
        self.profile=np.ctypeslib.as_array(self.lib.fm_profile(),shape=(65536,))
        self.sprofile=np.ctypeslib.as_array(self.lib.fm_sound_profile(),shape=(65536,))
        self.sound=np.ctypeslib.as_array(self.lib.fm_sound(),shape=(16,))
        self.tiles=np.ctypeslib.as_array(self.lib.fm_tile_pixels(),shape=(2048,8,8))
        self.palette=np.array([[(v&7)*255//7,((v>>3)&7)*255//7,((v>>6)&3)*255//3] for v in range(256)],dtype=np.uint8)
    def frame(self,p1=255,system=255): return self.lib.fm_frame(p1,system)
    def save(self,path):
        Image.fromarray(self.palette[self.picture[:,::2]]).resize((512,448),Image.Resampling.NEAREST).save(path)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--frames',type=int,default=1200)
    p.add_argument('--play',action='store_true')
    p.add_argument('--trace',action='store_true')
    a=p.parse_args()
    out=BUILD/'reference';out.mkdir(exist_ok=True)
    r=Reference()
    if a.trace:r.lib.fm_trace(str(out/'trace.txt').encode())
    for f in range(a.frames):
        system=0xfe if a.play and 180<=f<190 else 0xef if a.play and 210<=f<220 else 255
        p1=255
        if a.play and f>=300:p1 &= ~(0x40 if f%240<120 else 0x80);p1 &= ~4 if f%90<40 else 255
        pc=r.frame(p1,system)
        if f in [0,10,30,60,120,180,240,300,360,480,600,900,a.frames-1]:
            r.save(out/f'frame-{f:05d}.png')
            (out/f'ram-{f:05d}.bin').write_bytes(r.ram.tobytes())
            print(f'frame {f} pc {pc:04X} video {r.lib.fm_mode():02X}',flush=True)
    r.lib.fm_trace(None)
    (out/'profile.json').write_text(json.dumps({f'{i:04X}':int(v) for i,v in enumerate(r.profile) if v},indent=2))
    (out/'sound-profile.json').write_text(json.dumps({f'{i:04X}':int(v) for i,v in enumerate(r.sprofile) if v},indent=2))
    print('Executed addresses',np.count_nonzero(r.profile),'Top',sorted(enumerate(r.profile),key=lambda x:-int(x[1]))[:20])

if __name__=='__main__': main()
