"""Compile converted sound events into immediate 6502 register-store programs."""
import json
from build import BUILD

def build(out):
    tracks=json.loads((BUILD/'audio/manifest.json').read_text());records=[];loops={};starts={}
    for track in tracks:
        cmd=track['command'];data=(BUILD/f'audio/{cmd:02x}.bin').read_bytes();pos=0;items=[]
        while data[pos]:
            offset=pos;duration,mask=data[pos:pos+2];pos+=2;values=[]
            for reg in range(8):
                if mask>>reg&1:values.append((reg,data[pos]));pos+=1
            items.append({'label':f'pa_{cmd:02x}_{len(items)}','offset':offset,'duration':duration,'values':values})
        end={'label':f'pa_end_{cmd:02x}','duration':0,'values':[]}
        for j,item in enumerate(items):
            if j+1<len(items):item['next']=items[j+1]['label']
            elif track['loop_offset'] is not None:item['next']=next(i['label']for i in items if i['offset']==track['loop_offset'])
            else:item['next']=end['label']
        starts[cmd]=items[0]['label'];records+=items
        if track['loop_offset'] is None:records.append(end)
    regions=[2,3,4,5,10,11,12]+list(range(14,27));region=0;used=0;bankmap={}
    for r in records:
        # Each immediate LDA + absolute,X STA occupies five bytes.
        r['size']=5*(4+len(r['values']))+1 if r['duration'] else 6
        if used+r['size']>8192:region+=1;used=0
        bankmap[r['label']]=regions[region];used+=r['size']
    lines=[]
    for r in records:
        lines += [f'.segment "UPPER{bankmap[r["label"]]}"',r['label']+':']
        if not r['duration']:lines+=['    lda #0','    sta a_slots,x','    rts'];continue
        lines += [f'    lda #{r["duration"]}','    sta a_slots+7,x']
        for reg,value in r['values']:lines += [f'    lda #{value}',f'    sta a_slots+{8+reg},x']
        nxt=r['next'];lines += [f'    lda #{bankmap[nxt]}','    sta a_slots+1,x',f'    lda #<{nxt}','    sta a_slots+2,x',f'    lda #>{nxt}','    sta a_slots+3,x','    rts']
    ordered=sorted(tracks,key=lambda t:t['command']);lines += ['.segment "FIXED"']
    for name,values in [('audio_banks',[str(bankmap[starts[t['command']]])for t in ordered]),('audio_lo',['<'+starts[t['command']]for t in ordered]),('audio_hi',['>'+starts[t['command']]for t in ordered]),('audio_flags',[str(int(t['replace']or t['loop_frame']is not None))for t in ordered])]:
        lines += [name+':','.byte '+','.join(values)]
    (out/'audio-data.s').write_text('\n'.join(lines)+'\n')
    (out/'prepared-audio.json').write_text(json.dumps({'commands':len(tracks),'event_programs':len(records),'rom_bytes':sum(r['size']for r in records),'upper_banks':region+1},indent=2)+'\n')
