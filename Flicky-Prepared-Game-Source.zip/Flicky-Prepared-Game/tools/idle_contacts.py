"""Prove which spawn-position idle animations cannot touch solid terrain.

The union includes both variants, both facings, both idle poses, every bob
height, and an extra horizontal pixel for the source mixer's signed seam.
A zero result is a conservative proof; all other actors use pixel collision.
"""
import json


def build_idle_contacts(output, build, rom, maps):
    sprites = json.loads((output / 'chick-assets.json').read_text())
    index = (build / 'tile-index.bin').read_bytes()
    glyphs = (build / 'tile-glyphs.bin').read_bytes()
    safe = []
    for stage, words in enumerate(maps):
        terrain = [bytearray(256) for _ in range(224)]
        for row in range(28):
            for col in range(32):
                word = int.from_bytes(words[(row * 32 + col) * 2:(row * 32 + col) * 2 + 2], 'little')
                if not word & 0x1000:
                    continue
                code = word & 2047
                offset = ((index[4096 + code] & 127) - 9) * 8192 + index[code] + (index[2048 + code] << 8) - 0x8000
                for y, mask in enumerate(glyphs[offset + 8:offset + 16]):
                    for x in range(8):
                        terrain[row * 8 + y][col * 8 + x] = bool(mask & (128 >> x))
        layout = rom[0x2fca + stage]
        bits = 0
        for actor in range(8):
            raw_x, center = rom[0x0df3 + layout * 16 + actor * 2:0x0df5 + layout * 16 + actor * 2]
            world_x = raw_x * 2 + (raw_x >> 7)
            touched = False
            for pose in (5, 6):
                for variant in range(2):
                    for facing in range(2):
                        record_index = pose * 16 + variant * 8 + facing * 4
                        record = sprites['records'][record_index]
                        mask_id = sprites['masks'][record_index]
                        mask = (output / f'chick-maskshift-{mask_id:03}-0.bin').read_bytes()
                        left = (world_x - 2 * (record['stride'] - 1)) // 2
                        for bob in range(-3, 4):
                            top = center + bob - record['height'] // 2 + 1
                            for y in range(record['height']):
                                if not 0 <= top + y < 224:
                                    continue
                                value = int.from_bytes(mask[y * 4:y * 4 + 4], 'big')
                                for x in range(24):
                                    if value & (1 << (31 - x)):
                                        if terrain[top + y][(left + x) & 255] or terrain[top + y][(left + x + 1) & 255]:
                                            touched = True
            if not touched:
                bits |= 1 << actor
        safe.append(bits)
    (output / 'idle-contacts.s').write_text('.segment "BANK4"\nnative_idle_clear:\n.byte ' + ','.join(map(str, safe)) + '\n')
    (output / 'idle-contacts.json').write_text(json.dumps({'safe_masks': safe, 'safe_spawn_positions': sum(v.bit_count() for v in safe)}, indent=2) + '\n')
