.include "compat.s"
.include "compat_alu.s"
.segment "FIXED"
.export start,host_frame,host_stop
start:
    sei
    cld
    ldx #$ff
    txs
    lda #0
    sta $d40e
    sta $d400
    sta $d20e
    lda #$fe
    sta $d301
    jsr compat_reset
.ifdef COMPACT
    jsr compact_load
    jsr host_init
.endif
    lda #0
    tax
    jmp dispatch_ax
host_frame:
.ifdef COMPACT
    jsr host_present
    jmp guest_resume
.else
    jmp host_stop
.endif
host_stop:
    jmp host_stop
cart_init:
    rts
.ifdef COMPACT
compact_load:
    lda #10
    SELECT_BANK
    lda #0
    sta z_host
    sta z_addr
    lda #$90
    sta z_host+1
    lda #$60
    sta z_addr+1
    ldy #0
@byte:
    lda (z_host),y
    sta (z_addr),y
    iny
    bne @byte
    inc z_host+1
    inc z_addr+1
    lda z_addr+1
    cmp #$70
    bne @byte
    rts
.endif
.ifdef COMPACT
.include "interpreter.s"
.include "renderer.s"
.include "background_cache.s"
.include "host.s"
.include "common/audio.s"
.ifdef HYBRID
.include "hot_dispatch.s"
.include "hot.s"
.include "audio-data.s"
.endif
.else
.include "aot.s"
.include "dispatch.s"
.endif
.segment "VECTORS"
.word start
.byte 0,4
.word cart_init
