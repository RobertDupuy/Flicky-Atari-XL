; SG-1000 study: $1C1B samples a character at a chosen actor offset;
; $10EE collects chicks by that character class. No pixel ownership scan.
; This Atari version uses world-space boxes and the existing tile map instead.
f_actor=$07e0
f_enemy=$07e1
f_x=$07e2
f_y=$07e4
f_dx=$07e5
.segment "FIXED"
.export quick_player_terrain
quick_player_terrain:
    ldx n_animation+PLAYER
    lda native_player_height,x
    sta p_height
    lsr a
    sta n_step
    lda n_ylo+PLAYER
    sec
    sbc n_step
    clc
    adc #1
    sta p_y
    lda n_pose+PLAYER
    cmp #3
    bne :+
    inc p_y
:   lda native_player_radius,x
    sta p_sprite_width
    sec
    lda n_xlo+PLAYER
    sbc n_world
    sta p_left
    lda n_xhi+PLAYER
    sbc n_world+1
    sta p_left+1
    sec
    lda p_left
    sbc p_sprite_width
    sta p_left
    lda p_left+1
    sbc #0
    and #1
    sta p_left+1
    jsr prepared_rect_query
    sta n_terrain_contact
    rts
.export quick_contacts
quick_contacts:
    lda #6
    NATIVE_BANK
    jmp quick_contacts_bank
.segment "BANK6"
quick_contacts_bank:
    ; Following birds need only a floor/air pose hint. Free birds already
    ; sample tiles in their movement routine.
    lda #0
    sta n_pickup
    sta n_player_enemy
    lda n_train
    cmp #8
    bne @partial_flock
    lda n_flags+PLAYER
    and #4
    beq :+
    lda #0
    beq @full_hint
:   lda n_grounded
@full_hint:
    .repeat 8,I
        sta n_chick_contact+I
    .endrepeat
    jmp @enemies
@partial_flock:
    lda #0
    ldx #7
@chick:
    ; Chick motion consumes this latch at 30 Hz; keep hits between updates.
    sta n_chick_contact,x
    pha
    lda n_chick_state,x
    and #3
    bne :+
    ; Stagger stationary poses; moving birds keep their full animation.
    ; Keep its feet fixed so an idle bob never uploads six new characters.
    lda #0
    sta n_draw_yoffset,x
    txa
    asl a
    asl a
    asl a
    asl a
    clc
    adc n_game_ticks
    and #64
    beq @idle_first
    lda #6
    bne @idle_pose
@idle_first:
    lda #5
@idle_pose:
    sta n_animation,x
    txa
    and #1
    sta n_step
    lda n_flags,x
    and #$fe
    ora n_step
    sta n_flags,x
:   pla
    dex
    bpl @chick
    lda n_flags+PLAYER
    and #4
    bne @enemies
    sec
    lda n_xlo+PLAYER
    sbc n_world
    sta f_x
    lda n_xhi+PLAYER
    sbc n_world+1
    and #1
    sta f_x+1
    sec
    lda f_x
    sbc #20
    sta f_x
    lda f_x+1
    sbc #0
    and #1
    sta f_x+1
    sec
    lda n_ylo+PLAYER
    sbc #11
    sta f_y
    ldx #7
@pickup:
    lda n_flags,x
    bpl @next
    lda n_chick_state,x
    and #1
    bne @pose
    jsr fast_near
    bcc @next
    lda n_pickup
    ora fast_bits,x
    sta n_pickup
@pose:
    lda n_grounded
    sta n_chick_contact,x
@next:
    dex
    bpl @pickup
@enemies:
    lda #9
    sta f_enemy
@enemy:
    ldx f_enemy
    lda n_flags,x
    and #$a0
    cmp #$a0
    bne @next_enemy
    lda n_chick_state,x
    and #$10
    bne @next_enemy
    lda n_pause,x
    bne @next_enemy
    sec
    lda n_xlo,x
    sbc #20
    sta f_x
    lda n_xhi,x
    sbc #0
    and #1
    sta f_x+1
    sec
    lda n_ylo,x
    sbc #11
    sta f_y
    ldx #7
@target:
    lda n_flags,x
    bpl @next_target
    lda n_chick_state,x
    and #1
    beq @next_target
    jsr fast_near
    bcc @next_target
    lda #1
    sta n_enemy_contact,x
@next_target:
    dex
    bpl @target
    ; Player has screen coordinates; convert the enemy for the same box.
    clc
    lda f_x
    adc n_world
    sta f_x
    lda f_x+1
    adc n_world+1
    and #1
    sta f_x+1
    ldx #PLAYER
    jsr fast_near
    bcc @next_enemy
    ldx f_enemy
    lda n_player_enemy
    ora fast_bits-9,x
    sta n_player_enemy
@next_enemy:
    inc f_enemy
    lda f_enemy
    cmp #11
    bcs :+
    jmp @enemy
:   rts

; C=1 when centres are within 20 source X clocks and 11 scanlines.
; The 512-clock world wraps; the high subtraction bit is normalized.
fast_near:
    sec
    lda n_ylo,x
    sbc f_y
    cmp #23
    bcs @no
    sec
    lda n_xlo,x
    sbc f_x
    sta f_dx
    lda n_xhi,x
    sbc f_x+1
    and #1
    bne @no
    lda f_dx
    cmp #41
    bcs @no
    sec
    rts
@no:
    clc
    rts
fast_bits: .byte 1,2,4,8,16,32,64,128
