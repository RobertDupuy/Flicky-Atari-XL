; Chick state machines and delayed player trail, implemented directly in 6502.
; World-coordinate storage replaces camera translation of every actor.
.segment "FIXED"
.export chicks_reset,chicks_update,chick_update,chick_sample_terrain,train_record
.export train_check_door
.export popup_update,n_popup_value
n_popup_value=n_chain
.export n_train,n_rescued,n_pickup,n_delivered,n_score_event,n_round_complete,n_score
.export n_chick_state,n_chain,n_bob,n_cycle,n_pause,n_chick_contact,n_enemy_contact,n_draw_yoffset
.export n_history_yindex,n_history_xindex,n_history_y,n_history_xlo,n_history_xhi,n_trail_xlo,n_trail_xhi
chicks_reset:
    lda #4
    NATIVE_BANK
    jmp chicks_reset_bank
chicks_update:
    lda #4
    NATIVE_BANK
    ldx #0
@actor:
    lda n_flags,x
    bpl @next
    jsr chick_update_bank
@next:
    inx
    cpx #8
    bne @actor
    rts
chick_update:
    lda #4
    NATIVE_BANK
    jmp chick_update_bank
chick_sample_terrain:
    lda #4
    NATIVE_BANK
    jmp chick_sample_bank
train_record:
    lda #0
    sta $1d93
    beq train_record_common
train_record_tick:
    lda #1
    sta $1d93
train_record_common:
    lda #4
    NATIVE_BANK
    jmp train_record_bank
train_check_door:
    lda n_train
    beq @done
    lda n_grounded
    beq @done
    lda n_exiting
    bne @done
    lda #4
    NATIVE_BANK
    jmp train_check_door_bank
@done:
    rts
popup_update:
    lda #4
    NATIVE_BANK
    jmp popup_update_bank

.segment "BANK4"
chicks_reset_bank:
    lda n_round
@round:
    cmp #48
    bcc @idle_table
    sec
    sbc #48
    bcs @round
@idle_table:
    tax
    lda native_idle_clear,x
    sta n_idle_clear
    lda #0
    ldx #0
@clear:
    sta $c700,x
    sta $1b00,x
    sta $1c00,x
    inx
    bne @clear
    sta n_train
    sta n_pickup
    sta n_delivered
    sta n_score_event
    sta n_round_complete
    sta n_rescued
    lda #39
    sta n_history_yindex
    sta n_history_xindex
    lda n_round
    cmp #2
    bcs :+
    lda #$11
    sta n_rescued
:   lda n_layout
    asl a
    asl a
    asl a
    asl a
    sta n_ptr
    lda n_layout
    lsr a
    lsr a
    lsr a
    lsr a
    sta n_ptr+1
    clc
    lda n_ptr
    adc #<native_chick_positions
    sta n_ptr
    lda n_ptr+1
    adc #>native_chick_positions
    sta n_ptr+1
    ldx #0
@actor:
    txa
    asl a
    tay
    lda (n_ptr),y
    asl a
    bcc :+
    ora #1
:   
    sta n_xlo,x
    sta n_idle_xlo,x
    lda #0
    rol a
    sta n_xhi,x
    sta n_idle_xhi,x
    iny
    lda (n_ptr),y
    sta n_ylo,x
    sta n_idle_y,x
    lda #0
    sta n_yhi,x
    sta n_vx,x
    sta n_fx,x
    sta n_vy,x
    sta n_fy,x
    sta n_timer,x
    sta n_frame,x
    lda n_rescued
    and chick_bits,x
    cmp #1
    lda #$30
    bcs :+
    ora #$80
:   sta n_flags,x
    txa
    asl a
    asl a
    asl a
    sta n_bob,x
    jsr chick_target_left
    lda n_round
    and #$fc
    lsr a
    cmp #4
    bcc :+
    lda #4
:   eor #$ff
    clc
    adc #8
    sta c_temp
    txa
    cmp c_temp
    beq :+
    bcc :+
    inc n_frame,x
:   lda #5
    sta n_animation,x
    inx
    cpx #8
    bne @actor
    rts

; X remains the actor on return. Contact latches are from the previous update.
chick_update_bank:
    stx c_actor
    lda #0
    sta n_draw_yoffset,x
    inc n_timer,x
    lda n_timer,x
    and #3
    bne :+
    lda n_cycle,x
    clc
    adc #1
    and #3
    sta n_cycle,x
:   lda n_chick_state,x
    and #1
    bne @following
    jmp chick_free
@following:
    lda n_flags+PLAYER
    and #4
    bne @detach
    lda n_exiting
    bne @trail
    lda n_enemy_contact,x
    beq @trail
    lda #0
    sta n_enemy_contact,x
@detach:
    lda n_chick_state,x
    and #$fe
    ora #2
    sta n_chick_state,x
    lda n_chain,x
    sta c_index
    cmp n_train
    beq :+
    bcs @trail
:   sta n_train
    ldy #7
@scatter:
    lda n_chick_state,y
    and #1
    beq @next
    lda n_chain,y
    cmp c_index
    bcc @next
    lda n_chick_state,y
    and #$fe
    ora #2
    sta n_chick_state,y
    lda #0
    sta n_vy,y
@next:
    dey
    bpl @scatter
@trail:
    lda n_chain,x
    asl a
    asl a
    clc
    adc n_chain,x
    clc
    adc n_history_yindex
    clc
    adc #1
    cmp #40
    bcc :+
    sbc #40
:   tay
    lda n_history_y,y
    sta n_ylo,x
    ldy n_chain,x
    lda n_trail_xlo,y
    sta c_screen
    sec
    sbc n_world
    sta n_xlo,x
    lda n_trail_xhi,y
    sta c_screen+1
    sbc n_world+1
    sta n_xhi,x
    lda c_screen+1
    and #1
    bne @face_left
    lda n_flags,x
    and #$fe
    sta n_flags,x
    jmp @pose
@face_left:
    lda c_screen
    beq @pose
    lda n_flags,x
    ora #1
    sta n_flags,x
@pose:
    lda n_chick_contact,x
    pha
    lda #0
    sta n_chick_contact,x
    pla
    beq @air
    lda #0
    beq @animation
@air:
    lda c_screen+1
    and #1
    bne :+
    lda c_screen
    cmp #$f4
    bcs @idle
    bcc @air_pose
:   lda c_screen
    cmp #12
    bcc @idle
@air_pose:
    lda #4
    bne @animation
@idle:
    lda #8
@animation:
    jsr chick_animate
    lda #3
    sta n_draw_yoffset,x
    lda n_flags,x
    and #4
    beq @return
    lda n_exiting
    beq @return
    lda n_chain,x
    cmp n_delivered
    bne @return
    lda n_ylo,x
    cmp n_ylo+PLAYER
    bne @return
    lda c_screen
    bne @return
    jmp chick_deliver
@return:
    rts

chick_free:
    ; Source actors normalize screen coordinates before free movement.
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    and #1
    sta c_screen+1
    sec
    lda c_screen
    sbc n_world
    sta n_xlo,x
    lda c_screen+1
    sbc n_world+1
    sta n_xhi,x
    lda #0
    sta n_enemy_contact,x
    lda n_exiting
    bne @movement
    lda n_flags+PLAYER
    and #4
    bne @movement
    lda n_pickup
    and chick_bits,x
    beq @movement
    lda chick_bits,x
    eor #$ff
    and n_pickup
    sta n_pickup
    lda #$8b
    jsr chick_sound
    lda n_train
    sta n_chain,x
    inc n_train
    lda n_chick_state,x
    and #$fb
    ora #1
    sta n_chick_state,x
    and #2
    bne @return
    lda #1
    jmp chick_score
@movement:
    lda n_chick_state,x
    and #2
    beq chick_idle
    jmp chick_scattered
@return:
    rts

chick_idle:
    lda #0
    sta n_draw_yoffset,x
    lda #5
    sta n_animation,x
    rts
.ifdef LEGACY_IDLE_MOTION
    lda #8
    jsr chick_animate
    lda n_timer,x
    and #31
    bne :+
    lda n_flags,x
    eor #1
    sta n_flags,x
:   lda n_bob,x
    ldy #4
    cmp #$40
    bcc :+
    cmp #$c0
    bcs :+
    dey
:   sty c_temp
    clc
    adc c_temp
    sta n_bob,x
    asl a
    bcc :+
    ora #1
:   cmp #$80
    bcs @fold
    tay
    jmp @sine
@fold:
    eor #$ff
    clc
    adc #1
    bpl :+
    lda #127
:   tay
@sine:
    lda native_chick_sine,y
    ldy n_bob,x
    bpl :+
    eor #$ff
    clc
    adc #1
:   sta n_draw_yoffset,x
    rts

.endif
chick_scattered:
    jsr chick_sample_bank
    bne :+
    jmp @fall
:   
    cmp #9
    bne @walls
    lda n_ylo,x
    and #$f8
    sec
    sbc #7
    jmp @ground
@walls:
    and #1
    beq @right
    lda n_vx,x
    bpl @standing
    eor #$ff
    clc
    adc #1
    sta n_vx,x
    jsr chick_target_right
    jmp @start_pause
@right:
    lda c_mask
    and #8
    beq @standing
    lda n_vx,x
    bmi @standing
    eor #$ff
    clc
    adc #1
    sta n_vx,x
    jsr chick_target_left
    jmp @start_pause
@standing:
    lda n_chick_state,x
    and #4
    bne :+
    lda n_chick_state,x
    ora #4
    sta n_chick_state,x
    jsr chick_reverse
:   lda n_ylo,x
    and #$f8
    clc
    adc #2
@ground:
    sta n_ylo,x
    lda #0
    sta n_vy,x
    lda n_flags,x
    and #8
    beq :+
    lda n_frame,x
    and #1
    bne :+
    jsr chick_reverse
:   lda n_chick_state,x
    and #8
    bne @pause
    lda n_vx,x
    bne @move
@start_pause:
    lda n_chick_state,x
    ora #8
    sta n_chick_state,x
    lda #0
    sta n_pause,x
    sta n_timer,x
@pause:
    lda n_timer,x
    and #15
    bne @pause_pose
    inc n_pause,x
    lda n_pause,x
    cmp #2
    bne :+
    lda n_flags,x
    and #$fe
    sta n_flags,x
    lda n_target,x
    bpl :+
    inc n_flags,x
:   lda n_pause,x
    cmp #3
    bcc @pause_pose
    lda n_chick_state,x
    and #$f7
    sta n_chick_state,x
    jmp @move
@pause_pose:
    ldy n_pause,x
    lda chick_turn_pose,y
    sta n_animation,x
    rts
@move:
    lda n_flags,x
    and #8
    bne :+
    jsr motion_accelerate
:   jsr motion_integrate
    lda #0
    jmp chick_animate
@fall:
    lda n_timer,x
    bne :+
    lda #$8c
    jsr chick_sound
:   inc n_timer,x
    jsr motion_gravity
    jsr motion_integrate
    lda #4
    jmp chick_animate

chick_reverse:
    lda n_vx,x
    bmi chick_target_right
chick_target_left:
    txa
    asl a
    eor #$ff
    clc
    adc #$ed
    sta n_target,x
    lda #$ff
    bne chick_target_set
chick_target_right:
    txa
    asl a
    clc
    adc #20
    sta n_target,x
    lda #1
chick_target_set:
    sta n_acceleration,x
    lda n_flags,x
    and #$f7
    sta n_flags,x
    rts

; A is the animation-list offset (walk=0, air=4, idle=8).
chick_animate:
    clc
    adc n_cycle,x
    tay
    lda chick_poses,y
    sta n_animation,x
    rts
chick_sound:
    jsr audio_enqueue
    ldx c_actor
    rts
chick_score:
    sta n_score_event
    asl a
    tay
    sed
    clc
    lda native_score_points,y
    adc n_score
    sta n_score
    lda native_score_points+1,y
    adc n_score+1
    sta n_score+1
    lda n_score+2
    adc #0
    cld
    cmp #$99
    bcs :+
    sta n_score+2
:   rts
chick_deliver:
    lda n_rescued
    ora chick_bits,x
    sta n_rescued
    lda n_flags,x
    and #$7f
    sta n_flags,x
    lda #$85
    jsr chick_sound
    jsr rescue_wait
    ldy n_delivered
    lda chick_delivery_points,y
    inc n_delivered
    jsr popup_spawn_delivery
    lda n_score_event
    jsr chick_score
    lda n_train
    cmp n_delivered
    bne @done
    lda n_rescued
    cmp #$ff
    bne @continue
    lda #1
    sta n_round_complete
    bne @stop
@continue:
    lda #0
    sta n_exiting
@stop:
    lda #0
    sta n_train
    sta n_vx+CAMERA
    sta n_fx+CAMERA
    sta n_acceleration+CAMERA
    sta n_target+CAMERA
@done:
    rts

train_check_door_bank:
    sec
    lda n_ptr
    sbc #64
    sta n_src
    lda n_ptr+1
    sbc #0
    sta n_src+1
    ldy n_column
    dey
    lda (n_src),y
    and #$f0
    cmp #$c0
    bne @done
    ldx #7
@actor:
    lda n_chick_state,x
    and #1
    beq @next
    lda n_flags,x
    bpl @next
    ora #4
    sta n_flags,x
@next:
    dex
    bpl @actor
    lda #1
    sta n_exiting
    lda #0
    sta n_delivered
@done:
    rts

popup_spawn_delivery:
    sta n_score_event
    stx c_actor
    ldx #20
@shift:
    lda n_flags+1,x
    sta n_flags,x
    lda n_animation+1,x
    sta n_animation,x
    lda n_pause+1,x
    sta n_pause,x
    lda n_xlo+1,x
    sta n_xlo,x
    lda n_xhi+1,x
    sta n_xhi,x
    lda n_ylo+1,x
    sta n_ylo,x
    lda n_popup_value+1,x
    sta n_popup_value,x
    lda n_target+1,x
    sta n_target,x
    inx
    cpx #23
    bcc @shift
    lda #$b0
    sta n_flags+23
    lda #$fe
    sta n_pause+23
    lda #32
    sta n_target+23
    lda n_score_event
    sta n_popup_value+23
    sec
    sbc #5
    sta n_animation+23
    sec
    lda #0
    sbc n_world
    sta n_xlo+23
    lda #1
    sbc n_world+1
    sta n_xhi+23
    lda n_delivered
    asl a
    asl a
    asl a
    clc
    adc #9
    sta c_temp
    lda n_ylo+PLAYER
    bmi @above
    clc
    adc c_temp
    jmp @height
@above:
    sec
    sbc c_temp
@height:
    sta n_ylo+23
    ldx c_actor
    rts
popup_update_bank:
    ldx #20
@actor:
    lda n_flags,x
    bpl @next
    inc n_pause,x
    lda n_pause,x
    cmp n_target,x
    bne @next
    lda #0
    sta n_flags,x
@next:
    inx
    cpx #24
    bcc @actor
    rts

; Four surrounding solid-tile bits: upper left=1, lower left=2,
; lower right=4, upper right=8. Source rounds X and scroll separately.
chick_sample_bank:
    lda #0
    sta c_mask
    lda n_ylo,x
    and #$18
    asl a
    asl a
    asl a
    sta n_ptr
    lda n_ylo,x
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #>n_map
    sta n_ptr+1
    sec
    lda #0
    sbc n_world
    sta c_temp
    lda #2
    sbc n_world+1
    lsr a
    lda c_temp
    ror a
    lsr a
    lsr a
    and #$3e
    sta c_temp
    clc
    lda n_xlo,x
    adc n_world
    sta c_screen
    lda n_xhi,x
    adc n_world+1
    lsr a
    lda c_screen
    ror a
    lsr a
    lsr a
    clc
    adc c_temp
    and #63
    ora #1
    sta c_index
    tay
    jsr @bit
    clc
    lda n_ptr
    adc #64
    sta n_ptr
    bcc :+
    inc n_ptr+1
:   jsr @bit
    lda c_index
    clc
    adc #2
    and #63
    tay
    jsr @bit
    sec
    lda n_ptr
    sbc #64
    sta n_ptr
    bcs :+
    dec n_ptr+1
:   jsr @bit
    lda c_mask
    lsr a
    lsr a
    lsr a
    lsr a
    sta c_mask
    rts
@bit:
    lda (n_ptr),y
    and #$10
    cmp #$10
    ror c_mask
    rts

train_record_bank:
    ldy n_history_yindex
    lda n_ylo+PLAYER
    sta n_history_y,y
    dey
    bpl :+
    ldy #39
:   sty n_history_yindex
    ldy n_history_xindex
    lda n_scroll_delta
    sta n_history_xlo,y
    lda n_scroll_delta+1
    sta n_history_xhi,y
    ; Prefix sums turn eight trail distances into eight subtractions.
    ; Save the overwritten prefix for the forty-tick (last bird) sample.
    lda $1c00,y
    sta $1bb2
    lda $1c40,y
    sta $1bb3
    clc
    lda $1bb0
    adc n_scroll_delta
    sta $1bb0
    sta $1c00,y
    lda $1bb1
    adc n_scroll_delta+1
    sta $1bb1
    sta $1c40,y
    dey
    bpl :+
    ldy #39
:   sty n_history_xindex
    lda $1d93
    beq @distances
    lda n_game_ticks
    and #1
    beq @done
@distances:
    lda n_train
    beq @done
    clc
    lda n_xlo+PLAYER
    adc $1bb0
    sta c_sum
    lda n_xhi+PLAYER
    adc $1bb1
    sta c_sum+1
    tya
    clc
    adc #6
    cmp #40
    bcc :+
    sbc #40
:   tay
    ldx #0
@chick:
    cpx #7
    beq @oldest
    sec
    lda c_sum
    sbc $1c00,y
    sta n_trail_xlo,x
    lda c_sum+1
    sbc $1c40,y
    jmp @save
@oldest:
    sec
    lda c_sum
    sbc $1bb2
    sta n_trail_xlo,x
    lda c_sum+1
    sbc $1bb3
@save:
    sta n_trail_xhi,x
    tya
    clc
    adc #5
    cmp #40
    bcc :+
    sbc #40
:   tay
    inx
    cpx n_train
    bcc @chick
@done:
    rts

chick_bits: .byte 1,2,4,8,16,32,64,128
chick_poses: .byte 0,1,2,1,3,4,3,4,5,6,5,6
chick_turn_pose: .byte 7,8,7
chick_delivery_points: .byte 5,6,7,8,9,11,12,14
