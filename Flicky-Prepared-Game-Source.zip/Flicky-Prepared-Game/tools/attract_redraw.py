"""Research-only replacement of intro actors while preserving the MAME track.

The prepared output is sufficient for normal builds; original program ROMs
and MAME snapshots are never part of a release cartridge or source package.
"""
import ctypes as C,json
from pathlib import Path
import numpy as np
from PIL import Image
from build import BUILD
from run_reference import Reference
from attract_palette import row_palette,PMG_ORIGIN
from attract_art import SOURCE_PALETTES
from intro_scale_proposal import BIKE,PLANE
from round_clear_art import LETTERS

OUT=BUILD/'intro-final'
FLY=[
 '....bb.b....','...bbbbbb...','...bbwwwb...','...bbwkwb...','...bbwkwyy..',
 '....bwwyyy..','.bb.bbbbb.bb','bbbbbbwwbbbb','.bbbbwwbbbb.',
 '..bbbwwbbb..','...bbwwbb...','....yyyy....','....y..y....','...yy..yy...',
]
CHICK=['.yy..','yyyy.','yykyy','yyyy.','.yyy.','.yyyy','..yy.','..yy.','.y.y.','.y.yy']

def sprite(s):
    return dict(x=((int(s[2])|int(s[3])<<8)&511)/2,y=int(s[0])+1,
                height=int(s[1])-int(s[0]),flip=bool(s[7]&128),pose=int(s[6])|int(s[7])<<8)

def stamp(canvas,rows,x,y,flip=False,phase=0):
    rows=[row[::-1] for row in rows]if flip else rows
    for yy,row in enumerate(rows):
        dy=y+yy
        if not 0<=dy<224:continue
        pal=row_palette(dy//8)
        for xx,c in enumerate(row):
            dx=x+xx
            if not 0<=dx<160 or c=='.':continue
            color={'b':0x8a,'w':0x0e,'k':pal[2],'y':0xee,'r':0x38,
                   'p':0x5a,'o':0x1c}[c]
            canvas[dy,dx]=color

def native_actors(colors,descriptors,phase):
    s=[sprite(x)for x in descriptors]
    bike=s[1];bird=s[8];plane=s[16];cat=s[17]
    if bike['height']>0 and bike['y']<224:
        wheels=BIKE[11:].copy()
        if phase&1:
            wheels[-3]=wheels[-3].replace('kwk','kkk')
            wheels[-2]=wheels[-2].replace('kkk','kwk')
        stamp(colors,wheels,round(bike['x']*5/8),bike['y'],bike['flip'])
    for i in range(2,8):
        chick=s[i]
        if chick['height']>0 and chick['y']<224:
            rows=CHICK.copy()
            if phase&1:rows[5]='yyyy.'
            stamp(colors,rows,round(chick['x']*5/8),chick['y'],chick['flip'])
    if bird['height']>0 and bird['y']<224:
        grounded=bird['y']>=189
        if grounded:
            rows=BIKE[:11]+['....y.......','....yyy.....']
            rows=[''.join('.'if c=='k'and x>=8 else c for x,c in enumerate(row))for row in rows]
        else:
            rows=FLY.copy()
            if phase&1:
                rows[6]='.b..bbbbb..b';rows[7]='bbbbbwwbbbbb';rows[8]='.bbbbwwbbbb.'
        stamp(colors,rows,round(bird['x']*5/8)-3,bird['y'],bird['flip'])
    if plane['height']>0 and plane['y']<224:
        rows=PLANE.copy()
        if phase&1:
            # A second propeller pose, within the same native footprint.
            for y in (10,11,13,14):rows[y]=rows[y][:-2]+'.'+rows[y][-1]
            rows[12]=rows[12][:-3]+'www'
        top=min(plane['y'],cat['y']) if cat['height']>0 else plane['y']-1
        stamp(colors,rows,round(plane['x']*5/8),top,plane['flip'])

def compile_frame(colors):
    pix=np.zeros((224,160),np.uint8);pmg=np.zeros((4,256),np.uint8)
    mux=np.zeros((28,4,2),np.uint8)
    extra=np.zeros_like(pix)
    for row in range(28):
        y=row*8;wanted=colors[y:y+8];pal=row_palette(row)
        known=np.zeros(wanted.shape,bool)
        for code,color in enumerate(pal):
            hit=wanted==color;pix[y:y+8][hit]=code;known|=hit
        extra[y:y+8][~known]=wanted[~known]
        conflict=[];base=pix[y:y+8].copy();baseextra=extra[y:y+8].copy()
        for col in range(40):
            cell=pix[y:y+8,col*4:col*4+4]
            if np.any(cell==3)and np.any(cell==4):
                ink=4 if np.sum(cell==4)<=np.sum(cell==3)else 3
                conflict.append((col,ink))
                e=extra[y:y+8,col*4:col*4+4];e[cell==ink]=pal[ink];cell[cell==ink]=0
        def strips(values):
            from functools import lru_cache
            result=[]
            for color in sorted(set(values.flatten())-{0}):
                mask=values==color
                columns=np.flatnonzero(mask.any(axis=0)).tolist()
                old={int(x)-48 for x,c in mux[row-1]if x and c==color}if row else set()
                anchor=int(np.flatnonzero(np.any(colors==color,axis=0))[0])
                @lru_cache(None)
                def cover(i):
                    if i==len(columns):return (0,0,0),()
                    best=None
                    for x in range(max(0,columns[i]-7),min(columns[i],152)+1):
                        end=i+1
                        while end<len(columns)and columns[end]<=x+7:end+=1
                        tail,spans=cover(end)
                        score=(tail[0]+1,tail[1]+(x not in old),tail[2]+((x-anchor)%8!=0))
                        if best is None or score<best[0]:best=score,(x,)+spans
                    return best
                _,spans=cover(0)
                for x in spans:
                    bits=mask[:,x:x+8].copy();mask[:,x:x+8]=False;result.append((x,int(color),bits))
            return result
        choices=strips(extra[y:y+8])
        if len(choices)>4:
            # Per-cell PF2/PF3 choice is a hardware allocation problem. Search
            # both legal encodings before assigning any player; no background
            # or bird pixels are discarded to make a crowded band fit.
            assert len(conflict)<=16,('cell search',row,len(conflict))
            for variant in range(1,1<<len(conflict)):
                trial=base.copy();ex=baseextra.copy()
                for i,(col,preferred)in enumerate(conflict):
                    ink=7-preferred if variant>>i&1 else preferred
                    cell=trial[:,col*4:col*4+4];e=ex[:,col*4:col*4+4]
                    e[cell==ink]=pal[ink];cell[cell==ink]=0
                candidate=strips(ex)
                if len(candidate)<=4:
                    pix[y:y+8]=trial;extra[y:y+8]=ex;choices=candidate;break
        assert len(choices)<=4,('players',row,[(x,c)for x,c,_ in choices])
        # Minimize register changes between adjacent bands, which also prevents
        # interrupt writes from chasing a player already at the left edge.
        from itertools import permutations
        best=None
        for slots in permutations(range(4),len(choices)):
            cost=0
            if row:
                for p,(x,c,bits)in zip(slots,choices):
                    writes=(int(mux[row-1,p,0])!=48+x)+(int(mux[row-1,p,1])!=c)
                    previous=pmg[p,PMG_ORIGIN+y-8:PMG_ORIGIN+y]
                    # Prefer another player over changing a live player at
                    # a band edge. Empty bands can be preconfigured below.
                    cost+=writes*(1+10*bool(bits[0].any() and previous.any())+
                                  100*bool(bits[0].any() and previous[-1]))
            if best is None or cost<best[0]:best=(cost,slots)
        if row:mux[row]=mux[row-1]
        for p,(x,c,bits)in zip(best[1],choices):
            pmg[p,PMG_ORIGIN+y:PMG_ORIGIN+y+8]=np.packbits(bits,axis=1)[:,0];mux[row,p]=(48+x,c)
    # Configure the next span during an empty band rather than on its first
    # visible scanline. All four DMA pages remain zero outside their masks.
    for row in range(26,-1,-1):
        for p in range(4):
            if not np.any(pmg[p,PMG_ORIGIN+row*8:PMG_ORIGIN+row*8+8]):mux[row,p]=mux[row+1,p]
    # Exhaustive lossless reconstruction includes every player overlay.
    for row in range(28):
        y=row*8;actual=np.array(row_palette(row),np.uint8)[pix[y:y+8]]
        for p,(pos,color)in enumerate(mux[row]):
            if not pos:continue
            x=int(pos)-48;bits=np.unpackbits(pmg[p,PMG_ORIGIN+y:PMG_ORIGIN+y+8,None],axis=1).astype(bool)
            actual[:,x:x+8][bits]=color
        assert np.array_equal(actual,colors[y:y+8]),('native color reconstruction',row)
    return pix,pmg,mux

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    reference=Reference();source=np.load(BUILD/'attract-research/mame-frames.npz')
    times=source['times'];rgb=np.array([[(v&7)*255/7,(v>>3&7)*255/7,(v>>6)*85]for v in range(256)])
    sx=np.minimum((np.arange(160)+.5)*256/160,255).astype(int)
    lookup=[]
    for pal in SOURCE_PALETTES:
        distances=((rgb[:,None]-rgb[list(pal)][None])**2).sum(axis=2)
        lookup.append(distances.argmin(axis=1))
    frames=[];players=[];tables=[];track=[]
    for number,t in enumerate(times):
        path=BUILD/f'attract-research/mame/state-{t:04d}.bin'
        reference.ram[0xc000:0xf000]=np.frombuffer(path.read_bytes(),np.uint8)
        descriptors=reference.ram[0xd000:0xd200].reshape(32,16).copy()
        reference.ram[0xe800:0xef00]=0
        for slot in (*range(1,9),16,17):
            reference.ram[0xd001+16*slot]=reference.ram[0xd000+16*slot]
        reference.lib.fm_render_snapshot(0)
        original=reference.picture[:,::2][:,sx]
        colors=np.empty((224,160),np.uint8)
        for row in range(28):
            y=row*8;zone=0 if y<144 else 1 if y<184 else 2
            codes=lookup[zone][original[y:y+8]].copy()
            if zone==0:
                values=rgb[original[y:y+8]]
                gray=(values.max(axis=2)-values.min(axis=2)<50)&(values.min(axis=2)>70)
                codes[gray]=1
            colors[y:y+8]=np.array(row_palette(row),np.uint8)[codes]
        native_actors(colors,descriptors,number)
        colors[213:224]=0xba
        text='FIRE TO PLAY';x=(160-(len(text)*6-1))//2
        for c in text:
            for yy,line in enumerate(LETTERS[c]):
                for xx,b in enumerate(line):
                    if b=='1':colors[216+yy,x+xx]=0x0e
            x+=6
        try:pix,pmg,mux=compile_frame(colors)
        except AssertionError as error:
            np.save(OUT/'failed-colors.npy',colors);raise AssertionError((int(t),number,error))from error
        frames.append(pix);players.append(pmg);tables.append(mux)
        track.append(dict(frame=int(t),bike=sprite(descriptors[1]),flicky=sprite(descriptors[8]),
                          airplane=sprite(descriptors[16]),bomb=sprite(descriptors[18])))
        if number%40==0:print('Native intro frame',number,int(t),flush=True)
    np.savez_compressed(BUILD/'native/attract-pixels.npz',pixels=np.array(frames),pmg=np.array(players),mux=np.array(tables),times=times)
    (OUT/'animation-track.json').write_text(json.dumps(track,indent=2)+'\n')
    report=dict(frames=len(times),source_frames=[int(times[0]),int(times[-1])],
      motorcycle=[12,20],airplane=[17,21],replaced_actor_slots=[*range(1,9),16,17],
      preserved=['cloud motion','motorcycle motion','Flicky jumps','chick trajectories','balloon popping','bomb trajectories','letter unscrambling'],
      pmg_scanline_origin=PMG_ORIGIN,all_frames_reconstruct_exactly=True,sky='DLI dark-to-light blue',mountains='blue')
    (BUILD/'native/attract-redraw.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
