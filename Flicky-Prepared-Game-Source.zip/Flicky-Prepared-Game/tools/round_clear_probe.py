"""Real Atari800 portrait capture and automatic return-to-game verification.

The monitor selects the result state for this diagnostic; it is not a play
movie. The unmodified cartridge then draws the portrait, runs its ordinary
clock/audio interrupt and advances into the next round on its own.
"""
import argparse,json,time
from pathlib import Path
from raster_probe import Session
from prepared_probe import dumps
from build import BUILD

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cartridge',type=Path,default=BUILD/'native/flicky-native-dev.car')
    ap.add_argument('--labels',type=Path,default=BUILD/'native/native.lbl')
    ap.add_argument('--mode',choices=('pal','ntsc'),default='pal')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    labels={p[2].lstrip('.'):int(p[1],16) for l in args.labels.read_text().splitlines() if len(p:=l.split())==3}
    s=Session(args.cartridge.resolve(),args.output.resolve(),args.mode,True,f'capture-{time.time_ns()}.avi')
    try:
        s.tap('Control_R');time.sleep(.5)
        def store(label,value):
            a=labels[label];return [0xa9,value,0x8d,a&255,a>>8]
        stub=store('u_time_bonus',0x20)+store('n_flow',2)+store('n_flow_wait',240)+[0x20,labels['message_result']&255,labels['message_result']>>8,0x4c,labels['native_idle']&255,labels['native_idle']>>8]
        s.monitor(['c 05d0 '+' '.join(f'{b:02x}' for b in stub),'cont 05d0'],resume=False)
        time.sleep(.6);s.capture().save(s.out/'portrait.png')
        s.monitor([f'm {a:04x} {a+15:04x}' for a in (0x07f0,0x0700,0xfff0,0x0220,0x0680)])
        time.sleep(5.5);s.capture().save(s.out/'next-round.png')
        s.monitor(['antic','gtia']+[f'm {a:04x} {a+15:04x}' for a in (0x07f0,0x0700,0x0640,0xfff0,0x0220,0x0680)]+['quit'],resume=False)
        s.emu.wait(timeout=5)
    finally:s.close()
    data=dumps((s.out/'emulator.log').read_text())
    before,after=data[0x07f0][0],data[0x07f0][-1]
    vectors=[data[0xfff0][0],data[0xfff0][-1]]
    report={'mode':args.mode,'diagnostic_state_selection':True,'cartridge':str(args.cartridge),
            'portrait_active_before':before[0],'portrait_active_after':after[0],
            'round_before':data[0x0700][0][0],'round_after':data[0x0700][-1][0],
            'portrait_nmi':vectors[0][10]+256*vectors[0][11],
            'restored_nmi':vectors[1][10]+256*vectors[1][11],
            'music_playing_after':bool(data[0x0220][-1][0]),
            'renderer_fault':data[0x0640][-1][10],
            'clock_overflow':data[0x0680][-1][13]}
    (s.out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    assert before[0]==1 and after[0]==0 and report['round_after']==report['round_before']+1
    assert report['portrait_nmi']==labels['result_nmi'] and report['restored_nmi']==labels['sic_nmi']
    assert report['renderer_fault']==report['clock_overflow']==0 and report['music_playing_after']

if __name__=='__main__':main()
