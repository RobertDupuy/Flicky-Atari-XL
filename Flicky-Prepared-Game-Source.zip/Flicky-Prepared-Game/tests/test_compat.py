"""Independent checks for the expanded native Z80 arithmetic ABI."""
import ctypes as C,random,sys,subprocess
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_native import Native,BUILD
from test_cpu import Result,reference

@pytest.fixture(scope='module')
def machine():
    n=Native()
    n.lib.at_call.argtypes=[C.c_uint16,C.c_uint8,C.c_uint8,C.c_uint8]
    n.lib.at_call.restype=C.c_int64
    subprocess.run(['gcc','-std=c11','-O2','-shared','-fPIC',str(ROOT/'tests/reference.c'),'-o',str(BUILD/'reference.so')],check=True)
    ref=C.CDLL(str(BUILD/'reference.so')).reference_run
    ref.argtypes=[C.POINTER(C.c_uint8),C.c_uint,C.POINTER(C.c_uint8),C.POINTER(Result),C.POINTER(Result),C.c_uint]
    return n,ref

def setreg(n,**kw):
    for k,v in kw.items():n.memory[n.labels['z_'+k]]=v

def call(n,name,a=0,x=0,y=0):
    assert n.lib.at_call(n.labels[name],a,x,y)>0

@pytest.mark.parametrize('accumulator',[False,True])
def test_rotates(machine,accumulator):
    n,ref=machine
    for kind in range(4 if accumulator else 8):
        for value in range(256):
            for carry in [0,1]:
                flags=0xc4|carry
                code=bytes([[7,15,23,31][kind],0x76]) if accumulator else bytes([0xcb,kind*8,0x76])
                r,_=reference(ref,code,a=value,b=value,f=flags)
                setreg(n,f=flags)
                call(n,'rotate8',a=value,x=kind+(8 if accumulator else 0))
                assert n.lib.at_a()==(r.a if accumulator else r.b),(kind,value,carry)
                assert n.memory[n.labels['z_f']]==r.f,(kind,value,carry)

def test_daa(machine):
    n,ref=machine
    for a in range(256):
        for f in [0,1,2,3,16,17,18,19]:
            r,_=reference(ref,b'\x27\x76',a=a,f=f)
            setreg(n,a=a,f=f)
            call(n,'daa')
            assert (n.memory[n.labels['z_a']],n.memory[n.labels['z_f']])==(r.a,r.f),(a,f)

@pytest.mark.parametrize('kind',[0,1,2])
def test_alu16(machine,kind):
    n,ref=machine
    rng=random.Random(kind)
    for _ in range(1500):
        a,b,f=rng.randrange(65536),rng.randrange(65536),rng.randrange(256)
        code=bytes([0x09,0x76]) if kind==0 else bytes([0xed,0x4a if kind==1 else 0x42,0x76])
        r,_=reference(ref,code,h=a>>8,l=a&255,b=b>>8,c=b&255,f=f)
        setreg(n,h=a>>8,l=a&255,f=f)
        # z_word is immediately after z_host in the ABI; use exported symbol.
        n.memory[n.labels['z_word']]=b&255;n.memory[n.labels['z_word']+1]=b>>8
        call(n,'alu16',x=n.labels['z_l'],y=kind)
        assert tuple(n.memory[n.labels['z_'+s]] for s in ['h','l','f'])==(r.h,r.l,r.f),(kind,a,b,f)
