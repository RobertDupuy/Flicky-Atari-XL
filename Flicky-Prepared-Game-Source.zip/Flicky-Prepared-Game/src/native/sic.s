; SIC! 512 KB: hot code/data in lower cartridge windows, bulk animation
; data in upper windows. The common native kernel runs in underlying RAM.
; Only this small resident copy/NMI page can enable the upper ROM window.
.segment "FIXED"
.export sic_boot,sic_nmi,sic_read_frame,sic_read_glyph
.export i_bank,i_glyph,r_font,i_actor,i_ptr
.import __RESIDENT_LOAD__,__RESIDENT_SIZE__,__HIGHRAM_LOAD__
sic_boot:
    sei
    cld
    ldx #$ff
    txs
    lda #0
    sta $d40e
    sta $d400
    sta $d20e
    lda #$fe
    sta $d301
    lda #0
    sta n_src
    sta n_dst
    lda #$a0
    sta n_src+1
.ifdef NATIVE_JCART
    lda #$80
    sta n_dst+1
    lda #$20
.else
    lda #$20
    sta n_dst+1
.endif
    sta n_count
    ldy #0
@page:
    lda (n_src),y
    sta (n_dst),y
    iny
    bne @page
    inc n_src+1
    inc n_dst+1
    dec n_count
    bne @page
    ldx #0
@resident:
    lda __RESIDENT_LOAD__,x
    sta $0300,x
    lda __RESIDENT_LOAD__+$100,x
    sta $0400,x
    lda __RESIDENT_LOAD__+$200,x
    sta $0500,x
    inx
    bne @resident
    jmp sic_ram_start

.segment "RESIDENT"
sic_ram_start:
.ifndef NATIVE_JCART
    lda #$60
    sta $061f
    sta $d500
    lda #$20
    sta n_src+1
    sta n_count
    lda #$a0
    sta n_dst+1
    ldy #0
@page:
    lda (n_src),y
    sta (n_dst),y
    iny
    bne @page
    inc n_src+1
    inc n_dst+1
    dec n_count
    bne @page
.endif
    lda #15
    NATIVE_BANK
    ldx #0
@high:
    .repeat 8,I
        lda __HIGHRAM_LOAD__+I*$100,x
        sta $f800+I*$100,x
    .endrepeat
    inx
    bne @high
    jmp start

; Save hardware and shadow separately: an NMI can land between their stores.
; $1a..$1c are private to NMI, disjoint from foreground and audio scratch.
sic_nmi:
    sta $1b
    bit $d40f
    bmi @dli
    CART_NMI_ENTER
    lda $1b
    jmp display_nmi
@dli:
    ; Character-band interrupts have a scanline deadline. They never need
    ; cartridge data, so perform their entire short path in resident RAM.
    ; VBI has already selected the first font. Write it before doing the
    ; successor calculation: the old HUD special case missed the first
    ; gameplay scanline with ANTIC/PMG DMA active (visible as stray dashes).
    lda r_band
    sta $d40a
    sta $d409
    cld
    clc
    adc #4
    sta r_band
    lda $1b
    rti
sic_nmi_return:
    sta $1b
.ifndef NATIVE_JCART
    lda $1a
    sta $d500
.endif
    lda $1c
    sta $061f
.ifdef NATIVE_JCART
    CART_IRQ_WRITE
.endif
    lda $1b
    rti

sic_read_frame:
    ldx z:i_actor
    lda i_style_bank,x
    and #31
    CART_UPPER_VALUE
    sta $061f
    CART_WRITE
    ldy #11
@copy:
    lda (i_ptr),y
    sta i_frame_data,y
    dey
    bpl @copy
    lda #6
    NATIVE_BANK
    rts
sic_read_glyph:
    lda z:i_bank
    and #31
    CART_UPPER_VALUE
    sta $061f
    CART_WRITE
    ldy #0
    .repeat 8,I
        lda (i_glyph),y
        sta (r_font),y
        .if I<7
            iny
        .endif
    .endrepeat
    lda #6
    NATIVE_BANK
    rts
; Exact delta events: at most eight register bytes, no unbounded work.
audio_execute_prepared:
    lda a_slots+2,x
    sta z:a_ptr
    lda a_slots+3,x
    sta z:a_ptr+1
    lda a_slots+1,x
    CART_UPPER_VALUE
    sta a_bank
    CART_IRQ_WRITE
@read:
    ldy #0
    lda (a_ptr),y
    bne @event
    lda a_slots+5,x
    beq @stop
    sta z:a_ptr+1
    lda a_slots+4,x
    sta z:a_ptr
    jmp @read
@stop:
    sta a_slots,x
    beq @return
@event:
    sta a_slots+7,x
    iny
    lda (a_ptr),y
    sta z:a_mask
    iny
    .repeat 8,I
        lsr z:a_mask
        bcc :+
        lda (a_ptr),y
        sta a_slots+8+I,x
        iny
    :
    .endrepeat
    tya
    clc
    adc z:a_ptr
    sta a_slots+2,x
    lda z:a_ptr+1
    adc #0
    sta a_slots+3,x
@return:
.ifndef NATIVE_JCART
    lda a_bank
    ora #$40
    sta a_bank
    sta $d500
.endif
    rts
; Generic short upper-ROM read for packed actor data. n_token is 1..128.
.export sic_read_block
sic_read_block:
    lda $061f
    pha
    lda z:l_bank
    CART_UPPER_VALUE
    sta $061f
    CART_WRITE
    ldy n_token
    dey
@copy:
    lda (n_src),y
    sta (n_dst),y
    dey
    bpl @copy
    pla
    sta $061f
    CART_WRITE
    rts
.ifdef NATIVE_JCART
jcart_hot_bank:
    ; Preserve carry/overflow/decimal just as the SIC ORA/STA sequence does.
    php
    asl a
    ora #1
    sta $061f
    sta @write+1
@write:
    sta $d500
    plp
    ora #0
    rts
jcart_select:
    sta @write+1
@write:
    sta $d500
    rts
jcart_irq_select:
    sta @write+1
@write:
    sta $d500
    rts
.endif
.assert *<=$0600,error,"SIC resident area overflow"
