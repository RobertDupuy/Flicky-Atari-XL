.segment "FIXED"
.export level_load,n_map
; Expand the selected native level stream into 32 x 28 original tile words.
; Offsets are byte distances in the destination, with overlapping copies valid.
level_load:
    jsr round_select
    lda native_level_banks,x
    NATIVE_BANK
    lda native_level_lo,x
    sta n_src
    lda native_level_hi,x
    sta n_src+1
    lda #<n_map
    sta n_dst
    lda #>n_map
    sta n_dst+1
@token:
    jsr level_byte
    beq @done
    bmi @backreference
    sta n_count
@literal:
    jsr level_byte
    jsr level_emit
    dec n_count
    bne @literal
    beq @token
@backreference:
    and #127
    clc
    adc #3
    sta n_count
    jsr level_byte
    sta n_offset
    jsr level_byte
    sta n_offset+1
    sec
    lda n_dst
    sbc n_offset
    sta n_ptr
    lda n_dst+1
    sbc n_offset+1
    sta n_ptr+1
@copy:
    ldy #0
    lda (n_ptr),y
    jsr level_emit
    inc n_ptr
    bne :+
    inc n_ptr+1
:   dec n_count
    bne @copy
    beq @token
@done:
    rts
level_byte:
    ldy #0
    lda (n_src),y
    inc n_src
    bne :+
    inc n_src+1
:   cmp #0
    rts
level_emit:
    ldy #0
    sta (n_dst),y
    inc n_dst
    bne :+
    inc n_dst+1
:   rts
