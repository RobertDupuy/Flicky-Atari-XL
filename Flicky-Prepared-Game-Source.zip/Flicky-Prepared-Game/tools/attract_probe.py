"""Record cartridge startup/intro at normal speed; only emulator reset input."""
import argparse,json,time,os
from pathlib import Path
from raster_probe import Session
from native_engine import Engine

def observe_ram(s,cartridge,n):
    """Locate the emulator's RAM through a read-only process descriptor."""
    rom=cartridge.read_bytes()[16:];needle=rom[8192:8256]
    parent=int(Path('/proc/self/status').read_text().split('Pid:')[1].split()[0])
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:fields=dict(line.split(':',1) for line in (proc/'status').read_text().splitlines() if ':' in line)
        except OSError:continue
        if int(fields.get('PPid','0'))==parent and int(fields.get('NSpid','0').split()[-1])==s.emu.pid:break
    else:raise RuntimeError('Emulator process not found')
    fd=os.open(proc/'mem',os.O_RDONLY)
    load=n.labels['__HIGHRAM_LOAD__'];high=rom[15*16384+load-0x8000:15*16384+load-0x8000+32]
    for line in (proc/'maps').read_text().splitlines():
        bounds,perm,*_=line.split()
        if not perm.startswith('rw'):continue
        lo,hi=(int(v,16) for v in bounds.split('-'))
        if hi-lo>128*1024*1024:continue
        try:data=os.pread(fd,hi-lo,lo)
        except OSError:continue
        start=0
        while True:
            pos=data.find(high,start)
            if pos<0:break
            start=pos+1;base=lo+pos-0xf800
            try:
                if os.pread(fd,3,base+0xfffa)==bytes([3,16,0]) or os.pread(fd,1,base+0x1000)==b'\x4c':return fd,base
            except OSError:pass
    raise RuntimeError('Emulator RAM not found')

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['pal','ntsc'],required=True)
    p.add_argument('--cartridge',type=Path,required=True);p.add_argument('--labels',type=Path)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    n=Engine(a.cartridge,a.labels);name=f'intro-{time.time_ns()}.avi'
    s=Session(a.cartridge,a.output,a.mode,True,name)
    try:
        fd,base=observe_ram(s,a.cartridge,n)
        s.record();s.key('Shift_L',True);s.tap('F5');s.key('Shift_L',False)
        start=time.monotonic()
        samples=[]
        for target in range(4,49,4):
            while time.monotonic()-start<target:time.sleep(.05)
            s.capture().save(a.output/f'intro-{target:02d}.png')
            m=os.pread(fd,65536,base)
            row=dict(seconds=target,frame=int.from_bytes(m[n.labels['it_frame']:n.labels['it_frame']+2],'little'),finished=m[n.labels['it_finished']],mode=m[0x7ec],overflow=m[0x68d])
            samples.append(row);print(a.mode,row,flush=True)
            if row['finished']:time.sleep(2);break
        assert samples[-1]['finished'] and all(x['mode']==1 and not x['overflow'] for x in samples),samples
        s.key('Control_R',True);time.sleep(.25);s.key('Control_R',False);time.sleep(3)
        s.capture().save(a.output/'started-round-01.png')
        m=os.pread(fd,65536,base)
        print('entry',list(m[0x7ec:0x7f1]),list(m[0x640:0x64b]),flush=True)
        assert m[0x7ec]==0 and m[0x7f0]==0
        s.record()
        os.close(fd)
        (a.output/'capture.json').write_text(json.dumps(dict(mode=a.mode,video=name,
            continuous_normal_speed=True,game_state_edits_during_recording=False,
            samples=samples,game_entry_verified=True,
            input='emulator cold reset; fire pressed after the settled logo to test game entry'),indent=2)+'\n')
    finally:s.close()

if __name__=='__main__':main()
