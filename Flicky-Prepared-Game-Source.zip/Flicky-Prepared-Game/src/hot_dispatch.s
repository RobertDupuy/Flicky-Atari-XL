; A checked direct-mapped cache accelerates indirect object callbacks.
; Key = high PC byte plus low-byte bit 7; index = low-byte bits 0..6.
.segment "FIXED"
hot_dispatch:
    sta z_pc
    stx z_pc+1
    cpx #$80
    bcs @cold
    and #$80
    ora z_pc+1
    sta z_byte
    lda z_pc
    and #$7f
    tax
    stx z_hash
    lda $f600,x
    bmi @miss
    ldy $f500,x
    cpy z_byte
    bne @miss
    pha
    and #$1f
    ora #$80
    sta z_jump+1
    lda $f580,x
    sta z_jump
    pla
    lsr a
    lsr a
    lsr a
    lsr a
    lsr a
    clc
    adc #4
    jmp @go
@miss:
    ldx z_pc+1
    lda hot_count,x
    sta z_limit
    beq @cold
    lda hot_lo,x
    sta z_stream
    lda hot_hi,x
    sta z_stream+1
    lda #7
    SELECT_BANK
@search:
    ldy #0
    lda (z_stream),y
    cmp z_pc
    beq @found
    clc
    lda z_stream
    adc #4
    sta z_stream
    bcc :+
    inc z_stream+1
:   dec z_limit
    bne @search
@cold:
    jmp interp_next
@found:
    ldx z_hash
    lda z_byte
    sta $f500,x
    iny
    lda (z_stream),y
    sta z_jump
    sta $f580,x
    iny
    lda (z_stream),y
    sta z_jump+1
    and #$1f
    sta z_temp
    iny
    lda (z_stream),y
    pha
    sec
    sbc #4
    asl a
    asl a
    asl a
    asl a
    asl a
    ora z_temp
    sta $f600,x
    pla
@go:
    sta z_cur_bank
    SELECT_BANK
    jmp (z_jump)
