"""Regressions for mixed music/effects and static room/result presentation."""
import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build import BUILD
from native_engine import Engine
from fast_ui_assets import FONT,CHARS

def test_background_music_advances_through_effects_and_its_loop():
    n=Engine();n.lib.at_video_timing(0);n.call('audio_init');n.call('audio_start',0x82)
    captured=np.load(BUILD/'audio/82-pokey.npy')
    cues=(0x84,0x85,0x88,0x89,0x8a,0x8b,0x8c,0x8d,0x8f,0x90,0x91,0x92,0x93)
    for tick in range(3000):
        if tick%79==0:n.call('audio_start',cues[(tick//79)%len(cues)])
        n.call('audio_tick')
        frame=tick if tick<len(captured) else 208+(tick-len(captured))%(len(captured)-208)
        assert n.ram[0x220]==1,(tick,'music stopped')
        np.testing.assert_array_equal(n.ram[0x228:0x230],captured[frame],err_msg=f'music changed at tick {tick}')
    # The game-over cue is an intentional stop; a fresh round starts normally.
    n.call('audio_start',0x87)
    for _ in range(180):n.call('audio_tick')
    assert n.ram[0x220]==n.ram[0x240]==0
    n.call('audio_start',0x82);n.call('audio_tick');assert n.ram[0x220]==1

def test_static_messages_all_rounds_preserve_collision_and_both_buffers():
    n=Engine();n.lib.at_video_timing(0)
    maps=(BUILD/'native/maps-reference.bin').read_bytes()
    report=json.loads((BUILD/'native/static-messages.json').read_text())
    for entry in report['backgrounds']:
        stage=entry['round']-1;n.call('native_reset');n.set('n_round',stage);n.call('game_round_load')
        assert bytes(n.ram[0xc000:0xc700])==maps[stage*1792:(stage+1)*1792]
        row,col=entry['row'],entry['column']
        for i,c in enumerate(entry['message']):
            if c==' ':continue
            expected=bytes([0]+[sum(int(v)<<(6-2*x) for x,v in enumerate(line)) for line in FONT[c].split()]+[0,0])
            if stage%4==2:expected=(BUILD/'native/arcade-bonus-font.bin').read_bytes()[ord(c)*8:ord(c)*8+8]
            for back in (0,1):
                a=0x6000+back*4096+row*96+col+i;code=int(n.ram[a])
                g=0x2000+back*8192+(row//4)*1024+(code&127)*8
                assert bytes(n.ram[g:g+8])==expected,(stage,c,row,col)
                assert n.ram[a]==n.ram[a+32]==n.ram[a+64]
        assert n.get('r_fault')==0,stage

def test_bonus_intro_count_results_and_return_to_gameplay():
    n=Engine();n.lib.at_video_timing(0);n.call('native_reset');n.set('n_round',2);n.call('game_round_load')
    assert n.get('u_mode')==0 and n.get('u_wait')==31 and n.get('n_sound_event')==0x81
    start=n.get('b_spawn')
    for _ in range(31):n.call('game_update')
    assert n.get('b_spawn')==start and n.get('b_clock')==1
    n.call('game_update');assert n.get('u_mode')==0
    n.set('b_caught',17);n.call('message_result')
    assert n.get('u_mode')==0
    assert any(n.ram[0x1600+9*32:0x1600+10*32])
    n.set('b_caught',20);n.call('message_result')
    assert any(n.ram[0x1600+12*32:0x1600+13*32])
    n.set('n_flow',2);n.call('ui_refresh')
    hud=''.join(CHARS[int(v)&127] for v in n.ram[0x1f20:0x1f40])
    assert 'CAUGHT 20/20' in hud and 'TIME BONUS' not in hud
    n.set('n_round',3);n.call('game_round_load');assert n.get('u_mode')==0
    n.set('u_time_bonus',0x20);n.call('message_result')
    assert bytes(n.ram[0x6000+26*40+14:0x6000+26*40+26])==b'02000 POINTS'

def test_round_clear_native_art_and_all_awards_restore_gameplay():
    n=Engine();n.lib.at_video_timing(0)
    fonts=(BUILD/'native/round-clear-fonts.bin').read_bytes()
    pmg=(BUILD/'native/round-clear-pmg.bin').read_bytes()
    assert all(any(pmg[(i+1)*256:(i+2)*256]) for i in range(4))
    assert all(any(v & (3<<(2*i)) for v in pmg[:256]) for i in range(4))
    for award in (0x20,0x10,0x05,0x03,0x01,0x00):
        n.call('native_reset');n.call('game_round_load')
        n.set('u_time_bonus',award);n.call('message_result')
        assert n.get('result_active')==1 and n.get('u_mode')==3
        assert bytes(n.ram[0x2000:0x3c00])==fonts
        assert bytes(n.ram[0x0b00:0x1000])==pmg
        assert int(n.ram[0xfffa])+256*int(n.ram[0xfffb])==n.labels['result_nmi']
        expected=f'0{award:02x}00 POINTS'.encode()
        assert bytes(n.ram[0x6000+26*40+14:0x6000+26*40+26])==expected
        n.set('n_flow',2);n.set('n_flow_wait',1);n.call('game_update');n.call('game_update')
        assert n.get('n_round')==1 and n.get('result_active')==n.get('u_mode')==0
        assert int(n.ram[0xfffa])+256*int(n.ram[0xfffb])==n.labels['sic_nmi']
        assert n.get('r_fault')==0
        assert bytes(n.ram[0xc000:0xc700])==(BUILD/'native/maps-reference.bin').read_bytes()[1792:3584]

def test_round_clear_nmi_preserves_interrupted_upper_rom_copies():
    n=Engine();n.lib.at_video_timing(0);n.call('native_reset');n.call('game_round_load');n.call('message_result')
    rom=(BUILD/'native/flicky-native-dev.car').read_bytes()[16:]
    n.set('i_bank',0x81);n.set('i_glyph',0x40);n.set('i_glyph',0xa0,1)
    n.set('r_font',0);n.set('r_font',0x3f,1)
    expected=rom[16384+8192+64:16384+8192+72]
    # A RAM RTS pad consumes late interrupts without disturbing game state.
    n.labels['result_test_idle']=0x0500;n.ram[0x0500:0x0565]=[0xea]*100+[0x60]
    for delay in range(1,190):
        n.ram[0x3f00:0x3f08]=0
        n.lib.at_force_nmi(delay);n.call('sic_read_glyph');n.call('result_test_idle')
        assert bytes(n.ram[0x3f00:0x3f08])==expected,delay
        assert n.lib.at_cart_control()==n.ram[0x061f]==0x66,delay
        assert n.get('result_active')==1
